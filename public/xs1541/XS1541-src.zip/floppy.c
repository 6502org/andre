//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Floppy Handler
// Funktion: to handle floppy commands for cmd parser
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <inttypes.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloca.h>

#include "ieee.h"
#include "iec.h"
#include "main.h"
#include "uart.h"
#include "ymodem.h"
#include "floppy.h"
#include "image.h"
#include "track.h"
#include "burst.h"









// CONST


// TOKEN



// STRUCTS


// STATICS
static uint8_t	nxtBlkDr = 0;
static uint8_t	nxtBlkTr = 0;
static uint8_t	nxtBlkSe = 0;




// GLOBALS



// EXTERNALS






//--------------------------
// SEND BUFFER TO FLOPPY
int8_t SendBuffer(char *arg, int16_t anz)
{
	while(anz--)
	{
		BsOut(*(arg++));
	}
	return 0;
}
//--------------------------
// SEND STRING TO FLOPPY
int8_t SendString(char *arg)
{
	while(*arg)
	{
		BsOut(*(arg++));
	}
	return 0;
}
//--------------------------
// SEND STRING TO FLOPPY (P)
int8_t SendString_P(char *arg)
{
	char	c;

	while((c = pgm_read_byte(arg)))
	{
		BsOut(c);
		arg++;
	}
	return 0;
}


//--------------------------
// DEVICE BUFFER INIT
int8_t DevbufInit(st_devbuf *db, uint16_t size, uint8_t ch, uint16_t min, uint16_t max)
{
	db->ch	= ch;				// channel
	db->min = min;				// minimal bytes to read 
	db->max	= max;				// maximum bytes to read 
	RingbInit(&db->rb, size);
	return 0;
}

//--------------------------
// DEVICE BUFFER INIT
int8_t DevbufRead(st_devbuf *db, st_DiskBuf *fl)
{
	uint8_t		*p;
	uint8_t		data, rc;
	uint16_t	free, anz;
	st_ringbuf	*rb;

	if(ST)
		return 1;

	rb = &db->rb;
	free = RingbBytesFree(rb);

	if(free >= db->min)
	{
		//uartPrintf_P(PSTR("RB free/size/cnt: %d/%d/%d"), free, rb->size, rb->cnt);
		//uartPutCrLf();

		anz = db->max > free ? free : db->max;

		//uartPrintf_P(PSTR("read bytes: %d"), anz);
		//uartPutCrLf();

		/*
		Talk(db->ch);
		while(anz--)
		{
			data = BasIn();
			if((rc = RingbWrite(rb, data)))
			{
			//	uartPrintf_P(PSTR("RingbWrite() rc=%d"), rc);
			//	uartPutCrLf();
			}
			if(ST)
			{
				//uartPrintf_P(PSTR("Status: %02x"), ST);
				//uartPutCrLf();
				break;
			}
		}
		UnTalk();
		*/


		//uartPrintf_P(PSTR(";blk %d"), cnt++);
		//uartPutCrLf();

		if(!LoadFile(fl))
		{
  			p	= fl->buf;
			anz = fl->anz;
			while(anz--)
			{
				data = *(p++);
				if((rc = RingbWrite(rb, data)))
				{
				//	uartPrintf_P(PSTR("RingbWrite() rc=%d"), rc);
				//	uartPutCrLf();
				}
			}
		}

		//uartPrintf_P(PSTR("anz=%d"), anz);
		//uartPutCrLf();
	}
	return 0;
}



//--------------------------
// DUMP HEX
int8_t DumpHex(char *buf, uint16_t anz)
{
	uint8_t	n = 0;
	char 	*s;

	while(anz > 0)
	{
		uartPutChar(':');
		s = buf;

		// HEX PART
		for(n = 0; n < 16; ++n, buf++)
		{
			if((uint16_t)n < anz)
				uartPrintf_P(PSTR("%02x"), *buf);
			else
				uartPutString_p("  ");
		}
		uartPutString_p("  ");

		// ASCII PART
		buf = s;
		for(n = 0; n < 16; ++n, buf++)
		{
			if((uint16_t)n < anz)
			{
				if((uint8_t)(*buf) < 32)
					uartPutChar('.');
				else
					uartPutChar(*buf);
			}
		}
		uartPutCrLf();


		if(anz >= 16)	anz -= 16; else anz = 0;
	}
	return 0;
}
//--------------------------
// DUMP HEX
int8_t DumpHexStr(char *buf)
{
	uint16_t anz;

	anz = strlen(buf);
	return DumpHex(buf, anz);
}
//--------------------------
// DUMP HEX
int8_t DumpHexStr_P(char *buf)
{
	char	buf2[256];

	strcpy_P(buf2, buf);
	return DumpHexStr(buf2);
}

//--------------------------
// READ BUFFER
int8_t ReadBuf(char *buf, uint16_t *len)
{
	uint16_t	cnt = 0;
	uint16_t	anz = *len;
	
	SetST(0);
	while(anz--)
	{
		*(buf++) = BasIn();
		cnt++;


		if(ST)
		{
	 		if(ST & ~ST_EOI)
			{
				cnt--;
			}
			break;
		}
		//buf++;
	}
	*len = cnt;
	return 0;
}




//--------------------------
// SEND COMMAND
int8_t SendCmd(char *arg)
{
	//UnListen();
	if(Listen(15)) 
		return 3;

	//DumpHexStr(arg);
	SendString(arg);
	UnListen();
	return 0;
}
//--------------------------
// SEND COMMAND (FLASH)
/*int8_t SendCmd_P2(char *arg)
{
	char	buf2[256];

	strcpy_P(buf2, arg);
	return SendCmd(buf2);
}*/

//--------------------------
// SEND COMMAND (FLASH)
int8_t SendCmd_P(char *arg)
{
	//UnListen();
	if(Listen(15)) 
		return 3;

	//DumpHexStr_P(arg);
	SendString_P(arg);
	UnListen();
	return 0;
}

//--------------------------
// SET BP TO FIRST BYTE
int8_t SendBP_5_0()
{
	return SendCmd_p("B-P 5 0");
}

//--------------------------
// ALLOCATE BUFFER
int8_t AllocBuffer(uint8_t ch)
{
	char	s[2];

	s[0] = '#';
	s[1] = 0;
	if(Open(ch, s))
		return 3;
	return 0;
}

//--------------------------
// FREE ALLOCATED BUFFER
int8_t FreeBuffer(uint8_t ch)
{
	return Close(ch);
}

//--------------------------
// BLOCK READ
int8_t SendBlockRead(uint8_t ch,uint8_t dr,uint8_t tr,uint8_t se)
{
	char	buf[21];

	sprintf_P(buf,PSTR("U1 %d %d %d %d"),ch,dr,tr,se);
	//uartPutLine(buf);
	return SendCmd(buf);
}

//--------------------------
// MEMORY READ
int8_t SendMemoryRead(uint16_t adr,uint8_t anz)
{
	char	buf[21];

	strcpy_P(buf,PSTR("M-R"));
	buf[3] = adr & 0xff;
	buf[4] = adr >> 8;
	buf[5] = anz;
	//buf[6] = 0;

	if(Listen(15)) 
		return 3;

	SendBuffer(buf, 6);
	UnListen();
	return 0;
}


//--------------------------
// MEMORY WRITE
int8_t SendMemoryWrite(uint16_t adr,uint8_t anz, uint8_t *data)
{
	char	buf[21];

	if(anz > 32)
		return 1;

	strcpy_P(buf,PSTR("M-W"));
	buf[3] = adr & 0xff;
	buf[4] = adr >> 8;
	buf[5] = anz;
	//buf[6] = 0;

	if(Listen(15)) 
		return 3;

	SendBuffer(buf, 6);
	SendBuffer((char*)data, anz);

	UnListen();
	return 0;
}


static int8_t	singleBlk = 0;

//-----------------------------
// READ BLOCK FROM FLOPPY (STD)
int8_t ReadBlockStdStart()
{
	//uartPutLine_p("START BLK-READ");

	if(AllocBuffer(5))
	{
		//uartPrintf_p("AllocBuf(5)",0);
		//uartPutCrLf();
		return -2;
	}
	if(PrintIfErrorCh_P(PSTR("#:")))
	{
		//uartPrintf_p("err AllocBuf(5)",0);
		//uartPutCrLf();
		return -1;
	}
	singleBlk = 2;
	return 0;
}

//-----------------------------
// READ BLOCK FROM FLOPPY (STD)
int8_t ReadBlockStdEnd()
{
	//uartPutLine_p("END BLK-READ");

	FreeBuffer(5);
	singleBlk = 0;
	return 0;
}

//-----------------------------
// READ BLOCK FROM FLOPPY (STD)
int8_t ReadBlockStd(char *buf, uint8_t dr,uint8_t tr,uint8_t se)
{
	int8_t 		rc, sb;	
	uint16_t	anz;

	if(tr < 1)
		return -10;

	// DEBUG
	//uartPrintf_P(PSTR("ReadBlockStd(%d, %d)"), tr, se);

	rc = -1;
	while(1)
	{
		if((sb = singleBlk) == 0)
			ReadBlockStdStart();

		if(SendBlockRead(5,dr,tr,se))
		{
			//uartPrintf_p("B-R",0);
			//uartPutCrLf();
			rc = -3;
			break;
		}

/*		if(PrintIfErrorCh_P(PSTR("B-R:")))
		//if((rc = ReadErrorCh(NULL, 0)))
		{
			//uartPrintf_p("R-B rc=%d",rc);
			//uartPutCrLf();
			rc = -3;
			break;
		}

		//_delay_ms(100);
		if(SendBP_5_0())
		{
			rc = -4;
			break;
		}
		//if(PrintIfErrorCh_P(PSTR("B-P:")))
		//	return 0;//break;
*/
		//_delay_ms(1);
		if(Talk(5)) 
		{
			rc = -5;
			break;
		}

		//uartPutString_P(PSTR("ReadBuf()"));

		anz = 256;
		if(!ReadBuf(buf, &anz))
		{
			if((ST & ~ST_EOI))
			{
				// PROBLEM?
				rc = -7;
			}
			else if(anz == 256)
				rc = 0;
		}
		break;
	}
	UnTalk();

	if(sb == 0)
		ReadBlockStdEnd();

	return rc;
}


//-----------------------------
// READ BLOCK FROM FLOPPY
int8_t ReadBlock(uint8_t *buf, uint8_t dr, uint8_t track, uint8_t sector, int8_t opt)
{
	st_DiskBuf	db;

	switch(opt)
	{
	  case TP_BURST:
		db.curDr 	= dr;
		db.curTr 	= track;
		db.curSe 	= sector;
		db.curSeCnt	= 1;
		db.buf		= buf;
		return BurstRead(&db, track);
		
	  default:
		return ReadBlockStd((char*)(buf), dr, track, sector);
	}
}


//--------------------------------------
// READ BLOCK FROM FLOPPY (DEFAULT MODE)
int8_t ReadBlockDef(uint8_t *buf, uint8_t dr, uint8_t track, uint8_t sector)
{
	return ReadBlock(buf,dr,track,sector,BurstDefault());
}


//-----------------------------
// READ BLOCKS FROM FLOPPY
int8_t ReadBlocksNxt(st_DiskBuf *buf)
{
	if(buf->curSeCnt == 0)
		return 1;

	buf->curSe++;
	buf->curSeCnt--;
	switch(buf->opt)
	{
	  case TP_BURST:
		return BurstHandler(buf);

	  default:
		return  ReadBlockStd((char*)(buf->buf), buf->curDr, buf->curTr, buf->curSe);
	}
}


//-----------------------------
// READ BLOCKS FROM FLOPPY
int8_t ReadBlocks(st_DiskBuf *buf, uint8_t dr, uint8_t track, uint8_t sector, uint8_t sectors, uint8_t ntrk, uint8_t opt)
{
	buf->curDr 	= dr;
	buf->curTr 	= track;
	buf->curSe 	= sector;
	buf->curSeCnt= sectors;
	switch(opt)
	{
	  case TP_BURST:
		return BurstRead(buf, ntrk);
		break;
	  default:
		buf->opt	= TP_SLOW;
		return  ReadBlockStd((char*)buf->buf, dr, track, sector);
		break;
	}
}

//---------------------------------------
// READ BLOCKS FROM FLOPPY (DEFAULT MODE)
int8_t ReadBlocksDef(st_DiskBuf *buf, uint8_t dr, uint8_t track, uint8_t sector, uint8_t sectors, uint8_t ntrk)
{
	return ReadBlocks(buf, dr, track, sector, sectors, ntrk, BurstDefault());
}



//--------------------------
// DUMP BLOCK FROM FLOPPY
int8_t DumpBlock(uint8_t dr, uint8_t tr, uint8_t se, uint8_t anz, int8_t opt)
{
	int8_t 		rc;	
	uint8_t		blk[256];			// block buffer
	st_DiskBuf	buf;

	buf.buf = blk;

	//if(opt < 0)
	//	opt = BurstDefault();

	if(anz == 0)	anz = 1;

	uartPrintf_P(PSTR("B-R: dr=%d, tr=%d, se=%d, anz=%d"), dr,tr,se,anz);
	if(opt == TP_BURST) 
		uartPutString_p(" - burst");
	uartPutCrLf();

	//if(ReadBlock(&buf, dr, tr, se, opt) == 0)
	rc = ReadBlocks(&buf, dr, tr, se, anz, tr, opt);

	while(1)
	{
		if(!rc)
		{
			uartPrintf_P(PSTR(";BLK %d %d"),buf.curTr,buf.curSe);
			uartPutCrLf();

			nxtBlkDr = dr;
			nxtBlkTr = buf.buf[0];
			nxtBlkSe = buf.buf[1];
			DumpHex((char*)buf.buf, 256);
			
			if((--anz) == 0)
				break;
		}
		else
		{
			uartPutLine_p(";aborted");
			PrintIfErrorCh_P(PSTR("B-R:"));
			rc = 99;
			break;
		}
		rc = ReadBlocksNxt(&buf);
	}
	return rc;
}

//--------------------------
// DUMP BLOCK FROM FLOPPY
int8_t DumpNxtBlock()
{
	if(nxtBlkTr == 0) 
	{
		uartPutLine_p("*last block");
		return 0;
	}
	return DumpBlock(nxtBlkDr,nxtBlkTr,nxtBlkSe, 1, -1);
}


//--------------------------
// DUMP TRACK FROM FLOPPY
int8_t DumpTrack(uint8_t dr,uint8_t tr,uint8_t il, int8_t burstopt)
{
	st_blkbuf	*blkbuf;
	st_blk		*blk;
	st_dimage	di;
	int8_t		ft, rc;
	uint8_t		anz;
	uint16_t	free, size, a, b;

	uartPrintf_P(PSTR("Track: dr=%d, tr=%d, il=%d"), dr,tr,il);
	if(burstopt == TP_BURST) 
		uartPutString_p(" - burst");
	uartPutCrLf();

	a 	= BlkBufSize(0);
	b 	= BlkBufSize(1);
	free= BytesFree();
	anz	= (free - 200 - a) / (b - a);

	size = BlkBufSize(anz);
	uartPrintf_P(PSTR("free=%d, anz=%d, size=%d"), free, anz, size);
	uartPutCrLf();

	if(anz < 2)				// 2*Xmodem buf,Ringbuffer,Loadbu,Min
	{
		// MEMORY ERROR
		return 7;
	}
	blkbuf = alloca(size);

	ft = GetDefImageType();
	if(DimgInit(&di, dr, ft, burstopt))
		return 99;

	DimgReadTrackInit(&di, blkbuf, anz, dr, tr, il);

	ReadBlockStdStart();
	while(1)
	{
		rc = DimgReadTrack(blkbuf);
		if(rc == 1 || rc < 0)
			break;

		rc = DimgReadBlkbuf(blkbuf, &blk, -1);
		if(rc == 99)
			break;

		if(rc == 0)
		{
			rc = DimgFreeBlkbuf(blkbuf, blk);
		}
	}
	ReadBlockStdEnd();

	uartPutCrLf();
	return 0;
}


//---------------------------
// PREPARE FILE DOWNLOAD
int8_t LoadFileInit(st_DiskBuf *o, char *s, int8_t option)
{
	o->opt	= option;

	if(option == TP_BURST)
	{
		InitBurst();
		return(BurstFastload(o, s));
	}

	if(Open(0, s))
		return 3;

	if(Talk(0)) 
		return 3;

	o->stat = 0;
	return 0;
}


//---------------------------
// FAST FILE DOWNLOAD BLOCK
int8_t LoadFile(st_DiskBuf *o)
{
	uint16_t	anz;

	if(o->opt == TP_BURST)
	{
		return(BurstHandler(o));
	}

	anz = 254;
	if(ReadBuf((char*)o->buf, &anz))
		return -1;

	if(ST)
	{
		// PROBLEM, EOI
		UnTalk();
		Close(0);
	}

	o->anz	= anz;
	return 0;
}



//--------------------------
// DUMP FILE FROM FLOPPY
int8_t DumpFile(char *arg, int8_t option)
{
	st_DiskBuf	fl;
	char		*s;
	uint16_t	cnt = 1;
	uint8_t		blk[256];			// block buffer

	fl.buf = blk;

	s = arg;
	if(*s == 0)
		return 3;

	//uartPrintf_p("open: <%s>", s);
	//uartPutCrLf();

	if(LoadFileInit(&fl, s, option))
			return 3;

	do
	{
		uartPrintf_P(PSTR(";blk %d"), cnt++);
		uartPutCrLf();

		if(!LoadFile(&fl))
		{
  			DumpHex((char*)fl.buf, fl.anz);
		}
	} while(ST == 0);

	if(ST & ~ST_EOI)
	{
		// PROBLEM?
		uartPutLine_p(";aborted");
		return 3;
	}

	uartPutLine_p(";end");
	return 99;
}


//--------------------------
// SEND FILE HEADER
int8_t SendFileHeader(st_xmbuf	*xb, uint8_t ft, char *filenam)
{
	uint8_t	size;
	char	buf[128], *s;

  	uartPutString_p("sending ");
  	memset(buf, 0, sizeof(buf));
	switch(ft)
	{
	  case FT_T64:
	  	uartPutString_p("T64");
		break;

	  case FT_PRG:
	  	uartPutString_p("PRG");
		break;

	  case FT_P00:
	  default:
	  	uartPutString_p("P00");
	  	strcpy_P(buf, PSTR("C64File"));
	  	strncpy(buf +8, filenam, 16);
		size = 26;
		break;
	}
  	uartPutLine_p(" file ...");

	s = buf;
	while(size--)
	{
		XmWrite(xb, *(s++));
	}

	// WAIT FOR START 
/*	while(xb->eot == 0)
	{
		XmLoop(xb);
		if(xb->packetno)
			break;
	}*/
	return 0;
}


//--------------------------
// DOWNLOAD FILE FROM FLOPPY
int8_t DownloadFile(char *arg, int8_t ft, int8_t option)
{
	//char		buf[256];
	st_DiskBuf	fl;
	char		*s;
	st_ringbuf 	*rb;
	st_devbuf	*db;
	st_xmbuf	*xb;
	//int16_t		data = -1;
	uint16_t	anz;
	//uint16_t	cnt;
	uint8_t		blk[256];			// block buffer


	fl.buf = blk;

	s = arg;
	if(*s == 0)
		return 3;

	//uartPrintf_p("open: <%s>", s);
	//uartPutCrLf();
	if((anz = BytesFree()) < 128 +128 +550 +256 +100)	// 2*Xmodem buf,Ringbuffer,Loadbu,Min
	{
		// MEMORY ERROR
		return 7;
	}

	if(LoadFileInit(&fl, s, option))
			return 3;

	db = alloca(SIZE_DEVBUF + SIZE_DEVRING);
	rb = &db->rb;
	DevbufInit(db, SIZE_DEVRING, 0, 128, 254);

	xb = alloca(SIZE_XMBUF);
	XmPrepareTx(xb);
	XmSetHeader(xb, s, 0, NULL);
	SendFileHeader(xb, ft, s);

    //Talk(0);

	SetST(0);

	//cnt = 0;
	while(xb->eot == 0)
	{
		if(DevbufRead(db, &fl))
			break;

		XmWriteRB(xb, rb);
	}
	Close(0);

	while(xb->eot < 2)
	{
		XmWriteEot(xb, rb);
	}

	uartPutCrLf();
	switch(xb->eot)
	{
	  case 2:
		uartPutLine_p("xmodem transmission ok.");
		break;

	  default:
		uartPutLine_p("?xmodem transmission error.");
		break;
	}

	if(ST & ~ST_EOI)
	{
		// PROBLEM?
		uartPutLine_p("?file read error");
		return 3;
	}
	return 99;
}

//--------------------------
// DUMP MEMORY FROM FLOPPY
int8_t DumpMem(uint16_t adr, uint16_t len)
{
	char		buf[256];
	uint16_t	anz,anz2;
	uint16_t	cnt = 1;

	while(len)
	{
		anz = (len > 256) ? 256 : len;
		SendMemoryRead(adr, (uint8_t)(anz -1));

		uartPrintf_P(PSTR(";memblk %d, adr %04x, cnt %02x"), cnt++, adr, anz);
		uartPutCrLf();

		if(Talk(15)) 
			return 3;

		anz2 = sizeof(buf);
		if(!ReadBuf(buf, &anz2))
		{
  			DumpHex(buf, anz2);
		}
		UnTalk();

		if(anz2 != anz)
		{
			uartPrintf_P(PSTR(";read %02x"), anz2);
			uartPutCrLf();
		}

		if(ST & ~ST_EOI)
			break;

		adr += anz;
		len -= anz;
	}

	if(ST & ~ST_EOI)
	{
		// PROBLEM?
		uartPutLine_p(";aborted");
		return 3;
	}

	uartPutLine_p(";end");
	return 99;
}

//--------------------------
// LIST DIRECTORY
int8_t Catalog(char *arg)
{
	uint8_t	by, lb, hb;

//uartPutString_p("Open: ");
//uartPutLine(arg);


	if(Open(0, arg))
		return 3;

	if(Talk(0)) 
		return 3;

	do {
		SetST(0);
		BasIn();
	} while(ST == IEC_ST_RDTO);

	BasIn();

	by = 0;
	while(ST == 0)
	{
		if(by == 0)
		{
			BasIn();
			BasIn();
			lb = BasIn();
			hb = BasIn();
			if (ST)
				break;
			uartPrintf_P(PSTR("%d "), ((uint16_t)hb << 8) + lb);
		}
		by = BasIn();
		if(by == 0)	
		{
			uartPutCrLf();
		}
		else
		{
			uartPutChar(by);
		}
	}
	UnTalk();
	Close(0);

	if(ST & ~ST_EOI)
	{
		return 3;
	}
	return 99;
}

//--------------------------
// READ ERROR CHANNEL
int8_t ReadErrorCh(char *buf, uint8_t len)
{
	char	hbuf[41];
	int8_t	rc, c;
	char	*s;

	if (len < 2 || buf == NULL)
	{
		buf = hbuf;
		len = sizeof(hbuf);
	}
	s = buf;

	UnTalk();
	if(Talk(15)) 
		return -3;

	SetST(0);
	rc = 0;
	while(len)
	{
		c = BasIn();
		if(ST & ~ST_EOI)
		{
			break;
		}

		if(rc++ == 0)
		{
			if(ST)
			{
				SetST(0);
				continue;
			}
		}

		len--;
		*(s++) = c;
		if(ST)
			break;
	}
	if (len == 0)	s--;
	*s = 0;

	if(isdigit(*buf) && isdigit(*(buf+1)))
	{
		rc = (*buf & 0xf) * 10 + (*(buf+1) & 0xf);
	}
	else	rc = -1;

	UnTalk();
	return rc;
}

//--------------------------
// PRINT ERROR CHANNEL
int8_t PrintErrorCh()
{
	int8_t 	rc;
	char	buf[81];

	if((rc=ReadErrorCh(buf, sizeof(buf))) >= 0)
	{
		uartPutLine(buf);
	}
	else
	{
		uartPrintf_p("rc=%d", rc);
		uartPutCrLf();
		if (rc == -1)
			uartPutLine(buf);
	}
	return 99;
}

//--------------------------
// PRINT IF ERROR
int8_t PrintIfErrorCh_P(char *txt)
{
	int8_t	rc;
	char	buf[81];

	if((rc = ReadErrorCh(buf, sizeof(buf))) != 0)
	{
		if(txt != NULL)
		{
			uartPutString_P(txt);
			uartPutChar(' ');
		}
		uartPutLine(buf);
	}
	return rc;
}

//---------------------------------------------------------------------------
