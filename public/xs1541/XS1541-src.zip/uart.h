//-------------------------------------------------------------------------
// Titel:	 XS-1541 - RS232 Communication
// Funktion: handle UART Communication over 2 ring buffer and block buffer
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#ifndef UART_H
#define UART_H





// CONST
#define 	COMBUF_SIZE_TX		32
#define 	COMBUF_SIZE_RX		32

#define 	BAUD 	115200
//#define 	BAUD 	57600
//#define 	BAUD 	38400
//#define 	BAUD 	19200

//#define 	true 			1
//#define 	false 			0


#define uartPutLine_p(__s) 		uartPutLine_P(PSTR(__s))
#define uartPutString_p(__s) 	uartPutString_P(PSTR(__s))
#define uartPrintf_p(__s,p)		uartPrintf_P(PSTR(__s),p) 






#define RingbBytesInBuf(rb)		((rb)->cnt)
#define RingbBytesFree(rb)		((rb)->size - (rb)->cnt)






// STRUCTS
typedef struct 
{
	volatile uint16_t	wp;				// write idx
	volatile uint16_t	rp;				// read idx
	volatile uint16_t	cnt;			// bytes in buffer
	uint16_t			size;			// buffer size 
	uint8_t	buf[0];
} st_ringbuf;

typedef struct 
{
	uint16_t			size;			// buffer size 
	volatile uint16_t	idx;			// read/write idx
	volatile uint8_t	stat;			// 0=free, 1=locked wrt, 2=full, 3=locked rd, 4=sent
										// 16=EOT
	uint8_t				*pt;
} st_buf;



void RingbInit(st_ringbuf *rb, uint16_t);
int8_t RingbWrite(st_ringbuf *rb, char d);
int16_t RingbRead(st_ringbuf *rb);
//uint16_t RingbBytesInBuf(st_ringbuf *rb);
//uint16_t RingbBytesFree(st_ringbuf *rb);

void XbufInit(st_buf *xb, uint8_t *buf, uint16_t size);
int8_t XbufWrite(st_buf *xb, uint8_t);
int8_t XbufSend(st_buf *buf);


char uartGetChar(void);
int16_t uartGetCharTo(uint16_t to);
int16_t uartBytesInBuf();

void uartPutFlush(void);
void uartPutChar(char data);
void uartPutLine(char *buffer);
void uartPutString(char *buffer);
void uartPrintf(const char *format, ...);
void uartPutLine_P(char *buffer);
void uartPutString_P(char *buffer);
void uartPrintf_P(const char *format, ...);
void uartPutCrLf(void);
void initUart();


#endif
