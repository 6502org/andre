//-------------------------------------------------------------------------
// Titel:	 XS-1541 - FLOPPY Micocode Code (6502 assembler)
// Funktion: upload/start microcode
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#ifndef MICROCODE_H
#define MICROCODE_H






// STRUCTS
/*
typedef struct 
{
	uint8_t			stat;				// status: 0=free, 1=filling, 2=alloc, 3=sending
} st_mc;
*/


//ENUMS
enum microcode {MC_FLASH,MC_MORSE,MC_RPM,
				MC_PP,MC_S1,MC_S2,MC_S2_1581,MC_BURST1571,MC_BURST1581,
				MC_WARPRD1541,MC_TURBORD1541,
				MC_WARPRD1571,MC_TURBORD1571,
				MC_TURBORD1581,
				MC_TEST
		   	   };




// PROTOTYPES
int8_t McUpload(uint16_t adr, uint8_t *buf, uint16_t anz);
int8_t McUpload_P(uint16_t adr, uint8_t *pbuf, uint16_t anz);

int8_t McUploadFlash(void);
int8_t McUploadMorse(void);
int8_t McUploadRPM(void);



int8_t McUploadTurboRd(int8_t lwTyp);
int8_t McUploadWarpRd(int8_t lwTyp);
int8_t McUploadTest(int8_t lwTyp);




//int8_t McWarpReadPrepare(uint8_t typ);
//int8_t McWarpReadTrack(uint8_t tr, uint8_t cnt);
//int8_t McWarpReadBlk(uint8_t *se, uint8_t *buf);

//int8_t McTestWarpRd(void);

#endif

