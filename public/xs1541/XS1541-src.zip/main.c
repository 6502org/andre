//-------------------------------------------------------------------------
// Titel:	 XS-1541 Adapter
// Funktion: Adapter to connect IEEE-488, IEC and RS232
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// Prozessor : 	ATmega644
// Takt : 		14745600 Hz
// Datum : 		11.6.2008
// Version : 	in config.h
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <inttypes.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloca.h>

#include "config.h"
#include "compat.h"
#include "timer.h"
#include "main.h"
#include "uart.h"
#include "xmodem.h"
#include "ieee.h"
#include "iec.h"
#include "floppy.h"
#include "burst.h"
#include "parallel.h"
#include "image.h"
#include "microcode.h"
#include "transfer.h"










int xmodem_send_test(void);
int	xmodem_receive_test(void);

// CONST



// TOKEN
static prog_char CmdsS01[] = "ieEe";
static prog_char CmdsS02[] = "iec";
static prog_char CmdsS03[] = "#";
static prog_char CmdsS04[] = "deVice";
static prog_char CmdsS05a[] = "sp";
static prog_char CmdsS05b[] = "seTpin";
static prog_char CmdsS06a[] = "sd";
static prog_char CmdsS06b[] = "setData";
static prog_char CmdsS07[] = "rp";
static prog_char CmdsS08[] = "resetPin";
static prog_char CmdsS09[] = "lp";
static prog_char CmdsS10[] = "listPins";
static prog_char CmdsS11[] = "Help";
static prog_char CmdsS12[] = "@";
static prog_char CmdsS13[] = "$";
static prog_char CmdsS14[] = "cAtalog";
static prog_char CmdsS15[] = "diRectory";
static prog_char CmdsS16[] = "dumpFile";
static prog_char CmdsS17[] = "df";
static prog_char CmdsS18[] = "dumpMemory";
static prog_char CmdsS19[] = "dm";
static prog_char CmdsS20[] = "dumpBlock";
static prog_char CmdsS21[] = "db";
static prog_char CmdsS20a[] = "dumpNextBlock";
static prog_char CmdsS21a[] = "dn";
static prog_char CmdsS22[] = "lIsten";
static prog_char CmdsS23[] = "tAlk";
static prog_char CmdsS24[] = "unTalk";
static prog_char CmdsS25[] = "unListen";
static prog_char CmdsS26[] = "oPen";
static prog_char CmdsS27[] = "cLose";
static prog_char CmdsS28[] = "bSout";
static prog_char CmdsS29[] = "bAsin";
static prog_char CmdsS30[] = "st";
static prog_char CmdsS30a[] = "bst";
static prog_char CmdsS31[] = "dOwnload";
static prog_char CmdsS31a[] = "lOad";
static prog_char CmdsS32[] = "dl";
static prog_char CmdsS33[] = "uPload";
static prog_char CmdsS33a[] = "sAve";
static prog_char CmdsS34[] = "ul";
static prog_char CmdsS35[] = "listFiletypes";
static prog_char CmdsS36[] = "lft";
static prog_char CmdsS37[] = "listBam";
static prog_char CmdsS38[] = "lb";
static prog_char CmdsS39[] = "backup";
static prog_char CmdsS40[] = "bu";
static prog_char CmdsS41a[] = "burstCmd";
static prog_char CmdsS41b[] = "bc";
static prog_char CmdsS42a[] = "dumpTrack";
static prog_char CmdsS42b[] = "dt";
static prog_char CmdsS42c[] = "dumpDisk";
static prog_char CmdsS42d[] = "dd";
static prog_char CmdsS43[] = "cOnfig";
static prog_char CmdsS44a[] = "loadMc";
static prog_char CmdsS44b[] = "lMc";
static prog_char CmdsS45[] = "reSet";
static char *Cmds[] PROGMEM = {
				CmdsS01,CmdsS02,CmdsS03,CmdsS04,CmdsS05a,CmdsS05b,CmdsS06a,CmdsS06b,
				CmdsS07,CmdsS08,CmdsS09,CmdsS10,
				CmdsS11,CmdsS12,CmdsS13,CmdsS14,CmdsS15,CmdsS16,CmdsS17,CmdsS18,CmdsS19,CmdsS20,
				CmdsS21,CmdsS20a,CmdsS21a,CmdsS42a,CmdsS42b,CmdsS42c,CmdsS42d,
				CmdsS22,CmdsS23,CmdsS24,CmdsS25,CmdsS26,CmdsS27,CmdsS28,CmdsS29,
				CmdsS30,CmdsS30a,
				CmdsS31,CmdsS31a,CmdsS32,CmdsS33,CmdsS33a,CmdsS34,CmdsS35,CmdsS36,
				CmdsS37,CmdsS38,CmdsS39,CmdsS40,CmdsS41a,CmdsS41b,
				CmdsS43,CmdsS44a,CmdsS44b,CmdsS45,
				NULL};
static int8_t CmdsId[]  PROGMEM  = {T_IEEE,T_IEC,T_DEV,T_DEV,T_SP,T_SP,T_SD,T_SD,
					  T_RP,T_RP,T_LP,T_LP,
					  T_HLP,T_CMD,T_CAT,T_CAT,T_CAT,
					  T_DUMPFILE,T_DUMPFILE,T_DUMPMEM,T_DUMPMEM,T_DUMPBLK,T_DUMPBLK,
					  T_DUMPNXTBLK,T_DUMPNXTBLK,T_DUMPTRACK,T_DUMPTRACK,T_DUMPDISK,T_DUMPDISK,
					  T_LISTEN,T_TALK,T_UNTALK,T_UNLISTEN,T_OPEN,T_CLOSE,T_BSOUT,T_BASIN,
					  T_ST,T_BST,
					  T_DOWNLOAD,T_DOWNLOAD,T_DOWNLOAD,T_UPLOAD,T_UPLOAD,T_UPLOAD,T_LISTFT,T_LISTFT,
					  T_LISTBAM,T_LISTBAM,T_BACKUP,T_BACKUP,T_INQUIRE,T_INQUIRE,
					  T_CONFIG,T_LOADMC,T_LOADMC,T_RESET
					 };


//enum tokenPar {TP_ALL,TP_BAM,TP_D0,TP_D1,TP_BURST,TP_PARALLEL
static prog_char CmdParS01a[] = "all";
static prog_char CmdParS01b[] = "bam";
static prog_char CmdParS01c[] = "gcr";
static prog_char CmdParS02a[] = "d0";
static prog_char CmdParS02b[] = "d1";
static prog_char CmdParS02g[] = "u8";
static prog_char CmdParS02h[] = "u9";
static prog_char CmdParS02i[] = "u10";
static prog_char CmdParS02j[] = "u11";
static prog_char CmdParS03a1[] = "slOw";
static prog_char CmdParS03a2[] = "std";
static prog_char CmdParS03b[] = "buRst";
static prog_char CmdParS03c[] = "paRallel";
static prog_char CmdParS03d1[] = "serial1";
static prog_char CmdParS03d2[] = "s1";
static prog_char CmdParS03e1[] = "serial2";
static prog_char CmdParS03e2[] = "s2";
static prog_char CmdParS03e3[] = "serial3";
static prog_char CmdParS03e4[] = "s3";
static prog_char CmdParS03f[] = "waRp";
static prog_char CmdParS03g[] = "tuRbo";
static prog_char CmdParS03h1[] = "burstLoad";
static prog_char CmdParS03h2[] = "bl";
static prog_char CmdParS04a[] = "led";
static prog_char CmdParS04b[] = "echo";
static prog_char CmdParS05a[] = "noDump";
static prog_char CmdParS05b[] = "dumpHex";
static prog_char CmdParS05c[] = "dumpBin";
static prog_char CmdParS06a[] = "interLeave";
static prog_char CmdParS06b[] = "il";
static char *Cmdp[] PROGMEM = {CmdParS01a,CmdParS01b,CmdParS01c,
							CmdParS02a,CmdParS02b,
							CmdParS02g,CmdParS02h,CmdParS02i,CmdParS02j,
							CmdParS03a1,CmdParS03a2,CmdParS03b,CmdParS03c,
							CmdParS03d1,CmdParS03d2,
							CmdParS03e1,CmdParS03e2,CmdParS03e3,CmdParS03e4,
							CmdParS03f,CmdParS03g,CmdParS03h1,CmdParS03h2,
							CmdParS04a,CmdParS04b,
							CmdParS05a,CmdParS05b,CmdParS05c,
							CmdParS06a,CmdParS06b,
							NULL};
static int8_t CmdpId[]  PROGMEM  = {TP_ALL,TP_BAM,TP_GCR,
							TP_D0,TP_D1,
							TP_U8,TP_U9,TP_U10,TP_U11,
							TP_SLOW,TP_SLOW,TP_BURST,TP_PARALLEL,
							TP_S1,TP_S1,
							TP_S2,TP_S2,TP_S3,TP_S3,
							TP_WARP,TP_TURBO,TP_BURSTLOAD,TP_BURSTLOAD,
							TP_LED,TP_ECHO,
							TP_NODUMP,TP_DUMPHEX,TP_DUMPBIN,
							TP_INTERLEAVE,TP_INTERLEAVE
					 		};



enum ieee_pins { ATN, DAV, EOI, NRFD, NDAC, 		// IEEE
				DATA, CLK, RST, SRQ };				// IEC
static prog_char IeeePinsS01[] = "Atn";
static prog_char IeeePinsS02[] = "Dav";
static prog_char IeeePinsS03[] = "Eoi";
static prog_char IeeePinsS04[] = "nRfd";
static prog_char IeeePinsS05[] = "nDac";
static char *IeeePins[] PROGMEM = {IeeePinsS01,IeeePinsS02,IeeePinsS03,IeeePinsS04,IeeePinsS05,NULL};
static int8_t IeeePinsId[] PROGMEM = {ATN, DAV, EOI, NRFD, NDAC};

static prog_char IecPinsS01[] = "Atn";
static prog_char IecPinsS02[] = "Data";
static prog_char IecPinsS03[] = "Clk";
static prog_char IecPinsS04[] = "Rst";
static prog_char IecPinsS05[] = "Srq";
static char *IecPins[] PROGMEM = {IecPinsS01,IecPinsS02,IecPinsS03,IecPinsS04,IecPinsS05,NULL};
static int8_t IecPinsId[] PROGMEM = {ATN, DATA, CLK, RST, SRQ};



static prog_char mcTokS01[] = "flash";
static prog_char mcTokS02[] = "morse";
static prog_char mcTokS03[] = "rpm";
static prog_char mcTokS04a[] = "pp1541";
static prog_char mcTokS05a[] = "rdWarp1541";
static prog_char mcTokS06a[] = "rdTurbo1541";
static prog_char mcTokS90[] = "test";
static char *mcTok[] PROGMEM = {mcTokS01,mcTokS02,mcTokS03,
								//mcTokS04a,mcTokS05a,mcTokS06a,
								mcTokS90,
								NULL};
static int8_t mcId[] PROGMEM = {MC_FLASH,MC_MORSE,MC_RPM,
								//MC_PP1541,MC_WARPRD1541,MC_TURBORD1541
 								MC_TEST
							   };




//enum filetypes {FT_P00,FT_T64,FT_PRG,FT_D64,FT_D71,FT_D80,FT_D81,FT_D82,FT_X64,FT_G64,
//				FT_D64_40, FT_D64_42, FT_D64X, FT_D64_40X, FT_D64_42X
//		   	   };
static prog_char filtypS01[] = "p00";
static prog_char filtypS02[] = "t64";
static prog_char filtypS03[] = "prg";
static prog_char filtypS04[] = "d64";
static prog_char filtypS04a[] = "d64-40";
static prog_char filtypS04b[] = "d64-42";
static prog_char filtypS04c[] = "d64x";
static prog_char filtypS04d[] = "d64-40x";
static prog_char filtypS04e[] = "d64-42x";
static prog_char filtypS05[] = "d71";
static prog_char filtypS06[] = "d80";
static prog_char filtypS07[] = "d81";
static prog_char filtypS08[] = "d82";
static prog_char filtypS09[] = "x64";
static prog_char filtypS10[] = "g64";
static prog_char filtypS20[] = "img";
static char *FilTyp[] PROGMEM = {filtypS01,filtypS02,filtypS03,filtypS04,
			filtypS04a,filtypS04b,filtypS04c,filtypS04d,filtypS04e,
			filtypS05,filtypS06,filtypS07,filtypS08,filtypS09,filtypS10,
			filtypS20,NULL};
static int8_t FilTypId[] PROGMEM = {FT_P00,FT_T64,FT_PRG,FT_D64,
			FT_D64_40, FT_D64_42, FT_D64X, FT_D64_40X, FT_D64_42X,
			FT_D71,FT_D80,FT_D81,FT_D82,FT_X64,FT_G64,FT_IMG
			};


//enum devtypes {DT_1541,DT_1571,DT_1581,DT_2030,DT_4040,DT_8050,DT_8250,
//		   	   DT_DEFAULT};
static prog_char devtypS01[] = "1541";
static prog_char devtypS02[] = "1571";
static prog_char devtypS03[] = "1581";
static prog_char devtypS04[] = "2030";
static prog_char devtypS05[] = "4040";
static prog_char devtypS06[] = "8050";
static prog_char devtypS07[] = "8250";
static char *DevTyp[] PROGMEM = {devtypS01,devtypS02,
			devtypS03,devtypS04,devtypS05,devtypS06,devtypS07,
			NULL};
static int8_t DevTypId[] PROGMEM = {DT_1541,DT_1571,DT_1581,DT_2030,DT_4040,DT_8050,DT_8250
			};
 


//enum xs1541_tok {XT_CMDS,XT_PAR1,XT_FILETYPE,XT_DEVTYPE,XT_IECPINS,XT_IEEPINS
//   	   };
static void *xs1541_Tok[] PROGMEM = {Cmds,CmdsId,Cmdp,CmdpId,
			FilTyp,FilTypId,DevTyp,DevTypId,IecPins,IecPinsId,IeeePins,IeeePinsId,
			NULL};
static int8_t xs1541_Id[] PROGMEM = {
			XT_CMDS,XT_PAR1,XT_FILETYPE,XT_DEVTYPE,XT_IECPINS,XT_IEEPINS
			};





// STRUCTS
st_config	conf;


// STATICS





// GLOBALS
uint8_t	fDevice;								// 0=IEEE, 1=IEC
//uint8_t iec_device = 8;						// current device#


// EXTERNALS
extern uint8_t		rcvBcr;				// CR flag




//EMPTY_INTERRUPT(__vector_default);	// Leere Interrupts ignorieren





//----------------------------------------------------------------------
// IGNORE WHITE SPACE
void GetSpace(char **lin)
{
	if(*lin != NULL)
		while(isspace(**lin))	
			(*lin)++;
}

//----------------------------------------------------------------------
// TOKENIZE STRING
int8_t Tokenize(char **cmd, char **token, int8_t *tokenId)
{
	char	*cp, c;
	char	*s;
	int8_t	i, flg;

	/*uartPrintf_p("token: %04x", token);
	uartPutCrLf();
	uartPrintf_p("token ID: %04x", tokenId);
	uartPutCrLf();*/
//(const char*)( pgm_read_word(

	flg = 0;
	for(i=0; (cp=(char*)pgm_read_word(&token[i])) != NULL; ++i)
	{
		s = *cmd;

		//uartPutString_p("src=");
		//uartPutLine(s);

		while (1)
		{
			if((c = pgm_read_byte(cp)) == 0)
				flg = 1;

			//uartPutChar(c);

			if(*s == 0 || isspace(*s))
				break;

			if(isupper(c))
			{
				// REST OPIONAL
				c = tolower(c);
				flg = 1;
			}
			if(tolower(*s) != c)
			{
				flg = 0;
				break;
			}
			cp++;
			s++;
		}
		if (flg)
		{
			*cmd = s;
			return pgm_read_byte(&tokenId[i]);
		}
	}
	return -1;
}

//----------------------------------------------------------------------
// GET TOKEN
static char inline **GetToken(int8_t tok)
{
	return (char **)pgm_read_word(&xs1541_Tok[tok*2]);
}
//----------------------------------------------------------------------
// GET TOKEN
static int8_t inline *GetTokenId(int8_t id)
{
	return (int8_t *)pgm_read_word(&xs1541_Tok[id*2 +1]);
}

//----------------------------------------------------------------------
// SEARCH TOKEN INDEX BY ID
int8_t SearchID(char **token, int8_t *tokenId, int8_t id)
{
	int8_t	i;

	for(i=0; (char*)pgm_read_word(&token[i]) != NULL; ++i)
	{
		if(id == pgm_read_byte(&tokenId[i]))
		{
			return i;
		}
	}
	return -1;
}

//----------------------------------------------------------------------
// SEARCH GROUP INDEX BY ID
int8_t SearchGroupID(int8_t group)
{
	int8_t	i;

	for(i=0; i < sizeof(xs1541_Id); ++i)
	{
		if(pgm_read_byte(&xs1541_Id[i]) == group)
		{
			return i;
		}
	}
	return -1;
}
			
//----------------------------------------------------------------------
// GET TOKEN
char *GetTokenString(int16_t token)
{
	int8_t	i;

	if((i = SearchGroupID((token >> 8) & 0xff)) >= 0)
	{
		char	**tok	= GetToken(i);
		int8_t	*id		= GetTokenId(i);
		int8_t	idx		= SearchID(tok, id, token & 0xff);

		if(idx >= 0)
			return (char *)(pgm_read_word(&tok[idx]));
	}
	return PSTR("?");
}

//----------------------------------------------------------------------
// TOKENIZE GROUP
int8_t TokenizeGrp(char **cmd, int8_t group)
{
	int8_t	i;

	if((i = SearchGroupID(group)) >= 0)
	{
		if(pgm_read_byte(&xs1541_Id[i]) == group)
		{
			return Tokenize(cmd, 
							GetToken(i),
							GetTokenId(i)
						   );
		}
	}
	return -1;
}

//----------------------------------------------------------------------
// TOKENIZE COMMAND 
int8_t TokenizeCmd(char **cmd)
{
	GetSpace(cmd);

	switch(**cmd)
	{
	  case '$':
	  	return T_CAT;

	  case '@':
		(*cmd)++;
	  	return T_CMD;

	  case '#':
		(*cmd)++;
	  	return T_DEV;

	  case 0:
	  	return T_BLANK;
	}
	return TokenizeGrp(cmd, XT_CMDS);
}

//----------------------------------------------------------------------
// Read Parameter from Cmd Buffer
int16_t ReadPar(char **cmd)
{
	
	int8_t	i, grp, tok;

	GetSpace(cmd);
	if(**cmd == 0)
	{
		//uartPutLine_p("fefe!");
		return 0xfefe;
	}

	for(i=0; i < sizeof(xs1541_Id); ++i)
	{
		grp = pgm_read_byte(&xs1541_Id[i]);
		/*uartPrintf_p("i=%d; ", i);
		uartPrintf_p("grp=%d; ", grp);
		uartPutCrLf();*/
		if((tok = TokenizeGrp(cmd, grp)) >= 0)
		{
			//uartPutLine_p("found!");
			return (grp << 8) | tok;
		}
	}
	//uartPutLine_p("not found!");
	return 0xffff;
}




//----------------------------------------------------------------------
// GET HEX VALUE
uint16_t GetHex(char **lin)
{
	uint16_t	ac = 0;
	uint8_t		c;

	while(isxdigit(**lin))
	{
		c = (**lin) & 0xf;
		if(isalpha(**lin))
			c += 9;
			
		ac *= 16;
		ac += c;
		(*lin)++;
	}
	return ac;
}
//----------------------------------------------------------------------
// GET DIGIT VALUE
uint16_t GetDigits(char **lin, int8_t base)
{
	uint16_t	ac = 0;

	while(isdigit(**lin))
	{
		ac *= base;
		ac += (**lin) & 0xf;
		(*lin)++;
	}
	return ac;
}
//----------------------------------------------------------------------
// GET NUMERIC ARGUMENT
int8_t GetArgNum(char **lin, uint16_t *by)
{
	uint8_t		flg = 1;
	uint16_t	ac = 0;

	GetSpace(lin);
	switch(**lin)
	{
	  case '0':
	  	(*lin)++;
	  	if(tolower(**lin) != 'x')
		{
			ac = GetDigits(lin, 8);
			flg = 0;
			break;
		}
	  case '$':
	  	(*lin)++;
	  	if(isxdigit(**lin))
		{
			ac = GetHex(lin);
			flg = 0;
		}
		break;

	  case '%':
	  	(*lin)++;
	  	if(isdigit(**lin))
		{
			ac = GetDigits(lin, 2);
			flg = 0;
		}
		break;


	  default:
	  	if(isdigit(**lin))
		{
			ac = GetDigits(lin, 10);
			flg = 0;
		}
		break;
	}
	if(!isspace(**lin) && **lin != 0)
	{
		flg = 1;
	}
	GetSpace(lin);

	*by = ac;
	return flg;
}
//----------------------------------------------------------------------
// GET WORD ARGUMENT
int8_t GetArgWord(char **lin, uint16_t *wo)
{
	if(GetArgNum(lin, wo))
	{
		uartPutLine_p("?word value expected!");
		return 1;
	}
	return 0;
}
//----------------------------------------------------------------------
// GET BYTE ARGUMENT
int8_t GetArgByte(char **lin, uint8_t *by)
{
	uint16_t	wo;

	if(GetArgNum(lin, &wo))
	{
		uartPutLine_p("?byte value expected!");
		return 1;
	}
	*by = (uint8_t)wo;
	return 0;
}

//----------------------------------------------------------------------
// GET STRING ARGUMENT
int8_t GetArgString(char **lin, char **s)
{
	char	delimiter = 0, c1, c2 = 1;
	uint8_t anz = 0;


	GetSpace(lin);
	c1 = **lin;

	switch(c1)
	{
	  case '"':
	  case '\'':
	  	delimiter = c1;
		break;
	  case '{':
	  	delimiter = '}';
		break;
	  default:
	  	delimiter = 0;
	}
	c2 = delimiter +1;
	*s = *lin;

	//if (delimiter != 0) 	++s;

	/*uartPrintf_p("Char: %c",**lin);
	uartPutCrLf();
	uartPrintf_p("Delimiter: %c",delimiter);
	uartPutCrLf();*/
	if(c1)
	{
		while(1)
		{
			(*lin)++;
			anz++;

			c1 = **lin;
			if (isspace(c1) || c1 == 0)
			{
				if (c2 == delimiter)
				{
					if(anz > 1)
					{
						anz -= 2;
						(*s)++;
					}
					break;
				}
				if (delimiter == 0 || c1 == 0)
					break;
			}

			c2 = c1;
		}
	}
	GetSpace(lin);

	if(anz == 0)
	{
		uartPutLine_p("?string value expected!");
		return 1;
	}

	*((*s) + anz) = 0;					// TERMINATE STRING 
	return 0;
}
//----------------------------------------------------------------------
// GET STRING ARGUMENT
int8_t GetArgString2(char **lin, char **s)
{
	GetSpace(lin);
	if(**lin == 0) 
		return 1;
	return GetArgString(lin, s);
}



//----------------------------------------------------------------------
// IEEE COMMAND
int8_t ListPin(char *pin, int8_t state, int8_t dir, int8_t pullup)
{
	char	c;

	while((c = pgm_read_byte(pin++)))
	{
		if(state) 	uartPutChar(toupper(c));
		else		uartPutChar(tolower(c));
	}

	if (dir)
		uartPutString_p("-o");
	else
		uartPutString_p("-i");

	if (pullup)
		uartPutString_p("-pu");
	else
		;//uartPutString_p("");

	uartPutChar(32);
	return 0;
}


//----------------------------------------------------------------------
// IEEE COMMAND
int8_t IeeeListPort(void)
{
	uartPutString_p("IEEE port: ");
	ListPin(PSTR("ATN"), IEEE_ATN, IEEE_ATN_D, IEEE_ATN_PU);
	ListPin(PSTR("EOI"), IEEE_EOI, IEEE_EOI_D, IEEE_EOI_PU);
	ListPin(PSTR("DAV"), IEEE_DAV, IEEE_DAV_D, IEEE_DAV_PU);
	ListPin(PSTR("NRFD"), IEEE_NRFD, IEEE_NRFD_D, IEEE_NRFD_PU);
	ListPin(PSTR("NDAC"), IEEE_NDAC, IEEE_NDAC_D, IEEE_NDAC_PU);

	uartPrintf_P(PSTR("  Data: i%02x, o%02x"), IEEE_D_PIN, IEEE_D_PORT);
	if (IEEE_D_DDR)
		uartPutLine_p(" -out");
	else
		uartPutLine_p(" -in");

	return 99;
}

//--------------------------
// IEEE COMMAND
int8_t IeeeSetPort(char *arg, int8_t state)
{
	int8_t	pin;

	pin = TokenizeGrp(&arg, XT_IEEPINS);
	switch(pin)
	{
	  case ATN:
		IeeeAtn(state);
		break;

	  case DAV:
		IeeeDav(state);
		break;

	  case EOI:
		IeeeEoi(state);
		break;

	  case NRFD:
		IeeeNrfd(state);
		break;

	  case NDAC:
		IeeeNdac(state);
		break;

	  default:
		return 1;
	}
	IeeeListPort();
	return 0;
}


//----------------------------------------------------------------------
// IEC COMMAND
int8_t ListPin2(char *pin, int8_t state, int8_t ostate)
{
	char	c;

	while((c = pgm_read_byte(pin++)))
	{
		if(state) 	uartPutChar(toupper(c));
		else		uartPutChar(tolower(c));
	}

/*	if (dir)
		uartPutString_p("-o");
	else
		uartPutString_p("-i");*/

/*	if (pullup)
		uartPutString_p("-pu");
	else
		;//uartPutString_p("");*/

	if (IEC_OUT & _BV(ostate))
		uartPutString_p("-oL");

	uartPutChar(32);
	return 0;
}


//----------------------------------------------------------------------
// IEC COMMAND
int8_t IecListPort(void)
{
	uartPutString_p("IEC port: ");
	//ATN, DATA, CLK, RST, SRQ}
	ListPin2(PSTR("ATN"), IEC_ATN, IEC_OPIN_ATN);
	ListPin2(PSTR("DATA"),IEC_DATA,IEC_OPIN_DATA);
	ListPin2(PSTR("CLK"), IEC_CLK, IEC_OPIN_CLK);
	ListPin2(PSTR("RST"), IEC_RST, IEC_OPIN_RST);
	ListPin2(PSTR("SRQ"), IEC_SRQ, IEC_OPIN_SRQ);

	uartPrintf_P(PSTR("  Data: i%02x, o%02x"), IEC_D_PIN, IEC_D_PORT);
	if (IEC_D_DDR)
		uartPutLine_p(" -out");
	else
		uartPutLine_p(" -in");

	return 99;
}

//--------------------------
// IEC COMMAND
int8_t IecSetPort(char *arg, int8_t state)
{
	int8_t	pin;

	pin = TokenizeGrp(&arg, XT_IECPINS);
	switch(pin)
	{
	  case ATN:
		IecAtn(state);
		break;

	  case DATA:
		IecData(state);
		break;

	  case CLK:
		IecClk(state);
		break;

	  case RST:
		IecRst(state);
		break;

	  case SRQ:
		IecSrq(state);
		break;

	  default:
		return 1;
	}
	IecListPort();
	return 0;
}


//--------------------------
// LIST TOKEN LIST
int8_t ListToken(char **Cmds)
{
	char	*cp, c;
	int8_t	i, flg;

	for(i=0; (cp=(char*)pgm_read_word(&Cmds[i])) != NULL; ++i)
	{
		flg = 0;

		while (1)
		{
			if((c = pgm_read_byte(cp)) == 0)
				break;


			if(isupper(c))
			{
				// REST OPIONAL
				c = tolower(c);
				flg++;
			}
			uartPutChar(c);
			if(flg == 1)
			{
				uartPutChar('[');
				flg++;
			}
			cp++;
		}
		if (flg)
		{
			uartPutChar(']');
		}
		uartPutChar(' ');
	}
	uartPutCrLf();
	return 0;
}

//---------------------------
// LIST XS-1541 VERSIONSTRING
void ListVersion()
{
	uartPutCrLf();
	uartPutString_p("### XS-1541 Interface v"VERSION_STR" ###");
	uartPutCrLf();
}

//--------------------------
// LIST AVAILABLE COMMAND TOKEN
int8_t ListHelp()
{
	return ListToken(Cmds);
}
//--------------------------
// LIST AVAILABLE FILE TYPES
int8_t ListFilty()
{
	return ListToken(FilTyp);
}



//--------------------------
// LIST PARAMETER ERROR
int8_t ParError(int16_t par)
{
	if(par == -1) 
		uartPutString_p("?unknown parameter error");
	else
	{
		char	*s;

		uartPutString_p("?parameter not allowed: ");
		//uartPrintf_p("%04x", par);
		s = GetTokenString(par);
		//s = PSTR("test");
		uartPutString_P(s);
	}
	uartPutCrLf();
	return -1;
}


//--------------------------
// GET TRANSFER PARAM
//--------------------------
int8_t ParseTransfPar(tfer_data *tfer, char *arg)
{
	//int8_t	rc2;
	int8_t	rc = 0;
	uint8_t	by = 0;
	int16_t	tok, tok2;
	int8_t	unit = GetDeviceNum();
	int8_t	drive = 0;
	int8_t	interleave = 3;
	int8_t	bam = TP_ALL;
	int8_t	gcr = 0;
	int8_t	bus = -1;
	int8_t	turbo = TP_TURBO;
	int8_t	dump = TP_NODUMP;
	int8_t	devtyp = GetDeviceType();

  	while(*arg)
	{
		switch(((tok = ReadPar(&arg)) >> 8) & 0xff)
		{
		  case XT_DEVTYPE:
		  	devtyp = tok & 0xff;
			break;

		  case XT_PAR1:
			tok2 = tok & 0xff;
			switch(tok2)
			{
			  case TP_BURST:
			  case TP_PARALLEL:
			  case TP_S1:
			  case TP_S2:
			  case TP_S3:
			  case TP_SLOW:
				bus = tok2;
				break;
			  case TP_WARP:
			  case TP_TURBO:
			  case TP_BURSTLOAD:
				turbo = tok2;
				break;
			  case TP_NODUMP:
			  case TP_DUMPHEX:
			  case TP_DUMPBIN:
				dump = tok2;
				break;
			  case TP_ALL:
				bam = 0;
				break;
			  case TP_BAM:
				bam = 1;
				break;
			  case TP_GCR:
				gcr = 1;
				break;
			  case TP_INTERLEAVE:
				if(GetArgByte(&arg, &by))
					return 11;
				interleave = by;
				break;
			  case TP_U8:
			  case TP_U9:
			  case TP_U10:
			  case TP_U11:
				unit = (tok2) - TP_U8 +8;
				break;
			  case TP_D0:
			  case TP_D1:
				drive = (tok2) - TP_D0;
				break;
			  default:
				//uartPutLine_p("par1:");
				return ParError(tok);
			}
			break;

		  case 0xfe:
		  case 0xff:
			//uartPrintf_p("arg=%d; ", *arg);
			//uartPutCrLf();
			//break;

		  default:
			//uartPrintf_p("default: %04x", tok);
			//uartPutCrLf();
			return ParError(tok);
		}
		GetSpace(&arg);
	}
	if(bus < 0)
		rc = 15;
	else if(turbo < 0)
		rc = 16;
	else if(devtyp != DT_1541 && devtyp != DT_1571 && devtyp != DT_1581)
		rc = 17;
	else
	{
		if(!TferInit(tfer, bus, turbo, interleave))
		{
			TferSetDevice(tfer, devtyp, unit, drive);
			tfer->dump		= dump;
			tfer->fBAM		= bam;
			tfer->gcrDecode	= gcr;
		}
		else
			rc = 11;
	}
	return rc;
}


//--------------------------
// EXECUTE COMMAND TOKEN
int8_t Cmd(enum token cmd, char *arg)
{
//	char *s;
	int8_t rc = 0;
	uint8_t by = 0;
//	uint8_t by = 0, by2, by3;	//,by4;
//	uint16_t wo1, wo2;			//,by4;


	GetSpace(&arg);

	//uartPutString(cmd);
	switch(cmd)
	{
	  case T_IEEE:
		fDevice = 0;
		rc = 98;
		break;

	  case T_IEC:
		fDevice = 1;
		rc = 98;
		break;

	  case T_DEV:
	  	{
			//char	*s;
			uint8_t	dev		= GetDeviceNum();
			int8_t	devtyp	= GetDeviceType();

		  	while(*arg)
			{
				int16_t	tok;

				switch(((tok = ReadPar(&arg)) >> 8) & 0xff)
				{
				  case XT_DEVTYPE:
				  	devtyp = tok & 0xff;
					break;

				  case 0xfe:
				  case 0xff:
					if(GetArgByte(&arg, &dev))
						return 0;
					break;

				  default:
					uartPrintf_p("token: %d", tok);
					uartPutCrLf();
					return ParError(tok);
				}

			}
			if(dev < 8 || dev > 12)
			{
				rc = 2;
				break;
			}
			if(fDevice == 0) 	
			{
				ieee_device = dev;
				ieee_devtyp = devtyp;
			}
			else
			{
				iec_device = dev;
				iec_devtyp = devtyp;
			}
			InitFloppy(-1);
			if(rc == 0)
			{
				rc = 98;
			}
		}
		break;

	  case T_SD:
	  	// SET DATA ON IEEE OR PARALLEL
		{
			uint16_t	wo;

		  	if(*arg == 0)
				wo = -1;
			else if(GetArgWord(&arg, &wo))
				return 0;

			if(fDevice == 0) 	IeeeSetData(wo);
			else			 	IecSetData(wo);
		}
		break;

	  case T_SP:
		if(fDevice == 0) 	rc = IeeeSetPort(arg, 1);
		else			 	rc = IecSetPort(arg, 1);
		break;

	  case T_RP:
		if(fDevice == 0) 	rc = IeeeSetPort(arg, 0);
		else			 	rc = IecSetPort(arg, 0);
		break;

	  case T_LP:
		if(fDevice == 0) 	rc = IeeeListPort();
		else			 	rc = IecListPort();
		break;

	  case T_HLP:
	  	ListVersion();
		uartPutCrLf();
	  	ListHelp();
		break;

	  case T_CAT:
	  	Catalog(arg);
		break;

	  case T_CMD:
	  	if(*arg == 0)
			rc = PrintErrorCh();
		else
		  	rc = SendCmd(arg);
		break;

	  case T_ST:
		rc = 4;
		break;

	  case T_LOADMC:
	  	if(*arg == 0)
			return ListToken(mcTok);
		else
		{
			int16_t		tok;
			uint16_t	wo;
			uint8_t		i, buf[32];

			switch((tok = Tokenize(&arg, mcTok, mcId)))
			{
			  case MC_FLASH:
				if(McUploadFlash())	
					rc = 11;
				break;

			  case MC_MORSE:
				if(McUploadMorse())
					rc = 11;
				break;

			  case MC_RPM:
				//if(McUploadRPM())
					rc = 11;
				break;

			  case MC_TEST:
				{
					tfer_data tfer;

					if(!(rc = ParseTransfPar(&tfer, arg)))
					{
						uartPrintf_p("parameter ok", rc);
						uartPutCrLf();
						if((rc = TferTest(&tfer)))
						{
							uartPrintf_p("rc=%d", rc);
							uartPutCrLf();
							rc = 11;
						}
					}
				}
				break;

				//MC_PP,MC_S1,MC_S2,MC_S2_1581,MC_BURST1571,MC_BURST1581,
				//MC_WARPRD1541,MC_TURBORD1541,
				//MC_WARPRD1571,MC_TURBORD1571,
				//MC_TURBORD1581,
				//MC_TEST

			  default:
				if(GetArgWord(&arg, &wo))
					return 0;

				for(i=0; i<32; ++i)
				{
				  	if(*arg == 0)
						break;

					if(GetArgByte(&arg, &by))
						return 0;

					buf[i] = by;
				}
				//uartPrintf_p("bytes: %d", i);
				//uartPutCrLf();

				if(McUpload(wo, buf, i))
					rc = 11;
				break;
			}
		}
		break;


	  case T_CONFIG:
		{
			int16_t	tok;
			uint8_t	by2=0;


			switch(((tok = ReadPar(&arg)) >> 8) & 0xff)
			{
			  case XT_PAR1:
				switch(tok & 0xff)
				{
				  case TP_LED:
					if(GetArgByte(&arg, &by))
						return 0;

					if(*arg == 0)
					{
						// MODE only
						conf.led = by;
					}
					else if(!GetArgByte(&arg, &by2))
					{
						// MODE only
						conf.led	= 3;
						conf.led_p1	= by;
						conf.led_p2	= by2;
					}
					break;

				  case TP_ECHO:
					if(GetArgByte(&arg, &by))
						return 0;

					conf.echo = by;
					break;

				  default:
					//uartPutLine_p("par1:");
					return ParError(tok);
				}
				break;

			  case 0xfe:
			  case 0xff:
			  default:
				//uartPrintf_p("default: %04x", tok);
				//uartPutCrLf();
				return ParError(tok);
			}
		}
		break;

	  case T_BST:
		BurstStat();
		break;

	  case T_RESET:
		if(fDevice == 0) 	
		{
			IeeeIFC();
		}
		else
		{
			IecReset();
		}
		break;

	  case T_DUMPMEM:
		{
			uint16_t wo1, wo2;

		  	if(GetArgWord(&arg, &wo1))	;
			else if(GetArgWord(&arg, &wo2))	;
			else	
				rc = DumpMem(wo1, wo2);
		}
		break;

	  case T_DUMPBLK:
	  case T_DUMPTRACK:
		{
			int16_t	tok;
			int8_t	drive = 0;
			int8_t	cnt = 0;
			int8_t	tr = 0;
			int8_t	se = 0;
			int8_t	anz = 0;
			int8_t	option = BurstDefault();

		  	while(*arg)
			{
				switch(((tok = ReadPar(&arg)) >> 8) & 0xff)
				{
				  case XT_PAR1:
					switch(tok & 0xff)
					{
					  case TP_D1:
						drive = 1;
						break;
					  case TP_D0:
						drive = 0;
						break;
					  case TP_BURST:
					  case TP_PARALLEL:
					  case TP_SLOW:
						option = tok & 0xff;
						break;
					  default:
						//uartPutLine_p("par1:");
						return ParError(tok);
					}
					break;

				  case 0xfe:
				  case 0xff:
					if(GetArgByte(&arg, &by))
						return 0;

				  	switch(cnt++)
					{
					  case 0:
						tr = by;
						break;
					  case 1:
						se = by;
						break;
					  case 2:
						anz = by;
						break;
					}
					break;

				  default:
					//uartPrintf_p("default: %04x", tok);
					//uartPutCrLf();
					return ParError(tok);
				}
			}
			if(cmd == T_DUMPBLK)
			{
				if(cnt < 2)
					rc = 10;
				else
					rc = DumpBlock(drive,tr, se, anz, option);
			}
			else
			{
				if(cnt < 1)
					rc = 10;
				else
					rc = DumpTrack(drive,tr, se, option);
			}
		}
		break;

	  case T_DUMPNXTBLK:
		rc = DumpNxtBlock();
		break;

	  case T_DUMPDISK:
		{
			tfer_data tfer;

			if(!(rc = ParseTransfPar(&tfer, arg)))
			{
				uartPrintf_p("parameter ok", rc);
				uartPutCrLf();
				if((rc = TferTestRdDisc(&tfer)))
				{
					uartPrintf_p("rc=%d", rc);
					uartPutCrLf();
					rc = 11;
				}
			}
		}
		break;

	  case T_LISTEN:
	  	if(!GetArgByte(&arg, &by))
			Listen(by);
		break;

	  case T_TALK:
	  	if(!GetArgByte(&arg, &by))
			Talk(by);
		break;

	  case T_UNTALK:
		UnTalk();
		break;

	  case T_UNLISTEN:
		UnListen();
		break;

	  case T_OPEN:
		{
			char	*s;

			if(GetArgString(&arg, &s))
				rc = 99;
		  	if(!GetArgByte(&arg, &by))
			  	Open(by,s);
		}
		break;

	  case T_CLOSE:
	  	if(!GetArgByte(&arg, &by))
			Close(by);
		break;

	  case T_BSOUT:
	  	if(!GetArgByte(&arg, &by))
			BsOut(by);
		break;

	  case T_BASIN:
	  	if(*arg == 0)
			by = 1;
	  	else if(GetArgByte(&arg, &by))
			break;

		while(by)
		{
			SetST(0);
			uartPrintf_P(PSTR("%02x"), BasIn());
			by--;
		}
		uartPutCrLf();
		rc = 99;
		break;

	  case T_DUMPFILE:
	  case T_DOWNLOAD:
		{
			char	*s;
			int16_t	tok;
			int8_t	filtyp = FT_P00;
			int8_t	option = BurstDefault();

			if(GetArgString(&arg, &s))
				rc = 99;
			else while(1)
			{
				switch(((tok = ReadPar(&arg)) >> 8) & 0xff)
				{
				  case XT_FILETYPE:
					switch(tok & 0xff)
					{
					  case FT_PRG:
					  case FT_T64:
					  case FT_P00:
						filtyp = tok & 0xff;
						break;
					  default:
						//uartPutLine_p("filetyp:");
						return ParError(tok);
					}
					break;

				  case XT_PAR1:
					switch(tok & 0xff)
					{
					  case TP_BURST:
					  case TP_PARALLEL:
					  case TP_SLOW:
						option = tok & 0xff;
						break;
					  default:
						//uartPutLine_p("par1:");
						return ParError(tok);
					}
					break;

				  case 0xfe:
					/*uartPutString_p("Datei: ");
					uartPutString(s);
					uartPutCrLf();
					uartPrintf_p("filetyp %d, ", filtyp);
					uartPutCrLf();
					uartPrintf_p("option %d, ", option);
					uartPutCrLf();
					break;*/

					if(cmd == T_DOWNLOAD)
					  	rc = DownloadFile(s, filtyp, option);
					else
						rc = DumpFile(s, option);
					return rc;

				  default:
					//uartPrintf_p("default: %04x", tok);
					//uartPutCrLf();
					return ParError(tok);
				}
			}
		}
		break;

	  case T_UPLOAD:
	  	//uartPutLine_p("start your X-Modem file receive");
		//xmodem_send_test();
		//xmodem_receive_test();
#ifdef TEST_DIMAGE
		DimgTest(FT_D80);
#endif
		rc = 99; 
		break;

	  case T_LISTFT:
		ListFilty();
		rc = 99; 
		break;

	  case T_LISTBAM:					// [drive],[filetype],[ALL/BAM]
	  	{
			int8_t	option	= BurstDefault();
			int8_t	bam		= TP_BAM;
			int8_t	drive	= 0;
			int8_t	filtyp	= GetDefImageType();
			int16_t	tok;
			while(1)
			{
				switch(((tok = ReadPar(&arg)) >> 8) & 0xff)
				{
				  case XT_FILETYPE:
					filtyp = tok & 0xff;
					break;

				  case XT_PAR1:
					switch(tok & 0xff)
					{
					  case TP_ALL:
					  case TP_BAM:
						bam = tok & 0xff;
						break;
					  case TP_D1:
						drive = 1;
						break;
					  case TP_D0:
						drive = 0;
						break;
					  case TP_BURST:
					  case TP_PARALLEL:
					  case TP_SLOW:
						option = tok & 0xff;
						break;
					}
					break;

				  case 0xfe:
					//uartPrintf_p("drive %d, ", drive);
					//s = GetTokenString(filtyp | (XT_FILETYPE << 8));
					//uartPutLine_P(s);
					return ListBAM(drive, filtyp, bam, option);

				  default:
					return ParError(tok);
				}
			}
		}
		break;

	  case T_BACKUP:
		{
			int8_t		burstopt = BurstDefault();
			uint8_t		filtyp = GetDefImageType();
			uint8_t		bam = TP_BAM;
			uint16_t	drive = 0;
			uint16_t	loop = 1;


			while(loop)
			{
				int16_t	tok;
				switch(((tok = ReadPar(&arg)) >> 8) & 0xff)
				{
				  case XT_PAR1:
					switch(tok & 0xff)
					{
					  case TP_ALL:
					  case TP_BAM:
						bam = tok & 0xff;
						break;
					  case TP_D1:
						drive = 1;
						break;
					  case TP_D0:
						drive = 0;
						break;
					  case TP_BURST:
					  case TP_PARALLEL:
					  case TP_SLOW:
						burstopt = tok & 0xff;
						break;
					}
					break;

				  case XT_FILETYPE:
					filtyp = tok & 0xff;
					break;

				  case 0xfe:
					//uartPrintf_p("drive %d, ", drive);
					//s = GetTokenString(filtyp | (XT_FILETYPE << 8));
					//uartPutLine_P(s);
				  	rc = Backup(drive, filtyp, bam, burstopt);
					loop = 0;
					break;

				  default:
					return ParError(tok);
				}
			}
		}
		break;

	  case T_INQUIRE:							// BURST INQUIRE!
		if(BurstDefault() == TP_BURST)
		{
			uint16_t wo = 1;
			uint16_t p = 0;
			uint8_t rc;

			GetArgNum(&arg, &wo);
			rc = GetArgNum(&arg, &p);
			switch(wo)
			{
			  case 2:
				uartPutLine_p("*Burst InquireStatus(80)");
				InquireStatus(0x80, 0);
				break;
			  case 3:
				uartPutLine_p("*Burst InquireStatus(C0)");
				InquireStatus(0xc0, 0);
				break;
			  case 4:
				uartPutLine_p("*Burst QueryDiskFormat()");
				InquireStatus(0x00, 0);
				break;
			  case 5:
				uartPutString_p("*Burst Interleave(): ");
				if(rc)
				{
					rc = BurstInterleave(0);
					uartPrintf_p(" %d", rc);
				}
				else
				{
					uartPrintf_p("set to %d", p);
					BurstInterleave(p);
				}
				uartPutCrLf();
				break;
			  default:
				uartPutLine_p("*Burst Inquire Disk");
				InquireDisk();
				break;
			}
		}
		else
			SendCmd_P("I");						// normal @I command
		break;

	  case T_BLANK:
		rc = 99;
		break;

	  case 255:
		// UNKNOWN CMD
	  default:
		uartPutString_p("?unknown command");
		uartPutCrLf();
		return 1;
	}
	{
		char	*s;

		switch(rc)
		{
		  case 99:
			return(0);
		  case 98:
			if(fDevice == 0)
			{
				uartPrintf_p("IEEE-488 device %d (", ieee_device);
				s = GetTokenString(ieee_devtyp | (XT_DEVTYPE << 8));
			}
			else
			{
				uartPrintf_p("IEC device %d (", iec_device);
				s = GetTokenString(iec_devtyp | (XT_DEVTYPE << 8));
			}
			uartPutString_P(s);
			uartPutLine_p(")");
			return(0);
		  case 0:
		  	s = PSTR("ready.");
			break;
		  case 1:
		  	s = PSTR("?unknown pin");
			break;
		  case 2:
		  	s = PSTR("?device# 8 to 11 allowed");
			break;
		  case 3:
		  	uartPutChar('?');
		  case 4:
			uartPrintf_P(PSTR("ST:%02x"), ST);
			uartPutCrLf();
			SetST(0);
		  	return (0);
		  case 5:
		  	s = PSTR("?file type not allowed");
			break;
		  case 6:
		  	s = PSTR("?unknown filetype");
			break;
		  case 7:
		  	s = PSTR("?not enough memory error");
			break;
		  case 8:
		  	s = PSTR("?disk type not allowed");
			break;
		  case 9:
		  	s = PSTR("?unknown parameter");
			break;
		  case 10:
		  	s = PSTR("?missing parameter");
			break;
		  case 15:
		  	s = PSTR("?missing transfer methode");
			break;
		  case 16:
		  	s = PSTR("?missing speeder methode");
			break;
		  case 17:
		  	s = PSTR("?illegal devicetype");
			break;

		  case 11:
		  default:
		  	s = PSTR("?error");
			break;
		}
		uartPutString_P(s);
		uartPutCrLf();
	}
	return 0;
}



//--------------------------
// PARSE AND EXECUTE COMMAND
int8_t Terminal()
{
	char	buf[SIZE_TERMBUF +1];
	int8_t	cmd;
	int16_t	c;
	uint8_t	wp;
	tick_t	timer;
	char	*s;

	timer = ticks + 50;
	wp = 0;
	while(1)
	{
		c = uartGetCharTo(20);

		switch(c)
		{
		  case 13:
			if(conf.echo)
			{
				uartPutChar(13);
				uartPutChar(10);
			}
		  	if(wp == 0)
			{
				c = 0;
				break;
			}
			buf[wp++] = 0;

			/*s = buf;
			{
				int16_t	cmd;

				if((cmd = ReadPar(&s)) >= 0)
				{
					uartPrintf_p("cmd: %04x", cmd);
					uartPutCrLf();
					wp = 0;
					cmd = T_BLANK; 
					break;
				}
				else
					uartPutLine_p("??");
			}*/

			s = buf;
			cmd = TokenizeCmd(&s);
			Cmd(cmd, s);

			wp = 0;
			cmd = T_BLANK; 
			break;

		  case 8:
		  	if(wp)
			{
				if(conf.echo)
				{
					uartPutChar(c);
					uartPutChar(' ');
					uartPutChar(c);
				}
				wp--;
			}
			break;

		  default:
			if(c < 32)
				break;
			if(wp >= SIZE_TERMBUF)
				break;

			if(conf.echo)
				uartPutChar(c);

			buf[wp++] = c;
			break;
		}

		// BLINK LED
		switch(conf.led)
		{
		  case 0:
			LED_OFF();
			break;

		  case 1:
			LED_ON();
			break;

		  case 2:
			//conf.led = 3;
			if(fDevice ==0 )
			{
				// IEEE488
				conf.led_p1 = 33;
				conf.led_p2 = 33;
			}
			else
			{
				// IEC
				conf.led_p1 = 7;
				conf.led_p2 = 93;
			}

		  default:	
			cli();
			if(time_after(ticks,timer))
			{
				LED_TOGGLE();					// Flankenwechsel f�r LED

				while(time_after(ticks,timer))
					timer += LED_TEST ? conf.led_p1 : conf.led_p2;
			}
			sei();
			break;
		}


		// SHOW BURST STATUS <BST>
		//BurstStat();
	}
	return 0;
}


//--------------------------
// CALC FREE RAM SPACE
uint16_t BytesFree()
{
	extern unsigned char __heap_start;
	uint16_t momentan_frei = SP - (uint16_t) &__heap_start;
	return momentan_frei;
}
//--------------------------
// TEST RAM BUFFER
/*int8_t TestRam()
{
	char		*s;
	uint16_t 	i, fre; 

	fre = BytesFree();
	uartPrintf_P(PSTR(" %u Bytes free"), fre);
	uartPutCrLf();

	for(i=0; i<(fre -128) / 256; ++i)
	{
		s = alloca(256);
		if(s == NULL)
			break;
	}

	fre = BytesFree();
	uartPrintf_P(PSTR(" %u Bytes free"), fre);
	uartPutCrLf();
	return i;
}*/

//--------------------------
// TEST HIRES TIMER
/*int8_t TestTimer()
{
	uint8_t		tim500 = TIMEOUT_US(100);
	uint16_t	cnt;
	cnt = 0;

	start_timeout(tim500);

	while (1)  		
	{
		if(has_timed_out())
		{
			start_timeout(tim500);
			if(cnt++ >= 5000)
			{
				cnt = 0;
				LED_TOGGLE();			// Flankenwechsel f�r LED
			}
		}
	}
}*/

/*int8_t TestTokenGrp(int8_t group)
{
	int8_t	i;

	if((i = SearchGroupID(group)) >= 0)
	{
		if(pgm_read_byte(&xs1541_Id[i]) == group)
		{
			uartPrintf_P(PSTR("Grp %d: %04x/%04x"), group, GetToken(i), GetTokenId(i));
			uartPutCrLf();
		}
	}
	return -1;
}
void TestTokenPar(void)
{
	uartPrintf_P(PSTR("Cmds %04x/%04x"), Cmds, CmdsId);
	uartPutCrLf();
	uartPrintf_P(PSTR("Cmds %04x/%04x"), Cmdp, CmdpId);
	uartPutCrLf();
	uartPrintf_P(PSTR("Cmds %04x/%04x"), IecPins, IecPins);
	uartPutCrLf();
	TestTokenGrp(XT_CMDS);
	TestTokenGrp(XT_PAR1);
	TestTokenGrp(XT_IECPINS);
	
}*/


//------------------------------------------------------------------------
// Initialisierungen
//------------------------------------------------------------------------
void init()
{
	//TIMSK0 = 0;			// maskiere alle INT

	// Ports initialisieren
	LED_SETDDR();
	//LED_ON();

	//GLOBALS
	fDevice	= 0;

	conf.led	= 2;
	conf.echo	= 1;
}


/////////////////////////////////////////////////////////////////////////////
// Main-Funktion
/////////////////////////////////////////////////////////////////////////////
int main()
{
	uint8_t	cmd;

	init(); 				// Initialisierungen
	initUart();
	//initTimer0();			// Timer Interrupt initialisieren
	InitTimer();			// Timer Interrupt initialisieren
	InitIeee();
	InitIec();
	//InitPar();
	//InitBurst(); 
	sei();

  	ListVersion();
	uartPrintf_P(PSTR(" %u Bytes free"), BytesFree());
	uartPrintf_P(PSTR(", %ld Hz"), (int32_t)F_CPU);
	uartPutCrLf();
	uartPutCrLf();


	//TestTimer();
	//TestTokenPar();

	while (1)  			// Mainloop-Begin
	{
		if((cmd = Terminal()))
		{
			//ExecCmd(cmd);
		}
	}
}
//---------------------------------------------------------------------------

