//-------------------------------------------------------------------------
// Titel:    XS-1541 - IEE488 Handler
// Funktion: handle communication to parallel IEEE-488 floppy drives
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#ifndef IEEE_H
#define IEEE_H



extern uint8_t ieee_device;					// current device#
extern uint8_t ieee_status;					// bit0=timeout; bit7=device not present
extern uint8_t ieee_devtyp;					// DT_2030,DT_4040,DT_8050,DT_8250









// CAUTION!!!
// only use this without hardware connected 
// to test output with a multimeter

//#define IEEE_TEST



#define IEEE_ST_WRTO	_BV(0)					// write timeout
#define IEEE_ST_RDTO	_BV(1)					// read timeout
#define IEEE_ST_ATTO	_BV(2)					// ATN/DAV timeout
#define IEEE_ST_EOI		_BV(6)					// EOI
#define IEEE_ST_DNP		_BV(7)					// device not present




// PORT DEFINITION FOR ATN
#define IEEE_A_PIN		PIND
#define IEEE_A_DDR		DDRD
#define IEEE_A_PORT		PORTD

// PORT DEFINITION FOR DATA
#define IEEE_D_PIN		PINA
#define IEEE_D_DDR		DDRA
#define IEEE_D_PORT		PORTA

// PORT DEFINITION FOR CTRL
#define IEEE_PIN		PINC
#define IEEE_DDR        DDRC
#define IEEE_PORT       PORTC



#define IEEE_PIN_EOI	PC7
#define IEEE_PIN_DAV	PC6
#define IEEE_PIN_NRFD   PC5
#define IEEE_PIN_NDAC   PC4
#define IEEE_PIN_SRQ    PC3
#define IEEE_PIN_IFC    PC2
#define IEEE_PIN_REN    PC1
#define IEEE_PIN_ATN    PD3


//define ATN_INT_VECT          PCINT0_vect
//define ATN_INT_SETUP()       do { PCMSK0 = _BV(PCINT0); PCIFR |= _BV(PCIF0); } while (0)
//define set_atnack(x)         if (x) { PCICR |= _BV(PCIE0); } else { PCICR &= (uint8_t)~_BV(PCIE0); }




#define IEEE_BIT_EOI	_BV(IEEE_PIN_EOI)
#define IEEE_BIT_DAV	_BV(IEEE_PIN_DAV)
#define IEEE_BIT_NRFD   _BV(IEEE_PIN_NRFD)
#define IEEE_BIT_NDAC   _BV(IEEE_PIN_NDAC)
#define IEEE_BIT_ATN    _BV(IEEE_PIN_ATN)


#ifdef IEEE_SEPARATE_OUT
//  #define IEEE_PULLUPS    (IEEE_BIT_ATN | IEEE_BIT_EOI | IEEE_BIT_DAV | IEEE_BIT_NRFD | IEEE_BIT_NDAC)
//#  define IEC_OBIT_ATN   _BV(IEC_OPIN_ATN)
//#  define IEC_OBIT_DATA  _BV(IEC_OPIN_DATA)
//#  define IEC_OBIT_CLOCK _BV(IEC_OPIN_CLOCK)
//#  define IEC_OBIT_SRQ   _BV(IEC_OPIN_SRQ)
//  #define IEEE_OUT			IEEE_PORT
#else
  #define IEEE_OPIN_EOI		IEEE_PIN_EOI
  #define IEEE_OPIN_DAV 	IEEE_PIN_DAV
  #define IEEE_OPIN_NRFD	IEEE_PIN_NRFD
  #define IEEE_OPIN_NDAC	IEEE_PIN_NDAC
  #define IEEE_OPIN_ATN		IEEE_PIN_ATN
  #define IEEE_OBIT_EOI		_BV(IEEE_OPIN_EOI)
  #define IEEE_OBIT_DAV		_BV(IEEE_OPIN_DAV)
  #define IEEE_OBIT_NRFD   	_BV(IEEE_OPIN_NRFD)
  #define IEEE_OBIT_NDAC   	_BV(IEEE_OPIN_NDAC)
  #define IEEE_OBIT_ATN    	_BV(IEEE_OPIN_ATN)
  #define IEEE_OUT			IEEE_DDR
  #define IEEE_A_OUT		IEEE_A_DDR
#endif








#ifdef IEEE_TEST
 // PORT TESTMODE
 #define IeeeAtn(state)		do { if (!state) IEEE_A_PORT &= ~IEEE_OBIT_ATN;	else IEEE_A_PORT |= IEEE_OBIT_ATN; IEEE_DDR |= IEEE_OBIT_ATN; } while(0)
 #define IeeeEoi(state)		do { if (!state) IEEE_PORT &= ~IEEE_OBIT_EOI;	else IEEE_PORT |= IEEE_OBIT_EOI; IEEE_DDR |= IEEE_OBIT_EOI; } while(0)
 #define IeeeDav(state)		do { if (!state) IEEE_PORT &= ~IEEE_OBIT_DAV;	else IEEE_PORT |= IEEE_OBIT_DAV; IEEE_DDR |= IEEE_OBIT_DAV; } while(0)
 #define IeeeNrfd(state)	do { if (!state) IEEE_PORT &= ~IEEE_OBIT_NRFD;	else IEEE_PORT |= IEEE_OBIT_NRFD; IEEE_DDR |= IEEE_OBIT_NRFD; } while(0)
 #define IeeeNdac(state)	do { if (!state) IEEE_PORT &= ~IEEE_OBIT_NDAC;	else IEEE_PORT |= IEEE_OBIT_NDAC; IEEE_DDR |= IEEE_OBIT_NDAC; } while(0)
#else
 #define IeeeAtn(state)		do { if (state) IEEE_A_OUT &= ~IEEE_OBIT_ATN;	else IEEE_A_OUT |= IEEE_OBIT_ATN;   } while(0)
 #define IeeeEoi(state)		do { if (state) IEEE_OUT &= ~IEEE_OBIT_EOI;		else IEEE_OUT |= IEEE_OBIT_EOI;   } while(0)
 #define IeeeDav(state)		do { if (state) IEEE_OUT &= ~IEEE_OBIT_DAV;		else IEEE_OUT |= IEEE_OBIT_DAV;   } while(0)
 #define IeeeNrfd(state)	do { if (state) IEEE_OUT &= ~IEEE_OBIT_NRFD;	else IEEE_OUT |= IEEE_OBIT_NRFD;   } while(0)
 #define IeeeNdac(state)	do { if (state) IEEE_OUT &= ~IEEE_OBIT_NDAC;	else IEEE_OUT |= IEEE_OBIT_NDAC;   } while(0)
#endif


// INP
#ifdef IEEE_TEST
 // PORT TESTMODE
 static inline int8_t ieee_atn(void) {
 	IEEE_A_DDR	&= ~IEEE_OBIT_ATN;
 	IEEE_A_PORT |= IEEE_OBIT_ATN;
	return IEEE_PIN & IEEE_BIT_ATN;
 }
 static inline int8_t ieee_eoi(void) {
 	IEEE_DDR &= ~IEEE_OBIT_EOI;
 	IEEE_PORT |= IEEE_OBIT_EOI;
	return IEEE_PIN & IEEE_BIT_EOI;
 }
 static inline int8_t ieee_dav(void) {
 	IEEE_DDR &= ~IEEE_OBIT_DAV;
 	IEEE_PORT |= IEEE_OBIT_DAV;
	return IEEE_PIN & IEEE_BIT_DAV;
 }
 static inline int8_t ieee_nrfd(void) {
 	IEEE_DDR &= ~IEEE_OBIT_NRFD;
 	IEEE_PORT |= IEEE_OBIT_NRFD;
	return IEEE_PIN & IEEE_BIT_NRFD;
 }
 static inline int8_t ieee_ndac(void) {
 	IEEE_DDR &= ~IEEE_OBIT_NDAC;
 	IEEE_PORT |= IEEE_OBIT_NDAC;
	return IEEE_PIN & IEEE_BIT_NDAC;
 }
 #define IEEE_ATN	(ieee_atn())
 #define IEEE_EOI	(ieee_eoi())
 #define IEEE_DAV	(ieee_dav())
 #define IEEE_NRFD	(ieee_nrfd())
 #define IEEE_NDAC	(ieee_ndac())
#else
 #define IEEE_ATN	(IEEE_A_PIN & IEEE_BIT_ATN)
 #define IEEE_EOI	(IEEE_PIN & IEEE_BIT_EOI)
 #define IEEE_DAV	(IEEE_PIN & IEEE_BIT_DAV)
 #define IEEE_NRFD	(IEEE_PIN & IEEE_BIT_NRFD)
 #define IEEE_NDAC	(IEEE_PIN & IEEE_BIT_NDAC)
#endif


// DIRECTION
#define IEEE_ATN_D	(IEEE_A_DDR & IEEE_BIT_ATN)
#define IEEE_EOI_D	(IEEE_DDR & IEEE_BIT_EOI)
#define IEEE_DAV_D	(IEEE_DDR & IEEE_BIT_DAV)
#define IEEE_NRFD_D	(IEEE_DDR & IEEE_BIT_NRFD)
#define IEEE_NDAC_D	(IEEE_DDR & IEEE_BIT_NDAC)


// PULL UP
#define IEEE_ATN_PU		(IEEE_A_PORT & IEEE_BIT_ATN)
#define IEEE_EOI_PU		(IEEE_PORT & IEEE_BIT_EOI)
#define IEEE_DAV_PU		(IEEE_PORT & IEEE_BIT_DAV)
#define IEEE_NRFD_PU	(IEEE_PORT & IEEE_BIT_NRFD)
#define IEEE_NDAC_PU	(IEEE_PORT & IEEE_BIT_NDAC)



#ifndef set_atnack
//#  define set_atnack(state) do { if (state) TIMSK2 |= _BV(OCIE2A); else TIMSK2 &= ~_BV(OCIE2A); } while(0)
#endif





void IeeeSetData(int16_t wo);

void InitIeee(void);
void IeeeMainloop(void);

int8_t IeeeListen(uint8_t sa);
int8_t IeeeTalk(uint8_t sa);
int8_t IeeeUntalk(void);
int8_t IeeeUnlisten(void);
int8_t IeeeOpen(uint8_t sa, char *);
int8_t IeeeClose(uint8_t sa);
int8_t IeeeBsout(uint8_t by);
uint8_t IeeeBasin(void);
void IeeeIFC(void);


#endif
