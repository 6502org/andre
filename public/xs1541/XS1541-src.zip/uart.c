//-------------------------------------------------------------------------
// Titel:	 XS-1541 - RS232 Communication
// Funktion: handle UART Communication over 2 ring buffer and block buffer
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdarg.h>
#include <alloca.h>

#include "compat.h" 
#include "uart.h"
//#include "ieee.h"






#define	rxRingb		((st_ringbuf *)rxBuf)
#define	txRingb		((st_ringbuf *)txBuf)


//#define TEST_RB
//#define TEST_XBUF



// CONST



// TOKEN
enum token {P_NONE,P_XMODEM
		   };


// STRUCTS



// STATICS
volatile static st_buf	*xbuf = NULL;

//volatile static st_buf	*xbuf2 = NULL;
//volatile static uint8_t	protocoll = P_NONE;						// P_NONE,P_XMODEM

static uint8_t	txBuf[COMBUF_SIZE_TX + sizeof(st_ringbuf)];			// transmit buffer
static uint8_t	rxBuf[COMBUF_SIZE_RX + sizeof(st_ringbuf)];			// receive buffer




// GLOBALS
//volatile uint8_t	rcvBcr;											// CR flag





//--------------------------------------------------------------------
// RINGBUFFER Init (Constructor)
//--------------------------------------------------------------------
void RingbInit(st_ringbuf *rb, uint16_t len)
{
	rb->rp	= 0;
	rb->wp	= 0;
	rb->cnt	= 0;
	rb->size= len - sizeof(st_ringbuf);
}
/*uint8_t inline RingbBytesInBuf(st_ringbuf *rb)
{
	return rb->cnt;
}*/
/*uint8_t inline RingbBytesFree(st_ringbuf *rb)
{
	return rb->cnt - rb->cnt;
}*/

int8_t inline _RingbWrite(st_ringbuf *rb, char d)
{
	if(RingbBytesFree(rb) == 0)
		return -1;

	rb->buf[(rb->wp)++] = (uint8_t)d;
	if(rb->wp >= rb->size) 	
		rb->wp = 0;
	(rb->cnt)++;
	return 0;
}
int16_t inline _RingbRead(st_ringbuf *rb)
{
	uint8_t	data;

	if(RingbBytesInBuf(rb) == 0)
		return -1;

	data = rb->buf[(rb->rp)++];
	if(rb->rp >= rb->size) 	
		rb->rp = 0;
	(rb->cnt)--;
	return data;
}

int16_t RingbRead(st_ringbuf *rb)
{
	int16_t rc;
	cli();
	rc = _RingbRead(rb);
	sei();
	return rc;
}

int8_t RingbWrite(st_ringbuf *rb, char d)
{
	int8_t rc;
	cli();
	rc = _RingbWrite(rb, d);
	sei();
	return rc;
}




//----------------------------------------------------------------------
// INIT XTENDED BUFFER (Constructor)
//----------------------------------------------------------------------
void XbufInit(st_buf *xb, uint8_t *buf, uint16_t size)
{
	xb->size = size;
	xb->pt   = buf;
	xb->idx  = 0;
	xb->stat = 0;
}

//----------------------------------------------------------------------
// WRITE TO XTENDED BUFFER 
//----------------------------------------------------------------------
int8_t XbufWrite(st_buf *xb, uint8_t data)
{
	if(xb->stat != 1)
	{
		if(xb->stat != 0)
			return 2;

		// PREPARE WRITE
		xb->stat = 1;
		xb->idx  = 0;
	}

	// DATA INTO BUFFER
	xb->pt[(xb->idx)++] = data;

	if(xb->idx >= xb->size)
	{
		// BUFFER FULL
		xb->stat = 2;
	}
	return 0;
}

//----------------------------------------------------------------------
// SEND XTENDED BUFFER IN ISR
//----------------------------------------------------------------------
int8_t XbufSend(st_buf *buf)
{
	buf->idx  = 0;
	buf->stat = 3;

	cli();
//	protocoll = P_XMODEM;

	//if(xbuf == NULL)
		xbuf = buf;
	//else
	//	xbuf2= buf;

	sei();
	UCSRB |= (1<<UDRIE);									// UDRE Interrupt ein
	return 0;
}



//--------------------------------------------------------------------
// USART_RXC_vect - UART Interrupt bei Datenempfang komplett
//--------------------------------------------------------------------
ISR(USART_RXC_vect)
{
	uint8_t	rcvBlc = UDR;
	
//	switch(protocoll)
	{
//	  case P_XMODEM:
//	  	break;

//	  default:
		RingbWrite(rxRingb, rcvBlc);
	}
}

//--------------------------------------------------------------------
// USART_UDRE_vect - UART Interrupt bei Senderegister leer
//--------------------------------------------------------------------
ISR(USART_UDRE_vect)
{
	if(xbuf == NULL)
	{
		// D�SABLE ISR 
		int16_t data = _RingbRead(txRingb);
		if (data < 0)
		{
			// D�SABLE ISR 
			UCSRB &= ~_BV(UDRIE);
		}
		else
		{
			UDR = data;
		}
	}
	else
	{
		UDR = xbuf->pt[(xbuf->idx)++];

		if(xbuf->idx >= xbuf->size)
		{
			xbuf->stat = 4;
			xbuf = NULL;
		}
	}

}

//--------------------------------------------------------------------
// USART_TXC_vect - UART Interrupt bei Sendevorgang beendet
//--------------------------------------------------------------------
/*ISR(USART_TXC_vect)
{
	// Hier Interruptbehandlung
}*/




//----------------------------------------------------------------------
// Titel 	: C-Funktion Zeichen von UART holen.
//----------------------------------------------------------------------
char uartGetChar()
{
	int16_t	data;

	while((data = RingbRead(rxRingb)) < 0)
		;
	return data;
}

//----------------------------------------------------------------------
// Titel 	: C-Funktion Zeichen von UART holen mit Timeout
//----------------------------------------------------------------------
int16_t uartGetCharTo(uint16_t to)
{
	int16_t data;

	while(1)
	{
		cli();
		data = RingbRead(rxRingb);
		sei();
		if(data >= 0)
			break;

		if(to-- == 0)
			return -1;

		_delay_ms(1);
	}
	return data;
}

//----------------------------------------------------------------------
// Number of Bytes in RX Buffer
//----------------------------------------------------------------------
int16_t uartBytesInBuf()
{
	return RingbBytesInBuf(rxRingb);
}






//----------------------------------------------------------------------
// Titel 	: C-Funktion Zeichen zu UART senden.
//----------------------------------------------------------------------
void uartPutChar(char data)
{
	//warte bis UDR leer ist UCSRA / USR bei z.B.: 2313
	//while (!(UCSRA&32));

	while(RingbWrite(txRingb, (uint8_t)data))
	{
		while(RingbBytesFree(txRingb) == 0)
			;
	}
	UCSRB |= (1<<UDRIE);									// UDRE Interrupt ein
}


//----------------------------------------------------------------------
// Titel 	: SEND ALL CHAR IN RINGBUFFER
//----------------------------------------------------------------------
void uartPutFlush()
{
	while(RingbBytesInBuf(txRingb) != 0)
			;
}

//----------------------------------------------------------------------
// Titel 	: C-Funktion Zeichenkette zu UART senden.
//----------------------------------------------------------------------
void uartPutString(char *buffer)
{
	char	c;
	while((c = *(buffer++)))
		uartPutChar(c);
}
void uartPutString_P(char *buffer)
{
	char	c;
	while((c = pgm_read_byte(buffer++)))
		uartPutChar(c);
}

void uartPutCrLf(void)
{
	uartPutChar('\r');
	uartPutChar('\n');
}

void uartPutLine(char *buffer)
{
	uartPutString(buffer);
	uartPutCrLf();
}
void uartPutLine_P(char *buffer)
{
	uartPutString_P(buffer);
	uartPutCrLf();
}




//------------------------------------------------------------------------
// PRINTF DIRECT TO UART
void uartPrintf(const char *format, ...)
{
    va_list args;
	char 	buf[129];
    
    va_start( args, format );
    vsprintf(buf, format, args );
	uartPutString(buf);
}
void uartPrintf_P(const char *format, ...)
{
    va_list args;
	char 	buf[129];
    
    va_start( args, format );
    vsprintf_P(buf, format, args );
	uartPutString(buf);
}






#ifdef	TEST_RB
// RINGBUFFER TEST FUNC
int8_t RingbTest()
{
	int16_t	data;
	uint8_t	i;
	uint8_t	cnt = 0;
	uint8_t	cnt2 = 0;
	uint8_t	flg = 0;


	uartPutLine_p("Ring Buffer Test");
	uartPrintf_P(PSTR("Bytes free/alloc: %d/%d"), RingbBytesFree(txRingb),RingbBytesInBuf(txRingb));
	uartPutCrLf();
	while(1)
	{
		if(RingbWrite(txRingb, cnt))
		{
			if(flg == 0)
			{
				uartPrintf_P(PSTR("Buffersize: %d"), cnt);
				uartPutCrLf();
				uartPrintf_P(PSTR("Bytes free/alloc: %d/%d"), RingbBytesFree(txRingb),RingbBytesInBuf(txRingb));
				uartPutCrLf();
				flg++;
			}
			uartPutString_p("read test: ");
			for(i=0; i<20; ++i)
			{
				data = RingbRead(txRingb);
				if(data != cnt2)
				{
					flg = 2;
					uartPutLine_p("error.");
					uartPrintf_P(PSTR("read %d, expected %d, rp=%d, wp=%d"), data, cnt2, txRingb->rp, txRingb->wp);
					uartPutCrLf();
					//break;
				}
				cnt2++;
			}
			if (flg == 1)
				uartPutLine_p("ok");
			else
				break;

			RingbWrite(txRingb, cnt);
		}
		cnt++;
		//if(cnt == 20)
		//	break; 
		if(cnt == 0)
			break; 
	}
	uartPrintf_P(PSTR("Bytes free/alloc: %d/%d"), RingbBytesFree(txRingb),RingbBytesInBuf(txRingb));
	uartPutCrLf();

	uartPutString_p("last read test: ");
	for(;;)
	{
		data = RingbRead(txRingb);
		if(data < 0)
			break;

		if(data != cnt2)
		{
			uartPutLine_p("error.");
			uartPrintf_P(PSTR("read %d, expected %d, rp=%d, wp=%d"), data, cnt2, txRingb->rp, txRingb->wp);
			uartPutCrLf();
			//break;
		}
		cnt2++;
	}
	if (flg == 1)
		uartPutLine_p("ok");

	uartPrintf_P(PSTR("Bytes free/alloc: %d/%d"), RingbBytesFree(txRingb),RingbBytesInBuf(txRingb));
	uartPutCrLf();

	return flg;
}
#endif

//--------------------------
// TEST X-BUFFER
#ifdef	TEST_XBUF
void TestXbuf()
{
	uint8_t *buf;
	st_buf	p;

	uartPutLine_p("testing XBUF ...");

	buf = alloca(4 * 80);
	p.size = 4 * 80;
	p.rp = 0;
	p.pt = buf;
	for(uint16_t i=0; i<p.size; ++i)
	{
		p.pt[i] = '0' + (i & 0xf);
	}
	uartPutXbuf(&p);

	while(p.stat != 0)
		;

	uartPutLine_p("XBUF sent.");
}
#endif



//------------------------------------------------------------------------
// Initialisierung
//------------------------------------------------------------------------
void initUart()
{
	// UART initialisieren
	UCSRB = _BV(TXEN); 			// TX aktiv
	UCSRB |= _BV(RXEN); 		// RX aktivieren

	UBRRL = (uint8_t)(F_CPU/(BAUD*16L))-1; 			// Baudrate festlegen
	UBRRH = (uint8_t)((F_CPU/(BAUD*16L))-1)>>8; 	// Baudrate festlegen

	UCSRB |= _BV(RXCIE); 		// UART Interrupt bei Datenempfang komplett
	//UCSRB |= _BV(UDRIE); 		// UART Interrupt bei Senderegister leer
	//UCSRB |= _BV(TXCIE); 		// UART Interrupt bei Sendevorgang beendet


	RingbInit(rxRingb, sizeof(rxBuf));
	RingbInit(txRingb, sizeof(txBuf));
	//rcvBcr = 0;


	//uartPrintf_P(PSTR(" Takt: %ld Hz"), (int32_t)F_CPU);
	//uartPutCrLf();


#ifdef	TEST_RB
	RingbTest();
#endif
#ifdef	TEST_XBUF
	TestXbuf();
#endif
}


