//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Track Handler
// Funktion: handle read/write of whole tracks
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#ifndef TRACK_H
#define TRACK_H






// STRUCTS



typedef struct 
{
	uint8_t			stat;				// status: 0=free, 1=filling, 2=alloc, 3=sending
	uint8_t			sector;				// sector#
	uint8_t			buf[256];			// block buffer
} st_blk;

typedef struct 
{
	uint8_t			stat;				// status 
	uint8_t			mode;				// TP_SLOW,TP_BURST,TP_PARALLEL,TP_S1,TP_S2,TP_WARP
	uint8_t			cntBuf;				// number of 256 byte buffer
	uint8_t			cntFree;			// number of free buffer
	uint8_t			drive;				// current drive#
	uint8_t			track;				// current track#
	uint8_t			il1;				// interleave 1
	uint8_t			cntSec;				// number of sectors in this track
	//uint8_t			cntSec2;			// number of sectors in this track
	uint8_t			secIn;				// current sector for reading
	uint8_t			secOut;				// current sector for sending
	uint8_t			toRead;				// number of sectors to read
//	st_DiskBuf 		dbuf;
	uint8_t			bam[5];				// buffer allocation map
	st_blk			buf[0];				// cntBuf * buffer
} st_blkbuf;

#define	BlkBufSize(n)	(n*sizeof(st_blk) + sizeof(st_blkbuf))


// PROTOTYPES
int8_t DimgSearchBlkbuf(st_blkbuf *blkbuf, uint8_t sector);
int8_t DimgReadBlkbuf(st_blkbuf *blkbuf, st_blk	**blk, int8_t sector);
int8_t DimgFreeBlkbuf(st_blkbuf *blkbuf, st_blk	*blk);
int8_t DimgReadTrack(st_blkbuf *blkbuf);
int8_t DimgReadTrackInit(st_dimage *di, st_blkbuf *blkbuf, uint8_t bufAnz, uint8_t drive, uint8_t track, uint8_t interl);



#endif

