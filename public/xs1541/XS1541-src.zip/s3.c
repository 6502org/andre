//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Serial Speeder 2
// Funktion: handle fast communication over serial IEC (OpenCBM S1)
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util\delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//#include "config.h"
#include "compat.h"
#include "timer.h"
#include "main.h"
#include "uart.h"
/*
#include "xmodem.h"
#include "ieee.h"*/
#include "gcr.h"
#include "iec.h"
//#include "floppy.h"
#include "transfer.h"
#include "microcode.h"
#include "s3.h"





// DEFINES

//#define	Init(a)				ParInit(a)
//#define	Read(a)				ParRead(a)
//#define	Write(a,b)			ParWrite(a,b)
//#define	Exit()   			ParExit()



// CONST

//
// S2 CODE (1541, 1571)
//
static prog_uchar mcS3[] = {
 #include "s3.inc"
};

static prog_uchar mcS3_1581[] = {
 #include "s2-1581.inc"
};



// VARS








//
// FOR UART MESSAGES TO VIEW PROTOCOLL
//








//---------------------------
// WRITE BYTE TO FLOPPY
//---------------------------
static int8_t WriteByteNohs(uint8_t data)
{
    int8_t	b, i;

    for(i=4; ; i--) 
	{ 
		b = data & 0x01;
		IecData(!b);
		data >>= 1;

		IecAtn(1);
		while(!(IecDebounce() & IEC_BIT_CLK));			// wait for clock high

		b = data & 0x01;
		IecData(!b);
		data >>= 1;

		IecAtn(0);
        if(i<=1) return 0;

		while((IecDebounce() & IEC_BIT_CLK));			// wait for clock low
    }
	return 0;
}
static int8_t WriteByte(uint8_t data)
{
	WriteByteNohs(data);
	while((IecDebounce() & IEC_BIT_CLK));				// wait for clock low
	IecData(1);
	return 0;
}


//---------------------------
// WRITE 2 BYTE TO FLOPPY
//---------------------------
static int8_t Write2Byte(uint8_t data1, uint8_t data2)
{
	WriteByte(data1);
	WriteByte(data2);
	return 0;
}


//---------------------------
// ANALYZE STREAM FROM FLOPPY
//---------------------------
/*static uint8_t ReadAnalyze(void)
{
	uint8_t buf[129];
	uint8_t	i;

	//uartPutLine_p("# S3 readAnalyze()");

	//start_timeout(TIMEOUT_US(1));

	for(i=0; i<128; ++i)
	{
		//while(!has_timed_out());
		//start_timeout(TIMEOUT_US(1));

		buf[i] = (IEC_PIN  & (IEC_BIT_DATA | IEC_BIT_CLK));

		_delay_us(2);
	}
	sei();

	for(i=0; i<128; ++i)
	{
		uartPrintf_p("%02x ", buf[i]);
	}
	uartPutCrLf();
	return 0;
}*/

//---------------------------
// WAIT FOR CHANGE
//---------------------------
static int16_t ReadSync()
{
	uint8_t	eor, db;

	eor = (IEC_PIN & (IEC_BIT_DATA | IEC_BIT_CLK));

	start_timeout(TIMEOUT_US(17));
	while(1)
	{
		db = (IEC_PIN & (IEC_BIT_DATA | IEC_BIT_CLK));
		if(eor != db)
		{
			//if(eor == (db ^ (IEC_BIT_DATA | IEC_BIT_CLK)))
				return eor;

			//eor = db;
		}
		if(has_timed_out())
			return -1;
	}
}

//---------------------------
// READ BYTE FROM FLOPPY
//---------------------------
static uint8_t Read(void)
{
	//static uint8_t cnt=0;
	int16_t b1,b2, b3, b4;
	uint8_t d;

	//uartPutLine_p("# S3 read()");
	while(!(IecDebounce() & IEC_BIT_CLK));			// wait for clock high

	//uartPutLine_p("# S3 read() CLK1");
	cli();
	IecAtn(1);
	while((IEC_PIN  & IEC_BIT_CLK));			// wait for clock low

	_delay_us(10);
	b1 = ReadSync();

	/*if(cnt++ == 0)
	{
		ReadAnalyze();
		while(1);
	}*/

	_delay_us(14);
	b2 = ReadSync();

	_delay_us(18);
	b3 = ReadSync();

	_delay_us(14);
	b4 = ReadSync();

	sei();
	while((IEC_PIN  & IEC_BIT_CLK));			// wait for clock low
	IecAtn(0);
	sei();

    d  = 0;
	if(!(b1 & IEC_BIT_DATA))
		d |= 0x02;
	if(!(b1& IEC_BIT_CLK))
		d |= 0x08;
	if(!(b2 & IEC_BIT_DATA))
		d |= 0x01;
	if(!(b2 & IEC_BIT_CLK))
		d |= 0x04;
	if(!(b3& IEC_BIT_DATA))
		d |= 0x10;
	if(!(b3 & IEC_BIT_CLK))
		d |= 0x40;
	if(!(b4& IEC_BIT_DATA))
		d |= 0x20;
	if(!(b4 & IEC_BIT_CLK))
		d |= 0x80;

	/*if(b1 < 0 || b2 < 0 || b3 < 0 || b4 < 0)
	{
		uartPutCrLf();
		uartPrintf_p("*S3: b1=%02x ", b1);
		uartPrintf_p("b2=%02x ", b2);
		uartPrintf_p("b3=%02x ", b3);
		uartPrintf_p("b4=%02x ", b4);
		uartPrintf_p("d=%02x ", d);
		uartPutCrLf();
	}*/

    return d;
}



//---------------------------
// READ T/S FROM FLOPPY
//---------------------------
static int8_t Read2Byte(uint8_t *data)
{
	*(data++)	= Read();
	*(data)		= Read();
	return 0;
}





//----------------------------------------------------------------------
// UPLOAD PARALLEL BUS MICROCODE TO FLOPPY
//--------------------------------------------------------
static int8_t Init(int8_t lwTyp, turbo_start start)  
{
	int8_t	rc;

	switch(lwTyp)
	{
	  case DT_1541:
	  case DT_1571:
		rc = McUpload_P(0x0700, mcS3, sizeof(mcS3));
		break;
	  case DT_1581:
		rc = McUpload_P(0x0700, mcS3_1581, sizeof(mcS3_1581));
		break;
	  default:
		return -1;
	}

	uartPutLine_p("starting s3 driver");
	start();

    //cbm_iec_release(fd_cbm, IEC_CLOCK);
	IecClk(1);
    //while(!cbm_iec_get(fd_cbm, IEC_CLOCK));
	while((IecDebounce() & IEC_BIT_CLK));			// wait for clock low
	//cbm_iec_set(fd_cbm, IEC_ATN);
	IecAtn(0);
    //arch_usleep(20000);
	_delay_us(20000);
	return rc;
}

static void Exit(void) 
{
	uartPutLine_p("exit s3 driver");

	WriteByte(0);
	WriteByteNohs(0);
	//arch_usleep(100);
	_delay_us(100);

	IecData(1);
	IecAtn(1);
	IecClk(0);
}




DECLARE_TRANSFER_FUNCS(s3_transfer);
//DECLARE_TRANSFER_FUNCS_EX(pp_transfer, 1, 1);




