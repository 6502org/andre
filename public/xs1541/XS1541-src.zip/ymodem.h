//-------------------------------------------------------------------------
// Titel : XS-1541 - YMODEM PROTOCOL
//-------------------------------------------------------------------------
// Funktion : 	to handle xmodem and ymodem protocoll
//-------------------------------------------------------------------------
// Copyright 2001, 2002 Georges Menie (www.menie.org)
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------


#ifndef XMODEM_H
#define XMODEM_H




//#define TEST_XMODEM_TTY
//#define TEST_XMODEM_TTY2
//#define TEST_XMODEM_SEND
//#define TEST_XMODEM_RECEIVE






#ifdef TEST_XMODEM_TTY
	#define SOH  0x01
	#define STX  0x02
	#define EOT  0x04
	#define ACK  'a'
	#define NAK  'n'
	#define CAN  'c'
	#define CTRLZ 0x1A

	#define DLY_1S 10000
#else
	#define SOH  0x01
	#define STX  0x02
	#define EOT  0x04
	#define ACK  0x06
	#define NAK  0x15
	#define CAN  0x18
	#define CTRLZ 0x1A

	#define DLY_1S 1000
#endif

#define MAXRETRANS 25


#define	SIZE_XMBUF	sizeof(st_xmbuf)



typedef struct 
{
	uint8_t				zst;			// z state	(xmodem handler)
	uint8_t				bst;			// b state	(buffer handler)
	uint16_t 			bufsz;
	uint16_t 			pcnt;
	uint8_t 			crc;
	uint8_t 			eot;			// 1=send EOT, 2=EOT ok, 3=xm error
	uint8_t				packetno;
	uint8_t				retry;
	char 				*fnam;			// file name
	int32_t 			size;			// file size
	char				*dat;			// file Date
	//st_ringbuf 			*rb;
	st_buf				xbuf1;
	st_buf				xbuf2;
	uint8_t				buf1[128 +6];
	uint8_t				buf2[128 +6];
} st_xmbuf;








int8_t XmPrepareTx(st_xmbuf *buf);
void   XmSetHeader(st_xmbuf *buf, char *fnam, int32_t size, char *dat);
int8_t XmLoop(st_xmbuf *xm);
int8_t XmWrite(st_xmbuf *xm, int16_t data);
int8_t XmWriteRB(st_xmbuf *xm, st_ringbuf *rb);
int8_t XmWriteEot(st_xmbuf *xm, st_ringbuf *rb);
int8_t XmWriteCancel(st_xmbuf *xm);


#endif

