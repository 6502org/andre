//-------------------------------------------------------------------------
// Titel:    XS-1541 - GCR Code handler
// Funktion: GCR data encode / decode
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License only.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------


#ifndef GCR_H
#define GCR_H




// DEFINES
#define BLOCKSIZE   256
#define GCRBUFSIZE  326




// STRUCTS




//ENUMS




// PROTOTYPES
int8_t GcrDecode(uint8_t const *gcr, uint8_t *decoded);
int8_t GcrEncode(uint8_t const *block, uint8_t *encoded);


#endif

