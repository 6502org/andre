//-------------------------------------------------------------------------
// Titel:    XS-1541 - IEE488 Handler
// Funktion: handle communication to parallel IEEE-488 floppy drives
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util\delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "config.h"
#include "main.h"
#include "timer.h"
#include "ieee.h"
#include "uart.h"




//
// FOR UART MESSAGES TO VIEW PROTOCOLL
//
//#define DEBUG					// IEEE low level signals
//#define DEBUG1				// IEEE low level 
//#define DEBUG2				// IEEE high level
//#define DEBUGE				// IEEE status / error





#define	ATN_DELAY	80					// Bus delay after ATN in �s



extern int8_t IeeeListPort(void);




// GLOBALS
uint8_t ieee_device;					// current device#
uint8_t ieee_status;					// bit0=timeout out; bit1=timeout in; 
										// bit6=EOI, bit7=device not present
uint8_t ieee_devtyp;					// DT_2030,DT_4040,DT_8050,DT_8250





// STATICS
static int16_t last_byte;				// -1=kein byte








//#define EOI_RECVD       (1<<0)
//#define COMMAND_RECVD   (1<<1)
//#define JIFFY_ACTIVE    (1<<2)
//#define JIFFY_LOAD      (1<<3)


/*struct {
  uint8_t iecflags;
  enum { BUS_IDLE = 0, BUS_ATNACTIVE, BUS_FOUNDATN, BUS_FORME, BUS_NOTFORME, BUS_ATNFINISH, BUS_ATNPROCESS, BUS_CLEANUP, BUS_SLEEP } bus_state;
  enum { DEVICE_IDLE = 0, DEVICE_LISTEN, DEVICE_TALK } device_state;
  uint8_t secondary_address;
} ieee_data;*/




//----------------------------------------------------------------------
// IEEE SET DATA BYTE 
void IeeeSetData(int16_t wo)
{
	if(wo < 0 || wo > 255)
	{
		IEEE_D_DDR	= 0x00;				// INPUT!
		IEEE_D_PORT	= 0xff;
	}
	else
	{
		IEEE_D_DDR	= 0xff;				// OUTPUT!
		IEEE_D_PORT	= wo;
	}
}



//----------------------------------------------------------------------
// IEEE SEND BYTE 
static inline int8_t IeeeOut(uint8_t by)
{
	int8_t 	rc=0;

#ifdef DEBUG1
	uartPrintf_p("IeeeOut(%02x)", by);
	uartPutCrLf();
#endif

	IeeeDav(1);

#ifdef DEBUG
	//IeeeListPort();
	long i;
	for(i=0; i<50000; ++i)
		if(IEEE_NRFD == 0 || IEEE_NDAC == 0)
			break;
	if(i != 0)
	{
		uartPrintf_p("cnt=%ld", i);
		uartPutCrLf();
		IeeeListPort();
	}
#endif

	if(IEEE_NRFD && IEEE_NDAC) 
	{
		ieee_status |= IEEE_ST_DNP;						// !!DEVICE NOT PRESENT

#ifdef DEBUGE
	uartPrintf_p("..ST: device not present!");
	uartPutCrLf();
#endif

		return 1;			
	}

#ifdef DEBUG
	uartPrintf_p("..wait while NRFD");
	uartPutCrLf();
#endif

	while(!IEEE_NRFD);								// WAIT WHILE NRFD

	IEEE_D_DDR = 0xff;
	IEEE_D_PORT = ~by;

	IeeeDav(0);

#ifdef DEBUG
	uartPrintf_p("..DATA!, DAV!  wait while NDAC  ");
	uartPrintf_p("  Data: i%02x, o%02x", IEEE_D_PIN, IEEE_D_PORT);
	if (IEEE_D_DDR)
	{
		uartPutString_p(" -out");
		uartPutCrLf();
	}
	else
	{
		uartPutString_p(" -in");
		uartPutCrLf();
	}
#endif

	ieee_timer = 65;								// 65ms timeout

	while(!IEEE_NDAC)								// WAIT FOR DAC
	{
		if(!ieee_timer)
		{
			ieee_status |= IEEE_ST_WRTO;			// 65ms write timeout
			rc = 1;

#ifdef DEBUGE
	uartPrintf_p("..ST: write timeout!");
	uartPutCrLf();
#endif

			break;
		}
	}

	IeeeDav(1);
	IEEE_D_DDR = 0x00;
	IEEE_D_PORT = 0xff;

#ifdef DEBUG
	uartPrintf_p("..DAV hi");
	uartPutCrLf();
#endif

	return rc;
}

//----------------------------------------------------------------------
// IEEE GET BYTE 
static inline uint8_t IeeeIn()
{
	uint8_t 	rc=0;

#ifdef DEBUG1
	uartPrintf_p("IeeeIn()");
	uartPutCrLf();
#endif

	IeeeNdac(0);					// NDAC low
	IeeeNrfd(1);					// ready for data!
	
	ieee_timer = 65;				// 65ms timeout

#ifdef DEBUG
	uartPrintf_p("..NDAC!, NRFD hi,  wait for DAV");
	uartPutCrLf();
#endif

	while(IEEE_DAV)					// WAIT FOR DAV
	{
		if(!ieee_timer)
		{
			ieee_status |= IEEE_ST_RDTO;	// read timeout

			IeeeNdac(0);			// NDAC low
			IeeeNrfd(0);			// NRFD low

#ifdef DEBUGE
	uartPrintf_p("..ST: read timeout!");
	uartPutCrLf();
#endif

			return 0;
		}
	}
#ifdef DEBUG
	uartPrintf_p("..NRFD!");
	uartPutCrLf();
#endif
	IeeeNrfd(0);					// NRFD low

	if(!IEEE_EOI)
	{
#ifdef DEBUG
	uartPrintf_p("..ST: EOI");
	uartPutCrLf();
#endif
		ieee_status |= 0x40;		// last byte - EOI
	}

#ifdef DEBUG
	uartPrintf_p("..readig DATA  ");
	uartPrintf_p("  Data: i%02x, o%02x", IEEE_D_PIN, IEEE_D_PORT);
	if (IEEE_D_DDR)
		uartPutLine_p(" -out");
	else
		uartPutLine_p(" -in");
#endif
	rc = ~IEEE_D_PIN;

#ifdef DEBUG
	uartPutLine_p("..NDAC hi, waiting while DAV");
#endif
	IeeeNdac(1);					// data accepted!

	while(!IEEE_DAV);				// WAIT FOR DAV HIGH

#ifdef DEBUG
	uartPutLine_p("..NDAC");
#endif
	IeeeNdac(0);					// NDAC low
	return rc;
}


//----------------------------------------------------------------------
// IEEE SEND ATN
static inline int8_t IeeeAtnOut(uint8_t by)
{
	int8_t	rc;

#ifdef DEBUG1
	uartPutLine_p("IeeeAtnOut(%02x)", by);
#endif

	while(1) 
	{
		IeeeNrfd(1);
		IeeeNdac(1);

#ifdef DEBUG
	uartPutLine_p("..NRFD hi, NDAC hi");
#endif

		if(last_byte >= 0)
		{
			// SEND LAST BYTE WITH EOI

#ifdef DEBUG
	uartPutLine_p("..send lastbyte - EOI!");
#endif

			IeeeEoi(0);
			rc = IeeeOut(last_byte);
			IeeeEoi(1);
			last_byte = -1;

#ifdef DEBUG
	uartPutLine_p("..EOI hi!");
#endif
		}
		else
		{

#ifdef DEBUG
	uartPutLine_p("..wait while DAV", by);
#endif

			ieee_timer = 255;							// 255ms timeout

			while(!IEEE_DAV)							// WAIT WHILE DAV 
			{
				if(!ieee_timer)
				{
					ieee_status |= IEEE_ST_ATTO;	// ATN-OUT timeout

#ifdef DEBUG
	uartPutLine_p("..ST: ATN timeout!");
#endif

					return 1;
				}
			}
		}

#ifdef DEBUG
	uartPutLine_p("..ATN!");
#endif
		IeeeAtn(0);									// SET ATN

		if(IeeeOut(by)) break;

		return 0;
	}

#ifdef DEBUG
	uartPutLine_p("..IeeeAtnOut() aborted, ATN hi");
#endif

	IeeeAtn(1);									// ATN hi
	return 1;
}

//----------------------------------------------------------------------
// IEEE SEND LISTEN SECONDARY ADDRESS
static inline int8_t IeeeSecListen(uint8_t sa)
{
	int8_t	rc;

#ifdef DEBUG2
	uartPrintf_p("IeeeSecListen(%02x)", sa);
	uartPutCrLf();
#endif

	rc = IeeeOut(sa);
	IeeeAtn(1);									// SET ATN HI
	return rc;
}


//----------------------------------------------------------------------
// IEEE SEND TALK SECONDARY ADDRESS
static inline int8_t IeeeSecTalk(uint8_t sa)
{
	int8_t	rc;

#ifdef DEBUG2
	uartPrintf_p("IeeeSecTalk(%02x)", sa);
	uartPutCrLf();
#endif

	if(!(rc = IeeeOut(sa)))
	{
		IeeeNrfd(0);
		IeeeNdac(0);
	}
	IeeeAtn(1);									// SET ATN HI
	return rc;
}



//----------------------------------------------------------------------
// IEEE SEND BYTE 
int8_t IeeeBsout(uint8_t by)
{
#ifdef DEBUG2
	uartPrintf_p("IeeeBsout(%02x)", by);
	uartPutCrLf();
#endif
	if(last_byte >= 0)
	{
		// SEND BYTE IN BUFFER
		if(IeeeOut(last_byte)) 
			return 1;
	}
	last_byte = by;
	return 0;
}

//----------------------------------------------------------------------
// IEEE GET BYTE 
uint8_t IeeeBasin()
{
#ifdef DEBUG2
	uartPrintf_p("IeeeBasin()");
	uartPutCrLf();
#endif
	if(ieee_status == 0)
	{
		return IeeeIn();
	}
#ifdef DEBUGE
	else
	{
		uartPrintf_p("..ST=%02x", ieee_status);
		uartPutCrLf();
	}
#endif
	return 0;
}


//----------------------------------------------------------------------
// UNTALK
int8_t IeeeUntalk(void)
{
	int8_t 	rc;

#ifdef DEBUG2
	uartPutLine_p("IeeeUnTalk()");
#endif
	rc = IeeeAtnOut(0x5f);

#ifdef DEBUG
	uartPutLine_p("..ATN hi");
#endif
	IeeeAtn(1);									// SET ATN HI
	_delay_us(ATN_DELAY);
	return rc;
}

//----------------------------------------------------------------------
// UNLISTEN
int8_t IeeeUnlisten(void)
{
	int8_t 	rc;

#ifdef DEBUG2
	uartPutLine_p("IeeeUnListen()");
#endif
	rc = IeeeAtnOut(0x3f);

#ifdef DEBUG
	uartPutLine_p("..ATN hi");
#endif	
	IeeeAtn(1);									// SET ATN HI
	_delay_us(ATN_DELAY);
	return rc;
}


//----------------------------------------------------------------------
// LISTEN
int8_t IeeeListen(uint8_t sa)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_p("IeeeListen(%02x)", sa);
	uartPutCrLf();
#endif

	if(IeeeAtnOut(0x20 | (ieee_device & 0xf)))
		rc = 1;
	else if(IeeeSecListen(0x60 | (sa & 0x1f)))
		rc = 1;
	return rc;
}

//----------------------------------------------------------------------
// TALK
int8_t IeeeTalk(uint8_t sa)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_p("IeeeTalk(%02x)", sa);
	uartPutCrLf();
#endif

	if(IeeeAtnOut(0x40 | (ieee_device & 0xf)))
		rc = 1;
	else if(IeeeSecTalk(0x60 | (sa & 0x1f)))
		rc = 1;
	return rc;
}

//----------------------------------------------------------------------
// OPEN
int8_t IeeeOpen(uint8_t sa, char *s)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_p("IeeeOpen(%02x, \"", sa);
	uartPutString(s);
	uartPutString_p("\")");
	uartPutCrLf();
#endif

	if(IeeeAtnOut(0x20 | (ieee_device & 0xf)))
		rc = 1;
	else if(IeeeSecListen(0xF0 | (sa & 0x0f)))
		rc = 1;
	else 
	{
		while(*s)
		{
			if(IeeeBsout(*s)) 
			{
				rc = 1;
				break;
			}
			++s;
		}
		IeeeUnlisten();
	}
	return rc;
}

//----------------------------------------------------------------------
// CLOSE
int8_t IeeeClose(uint8_t sa)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_p("IeeeClose(%02x)", sa);
	uartPutCrLf();
#endif

	if(IeeeAtnOut(0x20 | (ieee_device & 0xf)))		// LISTEN
		rc = 1;
	else if(IeeeSecListen(0xE0 | (sa & 0x1f)))		// CLOSE SA
		rc = 1;

	IeeeUnlisten();
	return rc;
}



//----------------------------------------------------------------------
// RESET IEC
void IeeeIFC(void)
{
	IEEE_PORT &= ~IEEE_PIN_IFC;
	IEEE_DDR  |= IEEE_PIN_IFC;
	_delay_ms(250);
	IEEE_DDR  &= ~IEEE_PIN_IFC;
	IEEE_PORT |= IEEE_PIN_IFC;
}



/* ------------------------------------------------------------------------- */
/*  Initialization and main loop                                             */
/* ------------------------------------------------------------------------- */


void InitIeee(void) {

#ifdef IEC_SEPARATE_OUT
  /* Set up the port: Output bits as output, all others as input */
  //IEC_DDR  =            IEC_OBIT_ATN | IEC_OBIT_CLOCK | IEC_OBIT_DATA | IEC_OBIT_SRQ;
  /* Enable pullups on the input pins and set the output lines to high */
  //IEC_PORT = (uint8_t)~(IEC_OBIT_ATN | IEC_OBIT_CLOCK | IEC_OBIT_DATA | IEC_OBIT_SRQ);
#else
  /* Pullups would be nice, but AVR can't switch from */
  /* low output to hi-z input directly                */
#ifdef IEEE_TEST
  IEEE_PORT		|= (IEEE_BIT_EOI | IEEE_BIT_DAV | IEEE_BIT_NRFD | IEEE_BIT_NDAC);
  IEEE_A_PORT	|= (IEEE_BIT_ATN);
#else
  IEEE_PORT 	&= ~(IEEE_BIT_EOI | IEEE_BIT_DAV | IEEE_BIT_NRFD | IEEE_BIT_NDAC);
  IEEE_A_PORT 	&= ~(IEEE_BIT_ATN);
#endif
  IEEE_DDR		&= ~(IEEE_BIT_EOI | IEEE_BIT_DAV | IEEE_BIT_NRFD | IEEE_BIT_NDAC);
  IEEE_A_DDR	&= ~(IEEE_BIT_ATN);
#endif



  	ieee_device = 8;					// DEFAULT DEVICE_SELECT;
	ieee_devtyp = DT_8250;
	last_byte 	= -1;



#ifdef DEBUG
	uartPrintf_p("InitIeee()");
	uartPutCrLf();
#endif
}






//----------------------------------------------------------------------
// MAINLOOP
void IeeeMain()
{
}
