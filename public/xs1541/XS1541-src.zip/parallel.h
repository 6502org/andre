//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Parallel Handler 
// Funktion: handle communication to parallel floppy drives (SpeedDos cable)
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#ifndef PARALLEL_H
#define PARALLEL_H





// DEFINES







// STRUCTS





// PROTOTYPES
int8_t ParSectorCnt(uint8_t tr);

void ParWriteByte(uint8_t data1);
void ParWrite(uint8_t data1, uint8_t data2);
void ParWriteTrackMap(uint8_t tr, uint8_t *trackmap, uint8_t count);

void ParRead(uint8_t *data);
uint8_t ParReadByte(void);


int8_t ParReadBlk(uint8_t *buf);
int8_t ParReadGCR(uint8_t *buf);

void InitPar(void);



#endif
