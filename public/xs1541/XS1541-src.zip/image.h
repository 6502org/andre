//-------------------------------------------------------------------------
// Titel:	 XS-1541 - CBM Image File handling
// Funktion: handle read and write of floppy disk imagefiles
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#ifndef DIMAGE_H
#define DIMAGE_H




//#define TEST_DIMAGE

#define	MAX_READ_ERROR	32



//enum filetypes {FT_P00,FT_T64,FT_PRG,FT_D64,FT_D71,FT_D80,FT_D81,FT_D82,FT_X64,FT_G64,
//				FT_D64_40, FT_D64_42, FT_D64X, FT_D64_40X, FT_D64_42X


// STRUCTS




typedef struct 
{
	uint8_t			fileType;			// FT_*			- Basetype, D64
	uint8_t			fileOption;			// FT_*			- option, D64-40
	uint8_t			trkStart;			// first block (header)
	uint8_t			secStart;			// first block (header)
	uint8_t			trkDir;				// first directory block
	uint8_t			secDir;				// first directory block
	uint8_t			trkBAM;				// first BAM block
	uint8_t			secBAM;				// first BAM block
	uint8_t			tracks;				// number of tracks
	uint16_t		sectors;			// number of sectors
	uint8_t			curTrack;			// current track
	uint8_t			curSector;			// current sector
	uint8_t			curSectors;			// current sector
	uint8_t			curDrive;			// current drive (0: or 1:)
	int8_t 			burstOpt;			// Burst Option (-1 = default)
	uint8_t			diskName[16];		// disk name (in PETASCII, padded with $A0)
	uint16_t		id;					// disk ID
	uint8_t			errorCnt;			// Error count
	uint16_t		errorBuf[MAX_READ_ERROR];	// Error Buffer
	//uint8_t		bamSector;			// BAM sector
	uint8_t			*bam;				// BAM Block
	uint8_t			*tblSecCnt;			// sectors per track table (PGMSPACE!)
} st_dimage;


// HEADER BLOCKS

typedef struct 
{
	// ON TRACK 18/0 
	uint8_t			trkDir;				// track of directory	(takes always 18/1)
	uint8_t			secDir;				// sector of directory
	uint8_t			dos;				// $41 ("A") - DOS format version
	uint8_t			fil03;				// unused
	uint8_t			bam[140];			// BAM (35 tracks * 4 bytes)
	uint8_t			diskName[16];		// disk name (in PETASCII, padded with $A0)
	uint8_t			fil04;				// $A0
	uint8_t			fil05;				// $A0
	uint16_t		id;					// disk ID
	uint8_t			fil06;				// $A0
	uint16_t		ver;				// DOS version "2A"
	uint8_t			fil07[4];			// $A0
	uint8_t			fil08;				// $00
	uint8_t			dolphin[20];		// BAM track 36 - 40
	uint8_t			speedDos[20];		// BAM track 36 - 40
} st_d64_header;

typedef struct 
{
	// ON TRACK 18/0 
	uint8_t			trkDir;				// track of directory	(takes always 18/1)
	uint8_t			secDir;				// sector of directory
	uint8_t			dos;				// $41 ("A") - DOS format version
	uint8_t			dbl;				// $00=sigle side, $80-double side disk
	uint8_t			bam[140];			// BAM (35 tracks * 4 bytes)
	uint8_t			diskName[16];		// disk name (in PETASCII, padded with $A0)
	uint8_t			fil04;				// $A0
	uint8_t			fil05;				// $A0
	uint16_t		id;					// disk ID
	uint8_t			fil06;				// $A0
	uint16_t		ver;				// DOS version "2A"
	uint8_t			fil07[4];			// $A0
	uint8_t			fil08[50];			// unused ($00)
	uint8_t			freeSec[35];		// Free sector count for tracks 36-70
} st_d71_header;

typedef struct 
{
	// ON TRACK 53/0 (TRACK 18 OTHER SIDE)
	uint8_t			bam[140];			// BAM (35 tracks * 4 bytes)
} st_d71_bam2;

typedef struct 
{
	uint8_t			trkDir;				// track of directory	(takes always 18/1)
	uint8_t			secDir;				// sector of directory
	uint8_t			dos;				// $41 ("A") - DOS format version
	uint8_t			fil03;				// unused
	uint8_t			bam[140];			// BAM (35 tracks * 4 bytes)
	uint8_t			bam2[20];			// BAM track 36 - 40
	uint8_t			diskName[16];		// disk name (in PETASCII, padded with $A0)
	uint8_t			fil04;				// $A0
	uint8_t			fil05;				// $A0
	uint16_t		id;					// disk ID
	uint8_t			fil06;				// $A0
	uint16_t		ver;				// DOS version "2A"
	uint8_t			fil07[4];			// $A0
	uint8_t			fil08;				// $00
} st_prologic_header;



typedef struct 
{
	// ON TRACK 40/0 
	uint8_t			trkDir;				// track of directory	(takes always 40/3)
	uint8_t			secDir;				// sector of directory
	uint8_t			dos;				// $44 ("D") - DOS format version (=1541)
	uint8_t			fil02;				// reserved $00
	uint8_t			diskName[16];		// disk name (in PETASCII, padded with $A0)
	uint16_t		fil05;				// $A0,$A0
	uint16_t		id;					// disk ID
	uint8_t			fil06;				// $A0
	uint16_t		ver;				// DOS version "2D"
	uint8_t			fil07[4];			// $A0
} st_d81_header;

typedef struct 
{
	// ON TRACK 39/0 
	uint8_t			trkBAM;				// track of BAM
	uint8_t			secBAM;				// sector of BAM
	uint8_t			dos;				// $43 ("C") - DOS format version
	uint8_t			fil02;				// reserved
	uint16_t		fil03;				// unused
	uint8_t			diskName[16];		// disk name (in PETASCII, padded with $A0)
	uint8_t			fil05;				// $A0
	uint16_t		id;					// disk ID
	uint8_t			fil06;				// $A0
	uint16_t		ver;				// DOS version "2C"
	uint8_t			fil07[4];			// $A0
} st_d82_header;


// BAM BLOCKS

typedef struct 
{
	// ON TRACK 40/1,2 
	uint8_t			trkNx;				// next track
	uint8_t			secNx;				// next sector 
	uint8_t			ver;				// DOS version "D"
	uint8_t			compl;				// One's complement of version# ($BB)reserved
	uint16_t		id;					// disk ID
	uint8_t			io;					// IO byte. bit7:verify,bit6:check header CRC
	uint8_t			autoBoot;			// Auto-boot-loader flag 
	uint8_t			fil01[8];			// reserved
	uint8_t			bam[6*40];			// 40 tracks	(40/1:1..40, 40/2:41..80)
} st_d81_BAM;

typedef struct 
{
	uint8_t			trkNx;				// next track
	uint8_t			secNx;				// next sector 
	uint8_t			ver;				// DOS version "C"
	uint8_t			fil01;				// reserved
	uint8_t			trkLow;				// lowest track for this BAM		(1)
	uint8_t			trkHigh;			// highest track +1 for this BAM	(51)
	uint8_t			bam[5*50];			// 50 tracks	(1 .. 50)
} st_d82_BAM;


// DIRECTORY ENTRY

typedef struct 
{
	uint8_t			trkNx;				// next track
	uint8_t			secNx;				// next sector 
	uint8_t			fileType;			// 00=Scratched,80=DEL,81=SEQ,82=PRG,83=USR,84=REL
										// Bit 0-3:filetype,Bit 6:Locked flag (">"),
										// Bit 7:Closed flag  (produces  "*", or "splat")
	uint8_t			trkFil;				// file 1. blk track
	uint8_t			secFil;				// file 1. blk sector 
	uint8_t			fileName[16];		// file name (in PETASCII, padded with $A0)
	uint8_t			trkSide;			// track side blk	(REL files)
	uint8_t			secSide;			// sector side blk 	(REL files)
	uint8_t			recLen;				// record length 	(REL files)
	uint8_t			fil01[6];			// unused
	uint16_t		size;				// File size in sectors, low/high byte  order
} st_dirEntry;





#define DimgTracks(di)			(di->tracks)				// number of tracks
#define DimgSectors(di)			(di->sectors)				// number of sectors on disk
#define DimgSizeOfBAM(di)		(DimgSectors(di) / 8)		// number of Bytes for BAM



// PROTOTYPES
int8_t DimgTest(uint8_t ft);


int8_t GetDefImageType(void);
int8_t GetDefDeviceType(void);
int8_t GetDeviceType(void);
int8_t InitFloppy(int8_t);

int8_t DimgReadBAM(st_dimage *di, uint8_t *buf, uint16_t size);
int8_t DimgReadHeader(st_dimage *di);
//uint8_t DimgTracks(st_dimage *di);
//uint16_t DimgSectors(st_dimage *di);
int8_t DimgGetBAM(st_dimage *di, uint8_t tr);
int8_t DimgIsSectorFree(st_dimage *di, uint8_t tr, uint8_t se);
int8_t DimgSectorCnt(st_dimage *di, uint8_t tr);
int16_t DimgSectorNo(st_dimage *di, uint8_t tr, uint8_t se);
int8_t ListBAM(uint8_t drive, uint8_t ft, uint8_t bam, int8_t option);
int8_t Backup(uint8_t drive, uint8_t ft, uint8_t par, int8_t burstopt);
int8_t DimgInit(st_dimage *di, uint8_t drive, uint8_t ft, int8_t burstopt);



#endif

