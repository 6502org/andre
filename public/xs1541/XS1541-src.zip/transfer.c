//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Transfer Handler
// Funktion: handle data transfer to and from floppy drive
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util\delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//#include "config.h"
#include "compat.h"
//#include "timer.h"
#include "main.h"
#include "uart.h"
/*#include "xmodem.h"
#include "ieee.h"*/
#include "gcr.h"
#include "iec.h"
#include "floppy.h"
#include "image.h"
#include "transfer.h"
#include "microcode.h"





// DEFINES
#define DEBUG



// CONST
static const char d71_sector_map[] PROGMEM =
{ 0,
  21, 21, 21, 21, 21, 21, 21, 21, 21, 21,
  21, 21, 21, 21, 21, 21, 21, 19, 19, 19,
  19, 19, 19, 19, 18, 18, 18, 18, 18, 18,
  17, 17, 17, 17, 17,
  21, 21, 21, 21, 21, 21, 21, 21, 21, 21,
  21, 21, 21, 21, 21, 21, 21, 19, 19, 19,
  19, 19, 19, 19, 18, 18, 18, 18, 18, 18,
  17, 17, 17, 17, 17
};




// VARS





extern tfer_funcs tfer_pp_transfer;
extern tfer_funcs tfer_s1_transfer;
extern tfer_funcs tfer_s2_transfer;
extern tfer_funcs tfer_s3_transfer;







//
// FOR UART MESSAGES TO VIEW PROTOCOLL
//




//----------------------------------------
// DEBOUNCE IEC IO
//----------------------------------------
/*static uint8_t IecDebounce(void) 
{
	uint8_t tmp;

	do {
    	tmp = IEC_PIN & (IEC_BIT_DATA | IEC_BIT_CLK);
		_delay_us(1);
	} while (tmp != (IEC_PIN & (IEC_BIT_DATA | IEC_BIT_CLK)));
	return tmp;
}*/


//static int8_t start_turbo(int8_t fd, int8_t drive)
static int8_t start_turbo()
{
	uartPutLine_p("start()");
    return SendCmd_P(PSTR("U4"));
}



//----------------------------------------------------------------------
// CALC NUMBER OF SECTORS BY TRACK 
//----------------------------------------------------------------------
int8_t TferSectorCnt(uint8_t tr)
{
	if(tr == 0)
		return -1;

	if(tr > sizeof(d71_sector_map))
		return 17;

	return pgm_read_byte(d71_sector_map +tr);
}


//---------------------------
// WRITE BYTE TO FLOPPY
//---------------------------
static inline int8_t TferWriteByte(tfer_funcs *tfer, uint8_t data)
{
	return tfer->WriteByte(data);
}

//---------------------------
// WRITE 2 BYTES TO FLOPPY
//---------------------------
static inline int8_t TferWrite2Byte(tfer_funcs *tfer, uint8_t data1, uint8_t data2)
{
	return tfer->Write2Byte(data1, data2);
}

//---------------------------
// READ 2 BYTE FROM FLOPPY
//---------------------------
static inline int8_t TferRead2Byte(tfer_funcs *tfer, uint8_t *data)
{
	return tfer->Read2Byte(data);
}


//---------------------------
// READ BYTE FROM FLOPPY
//---------------------------
uint8_t TferReadByte(tfer_funcs *tfer)
{
	return tfer->Read();
}



//---------------------------
// READ BUFFER FROM FLOPPY
//---------------------------
static inline int8_t TferReadBuf(tfer_funcs *tfer, uint8_t *buf, uint16_t	cnt)
{
	while(cnt > 1)
	{
		tfer->Read2Byte(buf);
		cnt -= 2;
		buf += 2;
	}
	return 0;
}



//---------------------------
// READ BLOCK FROM FLOPPY
//---------------------------
/*int8_t TferReadBlk(tfer_funcs *tfer, uint8_t *buf)
{
	return TferReadBuf(tfer, buf, BLOCKSIZE);
}*/



//----------------------------------------------------------------------
// TURBO READ BLOCK
//----------------------------------------------------------------------
void TferSetNextBlk(tfer_data *tfer)
{
	if(--(tfer->cntSe))
	{
		tfer->sector += tfer->interleave;

		while(1)
		{
			while(tfer->sector >= tfer->cntSeTrack)
				tfer->sector -= tfer->cntSeTrack;

			if(NEED_SECTOR(tfer->trackMap[tfer->sector]))
				break;

			tfer->sector++;
		}
	}
}


//----------------------------------------------------------------------
// STANDARD READ BLOCK
//----------------------------------------------------------------------
int8_t TferStdReadBlk(tfer_data *tfer, uint8_t *se, uint8_t *buf)
{
	int8_t status;



	tfer->f.Write2Byte(tfer->track, *se);
	status = tfer->f.Read();

	TferReadBuf(&tfer->f, buf, BLOCKSIZE);

	TferSetNextBlk(tfer);
    return status;
}


//----------------------------------------------------------------------
// TURBO READ BLOCK
//----------------------------------------------------------------------
int8_t TferTurboReadBlk(tfer_data *tfer, uint8_t *se, uint8_t *buf)
{
	int8_t status;

#ifdef DEBUG
	//uartPutLine_p("turbo read block.");
#endif

	*se = tfer->sector;
	//uartPrintf_p("tr/se:%d ", tfer->track);
	//uartPrintf_p("/%d ", tfer->sector);

	tfer->f.Write2Byte(tfer->track, tfer->sector);
	_delay_us(100);
	status = tfer->f.Read();

/*	uint8_t buf2[2];

	tfer->f.Read2Byte(buf2);
	uartPrintf_p("b1=%d ", buf2[0]);
	uartPrintf_p("b2=%d ", buf2[1]);

	status = 0;*/


	TferReadBuf(&tfer->f, buf, BLOCKSIZE);

	TferSetNextBlk(tfer);
    return status;
}



//----------------------------------------------------------------------
// START WARP READ TRACK (GCR DATA)
//----------------------------------------------------------------------
int8_t TferWarpReadTrack(tfer_data *tfer)
{
	uint8_t	i;
    uint8_t c;

#ifdef DEBUG
	//uartPutLine_p("warp read track.");
#endif

	// WRITE TRACK-MAP TO FLOPPY
	tfer->f.Write2Byte(tfer->track, tfer->cntSe);
    for(i = 0; i < TferSectorCnt(tfer->track); i++)
    {
        c = !NEED_SECTOR(tfer->trackMap[i]);
        tfer->f.WriteByte(c);
    }
	return 0;
}


//----------------------------------------------------------------------
// WARP READ GCR BLOCK
// reads next available block. block # in <se>, block in <buf>
//----------------------------------------------------------------------
int8_t TferWarpReadBlk(tfer_data *tfer_d, uint8_t *se, uint8_t *buf)
{
	uint8_t st;

#ifdef DEBUG
	//uartPutLine_p("warp read block.");
#endif

	*se	= tfer_d->f.Read();
	st	= tfer_d->f.Read();
    if(st) 
	{
        return st;
    }

	TferReadBuf(&tfer_d->f, buf, GCRBUFSIZE);
	if(tfer_d->gcrDecode)
		GcrDecode(buf, buf);

	return 0;
}
 


//----------------------------------------------------------------------
// TRANSF SETTINGS: devicetype, device#, drive#
//----------------------------------------------------------------------
int8_t TferSetDevice(tfer_data *tfer_d, int8_t devtyp, int8_t device, int8_t drive)
{
	if(devtyp >= 0)
		tfer_d->devtyp	= devtyp;						// device type
	if(device >= 0)
		tfer_d->device	= device;						// Device #
	if(drive >= 0)
		tfer_d->drive	= drive;						// Drive #

	return 0;
}

//----------------------------------------------------------------------
// TRANSF SETTINGS: GCR flag
//----------------------------------------------------------------------
int8_t TferSetGcrDecode(tfer_data *tfer_d, int8_t gcrflg)
{
	tfer_d->gcrDecode	= gcrflg;					// 1=true; WarpMode only
	return 0;
}

//--------------------------------------------------------
// UPLOAD MICROCODE TO FLOPPY AND START
//--------------------------------------------------------
int8_t TferInit(tfer_data *tfer_d, int8_t bus, int8_t turbo, int8_t interleave)
{
	tfer_funcs	*tfer;

	if(turbo >= 0)
		tfer_d->turbo		= turbo;				// TP_WARP,TP_TURBO,TP_SLOW
	if(bus >= 0)
		tfer_d->bus			= bus;					// TP_PARALLEL,TP_S1,TP_S2,TP_BURST,TP_SLOW
	if(interleave >= 0)
		tfer_d->interleave	= interleave;			// sector interleave

	//
	// BUS FUNCTION
	//
	switch(bus)
	{
	  case TP_PARALLEL:
		tfer = &tfer_pp_transfer;
		break;

	  case TP_S1:
		tfer = &tfer_s1_transfer;
		break;

	  case TP_S2:
		tfer = &tfer_s2_transfer;
		break;

	  case TP_S3:
		tfer = &tfer_s3_transfer;
		break;
/*
	  case TP_BURST:
		tfer = &tfer_burst_transfer;
		break;*/

	  default:
		tfer = NULL;
		break;
	}
	if(tfer == NULL)
	{
		tfer_d->f.Init = NULL;
	}
	else
	{
		memcpy_P(&tfer_d->f, tfer, sizeof(tfer_funcs));
		tfer = &tfer_d->f;
	}

	//
	// TURBO MODE FUNCTION
	//
	switch(turbo)
	{
	  case TP_WARP:
		tfer_d->ReadBlock = TferWarpReadBlk;
		break;

	  case TP_TURBO:
		tfer_d->ReadBlock = TferTurboReadBlk;
		break;

	  case TP_BURSTLOAD:
		//tfer_d->ReadBlock = TferBurstReadBlk;
		//break;

	  default:
		tfer_d->ReadBlock = TferStdReadBlk;
		break;
	}

	tfer_d->gcrDecode	= 0;						// 1=true; WarpMode only
	tfer_d->fBAM		= 0;
	tfer_d->devtyp		= GetDeviceType();			// device type
	tfer_d->device		= GetDeviceNum();			// Device #
	tfer_d->drive		= 0;						// Drive #
	tfer_d->dump		= TP_NODUMP;

	if(tfer == NULL)
	{
		return -1;									// ERROR - no Trans Module
	}
	return 0;
}




//--------------------------------------------------------
// START TRANSFER: UPLOAD MICROCODE TO FLOPPY AND START
//--------------------------------------------------------
int8_t TferStart(tfer_data *tfer_d) 
{
	tfer_funcs	*tfer;

	tfer = &tfer_d->f;
	if(tfer->Init == NULL)
		return -1;							// ERROR - no Trans Module

	switch(tfer_d->turbo)
	{
	  case TP_WARP:
		SendCmd_P(PSTR("I"));
		if(McUploadWarpRd(tfer_d->devtyp))
			return 1;

#ifdef DEBUG
	uartPutLine_p("MC Warp upload ok.");
#endif
		break;

 	  case TP_TURBO:
		SendCmd_P(PSTR("I"));
		if(McUploadTurboRd(tfer_d->devtyp))
			return 1;

#ifdef DEBUG
	uartPutLine_p("MC Turbo upload ok.");
#endif		
		break;

 	  case TP_TEST:
		if(McUploadTest(tfer_d->devtyp))
			return 1;

#ifdef DEBUG
	uartPutLine_p("MC Bustest upload ok.");
#endif		
		break;

	  default:
		break;
	}

	if(tfer->Init(tfer_d->devtyp, start_turbo))				//McUpload_P(0x0700, mcPP1541, sizeof(mcPP1541));
		return -1;

#ifdef DEBUG
	uartPutLine_p("MC Trans upload ok.");
#endif

	return 0;
}




//--------------------------------------------------------
// STOP TRANSFER: STOP MICROCODE 
//--------------------------------------------------------
int8_t TferStop(tfer_data *tfer) 
{
	//tfer_funcs	*tfer;

	tfer->f.Exit();								// END 
	return 0;
}











//----------------------------------------------------------------------
// TRANSF SETTINGS: set track map
//----------------------------------------------------------------------
int8_t TferSetTrackMap(tfer_data *tfer_d, uint8_t tr)
{
	int8_t cnt;
	int8_t cntSe = TferSectorCnt(tr);

	tfer_d->track		= tr;
	tfer_d->cntSeTrack	= cntSe;

	if(tfer_d->fBAM == 0)
	{
#ifdef DEBUG
		//uartPutLine_p("set trackmap to default.");
#endif
		
		memset(tfer_d->trackMap, bs_must_copy, MAX_SECTORS);
		tfer_d->cntSe = cntSe;
	}
	else
	{
		// TRACKMAP MUST FILLED BEVORE!!
		cnt = 0;
		for(int8_t i = 0; i < cntSe; ++i)
		{
			if(NEED_SECTOR(tfer_d->trackMap[i]))
				++cnt;
		}
		tfer_d->cntSe = cnt;
	}
	return 0;
}


//----------------------------------------------------------------------
// READ BLOCK (FIRST PREPARE READ TRACK!)
//----------------------------------------------------------------------
int8_t TferReadBlk(tfer_data *tfer, uint8_t *se, uint8_t *buf)
{ 
	int8_t status;

	//tfer_data tfer;
	if(tfer->cntSe == 0)
	{
		return -1;
	}
	if(tfer->ReadBlock == NULL)
	{
#ifdef DEBUG
	uartPutLine_p("no turbo function");
#endif
		return -2;
	}

	status = tfer->ReadBlock(tfer, se, buf);
	if(status)
	{
		tfer->trackMap[*se] = bs_error;
	}
	else
	{
		tfer->trackMap[*se] = bs_copied;
	}
	return status;
}


//----------------------------------------------------------------------
// PREPARE READ TRACK 
//----------------------------------------------------------------------
int8_t TferReadTrack(tfer_data *tfer_d, uint8_t tr)
{ 
	tfer_funcs	*tfer;

	tfer = &tfer_d->f;

#ifdef DEBUG
	//uartPutLine_p("Start Read Track");
#endif

	TferSetTrackMap(tfer_d, tr);

	switch(tfer_d->turbo)
	{
	  case TP_WARP:
		return TferWarpReadTrack(tfer_d);

//	  case TP_TURBO:
	  default:
		tfer_d->sector = 0;
		break;
	}
	return 0;
}



#ifdef TEST_TRANS
//----------------------------------------------------------------------
// TEST WARP RD
//----------------------------------------------------------------------
int8_t TferTestRdDisc(tfer_data *tfer)
{ 
	uint8_t blk[GCRBUFSIZE];
	//uint8_t blk2[BLOCKSIZE];
	int8_t	cnt, rc;
	uint8_t	tr, se;

	uartPutLine_p("# Test read disk");
	uartPrintf_p("devtyp=%d; ", tfer->devtyp);
	uartPrintf_p("bus=%d; ", tfer->bus);
	uartPrintf_p("turbo=%d; ", tfer->turbo);
	uartPrintf_p("dump=%d; ", tfer->dump);
	uartPrintf_p("interl=%d; ", tfer->interleave);
	uartPrintf_p("unit=%d; ", tfer->device);
	uartPrintf_p("drive=%d; ", tfer->drive);
	uartPrintf_p("gcr=%d; ", tfer->gcrDecode);
	uartPrintf_p("bam=%d", tfer->fBAM);
	uartPutCrLf();

	if(TferStart(tfer))
		return 1;

	for(tr=1; tr<=35; ++tr)
	{
		cnt	= TferSectorCnt(tr);

		if(TferReadTrack(tfer, tr))
		{
			break;
		}

		uartPrintf_p("track %d: ", tr);
		while(cnt--)
		{
			if((rc = TferReadBlk(tfer, &se, blk)))
			{
				uartPrintf_p("se:%d ", se);
				uartPrintf_p("err:%d ", rc);
				break;
			}
			else
			{
				uartPrintf_p("%d ", se);
				//GcrDecode(blk, blk2);
			}
		}
		uartPutCrLf();
		//break;
	}

	TferStop(tfer);
	return 0;
}
//----------------------------------------------------------------------
// TEST BUS TRANSFER
//----------------------------------------------------------------------
int8_t TferTest(tfer_data *tfer)
{ 
	uint8_t blk[GCRBUFSIZE];
	uint8_t		b1, b2;
	uint16_t	i, j;


	tfer->turbo = TP_TEST;

	uartPutLine_p("# Test bus transfer");
	uartPrintf_p("devtyp=%d; ", tfer->devtyp);
	uartPrintf_p("bus=%d; ", tfer->bus);
	uartPrintf_p("turbo=%d; ", tfer->turbo);
	uartPrintf_p("dump=%d; ", tfer->dump);
	uartPrintf_p("interl=%d; ", tfer->interleave);
	uartPrintf_p("unit=%d; ", tfer->device);
	uartPrintf_p("drive=%d; ", tfer->drive);
	uartPrintf_p("gcr=%d; ", tfer->gcrDecode);
	uartPrintf_p("bam=%d", tfer->fBAM);
	uartPutCrLf();

	if(TferStart(tfer))
		return 1;


	for(j=0; j < 79; ++j)
	{
		//_delay_us(100);
		tfer->f.Write2Byte(0xF0, 0x55);
		//_delay_us(200);

		if(j == 0)		uartPutLine_p("writing 2 byte");

		b1 = tfer->f.Read();
		b2 = tfer->f.Read();

		if(b1 == 0xF0 && b2 == 0x55)
		{
			if(j == 0)		uartPutLine_p("single byte read ok");
			
		}
		else
		{
			uartPutCrLf();
			uartPrintf_p("single byte error: %02x, ", b1);
			uartPrintf_p("%02x", b2);
			uartPutCrLf();
			break;
		}

		uartPutChar('.');
		TferReadBuf(&tfer->f, blk, BLOCKSIZE);

		for(i=0, b1=0; i < 256; ++i)
		{
			//uartPrintf_p("%02x ", blk[i]);
			if((i^0xff) != blk[i])
				b1 = 1;
		}
		uartPutChar(8);
		if(b1) 
		{
			uartPutChar('E');
			uartPutCrLf();
			for(i=0; i < 256; ++i)
			{
				uartPrintf_p("%02x ", blk[i]);
			}
			uartPutCrLf();
			break;
		}
		else
			uartPutChar('x');

	}
	uartPutCrLf();

	TferStop(tfer);
	return 0;
}
#endif


//---------------------------
// INIT
//---------------------------
void InitTfer(void) 
{
/*	uint8_t trackmap[25];
	extern tfer_funcs d64copy_pp_transfer;

	TferWriteTrackMap(&d64copy_pp_transfer, 18, trackmap, 20);


#ifdef DEBUG
	uartPutLine_p("Init parallel interface");
#endif
*/
}




