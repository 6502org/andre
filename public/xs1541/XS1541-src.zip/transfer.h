//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Transfer Handler
// Funktion: handle data transfer to and from floppy drive
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------



#ifndef TRANSFER_H
#define TRANSFER_H




// DEFINES
#define MAX_SECTORS	21

#define NEED_SECTOR(b) ((((b)==bs_error)||((b)==bs_must_copy))?1:0)

#define TEST_TRANS





//typedef int(*turbo_start)(CBM_FILE,unsigned char);
typedef int8_t(*turbo_start)(void);



// STRUCTS
typedef struct tf_f  {
	int8_t	(*Init)(int8_t lwTyp, turbo_start);
	uint8_t	(*Read)(void);
	int8_t	(*Read2Byte)(uint8_t *data);
	int8_t	(*WriteByte)(uint8_t data);
	int8_t	(*Write2Byte)(uint8_t data1, uint8_t data2);
	void 	(*Exit)(void);
} tfer_funcs;

typedef struct s_tfd {
	int8_t	devtyp;						// DT_1541,DT_1571
	int8_t	bus;						// TP_PARALLEL,TP_S1,TP_S2,TP_BURST,TP_SLOW
	int8_t	turbo;					 	// TP_WARP,TP_TURBO,TP_SLOW
	int8_t	dump;						// dump flag
	int8_t	interleave;					// sector interleave
	int8_t	device;						// Device #
	int8_t	drive;						// Drive #
	int8_t	gcrDecode;					// 1=true; WarpMode only
	int8_t	fBAM;						// 1=true; 0=trackmap autoset
	int8_t	track;						// current track
	int8_t	sector;						// next sector to read
	int8_t	cntSe;						// number of sector to read
	int8_t	cntSeTrack;					// number of sector in track
	uint8_t	trackMap[MAX_SECTORS];
	int8_t	(*ReadBlock)(struct s_tfd *tfer_d, uint8_t *se, uint8_t *buf);
	tfer_funcs	f;
} tfer_data;






//ENUMS

typedef enum
{
    bs_invalid	 = 0,
    bs_dont_copy = 1,
    bs_must_copy = 2,
    bs_error	 = 3,
    bs_copied	 = 4
} enTrackMap;




#define DECLARE_TRANSFER_FUNCS(x) \
    tfer_funcs tfer_ ## x PROGMEM = {Init, \
                        Read, \
                        Read2Byte, \
                        WriteByte, \
                        Write2Byte, \
                        Exit   \
					}


/*#define DECLARE_TRANSFER_FUNCS_EX(x,c,t) \
    transfer_funcs d64copy_ ## x  PROGMEM  = {open_disk, \
                        read_block, \
                        write_block, \
                        close_disk, \
                        c, \
                        t, \
                        send_track_map, \
                        read_gcr_block}
*/

//#define TferRead(data)			




//ENUMS



// PROTOTYPES
int8_t TferWarpReadTrack(tfer_data *tfer_d);
int8_t TferWarpReadBlk(tfer_data *tfer_d, uint8_t *se, uint8_t *buf);

int8_t TferTurboReadBlk(tfer_data *tfer_d, uint8_t *se, uint8_t *buf);
int8_t TferStdReadBlk(tfer_data *tfer_d, uint8_t *se, uint8_t *buf);


int8_t TferInit(tfer_data *tfer_d, int8_t bus, int8_t turbo, int8_t interleave);
int8_t TferSetDevice(tfer_data *tfer_d, int8_t devtyp, int8_t device, int8_t drive);
int8_t TferSetGcrDecode(tfer_data *tfer_d, int8_t gcrflg);
int8_t TferStart(tfer_data *tfer_d);
int8_t TferStop(tfer_data *tfer_d);


int8_t TferSetTrackMap(tfer_data *tfer_d, uint8_t tr);

int8_t TferReadTrack(tfer_data *tfer, uint8_t tr);
int8_t TferReadBlk(tfer_data *tfer, uint8_t *se, uint8_t *buf);


//int8_t TferTestRdDisc(tfer_data *tfer_d, int8_t devtyp, int8_t bus, int8_t turbo, int8_t interleave);
int8_t TferTestRdDisc(tfer_data *tfer);
int8_t TferTest(tfer_data *tfer);

#endif

