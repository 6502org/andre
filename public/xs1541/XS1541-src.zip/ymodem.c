//-------------------------------------------------------------------------
// Titel : RS232 - YMODEM PROTOCOL
//-------------------------------------------------------------------------
// Copyright 2001, 2002 Georges Menie (www.menie.org)
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <inttypes.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "timer.h"
#include "uart.h"
#include "ymodem.h"
#include "main.h"
#include "crc16.h"







extern int8_t DumpHex(char *buf, uint16_t anz);



//#define _inbyte(timeout) 	uartGetCharTo(timeout)
//#define _outbyte(c)			uartPutChar(c)
#define	SetTimer(x)		{ cli(); xm_timer = x; sei(); }







//--------------------------
// GET BYTE WITH TIMEOUT
static int16_t _inbyte(void)
{
	int16_t data;

	data = uartGetCharTo(0);
	if(data < 0)
	{
		cli();
		if(xm_timer > 0)
			data = -1;
		else
			data = -2;
		sei();
	}
	return data;
}



//--------------------------
// FLUSH INPUT BUFFER
static void flushinput(void)
{
	while (uartGetCharTo(DLY_1S / 3) >= 0)
		;
}



//--------------------------
// PREPARE XMODEM SEND
static int8_t XmSendBlock(st_xmbuf *xm, st_buf *xb)
{
	uint8_t		*xbuff = xb->pt;
	uint8_t	i;

	xm->bufsz = 128;
	xbuff[0] = SOH; 
	xbuff[1] = xm->packetno;
	xbuff[2] = ~(xm->packetno);

	if(xm->crc) {
		uint16_t ccrc = crc16_ccitt(&xbuff[3], xm->bufsz);
		xbuff[xm->bufsz+3] = (ccrc>>8) & 0xFF;
		xbuff[xm->bufsz+4] = ccrc & 0xFF;
		xb->size = 128 +5;								// 3 head, 128 data, 2 CRC
	}
	else {
		uint8_t ccks = 0;
		for (i = 3; i < xm->bufsz +3; ++i) {
			ccks += xbuff[i];
		}
		xbuff[xm->bufsz+3] = ccks;
		xb->size = 128 +4;								// 3 head, 128 data, 1 SUM
	}

#ifdef TEST_XMODEM_TTY
	DumpHex((char *)xbuff, xb->size);
	xb->stat = 4;
	//for (i = 0; i < xb->size; ++i) 
	//	xbuff[i] = '0' + (i & 7);
	//XbufSend(xb);
#else
	XbufSend(xb);
	LED_TOGGLE();
#endif
	return 0;
}


//--------------------------
// PREPARE XMODEM SEND
void XmSetHeader(st_xmbuf *xm, char *fnam, int32_t size, char *dat)
{
	xm->fnam= fnam;			// file name
	xm->size= size;			// file size
	xm->dat	= dat;			// file Date
}


//--------------------------
// PREPARE YMODEM BLOCK 0
void XmPrepareHeader(st_xmbuf *xm)
{
	uint8_t	*p;

	p = xm->buf2;
	memset(p, 0, sizeof(xm->buf2));

	strcpy((char *)p, xm->fnam);

	xm->xbuf1.stat = 2;						// BUFFER READY
}


//--------------------------
// PREPARE XMODEM SEND
int8_t XmPrepareTx(st_xmbuf *xm)
{
	xm->zst = 0;
	xm->eot = 0;
	xm->bst	= 0;			// buffer state
	xm->pcnt= 0;

	xm->fnam= NULL;			// file name
	xm->size= 0;			// file size
	xm->dat	= NULL;			// file Date

	XbufInit(&xm->xbuf1, xm->buf1, 128 +6);
	XbufInit(&xm->xbuf2, xm->buf2, 128 +6);
	xm->xbuf1.stat = 99;
	xm->xbuf2.stat = 99;
	return 0;
}


//--------------------------
// XMODEM LOOP
int8_t XmLoop(st_xmbuf *xm)
{
	//st_buf	*xbuf;
	int16_t	data;
	uint8_t	i;

	switch(xm->zst)
	{
	  case 0:
		uartPutLine_p("start your X-Modem file receive");
		xm->crc 	 = 1;
		xm->packetno = 0;
		xm->retry 	 = 0;
		xm->zst++;
		SetTimer(DLY_1S * 2);

	  case 1:
		switch((data = _inbyte()))
		{
		  case -1:								// NO CHAR, NO TIMEOUT
			return 0;
		  case 'C':
			xm->crc = 1;
			xm->zst = 5;
			break;
		  case NAK:
			xm->crc = 0;
			xm->zst = 5;
			break;
		  case CAN:
		  	if((data = uartGetCharTo(DLY_1S)) == CAN)
			{
				uartPutChar(ACK);
				flushinput();
				xm->zst = 30;
				xm->eot = 3;
				return 1;
			}
		  default:
		  	xm->retry++;
			break;
		}
		if(xm->retry > 16)
		{
			uartPutChar(CAN);
			uartPutChar(CAN);
			uartPutChar(CAN);
			flushinput();
			xm->eot = 3;
			xm->zst = 31;						// no sync 
			return 1; 	
		}
		SetTimer(DLY_1S * 2);
		break;

	  case 5:														// START Y TRANSMISSION
		xm->xbuf1.stat = 0;
		xm->xbuf2.stat = 0;

		if(xm->fnam != NULL)
		{
			// WITH FILENAME
			XmPrepareHeader(xm);
			xm->packetno = 0;
			xm->zst = 19;
			break;
		}
		xm->zst = 8;


	  case 8:														// START X TRANSMISSION
		xm->packetno = 1;
		xm->zst++;

	  case 9:														// SEND BUFFER 1
		//SetTimer(DLY_1S);
		xm->retry 	 = 0;
		xm->zst++;

	  case 10:														// SEND BUFFER 1
	  	//xbuf = &xm->xbuf1 : &xm->xbuf2;
		switch(xm->xbuf1.stat)	
		{
		  case 2:
			XmSendBlock(xm, &xm->xbuf1);
			SetTimer(DLY_1S);
			xm->zst++;
			break;

		  case 16:
			xm->zst = 40;
			break;

		  case 17:
			xm->zst = 29;
			break;
		}
	  	break;

	  case 11:														// WAIT FOR BUFFER SENT
#ifdef TEST_XMODEM_TTY
		uartPutLine_p("** ZST=12");
#endif
		if(xm->xbuf1.stat != 4)	
		{
		  	data = uartGetCharTo(0);
		  	break;
		}
		SetTimer(DLY_1S);
		xm->zst++;

	  case 12:														// WAIT FOR ACK
		switch((data = _inbyte()))
		{
		  case -1:								// NO CHAR, NO TIMEOUT
			break;
		  case ACK:
		  	// NEXT BLOCK
			xm->xbuf1.stat = xm->eot == 1 ? 16 : 0;					// FREE BUFFER
			xm->packetno++;
			xm->zst = 19;
			break;
		  case CAN:
			xm->zst = 29;
			break;
		  case NAK:
		  default:
			if(xm->retry++ > 16)
			{
				xm->zst = 29;
				break;
			}

		  	// REPEAT SAME BLOCK
			xm->xbuf1.stat = 2;										// RESEND
			xm->zst = 9;
			break;
		}
	  	break;

	  case 19:														// SEND BUFFER 2
		//SetTimer(DLY_1S);
		xm->retry 	 = 0;
		xm->zst++;

	  case 20:														// SEND BUFFER 2
		switch(xm->xbuf2.stat)	
		{
		  case 2:
			XmSendBlock(xm, &xm->xbuf2);
			SetTimer(DLY_1S);
			xm->zst++;
			break;

		  case 16:
			xm->zst = 40;
			break;

		  case 17:
			xm->zst = 29;
			break;
		}
	  	break;

	  case 21:														// WAIT FOR BUFFER SENT
#ifdef TEST_XMODEM_TTY
		uartPutLine_p("** ZST=22");
#endif
		if(xm->xbuf2.stat != 4)	
		{
		  	data = uartGetCharTo(0);
		  	break;
		}
		SetTimer(DLY_1S);
		xm->zst++;

	  case 22:														// WAIT FOR ACK
		switch((data = _inbyte()))
		{
		  case -1:								// NO CHAR, NO TIMEOUT
			break;
		  case ACK:
		  	// NEXT BLOCK
			xm->xbuf2.stat = xm->eot == 1 ? 16 : 0;					// FREE BUFFER
			xm->packetno++;
			xm->zst = 9;
			break;
		  case CAN:
			xm->zst = 29;
			break;
		  case NAK:
		  default:
			if(xm->retry++ > 16)
			{
				xm->zst = 29;

#ifdef TEST_XMODEM_TTY
			uartPutLine_p("** ZST=29  (retry)");
#endif
				break;
			}

#ifdef TEST_XMODEM_TTY
			uartPutLine_p("** ZST=20  (repeat)");
#endif

		  	// REPEAT SAME BLOCK
			xm->xbuf2.stat = 2;										// RESEND
			xm->zst = 19;
			break;
		}
	  	break;

	  case 29:														// SEND CANCEL
		uartPutChar(CAN);
		uartPutChar(CAN);
		uartPutChar(CAN);
		flushinput();
		xm->eot = 3;
		xm->zst++;	

	  case 30:														// CANCEL
	  case 31:														// NO SYNC
	  	return 1;

	  case 40:														// SEND EOT
		for (i = 0; i < 10; ++i) {
			uartPutChar(EOT);
			if ((data = uartGetCharTo((DLY_1S)<<1)) == ACK) 
				break;
		}
		flushinput();
		
		xm->eot = (data == ACK) ? 2 : 3;
		xm->zst = 45;

	  case 45:														// XMODEM SEND END
	  	break;


	  default:
	  	break;
	}
	return 0;
}

//--------------------------
// XMODEM WRITE DATA TO SEND
int8_t XmWrite(st_xmbuf *xm, int16_t data)
{
	st_buf *xb;

	switch(xm->bst)
	{
	  case 0:
	  	xm->bst = 10;

	  case 10:
	  case 20:
	  	xb = xm->bst == 10 ? &xm->xbuf1 : &xm->xbuf2;

		// BUFFER FREE?
		if(xb->stat != 0)
			return 1;

		xb->size = 128 +3;
		XbufWrite(xb, 0);
		XbufWrite(xb, 0);
		XbufWrite(xb, 0);
		xm->bst++;

	  case 11:
	  case 21:
	  	xb = xm->bst == 11 ? &xm->xbuf1 : &xm->xbuf2;

		if(data < 0)
		{
			if(data == -1)
			{
				// EOF
				if(xb->idx <= 3)
				{
					// EMPTY XBUF
					xb->stat	= 16;
					xm->eot		= 1;
					xm->bst		= 30;
					break;
				}

				XbufWrite(xb, CTRLZ);
				while(XbufWrite(xb, 0) == 0);
				xm->eot = 1;
				xm->bst = 30;

#ifdef TEST_XMODEM_TTY
				uartPutLine_p("** BST=30  (EOT!)");
#endif
				break;
			}

			// CANCEL
			xb->stat	= 17;
			xm->eot		= 1;
			xm->bst		= 30;
			break;
		}
		else 
			XbufWrite(xb, data);

		if(xb->stat != 1)
		{
			// BUFFER FULL --> NEXT BUFFER
		  	if(xm->bst == 11)
			{
				xm->bst = 20;

#ifdef TEST_XMODEM_TTY2
			uartPutLine_p("** BST=20  (BUF 1 FULL)");
#endif
			}
			else
			{
				xm->bst = 10;

#ifdef TEST_XMODEM_TTY2
			uartPutLine_p("** BST=10  (BUF 2 FULL)");
#endif
			}
		}
		break;

	  case 30:								// EOT
		break;
	}
	return 0;
}


//----------------------------------
// XMODEM WRITE DATA FROM RINGBUFFER
int8_t XmWriteRB(st_xmbuf *xm, st_ringbuf *rb)
{
	uint8_t	data;
	st_buf	*xb1, *xb2;

	xb1 = &xm->xbuf1;
  	xb2 = &xm->xbuf2;

	XmLoop(xm);

	//uartPrintf_P(PSTR("Xm RB BytesInBuf: %d"), RingbBytesInBuf(rb));
	//uartPutCrLf();

	while(RingbBytesInBuf(rb))
	{
		if(xb1->stat != 0 && xb1->stat != 1 &&
			xb2->stat != 0 && xb2->stat != 1)
		{
			//uartPrintf_P(PSTR("Xm Buffer full: %d,%d"), xb1->stat, xb2->stat);
			//uartPutCrLf();
			break;
		}

		data = RingbRead(rb);
		XmWrite(xm, data);
		XmLoop(xm);
	}
	return 0;		
}

//----------------------------------
// XMODEM WRITE EOT AFTER RB
int8_t XmWriteEot(st_xmbuf *xm, st_ringbuf *rb)
{
	if(RingbBytesInBuf(rb))
	{
		XmWriteRB(xm, rb);
	}
	else
	{
		XmLoop(xm);
		XmWrite(xm, -1);
	}
	return 0;
}

//----------------------------------
// XMODEM CANCEL WRITE 
int8_t XmWriteCancel(st_xmbuf *xm)
{
	XmLoop(xm);
	XmWrite(xm, -2);
	return 0;
}

