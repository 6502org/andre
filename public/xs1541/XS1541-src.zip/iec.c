//-------------------------------------------------------------------------
// Titel:    XS-1541 - IEC Handler
// Funktion: handle communication to serial IEC floppy drives
//-------------------------------------------------------------------------
// Copyright (C) 2007,2008  Ingo Korb <ingo@akana.de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util\delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "config.h"
#include "compat.h"
#include "main.h"
#include "timer.h"
#include "uart.h"
#include "iec.h"
#include "burst.h"






//
// FOR UART MESSAGES TO VIEW PROTOCOLL
//
//#define DEBUG_out				// IEC-OUT signals
//#define DEBUG					// IEC low level signals
//#define DEBUG1				// IEC low level 
//#define DEBUG2				// IEC high level
//#define DEBUGE				// IEC status / error





#define	ATN_DELAY	50				// Bus delay after ATN in �s



extern int8_t IecListPort(void);




// GLOBALS
uint8_t iec_device;					// current device#
uint8_t iec_status;					// bit0=timeout out; bit1=timeout in; 
									// bit5=BUS CLEANUP;
									// bit6=EOI, bit7=device not present
uint8_t iec_devtyp;					// DT_1541,DT_1571,DT_1581


uint8_t iec_burst;					// Burst Flag





// STATICS
static int16_t last_byte;				// -1=kein byte










//----------------------------------------
// IEC SET DATA BYTE  (PARALLEL SPEED-DOS)
//----------------------------------------
void IecSetData(int16_t wo)
{
	if(wo < 0 || wo > 255)
	{
		IEC_D_DDR	= 0x00;				// INPUT!
		IEC_D_PORT	= 0xff;
	}
	else
	{
		IEC_D_DDR	= 0xff;				// OUTPUT!
		IEC_D_PORT	= wo;
	}
}





//----------------------------------------
// DEBOUNCE IEC IO
//----------------------------------------
uint8_t IecDebounce(void) 
{
	uint8_t tmp;

	do {
    	tmp = IEC_PIN & (IEC_BIT_ATN | IEC_BIT_DATA | IEC_BIT_CLK | IEC_BIT_SRQ);
		//_delay_us(1);
	} while (tmp != (IEC_PIN & (IEC_BIT_ATN | IEC_BIT_DATA | IEC_BIT_CLK | IEC_BIT_SRQ)));
	return tmp;
}




//----------------------------------------
// GET CHAR FROM IEC 
//----------------------------------------
static int16_t _IecGetc(void) 
{
	uint8_t i,val,tmp,cnt;

	val = 0;

	// WAIT UNTIL CLOCK HIGH (BYTE READY)
	do { 
	} while (!(IecDebounce() & IEC_BIT_CLK));

	// READY FOR DATA
	IecData(1);                                         // E9D7
	
	// Wait until all other devices released the data line    
	while (!(IecDebounce() & IEC_BIT_DATA)) ;                                  // FF20


	// Timer for EOI detection 
	start_timeout(TIMEOUT_US(256));
	do 
	{
		/*if(!IEC_SRQ)
		{
			int16_t	data;
			if((data = burst_getc3()) >= 0)
			{
				_delay_us(5);				// Test
				IecData(0);	
				_delay_us(20);				// 
				return data;
			}
		}*/

		if((tmp = has_timed_out()))
			break;		
	} while (IEC_CLK);

	// CHECK EOI TIMEOUT
	if (tmp) 
	{
		IecData(0);							// acknowledge 
		_delay_us(73);						//
		IecData(1);							//

		start_timeout(TIMEOUT_US(256));
		do 
		{
			if(has_timed_out())
			{
				iec_status |= IEC_ST_RDTO;				// READ TIMEOUT
				return -5;
			}
		} while (IecDebounce() & IEC_BIT_CLK);

		iec_status |= IEC_ST_EOI;						// last byte - EOI 
	}


	//
	// BURST IN?
	//
	/*if(iec_burst == 1)
	{
		int16_t	data;

		IecData(0);										// 
		_delay_us(73);									// 
		IecData(1);										// 
		if((data = burst_getc2()) >= 0)
		{
			_delay_us(5);								// Test
			IecData(0);									// 
			_delay_us(20);								// 
			return data;
		}
		uartPutLine_p("#burst error");
		iec_burst = 2;
	}*/





	for (i=0;i<8;i++) 
	{
		// data stable on rising edge 
		cnt = 5;
		start_timeout(TIMEOUT_US(256));
		do 
		{
	        tmp = IecDebounce() & (IEC_BIT_DATA | IEC_BIT_CLK);
			if(has_timed_out())
			{
				if(cnt-- == 0)
				{
					iec_status |= IEC_ST_RDTO;				// READ TIMEOUT
					return -3;
				}
			}
		} while (!(tmp & IEC_BIT_CLK));

    	val >>= 1;
		if(tmp & IEC_BIT_DATA)
	    	val |= 0x80;

		cnt = 5;
		start_timeout(TIMEOUT_US(256));
		do {												// EA1A
			if(has_timed_out())
			{
				if(cnt-- == 0)
				{
					iec_status |= IEC_ST_RDTO;				// READ TIMEOUT
					return -2;
				}
			}
		} while (IEC_CLK);
	}

	_delay_us(5);										// delay
	IecData(0);											//
	_delay_us(10);										// to avoid problems 
	return val;
}





//----------------------------------------
// SEND CHAR TO IEC 
//----------------------------------------
static uint8_t IecPutc(uint8_t data, const uint8_t fEoi) 
{
	uint8_t i;

	i = IecDebounce();
#ifdef DEBUG_out
	uartPrintf_p("iec-in: %02x", i);
	uartPutCrLf();
#endif

	// IEC: READY TO SEND
	IecClk(1);
#ifdef DEBUG_out
	uartPutLine_p("#clock high");
#endif

	if (i & IEC_BIT_DATA)								// E923
	{ 
		_delay_us(60); // Fudged delay
	}

#ifdef DEBUG_out
	uartPutLine_p("#wait for data high");
#endif

	// WAIT FOR ALL LISTENERS READY
	do 
	{
	} while (!(IecDebounce() & IEC_BIT_DATA));

	if (fEoi || (i & IEC_BIT_DATA)) 
	{
		// SEND EOI
#ifdef DEBUG_out
	uartPutLine_p("#EOI: wait for data high");
#endif
		do {
		} while (!(IecDebounce() & IEC_BIT_DATA));

#ifdef DEBUG_out
	uartPutLine_p("#wait for data low");
#endif
		do {
		} while (IecDebounce() & IEC_BIT_DATA);
	}

	IecClk(0);
	_delay_us(60);	
#ifdef DEBUG_out
	uartPutLine_p("#clock low!  #wait for data high");
#endif

	// WAIT FOR READY TO LISTEN
	do {
	} while (!(IecDebounce() & IEC_BIT_DATA));


	//
	// DO BURST IF 1571
	//
	switch(iec_burst)
	{
	  case 0:
		if(!BurstCheck(data))
		{
			//uartPutLine_p("#burst on");
			iec_burst = 1;
			return 0;
		}
		//uartPutLine_p("#no burst");
		iec_burst = 2;
		break;

	  case 1:
		burst_putc(data);
		iec_timer = 2;									// 2ms timeout
		while(1)
		{
			if(!IEC_DATA)
				return 0;

			if(!iec_timer)
			{
				//uartPutLine_p("#burst off");
				iec_burst = 2;
				break;
			}
		} 
		break;
	}


#ifdef DEBUG_out
	uartPutLine_p("sending byte ...");
#endif

	for(i=0; i<8; i++) 
	{
		if(!(IecDebounce() & IEC_BIT_DATA)) 
		{
			//iec_data.bus_state = BUS_CLEANUP;
#ifdef DEBUG_out
	uartPutLine_p("#ST |= IEC_ST_CLEANUP");
#endif
			iec_status |= IEC_ST_CLEANUP;				// cleanup
			return -1;
		}

#ifdef DEBUG_out
	if (data & (1<<i))	uartPutLine_p("#data high!");
	else				uartPutLine_p("#data low!");
#endif
		IecData(data & (1<<i));
		_delay_us(70);									// Implicid delay, fudged

#ifdef DEBUG_out
	uartPutString_p("#clock high - waiting -");
#endif
		IecClk(1);

		_delay_us(34);								// tested 1541


#ifdef DEBUG_out
	uartPutLine_p("#clock low, data high");
#endif
		IecClk(0);
		IecData(1);
		_delay_us(15);									// Settle time
	}

	// WAIT FOR FRAME HANDSHAKE
#ifdef DEBUG_out
	uartPutLine_p("#wait for data low (frame handshake)");
#endif
	iec_timer = 2;									// 2ms timeout
	do 
	{
		if(!iec_timer)
		{
#ifdef DEBUG_out
	uartPutLine_p("!!WRITE TIMEOUT!!");
#endif
			iec_status |= IEC_ST_WRTO;				// WRITE TIMEOUR
			return 1;
		}
	} while (IecDebounce() & IEC_BIT_DATA);

	return 0;
}




//----------------------------------------------------------------------
// IEC SEND BYTE 
static inline uint8_t IecOut(uint8_t data) 
{
	return IecPutc(data, 0);
}

//----------------------------------------------------------------------
// IEC SEND BYTE WITH EOI
static inline uint8_t IecOutEoi(uint8_t data) 
{
	return IecPutc(data, 1);
}

//----------------------------------------------------------------------
// IEC GET BYTE 
static inline int16_t IecIn()
{
  int16_t val;

  cli();
  val = _IecGetc();
  sei();

  return val;
}


//----------------------------------------------------------------------
// IEC SEND ATN
static inline int8_t IecAtnOut(uint8_t by)
{
	int8_t	rc;

	if(!(IecDebounce() & IEC_BIT_ATN))
	{
		iec_status |= IEC_ST_ATN;			// ATN active!!
		return 1;
	}

#ifdef DEBUG1
	uartPrintf_p("IecAtnOut(%02x)", by);
	uartPutCrLf();
#endif

	while(1) 
	{
#ifdef DEBUG
	//uartPutLine_p("..NRFD hi, NDAC hi");
#endif
		if(last_byte >= 0)
		{
			// SEND LAST BYTE WITH EOI

#ifdef DEBUG
	uartPutLine_p("..send lastbyte - EOI!");
#endif

			rc = IecOutEoi(last_byte);
			last_byte = -1;
		}

#ifdef DEBUG
	uartPutLine_p("..ATN!");
#endif

		//
		// INIT BURSTMODE 
		//
		switch(iec_devtyp)
		{
		  case DT_1571:
		  case DT_1581:
			//burst_putc(0x08);							// OFFER BURST INIT BYTE
			iec_burst = 0;								// test burst
			break;

		  default:
			iec_burst = 2;								// no burst
			break;
		}


		IecAtn(0);
		IecClk(0);
		IecData(1);

		iec_timer = 2;								// 2ms timeout

		while(IEC_DATA)								// WAIT WHILE DATA 
		{
			if(!iec_timer)
			{
				iec_status |= IEC_ST_ATTO;	// ATN-OUT timeout

#ifdef DEBUG
	uartPutLine_p("..ST: ATN timeout!");
#endif

				return 1;
			}
		}


		if(IecOut(by)) break;

		return 0;
	}

#ifdef DEBUG
	uartPutLine_p("..IecAtnOut() aborted, ATN hi");
#endif

	IecAtn(1);									// ATN hi
	_delay_us(ATN_DELAY);
	return 1;
}

//----------------------------------------------------------------------
// IEC SEND LISTEN SECONDARY ADDRESS
static inline int8_t IecSecListen(uint8_t sa)
{
	int8_t	rc;

#ifdef DEBUG2
	uartPrintf_p("IecSecListen(%02x)", sa);
	uartPutCrLf();
#endif

	rc = IecOut(sa);
	IecAtn(1);									// SET ATN HI
	_delay_us(ATN_DELAY);
	return rc;
}


//----------------------------------------------------------------------
// IEC SEND TALK SECONDARY ADDRESS
static inline int8_t IecSecTalk(uint8_t sa)
{
	int8_t	rc;

#ifdef DEBUG2
	uartPrintf_P(PSTR("IecSecTalk(%02x)"), sa);
	uartPutCrLf();
#endif

	if(!(rc = IecOut(sa)))
	{
		// TALK! OK
		IecAtn(1);								// RELEASE ATN
		_delay_us(ATN_DELAY);

		// CHANGE LISTENER-TALKER
		IecData(0);
		IecClk(1);
	}
	else
		IecAtn(1);								// SET ATN HI
	
	_delay_us(ATN_DELAY);
	return rc;
}

//----------------------------------------------------------------------
// IEC SEND BYTE 
int8_t IecBsout(uint8_t by)
{
#ifdef DEBUG2
	uartPrintf_p("IecBsout(%02x)", by);
	uartPutCrLf();
#endif
	if(last_byte >= 0)
	{
		// SEND BYTE IN BUFFER
		if(IecOut(last_byte)) 
			return 1;
	}
	last_byte = by;
	return 0;
}

//--#--------------------------------------------------------------------
// IEC GET BYTE 
uint8_t IecBasin()
{
#ifdef DEBUG2
	uartPutLine_p("IecBasin()");
#endif
	if(iec_status == 0)
	{
		return IecIn();
	}
#ifdef DEBUGE
	else
	{
		uartPrintf_p("..ST=%02x", iec_status);
		uartPutCrLf();
	}
#endif
	return 0;
}


//----------------------------------------------------------------------
// UNTALK
int8_t IecUntalk(void)
{
	int8_t 	rc;

#ifdef DEBUG2
	uartPutLine_p("IecUnTalk()");
#endif
	rc = IecAtnOut(0x5f);

#ifdef DEBUG
	uartPutLine_p("..ATN hi");
#endif
	//IecClk(1);									// SET CLK HI
	IecAtn(1);									// SET ATN HI
	
	_delay_us(ATN_DELAY);
	return rc;
}

//----------------------------------------------------------------------
// UNLISTEN
int8_t _IecUnlisten(void)
{
	int8_t 	rc;

#ifdef DEBUG2
	uartPutLine_p("IecUnListen()");
#endif
	rc = IecAtnOut(0x3f);

#ifdef DEBUG
	uartPutLine_p("..ATN hi");
#endif	
	return rc;
}

//----------------------------------------------------------------------
// UNLISTEN
int8_t IecUnlisten(void)
{
	int8_t 	rc;

	rc = _IecUnlisten();
	//IecClk(1);									// SET CLK HI
	IecAtn(1);									// SET ATN HI
	_delay_us(ATN_DELAY);
	return rc;
}

//----------------------------------------------------------------------
// LISTEN
int8_t IecListen(uint8_t sa)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_P(PSTR("IecListen(%02x)"), sa);
	uartPutCrLf();
#endif

	if(IecAtnOut(0x20 | (iec_device & 0xf)))
		rc = 1;
	else if(IecSecListen(0x60 | (sa & 0x1f)))
		rc = 1;
	
	_delay_us(ATN_DELAY);
	return rc;
}

//----------------------------------------------------------------------
// TALK
int8_t IecTalk(uint8_t sa)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_p("IecTalk(%02x)", sa);
	uartPutCrLf();
#endif

	if(IecAtnOut(0x40 | (iec_device & 0xf)))
		rc = 1;
	else if(IecSecTalk(0x60 | (sa & 0x1f)))
		rc = 1;
	
	_delay_us(ATN_DELAY);
	return rc;
}

//----------------------------------------------------------------------
// OPEN
int8_t IecOpen(uint8_t sa, char *s)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_p("IecOpen(%02x, \"", sa);
	uartPutString(s);
	uartPutString_p("\")");
	uartPutCrLf();
#endif

	if(IecAtnOut(0x20 | (iec_device & 0xf)))
		rc = 1;
	else if(IecSecListen(0xF0 | (sa & 0x0f)))
		rc = 1;
	else 
	{
		while(*s)
		{
			if(IecBsout(*s)) 
			{
				rc = 1;
				break;
			}
			++s;
		}
		IecUnlisten();
	}
	return rc;
}

//----------------------------------------------------------------------
// CLOSE
int8_t IecClose(uint8_t sa)
{
	int8_t 	rc=0;

#ifdef DEBUG2
	uartPrintf_p("IecClose(%02x)", sa);
	uartPutCrLf();
#endif

	if(IecAtnOut(0x20 | (iec_device & 0xf)))		// LISTEN
		rc = 1;
	else if(IecSecListen(0xE0 | (sa & 0x1f)))		// CLOSE SA
		rc = 1;

	IecUnlisten();
	return rc;
}


//------------------------------------
// RESET IEC
//------------------------------------
void IecReset(void)
{
	IecRst(0);
	_delay_ms(250);
	IecRst(1);
}


 


//------------------------------------
// INIT IEC
//------------------------------------
void InitIec(void) {

  IEC_D_PORT = 0xff;

#ifdef IEC_SEPARATE_OUT
  /* Set up the port: Output bits as output, all others as input */
#ifdef XA1541
  /* XA1541 negative logic: reset output pins */
  IEC_DDR	|= IEC_OBIT_ATN | IEC_OBIT_CLK | IEC_OBIT_DATA | IEC_OBIT_SRQ | IEC_OBIT_RST;
  IEC_PORT	&= ~(IEC_OBIT_ATN | IEC_OBIT_CLK | IEC_OBIT_DATA | IEC_OBIT_SRQ | IEC_OBIT_RST);
#else
  /* open collector logic: reset output pins */
  IEC_DDR	&= ~(IEC_OBIT_ATN | IEC_OBIT_CLK | IEC_OBIT_DATA | IEC_OBIT_SRQ | IEC_OBIT_RST);
  IEC_PORT 	&= ~(IEC_OBIT_ATN | IEC_OBIT_CLK | IEC_OBIT_DATA | IEC_OBIT_SRQ | IEC_OBIT_RST);
#endif
  /* Enable pullups on the input pins and set the output lines to high */
  IEC_PIN_PU |= (IEC_BIT_ATN | IEC_BIT_CLK | IEC_BIT_DATA | IEC_BIT_SRQ | IEC_BIT_RST);
#else
  /* Pullups would be nice, but AVR can't switch from */
  /* low output to hi-z input directly                */
  IEC_PORT 	&= ~(IEC_OBIT_ATN | IEC_OBIT_CLK | IEC_OBIT_DATA | IEC_OBIT_SRQ | IEC_OBIT_RST);
  IEC_DDR	&= ~(IEC_OBIT_ATN | IEC_OBIT_CLK | IEC_OBIT_DATA | IEC_OBIT_SRQ | IEC_OBIT_RST);
#endif



  	iec_device = 8;					// DEFAULT DEVICE#
	iec_devtyp = DT_1541;
	last_byte = -1;




//	PCICR |= _BV(PCIE3);			// enable Port D Pin Interrupts
//	PCMSK3 |= _BV(IEC_PIN_SRQ);		// enable SRQ Pin of Port D

	//PCIFR &= ~_BV(PCIF3)				// reset Pin change Flag

							// SRQ INTERRUPT :: OC1A/PCINT29	



#ifdef DEBUG
	uartPutLine_p("InitIec()");
#endif

	InitBurst();
	iec_burst = 0;
}


