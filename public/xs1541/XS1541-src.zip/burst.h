//-------------------------------------------------------------------------
// Titel : 	XS-1541 - IEC Handler
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// Funktion : 	handle fast burst mode of 1571 and 1581 floppy drives
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//-------------------------------------------------------------------------

#ifndef BURST_H
#define BURST_H




#define	ToggleClk()		IecClk(!IEC_CLK);
#define	ToggleSrq()		IecClk(!IEC_SRQ);






#define	BST_ST_RDTO		_BV(0)
#define	BST_ST_ISR		_BV(6)
#define	BST_ST_BYRDY	_BV(7)



#define	BurstByteReady()	(burstStat & BST_ST_BYRDY)




// STRUCTS





void  burst_putc(uint8_t data);
int16_t burst_getc(void);
int16_t burst_getc2(void);
int16_t burst_getc3(void);


void BurstStat(void);


int8_t BurstCheck(uint8_t data);
int8_t BurstCmd(char *cmd, int8_t len);
int16_t BurstCmdExit();
//int8_t BurstStat(void);

int8_t InquireDisk(void);
int8_t InquireStatus(int8_t flg, uint8_t NewStat);
int8_t QueryDiskFormat(int8_t flg, uint8_t offs);
int8_t BurstInterleave(uint8_t interleave);

int8_t BurstRead(st_DiskBuf *o, uint8_t ntrk);
int8_t BurstWrite(st_DiskBuf *o, uint8_t ntrk);
int8_t BurstFastload(st_DiskBuf *o, char *fileName);
int8_t BurstHandler(st_DiskBuf *);
void InitBurst(void);



#endif
