//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Burstmode Handler
// Funktion: handle fast burst mode of 1571 and 1581 floppy drives
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//-------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util\delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "config.h"
#include "compat.h"
#include "timer.h"
#include "main.h"
#include "uart.h"
#include "xmodem.h"
#include "ieee.h"
#include "iec.h"
#include "floppy.h"
#include "burst.h"
#include "image.h"




//#define	DEBUG


// CONST
//#define F_BURST_IN		_BV(0)				// watch SRQ for byte in
//#define F_BYTE_IN		_BV(7)				// byte received!




// VARS
static uint8_t	newDisk;						// INQUIRE FLAG

static volatile uint8_t		burstStat;			// ISR STATUS
static volatile uint8_t		burstData;			// BURST DATA RECEIVED
static volatile uint16_t	burstCnt;			// BYTE CNT
static volatile uint16_t	burstErr;			// ERROR CNT
static volatile uint16_t	burstCnt2;			// HIGH CNT









//
// FOR UART MESSAGES TO VIEW PROTOCOLL
//
//#define DEBUG_out				// IEC-OUT signals
//#define DEBUG					// IEC low level signals
//#define DEBUG1				// IEC low level 
//#define DEBUG2				// IEC high level
//#define DEBUGE				// IEC status / error





/* ------------------------------------------------------------------------- */
/*  Very low-level bus handling                                              */
/* ------------------------------------------------------------------------- */

#ifdef SRQ_INT_VECT

// PORT D INTERRUPTS
//
ISR(PCINT3_vect)
{
	uint8_t		pin = PIND;

	if(!(pin & IEC_BIT_SRQ))
	{
		uint8_t	data=0, i;

		for (i=0;i<8;i++) 
		{
			start_timeout(TIMEOUT_US(70));
			do 
			{   
				pin = IEC_PIN;
				if(has_timed_out())
				{
					burstStat |= BST_ST_RDTO;				// READ TIMEOUT
					i = 10;
					break;
				}
			} while (!(pin & IEC_BIT_SRQ));

			data <<= 1;
			if((pin & IEC_BIT_DATA))
				data |= 1;

			if(i >= 7)
				break;

			start_timeout(TIMEOUT_US(70));
			do 
			{   
				if(has_timed_out())
				{
					burstStat |= BST_ST_RDTO;				// READ TIMEOUT
					i = 10;
					break;
				}
			} while ((IEC_PIN & IEC_BIT_SRQ));
		}
		if(i == 7)
		{
			burstCnt++;
			burstData = data;
			burstStat |= BST_ST_BYRDY;				// BYTE READY
		}
		else
			burstErr++;

		PCIFR |= _BV(PCIF3);						// reset Pin change Flag		
	}
	else
		burstCnt2++;

	//burstStat |= BST_ST_ISR;						// ISR FLG
}/**/

#endif


/* ------------------------------------------------------------------------- */
/*  Byte transfer routines                                                   */
/* ------------------------------------------------------------------------- */

/**
 * _burst_getc - receive one byte 
 *
 * This function tries receives one byte from the serial bus and returns it
 * if successful. Returns -1 instead if the device state has changed, the
 * caller should return to the main loop immediately in that case.
 */
static inline int16_t __burst_getc(void) 
{
	uint16_t	cntSrq0;
	uint8_t		data=0, i, pin, cnt=100;

	for (i=0;i<8;i++) 
	{
		cntSrq0 = 0;
		do 
		{   
			if(++cntSrq0 == 0)
			{
				if(i != 0 || cnt-- == 0)
				{
					//uartPrintf_p("timeout srq high, i=%d", i);
					//uartPutCrLf();
					return -1;
				}
			}
		} while (IEC_SRQ);

		cntSrq0 = 0;
		do 
		{
			pin = IEC_PIN;
			if(++cntSrq0 == 0)
			{
				//uartPrintf_p("timeout srq low, i=%d", i);
				//uartPutCrLf();
				return -1;
			}
		} while (!(pin & IEC_BIT_SRQ));

		data <<= 1;
		if((pin & IEC_BIT_DATA))
			data |= 1;
	}
	return data;
}

int16_t burst_getc2(void) 
{
	int16_t	data;

	cli();

#ifdef SRQ_INT_VECT
	if(BurstByteReady())
	{
		burstStat= 0;
		data	 = burstData;
	}
	else
	{
#endif
		data = __burst_getc();
#ifdef SRQ_INT_VECT
	}
#endif

	sei();
	return data;
}

int16_t burst_getc(void) 
{
	cli();
	ToggleClk();									// START 
	return burst_getc2();
}



/**
 * iec_putc - send a byte over the serial bus in burst mode
 */
void burst_putc(uint8_t data) 
{
	uint8_t i;

	for(i=0;i<8;++i)
	{
		IecSrq(0);
		IecData(data & 0x80);
		data <<= 1;
		_delay_us(5);
		IecSrq(1);
		_delay_us(5);
	}
	IecData(1);
}


//-----------------------------
// CHECK IF FLOPPY ACCEPT BURST
int8_t BurstCheck(uint8_t data)
{
	//int16_t	cnt;

	burst_putc(data);
	_delay_us(100);									// 
	
	if(!IEC_DATA)
		return 0;

	return -1;
}


/*
//---------------------------
// FETCH BYTE
int8_t BurstByteReady(void)
{
	if(dataCnt == 8)
		return 1;
	return dataCnt ? -1 : 0;
}


//---------------------------
// FETCH BYTE
uint8_t BurstFetch(void)
{
	cli();
	//pinChgFlg &= ~F_BYTE_IN;
	data	= dataIn;
	dataCnt = 0;
	sei();
	return data;
}
*/

//---------------------------
// BURST ISR STATUS
void BurstStat(void)
{
	uint8_t	st, data;
	uint16_t	cnt1, cnt2, err;


	if((st = burstStat))
	{
		cli();
		data		= burstData;
		cnt1		= burstCnt;
		cnt2		= burstCnt2;
		err			= burstErr;
		burstData	= 0;
		burstStat	= 0;
		sei();
		uartPrintf_p("burst stat=%02x", st);
		uartPrintf_p("; cnt=%d", cnt1);
		uartPrintf_p("; high=%d", cnt2);
		uartPrintf_p("; err=%d", err);
		if(st & BST_ST_BYRDY)							// BYTE READY
		{
			uartPrintf_p("; data=%0x", data);
		}
		if(st & BST_ST_RDTO)							// READ TIMEOUT
			uartPutString_p("; timeout");
		uartPutCrLf();
	}
}



//---------------------------
// SEND BURST COMMAND
int8_t BurstCmd(char *cmd, int8_t len)
{
	char		cmd0[] = {'U', '0'};

	burst_putc(8);									// SWITCH TO FASTMODE
	_delay_ms(4);

	if(IecListen(15)) 
		return 3;

	SendBuffer(cmd0, 2);
	SendBuffer(cmd, len);
	_IecUnlisten();

	return 0;
}


//-----------------------------
// RESET ATN AND GET BURST BYTE
int16_t BurstCmdExit()
{
	int16_t		data = 0;
	int8_t		i;

  	cli();
	burstStat = 0;
	IecClk(0);
	IecAtn(1);							// SET ATN HI
	SetST(0);
	
	i = 3;
	while(i--)
	{
		if((data = burst_getc2()) >= 0)
			break;
	}
	return data;
}


//---------------------------
// INQUIRE DISK   [3]
int8_t InquireDisk()
{
	char		cmd[1];

	newDisk		= 0;

	cmd[0] = 0x04;						// inquire
	BurstCmd(cmd, 1);
	return BurstCmdExit();
}

//---------------------------
// QUERY DISK FORMAT  [6]
int8_t QueryDiskFormat(int8_t flg, uint8_t offs)
{
	char		cmd[2];

	//----------------------------------------------------------------------------
	// 02	F    X    T    S    1    0    1    N
	//----------------------------------------------------------------------------
	// 03   	            OFFSET      (OPTIONAL F-BIT SET)
	//----------------------------------------------------------------------------
	//	F - FORCE FLAG (F=1, WILL STEP THE HEAD WITH THE 
	//	T - END SECTOR TABLE (T=1, SEND)
	//----------------------------------------------------------------------------

	cmd[0] = 0x0a | flg;						// QueryDiskFormat
	cmd[1] = offs;						// optional offset
	BurstCmd(cmd, (flg & 0x80)?2:1);

	return BurstCmdExit();
}

//---------------------------
// INQUIRE STATUS   [7]
int8_t InquireStatus(int8_t flg, uint8_t NewStat)
{
	char		cmd[2];

	//----------------------------------------------------------------------------
	//  02    W    C    X    0    1    1    0    N
	//----------------------------------------------------------------------------
	//  03                  	NEW STATUS (W-BIT CLEAR)
	//----------------------------------------------------------------------------
	//	W - WRITE SWITCH 
	//	C - CHANGE (C=1 & W=0 - FORCE LOGIN DISK,
	//		    	C=1 & W=1 - RETURN WHETHER DISK WAS LOGGED 
	//		    IE. $XB ERROR OR OLD STATUS)
	//----------------------------------------------------------------------------

	cmd[0] = 0x0c;						// CMD
	cmd[1] = NewStat;					// optional offset
	BurstCmd(cmd, (flg & 0x80)?1:2);

	if(!(flg & 0x80))
	{
		IecAtn(1);										// SET ATN HI
		return 0;
	}
	return BurstCmdExit();
}

//------------------------
// SECTOR INTERLEAVE   [7]
int8_t BurstInterleave(uint8_t interleave)
{
	char		cmd[2];

	//----------------------------------------------------------------------------
	//  02    W      X      X      0      1      0      0      N
	//----------------------------------------------------------------------------
	//  03                      INTERLEAVE
	//----------------------------------------------------------------------------
	// SWITCHES: W -- write switch (0 = write)
	//           N -- drive number
	//           X -- Don't care
	//----------------------------------------------------------------------------

	if(interleave == 0)
	{
		// READ
		cmd[0] = 0x88;							// CMD
		BurstCmd(cmd, 1);
		return BurstCmdExit();
	}
	else
	{
		// WRITE
		cmd[0] = 0x08;							// CMD
		cmd[1] = interleave;					// par
		BurstCmd(cmd, 2);
	}

	IecAtn(1);										// SET ATN HI
	return 0;
}



//---------------------------
// FAST BLOCK READ
int8_t BurstRead(st_DiskBuf *o, uint8_t ntrk)
{
	char		cmd[5];

	//if(newDisk)
	//	InquireDisk();


	//o->stat	= 99;
	o->opt	= TP_BURST;
	o->log	= 0;


	//uartPutLine_p("** Burst Read **");
	//_delay_ms(10);

	if(GetDeviceType() == DT_1581)
	{
		cmd[0]	= 0x80;					// read blocks logical
		o->log	= 1;
	}
	else
		cmd[0] = 0x00;					// read blocks

	cmd[1] = o->curTr;					// 
	cmd[2] = o->curSe;					// 
	cmd[3] = o->curSeCnt;				// 
	cmd[4] = ntrk==0?o->curTr:ntrk;		// optional
	BurstCmd(cmd, 5);

	o->stat = 0x10;
	return BurstHandler(o);
}



//---------------------------
// FAST BLOCK WRITE
int8_t BurstWrite(st_DiskBuf *o, uint8_t ntrk)
{
	char		cmd[5];

	//if(newDisk)
	//	InquireDisk();

	//o->stat	= 99;
	o->opt	= TP_BURST;

	//uartPutLine_p("** Burst Write **");
	//_delay_ms(10);

	cmd[0] = 0x00;						// write blocks
	cmd[1] = o->curTr;					// 
	cmd[2] = o->curSe;					// 
	cmd[3] = o->curSeCnt;				// 
	cmd[4] = ntrk==0?o->curTr:ntrk;		// optional
	BurstCmd(cmd, 5);

	o->stat = 0x50;
	return BurstHandler(o);
}


//---------------------------
// PREPARE FAST FILE DOWNLOAD
int8_t BurstFastload(st_DiskBuf *o, char *fileName)
{
	char		cmd[25];

	//if(newDisk)
	//	InquireDisk();

	o->stat	= 99;
	o->opt	= TP_BURST;

	uartPutLine_p("** Burst Load **");
	_delay_ms(10);

	cmd[0] = 0x9f;						// fastload: all files
	//cmd[0] = 0x1f;					// fastload: PGM only

	strcpy(cmd +1, fileName);
	BurstCmd(cmd, strlen(fileName) +1);

	o->stat = 0;
	return 0;
}


//---------------------------
// FAST FILE DOWNLOAD BLOCK
int8_t BurstHandler(st_DiskBuf *o)
{
	uint8_t		*s;
	int16_t		data = 0;
	int16_t		anz, anz2;

	while(1)
	switch(o->stat)
	{
	  case 0x00:										// ::OPEN FILE
	  case 0x10:										// ::FIRST BLOCK
	  case 7:											// ::INQUIRE
	  	data = BurstCmdExit();
		o->stat += 2;
		break;

	  case 0x01:										// ::GET BLOCK
	  case 0x11:										// ::GET BLOCK
		data = burst_getc();

	  case 0x02:										// ::GET BLOCK
	  case 0x12:										// ::GET BLOCK
		o->stat &= 0xf0;
		o->stat |= 0x01;

		//uartPrintf_p("Start:%02x", data);
		//uartPutCrLf();

		if(data == 0x1f)
		{
			// EOI 
			iec_status |= IEC_ST_EOI;						// last byte - EOI  // EA07
			o->stat = 9;
			anz = burst_getc();
		}
		else if((data & 0xf) < 2)
		{
			// FULL BLOCK
			if(o->stat == 0x01)
				anz = 254;
			else if(o->log != 0 || (data & 0x80) == 0)
			{
				// 1581 logical or 1571 GCR
				anz = 256;
			}
			else switch(data & 0x30)						// PHYSICAL!!
			{
			  case 0x00:
				anz = 128;
				break;
			  case 0x10:
				anz = 256;
				break;
			  case 0x20:
				anz = 512;
				break;
			  default:
				anz = 1024;
				break;
			}
		}
		else
		{
			// FILE NOT FOUND OR ERROR
			/*data = burst_getc();
			uartPrintf_p("Err:%02x", data);
			uartPutCrLf();*/

			o->stat = 99;
			return -2;
		}
		if(anz > 256)
		{
			anz2	= 256;
		}
		else
		{
			anz2	= anz;
		}
		o->anz	= anz2;
		s		= o->buf;

		while(anz--)
		{
			if((data = burst_getc()) < 0)
			{
				iec_status |= IEC_ST_RDTO;					// ERROR
				o->stat = 99;
				return -1;
			}
			if(anz2)
			{
				*(s++) = data;
				anz2--;
			}
		}
		return 0;

	  case 9:										// ::EOF
		iec_status |= IEC_ST_EOI;					// last byte - EOI  // EA07
		o->anz = 0;
		return 1;

	  case 10:										// ::OK
		return 0;

	  case 99:										// ::ERROR
	  default:
		iec_status |= IEC_ST_RDTO;					// ERROR
		return -1;
	}
	return 0;
}



//---------------------------
// INIT
//---------------------------
void InitBurst(void) 
{
#ifdef SRQ_INT_VECT

	PCICR |= _BV(PCIE3);			// enable Port D Pin Interrupts
	PCMSK3 |= _BV(IEC_PIN_SRQ);		// enable SRQ Pin of Port D
/*
	//PCIFR &= ~_BV(PCIF3)			// reset Pin change Flag

									// SRQ INTERRUPT :: OC1A/PCINT29	

	/pindOld		= 0;
	pinChgFlg	= 0;
	//cntSrqChg	= 0;
	dataCnt		= 0;
	dataIn		= 0;
	*/

	burstStat	= 0;			// ISR STATUS
	burstData	= 0;			// BURST DATA RECEIVED
	burstCnt2	= 0;			// CNT HIGH
	burstCnt	= 0;			// BYTE CNT
	burstErr	= 0;			// ERROR CNT



#endif

	newDisk		= 1;

#ifdef DEBUG
	uartPutLine_p("InitBurst()");
#endif
}




