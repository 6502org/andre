//-------------------------------------------------------------------------
// Titel:    HEX Dump Utility                  (recompile it with Pelles-C)
// Funktion: produce .INC files from AS65 file
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>



////////////////////
//  Main Program
void
main (int argc, char **argv)
{
	unsigned char	c;
	int		i;
	long	size;
	FILE	*fh;

	if(argc != 1)	
	{
		if((fh = fopen(*(argv +1), "rb")) == NULL)
		{
			fprintf(stderr, "** cannot open file: %s", *(argv +1));
			exit (1);
		}

		fseek(fh, 0, SEEK_END);
		size = ftell(fh);
		//fprintf(stderr, "filesize=%ld", size);
		fseek(fh, 0, SEEK_SET);

		i = 0;
		while(size--)
		{
			c = fgetc(fh);
			printf("0x%02x", c);

			if(size != 0)
			{
				printf(",");
				if(i++ < 15)
					;
				else
				{
					printf("\n");
					i = 0;
				}
			}
		}

		fclose(fh);
	}
	else
		fprintf(stderr, "Use: %s file", *(argv +0));
}
