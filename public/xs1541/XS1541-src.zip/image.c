//-------------------------------------------------------------------------
// Titel:	 XS-1541 - CBM Image File handling
// Funktion: handle read and write of floppy disk imagefiles
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <inttypes.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloca.h>

#include "main.h"
#include "uart.h"
#include "ymodem.h"
#include "ieee.h"
#include "iec.h"
#include "burst.h"
#include "floppy.h"
#include "image.h"










// CONST



// TOKEN



// STRUCTS


// STATICS
				// SECTOR LENGTH BY TRACK  (up to track / sectors, ...)
static uint8_t sleD64[] PROGMEM = {17,21,24,19,30,18,35,17,42,17,0};	
static uint8_t sleD71[] PROGMEM = {17,21,24,19,30,18,35,17,52,21,59,19,65,18,70,17,0};		
static uint8_t sleD82[] PROGMEM = {39,29,53,27,64,25,77,23,116,29,130,27,141,25,154,23,0};
static uint8_t sleD81[] PROGMEM = {80,40,0};






// GLOBALS



// EXTERNALS




//----------------------------------------------------------------------
// GET DEFAULT IMAGE TYPE FOR SELECTED DEVICE TYPE
//----------------------------------------------------------------------
int8_t InitFloppy(int8_t imageType)
{
	char	*s = NULL;

	if(imageType < 0)
		imageType = GetDefImageType();

	switch(fDevice == 0 ? ieee_devtyp : iec_devtyp)
	{
	  case DT_1541:
	  case DT_1581:
	  case DT_2030:
	  case DT_4040:
	  case DT_8050:
		break;
	  case DT_1571:
		if(imageType == FT_D71)		s = PSTR("U0>M1");
		else						s = PSTR("U0>M0");
		break;
	  case DT_8250:
		break;
	  default:
		break;
	}
	if(s != NULL)
	{
		/*uartPutString_p("send Cmd: ");
		uartPutString_P(s);
		uartPutCrLf();*/
		SendCmd_P(s);
	}
	return 0;
}

//----------------------------------------------------------------------
// GET DEFAULT IMAGE TYPE FOR SELECTED DEVICE TYPE
//----------------------------------------------------------------------
int8_t GetDefImageType()
{
	int8_t	it;

	switch(fDevice == 0 ? ieee_devtyp : iec_devtyp)
	{
	  case DT_1541:
		it = FT_D64;
		break;
	  case DT_1571:
		it = FT_D71;
		break;
	  case DT_1581:
		it = FT_D81;
		break;
	  case DT_2030:
		it = FT_D64;
		break;
	  case DT_4040:
		it = FT_D64;
		break;
	  case DT_8050:
		it = FT_D80;
		break;
	  case DT_8250:
		it = FT_D82;
		break;
	  default:
		it = -1;
		break;
	}
	return it;
}

//----------------------------------------------------------------------
// GET DEFAULT DEVICE TYPE FOR SELECTED ADAPTER TYPE
//----------------------------------------------------------------------
int8_t GetDefDeviceType()
{
	return (fDevice == 0 ? DT_8250 : DT_1541);
}

//----------------------------------------------------------------------
// GET DEVICE TYPE FOR SELECTED ADAPTER TYPE
//----------------------------------------------------------------------
int8_t GetDeviceType()
{
	return (fDevice == 0 ? ieee_devtyp : iec_devtyp);
}



//----------------------------------------------------------------------
// (RE)SET BIT IN VBAM (FREE/ALLOCATE BLOCK)
//----------------------------------------------------------------------
int8_t DimgSetVBAM(st_dimage *di, uint16_t block, int8_t state)
{
	uint8_t		byte, bit;

	//uartPrintf_P(PSTR("%d:%d,"),block, !state);
	if(block >= di->sectors)
		return -1;

	byte 	= block >> 3;
	bit		= block & 0x7;
	if(state)
		di->bam[byte] |= _BV(bit);
	else
		di->bam[byte] &= ~_BV(bit);

	return 0;
}

//----------------------------------------------------------------------
// READ BAM DATA FROM DISK
//----------------------------------------------------------------------
int8_t DimgReadBAM(st_dimage *di, uint8_t *buf, uint16_t size)
{
	//st_DiskBuf	blk;
	//uint8_t		*buf = blk->buf;
	uint8_t		*p_bam;
	int8_t		rc;
	uint8_t		tr, se;
	uint8_t		i, j, k, l;
	uint8_t		b_tr, b_se;
	uint16_t	secCnt;
	uint8_t		blk[256];			// block buffer

	//blk.buf = blkbuf;

	if(size < DimgSizeOfBAM(di))
		return -1;

//	InitFloppy(di->fileType);

	di->bam = buf;

	secCnt	= 0;										// NUMBER OF SECTORS ON DISK

	tr = di->trkBAM;
	se = di->secBAM;
	rc = -1;
	switch(di->fileType)
	{
	  case FT_D80:
	  case FT_D82:
	  	{
		  	st_d82_BAM	*bam = (st_d82_BAM *)blk;

			//blks 	= (di->fileType == FT_D82) ? 4 : 2;			// NUMBER OF BAM BLOCKS
			b_tr	= 1;										// BAM TRACK
			//b_se	= 0;										// BAM SECTOR

		  	for(i=0; i<4; ++i)
			{
				if(tr != di->trkBAM)
					break;

				if(ReadBlock(blk, di->curDrive, tr, se, di->burstOpt))
					break;

				tr = bam->trkNx;
				se = bam->secNx;

			  	for(j=0, p_bam=bam->bam; j<50; ++j)
				{
					b_se = DimgSectorCnt(di, b_tr);				// SECTORS PER TRACK
					p_bam++;									// 1. BYTE = SECTOR COUNT
				  	for(k=0; k<4; ++k)
					{
					  	for(l=0; l<8; ++l)
						{
							if(b_se == 0)
								break;

							b_se--;
							//if(b_tr == 38 || b_tr == 39)
							DimgSetVBAM(di, secCnt++, (*p_bam) & _BV(l));
						}
						p_bam++;
					}
					//uartPrintf_P(PSTR("%d/%d;"),b_tr,secCnt);
					if(++b_tr > di->tracks)
						break;
				}
				//break;
				if(b_tr > di->tracks)
					break;
			}
		}
		//uartPutCrLf();
		//uartPrintf_P(PSTR("sectors written: %d"),secCnt);
		break;

	  case FT_D64:
	  case FT_D71:
	  	{
		  	st_d71_header	*bam = (st_d71_header *)blk;
		  	st_d71_bam2		*bam2 = (st_d71_bam2 *)blk;
			b_tr	= 1;										// BAM TRACK

			p_bam = bam->bam;
		  	for(i=0; i<2; ++i)
			{
				// 18/0 and 53/0
				if(ReadBlock(blk, di->curDrive, tr, se, di->burstOpt))
					break;

			  	for(j=0; j<35; ++j)
				{
					b_se = DimgSectorCnt(di, b_tr);				// SECTORS PER TRACK
					if(tr == 18)
						p_bam++;								// 1. BYTE = SECTOR COUNT

				  	for(k=0; k<3; ++k)
					{
					  	for(l=0; l<8; ++l)
						{
							if(b_se == 0)
								break;

							b_se--;
							//if(b_tr == 38 || b_tr == 39)
							DimgSetVBAM(di, secCnt++, (*p_bam) & _BV(l));
						}
						p_bam++;
					}
					//uartPrintf_P(PSTR("%d/%d;"),b_tr,secCnt);
					if(++b_tr > di->tracks)
						break;
				}
				//break;
				if(b_tr > di->tracks)
					break;

				tr = 53;					// NEXT BLOCK	//bam->trkNx;
				p_bam = bam2->bam;
			}
		}
		//uartPutCrLf();
		//uartPrintf_P(PSTR("sectors written: %d"),secCnt);
		break;

	  case FT_D81:
	  	{
		  	st_d81_BAM	*bam = (st_d81_BAM *)blk;

			//blks 	= (di->fileType == FT_D82) ? 4 : 2;			// NUMBER OF BAM BLOCKS
			b_tr	= 1;										// BAM TRACK
			//b_se	= 0;										// BAM SECTOR

		  	for(i=0; i<4; ++i)
			{
				if(tr != di->trkBAM)
					break;

				//uartPrintf_P(PSTR("read block: %d/%d"),tr, se);
				//uartPutCrLf();

				if(ReadBlock(blk, di->curDrive, tr, se, di->burstOpt))
					break;

				tr = bam->trkNx;
				se = bam->secNx;

			  	for(j=0, p_bam=bam->bam; j<40; ++j)
				{
					b_se = DimgSectorCnt(di, b_tr);				// SECTORS PER TRACK
					p_bam++;									// 1. BYTE = SECTOR COUNT
				  	for(k=0; k<5; ++k)
					{
					  	for(l=0; l<8; ++l)
						{
							if(b_se == 0)
								break;

							b_se--;
							//if(b_tr == 38 || b_tr == 39)
							DimgSetVBAM(di, secCnt++, (*p_bam) & _BV(l));
						}
						p_bam++;
					}
					//uartPrintf_P(PSTR("%d/%d;"),b_tr,secCnt);
					if(++b_tr > di->tracks)
						break;
				}
				//break;
				if(b_tr > di->tracks)
					break;
			}
		}
		//uartPutCrLf();
		//uartPrintf_P(PSTR("sectors written: %d"),secCnt);
		break;

	  default:
		// UNKNOWN IMAGE FORMAT
		break;
	}
	
	if(di->sectors == secCnt)
		rc = 0;

	return rc;
}


//----------------------------------------------------------------------
// TEST BAM IF SECTOR IS FREE 
//----------------------------------------------------------------------
int8_t DimgIsSectorFree(st_dimage *di, uint8_t tr, uint8_t se)
{
	uint16_t	block;
	uint8_t		byte, bit;

	if(di->bam == NULL)
		return 0;								// ALLOCATED IF NO BAM!!

	block	= DimgSectorNo(di, tr, se);

	byte 	= block >> 3;
	bit		= block & 0x7;

	return (di->bam[byte] & _BV(bit)) != 0;
}


//----------------------------------------------------------------------
// CALC NUMBER OF SECTORS BY TRACK 
//----------------------------------------------------------------------
int8_t DimgSectorCnt(st_dimage *di, uint8_t tr)
{
	uint8_t	*pt,trk;
 
	if(tr == 0 || tr > di->tracks)
		return -1;

	pt = di->tblSecCnt;

	while(1)
	{
		if(!(trk = pgm_read_byte(pt++)))
			break;

		if(tr <= trk)
		{
			return(pgm_read_byte(pt));
		}
		pt++;
	}
	return -1;
}





//----------------------------------------------------------------------
// CALC SECTOR NUMBER 
//----------------------------------------------------------------------
int16_t DimgSectorNo(st_dimage *di, uint8_t tr, uint8_t se)
{
	uint8_t	*pt, trk, sec=0, i;
	int16_t	rc;
 
	if(tr == 0 || tr > di->tracks)
		return -1;

	switch(di->fileType)
	{
	  case FT_D81:
		if(se >= 40)
			return -1;

	  	rc = (tr -1) * 40 + se;
		break;

	  default:
		rc = 0;
		pt = di->tblSecCnt;
		trk = 0;

		for(i=1; i<=tr; i++)
		{
			if(i > trk)
			{
				trk = pgm_read_byte(pt++);
				sec = pgm_read_byte(pt++);
			}
			if(i == tr)
				break;

			rc += sec;
		}
		if(se >= sec)
			return -1;

		rc += se;
		break;
	}
	return rc;
}


//----------------------------------------------------------------------
// LIST BAM OF DISK
//----------------------------------------------------------------------
int8_t ListBAM(uint8_t drive, uint8_t ft, uint8_t bam, int8_t opt)
{
	uint16_t	free, size;
	int8_t		se;
	uint8_t		tr;
	uint8_t		se2;
	uint8_t		flg;
	uint8_t		*ptr;
	st_dimage 	dim;
	st_dimage	*di = &dim; 

	InitBurst();
	if(DimgInit(di, drive, ft, opt))
		return 99;

	free = BytesFree();
	size = DimgSizeOfBAM(di);
	if(free >= DimgSizeOfBAM(di) +128)
	{
		uartPrintf_P(PSTR("reading BAM (%d Bytes). "),size);

		ptr = alloca(size);
		if(DimgReadBAM(di, ptr, size))
		{
			uartPutLine_p("error.");
		}
		else
		{
			uartPutLine_p("ok.");

			for(tr=1; tr<=di->tracks; tr++)
			{
				flg = 0;
				if(bam == TP_BAM)
				{
					se = DimgSectorCnt(di, tr);
					se2 = 0;
					while(se--)
					{
						if(!DimgIsSectorFree(di, tr, se2++))
						{
							flg = 1;
							break;
						}
					}
				}
				else
					flg = 1;

				if(flg)
				{
					uartPrintf_P(PSTR("track %2d: "), tr);

					se = DimgSectorCnt(di, tr);
					se2 = 0;
					while(se--)
					{
						if(DimgIsSectorFree(di, tr, se2++))
							uartPutChar('.');
						else
							uartPutChar('X');
					}
					uartPutCrLf();
				}
			}
		}
	}
	else
	{
		uartPrintf_P(PSTR("?memory error: %d"), free);
		uartPutCrLf();
	}
	return 3;
}


//----------------------------------------------------------------------
// BACKUP DISK (READ BLOCKS)
//----------------------------------------------------------------------
int8_t BackupReadBlocks(st_dimage *di, st_devbuf *db)
{
	uint8_t		buf[256];			// block buffer
	uint16_t	free, i;
	int8_t		rc;
	int8_t		se;
	uint8_t		tr;
	//uint8_t		se2;
	uint8_t		*ptr;
	uint16_t	anz;
	st_ringbuf	*rb;


	rb = &db->rb;

	if(di->curTrack == 0)
	{
		// INIT!
		di->curTrack++;
		di->curSector = 0;
	}
	else if(di->curTrack > di->tracks)
	{
		// EOF!
		return 1;
	}

	se = di->curSector;
	tr = di->curTrack;
	
	//if(ST)
	//	return 1;

	rb = &db->rb;
	free = RingbBytesFree(rb);

	while(1)
	{
		if(free >= db->min)
		{
			if(se == 0)
			{
				di->curSectors = DimgSectorCnt(di, tr);
			}


			//uartPrintf_P(PSTR("RB free/size/cnt: %d/%d/%d"), free, rb->size, rb->cnt);
			//uartPutCrLf();

			anz = 256;	//db->max > free ? free : db->max;

			if(DimgIsSectorFree(di, tr, se))
			{
				// BLOCK IS EMPTY
				while(anz--)
					RingbWrite(rb, 0);	
			}
			else
			{
				if(di->bam == NULL)
				{
					// ALL BLOCKS
					/*if(se == 0)
					{
						uint8_t		tr2 = tr +1;

						if(tr2 > di->tracks) 
							tr2 = di->trkDir;
						rc = ReadBlocksDef(&blk, di->curDrive, tr, se, di->curSectors, tr2);
					}
					else
					{
						rc = ReadBlocksNxt(&blk);
					}*/
					rc = ReadBlockDef(buf, di->curDrive, tr, se);
				}
				else
				{
					rc = ReadBlockDef(buf, di->curDrive, tr, se);
				}
				


				if(rc)
				{
					if(di->errorCnt >= MAX_READ_ERROR)
						break;

					di->errorBuf[di->errorCnt++] = (tr << 8) | se;			// Error Buffer
					memset(buf, 0, sizeof(buf));
				}

				for(i=0, ptr=buf; i<256; ++i)
				{
					RingbWrite(rb, *(ptr++));	
				}				
			}

			// NEXT SECTOR
			if(++se >= di->curSectors)
			{
				di->curTrack++;
				di->curSector = 0;
			}
			else
				di->curSector = se;
		}
		return 0;
	}

	// READ ERROR?

	return -1;
}

//----------------------------------------------------------------------
// BACKUP DISK TO DISKIMAGE FILE (XMODEM)
//----------------------------------------------------------------------
int8_t Backup(uint8_t drive, uint8_t ft, uint8_t par, int8_t burstopt)
{
	int8_t		rc,n;
	uint16_t	free, size=0;
	char		*s;
	//---- DIMAGE ---------
	uint8_t		*ptr;
	st_dimage 	dim;
	st_dimage	*di = &dim; 
	//---- XBUF -----------
	st_ringbuf 	*rb;
	st_devbuf	*db;
	st_xmbuf	*xb;
	uint16_t	ramMin;

	InitBurst();
	if(DimgInit(di, drive, ft, burstopt))
		return 99;

	// CHECK RAM
	ramMin = 128 +128 + 550 + 300;			// RAM REQUIREMENT: 2*Xmodem buffer, Ringbuffer, Min
	if(par == TP_BAM)
	{
		size	= DimgSizeOfBAM(di);		// BAM SIZE
		ramMin += size;						// RAM REQUIREMENT: +BAM SIZE
	}

	free = BytesFree();
	if(free < ramMin)
	{
		// MEMORY ERROR
		return 7;
	}

	if(ft != FT_IMG && GetDeviceType() == DT_1571)
	{
		uartPutLine_p("setting interleave to 1");
		BurstInterleave(1);
	}


	// PREPARE BACKUP

	uartPutString_p("backup disk to imagefile (");
	s = GetTokenString(ft | (XT_FILETYPE << 8));
	uartPutString_P(s);
	uartPutChar('/');
		
	if(par == TP_BAM)
	{
		uartPutLine_p("allocated blocks)");
		uartPrintf_P(PSTR("reading BAM (%d Bytes). "), size);

		ptr = alloca(size);
		if(DimgReadBAM(di, ptr, size))
		{
			uartPutLine_p("error.");
			return 99;
		}
		else
		{
			uartPutLine_p("ok.");
		}
	}
	else
		uartPutLine_p("all blocks)");


	// PREPARE XMODEM TRANSFER
	db = alloca(SIZE_DEVBUF + SIZE_DEVRING);			// 6 + struc + 550
	rb = &db->rb;
	DevbufInit(db, SIZE_DEVRING, 0, 256, 256);

	xb = alloca(SIZE_XMBUF);							// 2 * 128 + 12 + struc
	XmPrepareTx(xb);
	XmSetHeader(xb, "image.d64", 0, NULL);
	//SendFileHeader(xb, ft, s);


	uartPrintf_P(PSTR("bytes free: %d, %d buffer"), BytesFree(), BytesFree() / 256);
	uartPutCrLf();


	// START BACKUP

	while(xb->eot == 0)
	{
		if((rc = BackupReadBlocks(di, db)))
			break;

		XmWriteRB(xb, rb);
	}
	uartPutCrLf();

	n = 0;
	while(di->errorCnt--)
	{
		uartPrintf_P(PSTR("read error track/sector: %d/%d"), di->errorBuf[n]>>8, di->errorBuf[n] & 0xff);
		uartPutCrLf();
		n++;
	}
	if(n == MAX_READ_ERROR)
		uartPutLine_p("maybe more read errors ...");

	if(rc < 0)
	{
		// READ ERROR
		while(xb->eot < 2)
		{
			XmWriteCancel(xb);
		}
		uartPutLine_p("xmodem transmission canceled.");
	}
	else
	{
		// EOF
		while(xb->eot < 2)
		{
			XmWriteEot(xb, rb);
		}
		switch(xb->eot)
		{
		  case 2:
			uartPutLine_p("xmodem transmission ok.");
			break;

		  default:
			uartPutLine_p("?xmodem transmission error.");
			break;
		}
	}
	return 0;
}

//----------------------------------------------------------------------
// DISK IMAGE INIT
//----------------------------------------------------------------------
int8_t DimgInit(st_dimage *di, uint8_t drive, uint8_t ft, int8_t burstOpt)
{
	int8_t		se;
	uint8_t		tr;

	di->fileType	= ft;				// FT_*
	di->fileOption	= ft;				// FT_*
	di->tblSecCnt	= NULL;				// sectors per track table (PGMSPACE!)
	di->bam			= NULL;				// BAM Block
	//di->bamSector	= 0;				// cur. BAM sector
	di->errorCnt	= 0;				// Error count
	di->burstOpt	= burstOpt;


	switch(ft)
	{
	  case FT_D64_40:
	  case FT_D64_40X:
	  case FT_D64_42:
	  case FT_D64_42X:
	  case FT_D64X:
		di->fileType	= FT_D64;			// FT_*

	  case FT_D64:
		di->trkStart	= 18;				// first block
		di->secStart	= 0;				// first block
		di->trkDir		= 18;				// first dir block
		di->secDir		= 1;				// first dir block
		di->trkBAM		= 18;				// first BAM block
		di->secBAM		= 0;				// first BAM block
		di->tblSecCnt	= sleD64;			// sectors per track table (PGMSPACE!)

		switch(ft)
		{
		  case FT_D64_40X:
		  case FT_D64_40:
			di->tracks	= 40;				// number of tracks
			break;
		  case FT_D64_42:
		  case FT_D64_42X:
			di->tracks	= 42;				// number of tracks
			break;
		  case FT_D64X:
		  case FT_D64:
			di->tracks	= 35;				// number of tracks
			break;
		}
		break;


	  case FT_D71:
		di->trkStart	= 18;				// first block
		di->secStart	= 0;				// first block
		di->trkDir		= 18;				// first dir block
		di->secDir		= 1;				// first dir block
		di->trkBAM		= 18;				// first BAM block
		di->secBAM		= 0;				// first BAM block
											// second BAM at 53/0
		di->tracks		= 70;				// number of tracks

		di->tblSecCnt	= sleD71;			// sector per track table (PGMSPACE!)
		break;

	  case FT_D80:
	  case FT_D82:
		di->trkStart	= 39;				// first block
		di->secStart	= 0;				// first block
		di->trkDir		= 39;				// first dir block
		di->secDir		= 1;				// first dir block
		di->trkBAM		= 38;				// first BAM block
		di->secBAM		= 0;				// first BAM block
		di->tracks		= (ft == FT_D80) ? 77 : 154;	// number of tracks
		di->tblSecCnt	= sleD82;			// sector per track table (PGMSPACE!)
		break;

	  case FT_D81:
		di->trkStart	= 40;				// first block
		di->secStart	= 0;				// first block
		di->trkDir		= 40;				// first dir block
		di->secDir		= 3;				// first dir block  (40/3-39)
		di->trkBAM		= 40;				// first BAM block
		di->secBAM		= 1;				// first BAM block  (40/1,2)
		di->tracks		= 80;
		di->tblSecCnt	= sleD81;			// sector per track table (PGMSPACE!)
		break;

	  default:
		return -1;
	}

	di->curTrack	= 0;					// current track
	di->curSector	= 0;					// current sector
	di->curDrive	= drive;				// current drive

	tr	= di->tracks;
	se	= DimgSectorCnt(di, tr);
	di->sectors	= DimgSectorNo(di, tr, se -1) +1;		// number of sectors
	return 0;
} 





//----------------------------------------------------------------------
// DIMAGE TEST PROGRAM
//----------------------------------------------------------------------
#ifdef TEST_DIMAGE
int8_t DimgTest(uint8_t ft)
{
	uint16_t	free, size;
	int8_t		se;
	uint8_t		tr;
	uint8_t		tr2=0, se2;
	uint8_t		*ptr;
	int16_t		cnt;
	st_dimage 	dim;
	st_dimage	*di = &dim; 

	DimgInit(di, 0, ft);
	uartPrintf_P(PSTR("tracks:%d,sectors:%d,BAM-size:%d,headerblk:%d/%d,dir:%d/%d,BAM:%d/%d"),
				DimgTracks(di),DimgSectors(di),DimgSizeOfBAM(di),
				di->trkStart,di->secStart,di->trkDir,di->secDir,di->trkBAM,di->secBAM);
	uartPutCrLf();

	for(tr=1,se2=0; tr-1<=DimgTracks(di); tr++)
	{
		se = DimgSectorCnt(di, tr);
		if(se != se2)
		{
			if(se2 != 0)
			{
				uartPrintf_P(PSTR("track %d - %d: %d sectors"),tr2,tr-1,se2);
				uartPutCrLf();
			}
			se2 = se;
			tr2 = tr;
		}
	}
	/*for(tr=1; tr<=DimgTracks(di); tr++)
	{
		cnt = DimgSectorNo(di, tr, 0);
		uartPrintf_P(PSTR("%d/%d "),tr,cnt);
	}
	uartPutCrLf();*/

	//ListBam()
	free = BytesFree();
	size = DimgSizeOfBAM(di);
	if(free >= DimgSizeOfBAM(di) +128)
	{
		uartPrintf_P(PSTR("reading BAM (%d Bytes). "),size);

		ptr = alloca(size);
		if(DimgReadBAM(di, ptr, size))
		{
			uartPutLine_p("error.");
		}
		else
		{
			uartPutLine_p("ok.");

			for(tr=32; tr<48; tr++)
			{
				uartPrintf_P(PSTR("track %2d: "), tr);

				se = DimgSectorCnt(di, tr);
				se2 = 0;
				while(se--)
				{
					if(DimgIsSectorFree(di, tr, se2++))
						uartPutChar('.');
					else
						uartPutChar('X');
				}
				uartPutCrLf();
			}
		}
	}

	return 0;
}
#endif

