//-------------------------------------------------------------------------
// Titel:	 XS-1541 - TIMER
// Funktion: initialize and handle AVR hardware timer
//-------------------------------------------------------------------------
// Copyright (C) 2007,2008  Ingo Korb <ingo@akana.de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

//#include "config.h"
#include <avr/interrupt.h>
#include <avr/io.h>
#include "compat.h"
//#include "diskchange.h"
//#include "errormsg.h"
#include "timer.h"



volatile uint8_t 	cnt0;				// 100Hz
volatile uint16_t	cnt1;				// HIRES TIMER
volatile uint8_t 	iec_timer;			// ms timer
volatile uint8_t 	ieee_timer;			// ms timer
volatile uint16_t	xm_timer;			// xmodem timer
volatile tick_t		ticks;



//----------------------------------------------------------------------
// MAIN TIMER
ISR(TIMER1_COMPA_vect) 
{
	if(cnt0++ >= 10) 
	{
		// 100Hz
		cnt0 = 0;
		ticks++;
	}
	cnt1++;

	/*if (error_blink_active) {
	if ((ticks & 15) == 0)
		DIRTY_LED_PORT ^= DIRTY_LED_BIT();
	}*/

	if(ieee_timer != 0)	ieee_timer--;
	if(iec_timer != 0)	iec_timer--;
	if(xm_timer != 0)	xm_timer--;
}

void InitTimer(void) 
{
	//--- Timer 0 initialisieren --- 
	//TCCR0 = _BV(CS01);			// Count F_CPU/8 in timer 0 
	TCCR0 = _BV(CS01)|_BV(CS00);	// Count F_CPU/64 in timer 0 


	//--- Timer 1 initialisieren --- 1000Hz
	TCNT1  = 0;
	TCCR1A = 0;
	TCCR1B = _BV(CS10);			// Teiler 1/1
	TCCR1B |= _BV(WGM12);		// Modus: Z�hlen bis Vergleichswert

	//TIMSK  = _BV(TOIE1);		// Timer1 Overflow

	//OCR1A = 3686; 			// Vergleichswert 1ms bei 3,7 MHz
	//OCR1A = 14745; 			// Vergleichswert speichern 14745600 Hz
	OCR1A = F_CPU /1000;		// Vergleichswert f�r 1ms

	TIMSK1 |= _BV(OCIE1A);		// maskiere Timer-INT

	cnt0 = 0;
	cnt1 = 0;
}

