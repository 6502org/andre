//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Floppy Handler
// Funktion: to handle floppy commands for cmd parser
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------


#ifndef FLOPPY_H
#define FLOPPY_H




#define SendCmd_p(__s) 	SendCmd_P(PSTR(__s))



#define SIZE_DEVBUF		sizeof(st_devbuf)
#define SIZE_DEVRING	550	




// STRUCTS
typedef struct 
{
	uint16_t		min;				// minimal bytes to read 
	uint16_t		max;				// maximum bytes to read 
	uint8_t			ch;					// channel
	st_ringbuf		rb;
} st_devbuf;





enum filetypes {FT_P00,FT_T64,FT_PRG,FT_D64,FT_D71,FT_D80,FT_D81,FT_D82,FT_X64,FT_G64,FT_IMG,
				FT_D64_40, FT_D64_42, FT_D64X, FT_D64_40X, FT_D64_42X
		   	   };





#define BurstDefault()	(((iec_devtyp == DT_1571 ||  iec_devtyp == DT_1581) && fDevice != 0) ? TP_BURST : TP_SLOW)

#define HighSpeed()		((iec_devtyp == DT_1541 && fDevice != 0) ? 0 : 1)



int8_t SendBuffer(char *arg, int16_t anz);


int8_t DumpHex(char *buf, uint16_t anz);
int8_t DumpHexStr(char *buf);
int8_t ReadBuf(char *buf, uint16_t *len);
//int8_t ReadBlock(char *buf, uint8_t dr,uint8_t tr,uint8_t se);
int8_t ReadBlock(uint8_t *buf, uint8_t dr, uint8_t track, uint8_t sector,int8_t opt);
int8_t ReadBlockStd(char *buf, uint8_t dr,uint8_t tr,uint8_t se);
int8_t ReadBlockDef(uint8_t *buf, uint8_t dr, uint8_t track, uint8_t sector);
int8_t ReadBlocksDef(st_DiskBuf *buf, uint8_t dr, uint8_t track, uint8_t sector, uint8_t sectors, uint8_t ntrk);
int8_t ReadBlocksNxt(st_DiskBuf *buf);

int8_t SendMemoryRead(uint16_t adr,uint8_t anz);
int8_t SendMemoryWrite(uint16_t adr,uint8_t anz, uint8_t *data);

int8_t DevbufInit(st_devbuf *db, uint16_t size, uint8_t ch, uint16_t min, uint16_t max);

#ifdef XMODEM_H
int8_t SendFileHeader(st_xmbuf	*xb, uint8_t ft, char *filenam);
#endif

int8_t LoadFileInit(st_DiskBuf *o, char *fileName, int8_t option);
int8_t LoadFile(st_DiskBuf *o);

int8_t DownloadFile(char *arg, int8_t, int8_t);
int8_t DumpFile(char *arg, int8_t option);
int8_t DumpBlock(uint8_t dr,uint8_t tr,uint8_t se,uint8_t anz, int8_t option);
int8_t DumpTrack(uint8_t dr,uint8_t tr,uint8_t il, int8_t option);
int8_t DumpNxtBlock(void);
int8_t DumpMem(uint16_t, uint16_t);
int8_t SendString(char *arg);
int8_t SendBlockRead(uint8_t ch,uint8_t dr,uint8_t tr,uint8_t se);
int8_t Catalog(char *arg);
int8_t ReadErrorCh(char *, uint8_t len);
int8_t PrintErrorCh(void);
int8_t PrintIfErrorCh_P(char *);
int8_t SendCmd(char *arg);
int8_t SendCmd_P(char *arg);


#endif

