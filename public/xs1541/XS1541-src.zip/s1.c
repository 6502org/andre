//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Serial Speeder 1
// Funktion: handle fast communication over serial IEC (OpenCBM S1)
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util\delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//#include "config.h"
#include "compat.h"
//#include "timer.h"
#include "main.h"
/*#include "uart.h"
#include "xmodem.h"
#include "ieee.h"*/
#include "gcr.h"
#include "iec.h"
//#include "floppy.h"
#include "transfer.h"
#include "microcode.h"
#include "s1.h"





// DEFINES

//#define	Init(a)				ParInit(a)
//#define	Read(a)				ParRead(a)
//#define	Write(a,b)			ParWrite(a,b)
//#define	Exit()   			ParExit()



// CONST

//
// S1 CODE (1541, 1571)
//
static prog_uchar mcS1[] = {
 #include "s1.inc"
};





// VARS








//
// FOR UART MESSAGES TO VIEW PROTOCOLL
//








//---------------------------
// WRITE BYTE TO FLOPPY
//---------------------------
static int8_t WriteByteNohs(uint8_t data)
{
    int8_t	b, i;

    for(i=7; ; i--) 
	{ 
		b = data & 0x80;
		data <<= 1;

		IecData(!b);
		IecClk(1);
		while((IecDebounce() & IEC_BIT_CLK));			// wait for clock low

		IecData(b);
		while(!(IecDebounce() & IEC_BIT_CLK));			// wait for clock high

		IecData(1);
		IecClk(0);

        if(i<=0) return 0;

		while((IecDebounce() & IEC_BIT_DATA));			// wait for data low
    }
	return 0;
}
static int8_t WriteByte(uint8_t data)
{
	WriteByteNohs(data);
	while((IecDebounce() & IEC_BIT_DATA));				// wait for data low
	return 0;
}


//---------------------------
// WRITE 2 BYTE TO FLOPPY
//---------------------------
static int8_t Write2Byte(uint8_t data1, uint8_t data2)
{
	WriteByte(data1);
	WriteByte(data2);
	return 0;
}



//---------------------------
// READ BYTE FROM FLOPPY
//---------------------------
static uint8_t Read(void)
{
	uint8_t d, b;
	int8_t	i;

    d = 0;
    for(i=7; i>=0; i--) 
	{
		while(!(IecDebounce() & IEC_BIT_DATA));			// wait for data high

		IecClk(1);

		d >>= 1;
		b = (IecDebounce() & IEC_BIT_CLK);
        if(!b)
			d |= 0x80;

		IecData(0);
		while((IecDebounce() & IEC_BIT_CLK) == b);		// wait for clock change

		IecData(1);
		while((IecDebounce() & IEC_BIT_DATA));			// wait for data low

		IecClk(0);
    }
    return d;
}



//---------------------------
// READ T/S FROM FLOPPY
//---------------------------
static int8_t Read2Byte(uint8_t *data)
{
	*(data++)	= Read();
	*(data)		= Read();
	return 0;
}





//----------------------------------------------------------------------
// UPLOAD PARALLEL BUS MICROCODE TO FLOPPY
//--------------------------------------------------------
static int8_t Init(int8_t lwTyp, turbo_start start)  
{
	int8_t	rc;

	switch(lwTyp)
	{
	  case DT_1541:
	  case DT_1571:
		rc = McUpload_P(0x0700, mcS1, sizeof(mcS1));
		break;
	  default:
		return -1;
	}

	start();
	while((IecDebounce() & IEC_BIT_DATA));			// wait for data low
	return rc;
}

static void Exit(void) 
{
	WriteByte(0);
	WriteByteNohs(0);
	//arch_usleep(100);
}




DECLARE_TRANSFER_FUNCS(s1_transfer);
//DECLARE_TRANSFER_FUNCS_EX(pp_transfer, 1, 1);




