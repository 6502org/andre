//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Track Handler
// Funktion: handle read/write of whole tracks
//-------------------------------------------------------------------------
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <inttypes.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloca.h>

#include "main.h"
#include "uart.h"
#include "ymodem.h"
#include "ieee.h"
#include "iec.h"
#include "burst.h"
#include "floppy.h"
#include "image.h"
#include "track.h"











// CONST



// TOKEN



// STRUCTS


// STATICS


// GLOBALS



// EXTERNALS







//----------------------------------------------------------------------
// SEARCH SEKTOR IN BLK BUFFER
//----------------------------------------------------------------------
int8_t DimgSearchBlkbuf(st_blkbuf *blkbuf, uint8_t sector)
{
	int8_t	i;

	// SEARCH FOR REQUESTED SECTOR
	for(i = 0; i < blkbuf->cntBuf; ++i)
	{
		if(blkbuf->buf[i].stat == 2 && blkbuf->buf[i].sector == sector)
		{
			return i;
		}	
	}
	return -1;
}


//----------------------------------------------------------------------
// READ BLOCK BUFFER
//----------------------------------------------------------------------
int8_t DimgReadBlkbuf(st_blkbuf *blkbuf, st_blk	**pBlk, int8_t sector)
{
	st_blk	*blk;
	int8_t	n;

	if(sector < 0)
	{
		if(blkbuf->secOut >= blkbuf->cntSec)
			return 99;

		sector = blkbuf->secOut;
	}

	//uartPrintf_P(PSTR("srch %d;"), sector);
	if((n = DimgSearchBlkbuf(blkbuf, sector)) < 0)
		return -1;

	if(sector == blkbuf->secOut)
		blkbuf->secOut++;

	blk			= &(blkbuf->buf[n]);
	blk->stat	= 3;

	// DEBUG
	//uartPrintf_P(PSTR("sd %d;"), blk->sector);

	*pBlk = blk;
	return 0;
}


//----------------------------------------------------------------------
// READ BLOCK BUFFER
//----------------------------------------------------------------------
int8_t DimgFreeBlkbuf(st_blkbuf *blkbuf, st_blk	*blk)
{
	if(blk->stat != 3)
	{
		return -1;
	}

	// DEBUG
	uartPrintf_P(PSTR("fr %d;"), blk->sector);

	blk->stat	= 0;
	blkbuf->cntFree++;
	return 0;
}



//----------------------------------------------------------------------
// READ A TRACK (NEXT SECTOR)
//----------------------------------------------------------------------
int8_t DimgReadTrack(st_blkbuf *blkbuf)
{
	int8_t	i, b;
	int8_t	n, cnt;
	//uint8_t sector;
	st_blk	*blk;

	if(!blkbuf->toRead)
		return 99;

	//uartPutLine_p("deb1");

//	ReadBlockDef(&blkbuf->dbuf, 0, blkbuf->track, blkbuf->secIn);

	if(blkbuf->cntFree == 0)
	{
		uartPutLine_p("no buffer");
		return 1;
	}

	//uartPutLine_p("deb2");

	// SEARCH FREE BUFFER
	for(i = 0,n = -1; i < blkbuf->cntBuf; ++i)
	{
		if(blkbuf->buf[i].stat == 0)
		{
			n = i;
			break;
		}	
	}
	if(n < 0) 	
	{
		//uartPutLine_p("no free buffer");
		return -1;
	}

	// SET BUFFER
	blk = &(blkbuf->buf[n]);

	//uartPutLine_p("deb3");

	// BUFFER PROBLEM?
	//
	if(blkbuf->cntFree == 1 && blkbuf->secIn != blkbuf->secOut)
	{
		// PROBLEM? ONLY ONE BUFFER FREE?
		if(DimgSearchBlkbuf(blkbuf, blkbuf->secOut) < 0)
		{
			// ALARM!!
			uartPutString_p("XXX;");
			blkbuf->secIn	= blkbuf->secOut;
			blkbuf->stat	= 0;
		}
	}

	//uartPutLine_p("deb4");

	// BLOCK ALREADY BUFFERED?
	//
	if(DimgSearchBlkbuf(blkbuf, blkbuf->secIn) < 0)
	{
		// DEBUG
		uartPrintf_P(PSTR("rd %d;"), blkbuf->secIn);

		// READ BLOCK 
		if(ReadBlockDef(blk->buf, blkbuf->drive, blkbuf->track, blkbuf->secIn))
			return -1;

		blkbuf->toRead--;

		i = blkbuf->secIn / 8;
		b = blkbuf->secIn % 8;
		blkbuf->bam[i] |= _BV(b);			// ALLOCATE BLOCK IN BAM

		blkbuf->cntFree--;
		blk->sector	= blkbuf->secIn;		// SECTOR#
		blk->stat	= 2;					// ALLOCATE BUFFER
	}


	// SEARCH NEXT SECTOR#
	switch(blkbuf->stat)
	{
	  case 0:
		// SIMPEL READING INTERLEAVE 1
		if(blkbuf->secIn++ >= blkbuf->cntSec)
			blkbuf->stat = 99;
		break;

	  case 50:
		// FIX INTERLEAVE
	  	blkbuf->secIn += blkbuf->il1;
		break;

	  case 60:
		// BURST TRACK READ, FIX INTERLEAVE 5
	  	blkbuf->secIn += blkbuf->il1;
		break;

	  default:
		// TRACK READY
		return 99;
	}

	// OVERFLOW??
	while(blkbuf->secIn >= blkbuf->cntSec)
		blkbuf->secIn -= blkbuf->cntSec;

	// ALREADY READ??
	cnt = blkbuf->cntSec;
	do 
	{
		i = blkbuf->secIn / 8;
		b = blkbuf->secIn % 8;
		if(!(blkbuf->bam[i] & _BV(b)))
			break;

		if(blkbuf->secIn++ >= blkbuf->cntSec)
		{
			blkbuf->secIn= 0;

			if(cnt-- == 0)
			{
				blkbuf->stat = 99;
				break;
			}
		}
	} while(1);

	return 0;
}

//----------------------------------------------------------------------
// READ A TRACK (INIT)
//----------------------------------------------------------------------
int8_t DimgReadTrackInit(st_dimage *di, st_blkbuf *blkbuf, uint8_t bufAnz, uint8_t drive, uint8_t track, uint8_t interl)
{
	
	int8_t	i;

	blkbuf->stat	= 0;					// status 
	blkbuf->mode	= TP_SLOW;
	blkbuf->cntBuf	= bufAnz;				// number of 256 byte buffer
	blkbuf->cntFree	= bufAnz;				// number of free buffer
	blkbuf->drive	= drive;				// current drive#
	blkbuf->track	= track;				// current track#
	blkbuf->il1		= 1;					// interleave 1
	blkbuf->cntSec	= DimgSectorCnt(di, track);	// number of sectors in this track
	//blkbuf->cntSec2	= blkbuf->cntSec;		// number of sectors to read
	blkbuf->toRead	= blkbuf->cntSec;		// number of sectors to read
	blkbuf->secIn	= 0;					// current sector for reading
	blkbuf->secOut	= 0;					// current sector for sending

	for(i = 0; i < sizeof(blkbuf->bam); ++i)
	{
		blkbuf->bam[i] = 0;
	}

	for(i = 0; i < blkbuf->cntBuf; ++i)
	{
		blkbuf->buf[i].stat = 0;
	}

	if(interl)
	{
		blkbuf->stat	= 50;					// status 
		blkbuf->il1		= interl;				// interleave 
	}
	/*else switch(di->fileType)
	{
	  case FT_D64:
	  case FT_D71:
		blkbuf->stat	= 50;					// status 
		if(HighSpeed())
			blkbuf->il1	= 8;					// interleave 
		else
			blkbuf->il1	= 15;					// interleave 
		break;

	  case FT_D80:
	  case FT_D82:
		blkbuf->stat	= 50;					// status 
		blkbuf->il1		= 8;					// interleave 
		break;

	  case FT_D81:
		blkbuf->stat	= 50;					// status 
		blkbuf->il1		= 1;					// interleave 
		break;

	  default:
		break;
	}*/
	else switch(GetDeviceType())
	{
	  case DT_1541:
		blkbuf->stat	= 50;					// status 
		if(HighSpeed())
			blkbuf->il1	= 8;					// interleave 
		else
			blkbuf->il1	= 15;					// interleave 
		break;

	  case DT_1571:
		blkbuf->stat	= 60;					// status 
		blkbuf->il1		= 5;					// interleave 
		break;

	  case DT_1581:
	  case DT_2030:
	  case DT_4040:
	  case DT_8050:
	  case DT_8250:
		blkbuf->stat	= 50;					// status 
		blkbuf->il1		= 1;					// interleave 
		break;

	  default:
		blkbuf->stat	= 50;					// status 
		blkbuf->il1		= 1;					// interleave 
		break;
	}

	// DEBUG
	uartPrintf_P(PSTR("interleave %d"), blkbuf->il1);
	uartPutCrLf();

	return 0;
}


