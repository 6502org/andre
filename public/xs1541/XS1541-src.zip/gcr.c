//-------------------------------------------------------------------------
// Titel:	 XS-1541 - GCR Code handler
// Funktion: GCR data encode / decode
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License only.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <inttypes.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloca.h>

#include "gcr.h"











// CONST
static const uint8_t loDec[] PROGMEM = {
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0x08, 0x00, 0x01, 0xff, 0x0c, 0x04, 0x05,
    0xff, 0xff, 0x02, 0x03, 0xff, 0x0f, 0x06, 0x07,
    0xff, 0x09, 0x0a, 0x0b, 0xff, 0x0d, 0x0e, 0xff
};

static const uint8_t hiDec[] PROGMEM = {
    0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
    0xff, 0x80, 0x00, 0x10, 0xff, 0xc0, 0x40, 0x50,
    0xff, 0xff, 0x20, 0x30, 0xff, 0xf0, 0x60, 0x70,
    0xff, 0x90, 0xa0, 0xb0, 0xff, 0xd0, 0xe0, 0xff
};

static const unsigned char gcrEnc[] PROGMEM = {
        0x0a, 0x0b, 0x12, 0x13, 0x0e, 0x0f, 0x16, 0x17,
        0x09, 0x19, 0x1a, 0x1b, 0x0d, 0x1d, 0x1e, 0x15
    };


// TOKEN



// STRUCTS





// STATICS


// GLOBALS



// EXTERNALS







//----------------------------------------------------------------------
// DECODE GCR DATA
//----------------------------------------------------------------------
int8_t GcrDecode(uint8_t const *gcr, uint8_t *decoded)
{
	uint8_t lo[sizeof(loDec)];
	uint8_t hi[sizeof(hiDec)];
    register uint8_t g0, g1, g2, g3, g4;
    uint8_t		ref, chk = 0, hdr, *c = NULL;
    uint16_t	i;

	memcpy_P(lo, loDec, sizeof(loDec));
	memcpy_P(hi, hiDec, sizeof(hiDec));

    g0 = *(gcr++);
    g1 = *(gcr++);

    hdr = hi[(g0 >> 3) & 0x1f] |
          lo[((g0 & 0x07) << 2) | ((g1 >> 6) & 0x03)];

    if(hdr != 0x07) {
        return 4;
    }

    for(i = 0; i < BLOCKSIZE; i+=4) {
        g2 = *(gcr++);
        g3 = *(gcr++);
        g4 = *(gcr++);
        if(c) {
            chk ^= *c++ = hi[(g0 >> 3) & 0x1f] |
                          lo[((g0 & 0x07) << 2) | ((g1 >> 6) & 0x03)];
        } else {
            c = decoded;
        }
        chk ^= *c++ = hi[(g1 >> 1) & 0x1f] |
                      lo[((g1 & 0x01) << 4) | ((g2 >> 4) & 0x0f)];
        chk ^= *c++ = hi[((g2 & 0x0f) << 1) | ((g3 >> 7) & 0x01)] |
                      lo[(g3 >> 2) & 0x1f];
        chk ^= *c++ = hi[((g3 & 0x03) << 3) | ((g4 >> 5) & 0x07)] |
                      lo[g4 & 0x1f];
        g0 = *(gcr++);
        g1 = *(gcr++);
    }
    chk ^= *c = hi[(g0 >> 3) & 0x1f] |
                lo[((g0 & 0x07) << 2) | ((g1 >> 6) & 0x03)];
    g2 = *gcr;
    ref = hi[(g1 >> 1) & 0x1f] |
          lo[((g1 & 0x01) << 4) | ((g2 >> 4) & 0x0f)];

    return (chk != ref) ? 5 : 0;
}



//----------------------------------------------------------------------
// DECODE GCR DATA
//----------------------------------------------------------------------
int8_t GcrEncode(uint8_t const *block, uint8_t *encoded)
{
    register uint8_t h, l, g0, g1, g2, g3, g4;
    register uint8_t c = 0x07;
	uint8_t chk = 0;
    uint16_t	i;
    uint8_t gcr[sizeof(gcrEnc)];
	uint8_t empty[4];

	memcpy_P(gcr, gcrEnc, sizeof(gcr));
	memset(empty, 0, sizeof(empty));

    for(i = 0; i <= BLOCKSIZE; i+=4) {
        if(i == BLOCKSIZE) {
            block    = empty;
            empty[0] = chk;
        }
        h    = gcr[c >> 4]; l = gcr[c & 0x0f];
        g0   = (h << 3) | (l >> 2);
        g1   = (l & 0x03) << 6;
        chk ^= c = *(block++);
        h    = gcr[c >> 4]; l = gcr[c & 0x0f];
        g1  |= (h << 1) | (l >> 4);
        g2   = (l & 0x0f) << 4;
        chk ^= c = *(block++);
        h    = gcr[c >> 4]; l = gcr[c & 0x0f];
        g2  |= (h >> 1);
        g3   = ((h & 0x01) << 7) | (l << 2);
        chk ^= c = *(block++);
        h    = gcr[c >> 4]; l = gcr[c & 0x0f];
        g3  |= (h >> 3);
        g4   = ((h & 0x07) << 5) | (l);

        *(encoded++) = g0;
        *(encoded++) = g1;
        *(encoded++) = g2;
        *(encoded++) = g3;
        *(encoded++) = g4;

        chk ^= c = *(block++);
    }
    return 0;
}
