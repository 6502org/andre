//-------------------------------------------------------------------------
// Titel:	 XS-1541 - TIMER
// Funktion: initialize and handle AVR hardware timer
//-------------------------------------------------------------------------
// Copyright (C) 2007,2008  Ingo Korb <ingo@akana.de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------



#ifndef TIMER_H
#define TIMER_H



typedef uint16_t tick_t;


extern volatile uint8_t 	cnt0;				// 100Hz
extern volatile tick_t		cnt1;				// HIRES TIMER
extern volatile tick_t		ticks;
extern volatile uint8_t 	iec_timer;			// ms timer
extern volatile uint8_t 	ieee_timer;			// ms timer
extern volatile uint16_t	xm_timer;			// xmodem timer







/// Global timing variable, 100 ticks per second
#define HZ 100



#define MS_TO_TICKS(x) (x/10)

/* Adapted from Linux 2.6 include/linux/jiffies.h:
 *
 *      These inlines deal with timer wrapping correctly. You are
 *      strongly encouraged to use them
 *      1. Because people otherwise forget
 *      2. Because if the timer wrap changes in future you won't have to
 *         alter your driver code.
 *
 * time_after(a,b) returns true if the time a is after time b.
 *
 * Do this with "<0" and ">=0" to only test the sign of the result. A
 * good compiler would generate better code (and a really good compiler
 * wouldn't care). Gcc is currently neither.
 * (">=0" refers to the time_after_eq macro which wasn't copied)
 */
#define time_after(a,b)         \
         ((int16_t)(b) - (int16_t)(a) < 0)
#define time_before(a,b)        time_after(b,a)


/// Calculate timer start value for given timeout in microseconds
#define TIMEOUT_US(x) (256-((float)F_CPU/64000000.0)*x)

/**
 * start_timeout - start a timeout using timer0
 * @startval: starting value for timer
 *
 * This function sets timer 0 to the specified value and clears its overflow
 * flag. Use in conjunction with TIMEOUT_US to cause a timer overflow after
 * a specified number of microseconds. DON'T use a variable as a parameter to
 * the TIMEOUT_US macro because that would require run-time float calculations.
 */
#define start_timeout(startval) do { TCNT0 = startval; TIFR |= _BV(TOV0); } while (0)

/**
 * has_timed_out - returns true if timeout was reached
 *
 * This function returns true if the overflow flag of timer 0 is set which
 * (together with start_timeout and TIMEOUT_US) will happen when the
 * specified time has elapsed.
 */
#define has_timed_out() (TIFR & _BV(TOV0))


void InitTimer(void);

#endif
