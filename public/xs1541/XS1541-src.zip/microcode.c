//-------------------------------------------------------------------------
// Titel:	 XS-1541 - FLOPPY Micocode Code (6502 assembler)
// Funktion: upload/start microcode
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr\io.h>
#include <avr\pgmspace.h>
#include <avr\interrupt.h>
#include <util\delay.h>
#include <inttypes.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <alloca.h>

#include "main.h"
#include "uart.h"
#include "ymodem.h"
#include "ieee.h"
#include "gcr.h"
#include "iec.h"
//#include "burst.h"
#include "floppy.h"
//#include "image.h"
#include "transfer.h"
#include "microcode.h"
#include "parallel.h"











// CONST



// TOKEN



// STRUCTS

//
// DEMO CODE
//
static prog_uchar mcFlash[] = {
 #include "flash.inc"
};

static prog_uchar mcMorse[] = {
 #include "morse.inc"
};

/*static prog_uchar mcRPM[] = {
 #include "rpm1541.inc"
};*/



//
// WARP
//
static prog_uchar mcWarpRd1541[] = {
 #include "warpread1541.inc"
};
static prog_uchar mcWarpRd1571[] = {
 #include "warpread1571.inc"
};


//
// TURBO
//
static prog_uchar mcTurboRd1541[] = {
 #include "turboread1541.inc"
};
static prog_uchar mcTurboRd1571[] = {
 #include "turboread1571.inc"
};
static prog_uchar mcTurboRd1581[] = {
 #include "turboread1581.inc"
};



//
// BUSTEST
//
static prog_uchar mcBusTest[] = {
 #include "testread.inc"
};
static prog_uchar mcBusTest1581[] = {
 #include "testread1581.inc"
};




// STATICS


// GLOBALS



// EXTERNALS







//----------------------------------------------------------------------
// UPLOAD MICROCODE TO FLOPPY
//----------------------------------------------------------------------
int8_t McUpload(uint16_t adr, uint8_t *p, uint16_t anz)
{
	//uint8_t	*p;
	uint16_t	anz2;
	
	//p = buf;
	while(1)
	{
		anz2 = (anz > 32) ? 32 : anz;

		if(SendMemoryWrite(adr, anz2, p))
			return 1;

		p	+= anz2;
		adr	+= anz2;

		anz	-= anz2;
		if(anz == 0)
			break;
	}
	return 0;
}
int8_t McUpload_P(uint16_t adr, uint8_t *pbuf, uint16_t anz)
{
	uint8_t	buf[512];
	
	memcpy_P(buf, pbuf, anz);
	return McUpload(adr, buf, anz);
}


//----------------------------------------------------------------------
// UPLOAD MICROCODE TO FLOPPY
//----------------------------------------------------------------------
int8_t McUploadFlash()
{
	return McUpload_P(0x0500, mcFlash, sizeof(mcFlash));
}


//----------------------------------------------------------------------
// UPLOAD MICROCODE TO FLOPPY
//----------------------------------------------------------------------
int8_t McUploadMorse()
{
	return McUpload_P(0x0500, mcMorse, sizeof(mcMorse));
}


//----------------------------------------------------------------------
// UPLOAD MICROCODE TO FLOPPY
//----------------------------------------------------------------------
/*int8_t McUploadRPM()
{
	return McUpload_P(0x0500, mcRPM, sizeof(mcRPM));
}*/


//----------------------------------------------------------------------
// UPLOAD TURBO LOAD TO FLOPPY
//----------------------------------------------------------------------
int8_t McUploadTurboRd(int8_t lwTyp)
{
	switch(lwTyp)
	{
	  case DT_1541:
		return McUpload_P(0x0500, mcTurboRd1541, sizeof(mcTurboRd1541));
	  case DT_1571:
		return McUpload_P(0x0500, mcTurboRd1571, sizeof(mcTurboRd1571));
	  case DT_1581:
		return McUpload_P(0x0500, mcTurboRd1581, sizeof(mcTurboRd1581));
	  default:
		return -1;
	}
}


//----------------------------------------------------------------------
// UPLOAD WARP LOAD TO FLOPPY
//----------------------------------------------------------------------
int8_t McUploadWarpRd(int8_t lwTyp)
{
	switch(lwTyp)
	{
	  case DT_1541:
		return McUpload_P(0x0500, mcWarpRd1541, sizeof(mcWarpRd1541));
	  case DT_1571:
		return McUpload_P(0x0500, mcWarpRd1571, sizeof(mcWarpRd1571));
	  default:
		return -1;
	}
}


//----------------------------------------------------------------------
// UPLOAD WARP LOAD TO FLOPPY
//----------------------------------------------------------------------
int8_t McUploadTest(int8_t lwTyp)
{
	switch(lwTyp)
	{
	  case DT_1541:
	  case DT_1571:
		return McUpload_P(0x0500, mcBusTest, sizeof(mcBusTest));
	  case DT_1581:
		return McUpload_P(0x0500, mcBusTest1581, sizeof(mcBusTest1581));
	  default:
		return -1;
	}
}



//----------------------------------------------------------------------
// PREPARE WARP READ 
//----------------------------------------------------------------------
/*int8_t McWarpReadPrepare(uint8_t typ)
{
	SendCmd_P(PSTR("I"));
	//if(McUploadPP1541())
	//	return 1;

	//if(McUploadWarpRd1541())
	//	return 1;

	SendCmd_P(PSTR("U4"));
	return 0;
}*/




