//-------------------------------------------------------------------------
// Titel:	 XS-1541 - Parallel Handler 
// Funktion: handle communication to parallel floppy drives (SpeedDos cable)
//-------------------------------------------------------------------------
// Copyright (C) Michael Klein <michael(dot)klein(at)puffin(dot)lb(dot)shuttle(dot)de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version
// 2 of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util\delay.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//#include "config.h"
#include "compat.h"
#include "uart.h"
/*#include "timer.h"
#include "main.h"
#include "xmodem.h"
#include "ieee.h"*/
#include "main.h"
#include "gcr.h"
#include "iec.h"
//#include "floppy.h"
#include "transfer.h"
#include "microcode.h"
#include "parallel.h"





// DEFINES
#define	ParOutput()			{IEC_D_DDR = 0xff;}
#define	ParInput()			{IEC_D_DDR = 0;IEC_D_PORT = 0xff;}


//#define	Init(a)				ParInit(a)
//#define	Read(a)				ParRead(a)
//#define	Write(a,b)			ParWrite(a,b)
//#define	Exit()   			ParExit()



// CONST

//
// PARALLEL CABLE CODE
//
static prog_uchar mcPP1541[] = {
 #include "pp1541.inc"
};

static prog_uchar mcPP1571[] = {
 #include "pp1571.inc"
};




// VARS








//
// FOR UART MESSAGES TO VIEW PROTOCOLL
//








//---------------------------
// WRITE BYTE TO FLOPPY
//---------------------------
static int8_t WriteByte(uint8_t data)
{
	while(IecDebounce() & IEC_BIT_DATA);		// wait for data low

	ParOutput();
	IEC_D_PORT = data;
	_delay_us(1);
	IecClk(1);

	while(!(IecDebounce() & IEC_BIT_DATA));		// wait for data high
	ParInput();
	IecClk(0);
	return 0;
}


//---------------------------
// WRITE 2 BYTE TO FLOPPY
//---------------------------
static int8_t Write2Byte(uint8_t data1, uint8_t data2)
{
	while(IecDebounce() & IEC_BIT_DATA);		// wait for data low

	ParOutput();
	IEC_D_PORT = data1;
	IecClk(1);

	while(!(IecDebounce() & IEC_BIT_DATA));		// wait for data high
	IEC_D_PORT = data2;
	IecClk(0);
	return 0;
}



//---------------------------
// READ T/S FROM FLOPPY
//---------------------------
static int8_t Read2Byte(uint8_t *data)
{
	ParInput();

	//uartPutChar('.');

	while(IecDebounce() & IEC_BIT_DATA);		// wait for data low
	*(data++) = IEC_D_PIN;
	IecClk(1);

	while(!(IecDebounce() & IEC_BIT_DATA));		// wait for data high
	*(data) = IEC_D_PIN;
	IecClk(0);
	return 0;
}



//---------------------------
// READ BYTE FROM FLOPPY
//---------------------------
static uint8_t Read()
{
	uint8_t buf[2];

	Read2Byte(buf);
	return buf[0];
}




//----------------------------------------------------------------------
// UPLOAD PARALLEL BUS MICROCODE TO FLOPPY
//--------------------------------------------------------
static int8_t Init(int8_t lwTyp, turbo_start start) 
{
	int8_t	rc;

	ParInput();					// INPUT!

	switch(lwTyp)
	{
	  case DT_1541:
		rc = McUpload_P(0x0700, mcPP1541, sizeof(mcPP1541));
		break;
	  case DT_1571:
		rc = McUpload_P(0x0700, mcPP1571, sizeof(mcPP1571));
		break;
	  default:
		return -1;
	}

	start();
	IecClk(0);
	while(IecDebounce() & IEC_BIT_DATA);		// wait for data low
	return rc;
}

static void Exit(void) 
{
	//uartPutLine_p("exit par driver");

	Write2Byte(0, 0);
	ParInput();
	//arch_usleep(100);
	while(!(IecDebounce() & IEC_BIT_DATA));		// wait for data high
}




DECLARE_TRANSFER_FUNCS(pp_transfer);
//DECLARE_TRANSFER_FUNCS_EX(pp_transfer, 1, 1);




