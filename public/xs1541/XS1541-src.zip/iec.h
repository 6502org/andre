//-------------------------------------------------------------------------
// Titel : 	XS-1541 - IEC Handler
//-------------------------------------------------------------------------
// Copyright (C) 2007,2008  Ingo Korb <ingo@akana.de>
// Copyright (C) 2008  Thomas Winkler <t.winkler@tirol.com>
//-------------------------------------------------------------------------
// Funktion : 	handle communication to serial IEC floppy drives
//-------------------------------------------------------------------------
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation;
// version 2 of the License ONLY.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
//-------------------------------------------------------------------------

#ifndef IEC_H
#define IEC_H



extern uint8_t iec_device;					// current device#
extern uint8_t iec_status;					// bit0=timeout; bit7=device not present
extern uint8_t iec_devtyp;					// DT_1541,DT_1571,DT_1581



// STRUCTS
typedef struct 
{
	uint8_t			stat;				// status
	uint8_t			opt;				// normal / burst / parallel
	uint8_t			log;				// logical flag, 1=1581 logical
	uint8_t			curDr;				// current drive
	uint8_t			curTr;				// current track
	uint8_t			curSe;				// current sector
	uint8_t			curSeCnt;			// current sector count
	uint16_t		anz;				// number of bytes in buf
	uint8_t			*buf;				// block buffer
	//uint8_t			buf[256];			// block buffer
	//uint8_t			buf[1024];			// block buffer
} st_DiskBuf;














#define IEC_ST_WRTO		_BV(0)					// write timeout
#define IEC_ST_RDTO		_BV(1)					// read timeout
#define IEC_ST_ATTO		_BV(2)					// ATN/DAV timeout
#define IEC_ST_ATN		_BV(3)					// ATN is active!!
#define IEC_ST_CLEANUP	_BV(5)					// BUS CLEANUP
#define IEC_ST_EOI		_BV(6)					// EOI
#define IEC_ST_DNP		_BV(7)					// device not present




// PORT DEFINITION FOR DATA (parallel SpeedDos)
#define IEC_D_PIN		PINB
#define IEC_D_DDR		DDRB
#define IEC_D_PORT		PORTB

// PORT DEFINITION FOR CTRL
#define IEC_PIN			PIND
#define IEC_PIN_PU		PORTD
#define IEC_DDR_PU		DDRD




// IEC IN
#define IEC_PIN_ATN		PD2			//(INT0)
#define IEC_PIN_DATA	PD4
#define IEC_PIN_SRQ		PD5
#define IEC_PIN_RST		PD6
#define IEC_PIN_CLK		PD7


#ifdef IEC_SEPARATE_OUT
	// IEC OUT
	#define IEC_OPIN_ATN	PC3
	#define IEC_OPIN_DATA	PC1
	#define IEC_OPIN_RST	PC2
	#define IEC_OPIN_SRQ	PC2
	#define IEC_OPIN_CLK	PC0
	#define IEC_DDR			DDRC
	#define IEC_PORT		PORTC
#endif




#define IEC_BIT_ATN		_BV(IEC_PIN_ATN)
#define IEC_BIT_DATA	_BV(IEC_PIN_DATA)
#define IEC_BIT_RST		_BV(IEC_PIN_RST)
#define IEC_BIT_SRQ		_BV(IEC_PIN_SRQ)
#define IEC_BIT_CLK		_BV(IEC_PIN_CLK)



#ifdef IEC_SEPARATE_OUT
  #define IEC_PULLUPS		(IEC_BIT_ATN | IEC_BIT_DATA | IEC_BIT_RST | IEC_BIT_SRQ | IEC_BIT_CLK)
  #define IEC_OBIT_ATN		_BV(IEC_OPIN_ATN)
  #define IEC_OBIT_DATA		_BV(IEC_OPIN_DATA)
  #define IEC_OBIT_CLK		_BV(IEC_OPIN_CLK)
  #define IEC_OBIT_SRQ		_BV(IEC_OPIN_SRQ)
  #define IEC_OBIT_RST		_BV(IEC_OPIN_RST)

#ifdef XA1541
	#define IEC_OUT			IEC_PORT
#else
	#define IEC_OUT			IEC_DDR
#endif

#else
  #define IEC_DDR			IEC_DDR_PU
  #define IEC_PORT			IEC_PIN_PU
  #define IEC_OPIN_ATN		IEC_PIN_ATN
  #define IEC_OPIN_DATA		IEC_PIN_DATA
  #define IEC_OPIN_RST		IEC_PIN_RST
  #define IEC_OPIN_SRQ		IEC_PIN_SRQ
  #define IEC_OPIN_CLK		IEC_PIN_CLK
  #define IEC_OBIT_ATN		_BV(IEC_OPIN_ATN)
  #define IEC_OBIT_DATA		_BV(IEC_OPIN_DATA)
  #define IEC_OBIT_RST		_BV(IEC_OPIN_RST)
  #define IEC_OBIT_SRQ		_BV(IEC_OPIN_SRQ)
  #define IEC_OBIT_CLK		_BV(IEC_OPIN_CLK)
  #define IEC_OUT			IEC_DDR
#endif




// SET IEC STATE
#define IecAtn(state)		do { if ((state)) IEC_OUT &= ~IEC_OBIT_ATN;	else IEC_OUT |= IEC_OBIT_ATN;   } while(0)
#define IecData(state)		do { if ((state)) IEC_OUT &= ~IEC_OBIT_DATA;	else IEC_OUT |= IEC_OBIT_DATA;  } while(0)
#define IecClk(state)		do { if ((state)) IEC_OUT &= ~IEC_OBIT_CLK;	else IEC_OUT |= IEC_OBIT_CLK;   } while(0)
#define IecRst(state)		do { if ((state)) IEC_OUT &= ~IEC_OBIT_RST;	else IEC_OUT |= IEC_OBIT_RST;   } while(0)
#define IecSrq(state)		do { if ((state)) IEC_OUT &= ~IEC_OBIT_SRQ;	else IEC_OUT |= IEC_OBIT_SRQ;   } while(0)





// INP
#define IEC_ATN		(IEC_PIN & IEC_BIT_ATN)
#define IEC_DATA	(IEC_PIN & IEC_BIT_DATA)
#define IEC_CLK		(IEC_PIN & IEC_BIT_CLK)
#define IEC_RST		(IEC_PIN & IEC_BIT_RST)
#define IEC_SRQ		(IEC_PIN & IEC_BIT_SRQ)





void IecSetData(int16_t wo);
uint8_t IecDebounce(void);

void InitIec(void);
void IecMainloop(void);

int8_t IecListen(uint8_t sa);
int8_t IecTalk(uint8_t sa);
int8_t IecUntalk(void);
int8_t _IecUnlisten(void);
int8_t IecUnlisten(void);
int8_t IecOpen(uint8_t sa, char *);
int8_t IecClose(uint8_t sa);
int8_t IecBsout(uint8_t by);
uint8_t IecBasin(void);
void	IecReset(void);


#endif
