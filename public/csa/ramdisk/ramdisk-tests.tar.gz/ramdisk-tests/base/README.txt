
CHECK0:
	fill pages 0-255 with byte index, and read it back

MIRROR:
	check mirrored pages
	by filling (from the end to the front) the pages with their page/bank number
	then checking from front to end which pages are still ok
	
SCAN:
	scan the ramdisk for dram modules and their respective size

	
