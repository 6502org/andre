
RAMDISK
-------

Using 4 30-pin SIMM modules to create a RAM disk drive.

Memory Map
----------

Base address: $e860/$e870 (jumperable)

Offset	Register
-----------------------------------
0	Data register
1	dRAM addr 0-7 (byte address)
2	dRAM addr 8-15 (page address)
3	dRAM addr 16-23	(bank address)

Access by setting dRAM address, then
read or write Data register.

dRAM addr 0-7 increments with Data register access.
Note: Address wraps on page boundary, i.e. page address
is not incremented.

dRAM Adress bits A22 and A23 are used to select SIMM module.
If dRAM module is smaller than 4MByte, then each dRAM module 
is mirrored within its 4MByte range.


Tests
-----

The subdirectories here contain some test programs for the 
ramdisk module. They are written to run in the Commodore PET
environment.

