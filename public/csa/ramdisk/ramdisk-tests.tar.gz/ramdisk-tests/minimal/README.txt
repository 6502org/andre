
test programs for the DRAM card:

REG0:
        checks register "byte", "page" and "bank" for
        memory functionality
REG1:
        checks counter functionality of access to "data"
        register
PAGE0:
        fills bank 0 page 0 with zero bytes and
        then checks 4 times if there still is a zero
	(Note: if the system always returns zero anyway, no error is detected!)
PAGE1:
        fills bank 0 page 0-15 with a copy of the kernel
        then checks 4 times if is still there
	
		
