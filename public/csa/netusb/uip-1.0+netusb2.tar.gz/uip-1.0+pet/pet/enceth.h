
void init_ether(void);
void send_ether(void);
int rcv_ether(void);
void __fastcall__ putser(char);
