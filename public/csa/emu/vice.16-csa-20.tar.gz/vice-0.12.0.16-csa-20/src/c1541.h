/*
 * $Id: c1541.h,v 1.1 1997/05/22 21:09:42 tvr Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * Stand alone front end for disk image maintenance.
 *
 *
 * Written by
 *   Teemu Rantanen   (tvr@cs.hut.fi)
 *   Jouko Valta      (jopi@stekt.oulu.fi)
 *
 * $Log: c1541.h,v $
 * Revision 1.1  1997/05/22 21:09:42  tvr
 * Initial revision
 *
 */

#ifndef _C1541_H
#define _C1541_H

#include "fs_cbm.h"

extern int  ip_execute ( DRIVE *floppy, BYTE *buf, int length );
extern int  do_validate ( DRIVE *floppy );
extern int  check_header ( int fd, hdrinfo *hdr );
extern int  check_track_sector( int format, int track, int sector );
extern int  get_diskformat ( int devtype );
extern char *pc_get_cbmname (FILE *fd, char *fsname);
extern int  num_blocks ( int format, int tracks );
extern void no_a0_pads ( BYTE *ptr, int l );
extern int  compare_filename ( char *name, char *pattern );

#endif /* ndef _C1541_H */
