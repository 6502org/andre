/*
 * $Id: vmachine.h,v 1.15 1997/05/22 21:45:20 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file contains useful stuff when you are creating
 * virtual machine like MCS6510 based microcomputer.
 *
 * Included are:
 *	o Keyboard size
 *	o Interrupts
 *	o Colors
 *	o Video timing
 *
 *
 * Written by
 *   Vesa-Matti Puro (vmp@lut.fi)
 *   Jarkko Sonninen (sonninen@lut.fi)
 *   Jouko Valta     (jopi@stekt.oulu.fi)
 *   Andre Fachat   (a.fachat@physik.tu-chemnitz.de)
 *
 *
 * $Log: vmachine.h,v $
 * Revision 1.15  1997/05/22 21:45:20  ettore
 * A_* alarm sources, separated from I_* interrupt sources.
 *
 * Revision 1.14  1996/07/29 23:33:55  ettore
 * *** empty log message ***
 *
 * Revision 1.13  1996/04/01  09:01:41  jopi
 * VIC-20 and PET interrupts, timings, etc.
 *
 * Revision 1.12  1995/11/07  16:51:00  jopi
 * PET
 *
 * Revision 1.11  1995/06/28  19:40:56  jopi
 * VDC colours added. VIC20 screen & timing constants.
 *
 * Revision 1.10  1994/12/12  16:59:44  jopi
 * New system
 *
 * Revision 1.9  1994/08/10  18:34:13  jopi
 * More changeability
 *
 * Revision 1.8  1994/06/16  17:19:26  jopi
 *
 * Revision 1.7  1994/06/07  18:31:11  jopi
 * Patchlevel 2
 *
 * Revision 1.6  1994/02/18  16:10:57  jopi
 *
 * Revision 1.5  1994/01/26  16:08:37  jopi
 * X64 version 0.2 PL 1
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 *
 * Revision 1.3  93/06/21  13:39:50  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 *
 */

#ifndef X64_VMACHINE_H
#define X64_VMACHINE_H


#include "vice.h"

#ifdef C128
#define KBD_ROWS	11	/* C128 Keyboard size */
#else
#if defined(PET) || defined(CSA)
#define	KBD_ROWS	10	/* PET Keyboard size */
#else
#define KBD_ROWS	8	/* C64/VIC20/Plus4 Keyboard size */
#endif
#endif

/*
 * CPU alarms.
 */

#define A_RASTERDRAW	0 	/* Draw one raster line. */
#define A_RASTERFETCH	1 	/* Video chip memory fetch. */
#define A_RASTER	2	/* Raster compare. */
#define A_CIA1TOD	3 	/* CIA 1 TOD alarm */
#define A_CIA1TA	4       /* CIA 1 timer A */
#define A_CIA1TB	5  	/* CIA 1 timer B */
#define A_CIA2TOD	6   	/* CIA 2 TOD alarm */
#define A_CIA2TA	7   	/* CIA 2 timer A */
#define A_CIA2TB	8   	/* CIA 2 timer B */

#define NUMOFALRM	9

#define	A_VIA1T1	A_CIA1TA
#define	A_VIA1T2	A_CIA1TB
#define	A_VIA2T1	A_CIA2TA
#define	A_VIA2T2	A_CIA2TB

#ifdef PET
/* PET IRQs */
#define	A_VIAT1		A_CIA1TA	/* pet via t1 */
#define	A_VIAT2		A_CIA1TB	/* pet via t2 */
#endif

#ifdef CSA
/* CSA IRQs */
#define	A_VIACT1	A_CIA1TA	/* pet via t1 */
#define	A_VIACT2	A_CIA1TB	/* pet via t2 */
#define	A_CSABIOS	A_CIA1TOD	/* CSA BIOS port 50 Hz IRQ */
#define	A_ACIA1		A_CIA2TA	/* ACIA1 */
#define	A_ACIA2		A_CIA2TB	/* ACIA2 */
#endif


/*
 * Interrupts.
 */

#define I_RASTERDRAW     0      /* Draw one raster line */
#define I_RASTERFETCH    1      /* Video chip memory fetch */
#define I_RASTER	 2	/* Raster compare */

#define I_BRK		 3	/* Software interrupt */

/* CIA 1 / VIA 2 IRQs */
#define I_CIA1FL	 4	/* CIA 1 FLAG1 */
#define I_CIA1SP	 5	/* CIA 1 serial port */
#define I_CIA1TOD	 6	/* CIA 1 TOD alarm */
#define I_CIA1TA	 7      /* CIA 1 timer A */
#define I_CIA1TB	 8 	/* CIA 1 timer B */

/* CIA 2 / VIA 1 NMIs */
#define I_CIA2FL	 9 	/* CIA 2 FLAG 1 */

#define I_CIA2SP	 10 	/* CIA 2 serial port */
#define I_CIA2TOD	 11 	/* CIA 2 TOD alarm */
#define I_CIA2TA	 12	/* CIA 2 timer A */
#define I_CIA2TB	 13	/* CIA 2 timer B */

/* VIA 2 IRQs */
#define	I_VIA1FL	I_CIA1FL

/* VIA 1 NMIs */
#define	I_VIA2FL	I_CIA2FL

#ifdef PET
/* PET IRQs */
#define	I_VIAFL		I_CIA1FL	/* pet via flag */
#endif

#ifdef CSA
#define	I_VIACFL	I_CIA1FL	/* pet via flag */
#define	I_CSABIOS	I_CIA2FL	/* pet via flag */
#define	I_ACIA1		I_CIA1SP	/* pet via flag */
#define	I_ACIA2		I_CIA2SP	/* pet via flag */
#endif

/* SPECIAL */
#define I_SPECX		14	/* Special "interrupt" for x_loop */
#define I_RESTORE	15	/* Restore key NMI */
#define I_RESET		16	/* Reset in startup */

#define NUMOFINT        17


/*
 * Video Constants
 */

#define MAX_COLORS	16
#define SPECIAL_COLORS	6	/* 4 VIC BG, 2 VDC BG */


#ifdef VIC20
#define XSIZE		22
#define YSIZE		23
#define XPIX	        XSIZE*8	
#define YPIX	        YSIZE*8	
#else

/*
#if (defined(PET) && (PET_COLS == 80))
#define XSIZE		80
#define YSIZE		25
#define XPIX		640
#define YPIX		200
#else
#define XSIZE		40
#define YSIZE		25
#define XPIX		320
#define YPIX		200
#endif
*/
#if defined(PET) || defined(CSA)
extern int XSIZE;
extern int XPIX;
#else
#define	XSIZE		40
#define	XPIX		320
#endif

#define	YSIZE		25
#define	YPIX		200

#endif  /* VIC20 */

#if 0
#define VDC_XPIX        640
#define VDC_YPIX        200
#define VDC_XSIZE       80
#define VDC_YSIZE       25
#endif

/* border, background & sprite colors */
#define C_BORDER	0
#define C_BG0		1
#define C_BG1		2
#define C_BG2		3
#define C_BG3		4

#define C_SPRMUL0	5
#define C_SPRMUL1	6
#define C_SPR0		7
#define C_SPR1		8
#define C_SPR2		9
#define C_SPR3		10
#define C_SPR4		11
#define C_SPR5		12
#define C_SPR6		13
#define C_SPR7		14

#define C_AUX		C_BG3

#define C_VDC_BORDER	15
#define C_VDC_BG0	16


/* display modes */

#define V_BLANK		0
#define V_TEXT		1
#define V_MTEXT		2
#define V_ECTEXT	3
#define V_BITMAP	4
#define V_MBITMAP	5
#define V_TILT		6


/* Timing Constants
 *
 * Exact values are more complicated, but these approximations are
 *  enough for emulator's use
 */

#ifdef PAL

#ifdef VIC20
#define CYCLES_PER_SEC	1108405
#define CYCLES_PER_LINE	71
#else
#define CYCLES_PER_SEC	985248	/* 2MHz mode: 1.89050MHz */
				/* Z80 average 1.97051MHz */
#define CYCLES_PER_LINE	63
#endif
#define SCR_LINES	312
#define RFSH_PER_SEC	50

#else  /* NTSC */

#ifdef VIC20
#define CYCLES_PER_SEC	1022727
#define SCR_LINES	261
#else
#define CYCLES_PER_SEC	1022730
#define SCR_LINES	262
#endif
#define CYCLES_PER_LINE	65
#define RFSH_PER_SEC	60

#endif /* PAL */

#if 0
#define VDC_SCR_LINES   200
#endif

#define CYCLES_PER_RFSH   (SCR_LINES * CYCLES_PER_LINE)

#endif  /* X64_VMACHINE_H */
