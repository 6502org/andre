/*
 * $Id: crtc.c,v 1.1 1997/05/22 21:55:01 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 *
 * See README for copyright notice
 *
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *   Andre' Fachat    (a.fachat@physik.tu-chemnitz.de)
 *
 * $Log: crtc.c,v $
 * Revision 1.1  1997/05/22 21:55:01  ettore
 * Initial revision
 *
 */

/* CRTC video chip emulation. */

#ifndef CSA
#ifndef PET
#define PET
#endif
#endif

#define _CRTC_C

#include "crtc.h"
#include "raster.h"

#include <stdlib.h>
#include <stdio.h>

#include "vmachine.h"
#include "extern.h"
#include "interrupt.h"

static void crtc_init_dwg_tables(void);
static void crtc_update_memory_ptrs(void);
static void crtc_ArrangeWindow(int width, int height);
static int fill_cache(struct line_cache *l, int *xs, int *xe, int r);
static void draw_line(void);
static void draw_line_2x(void);
static void draw_line_cached(struct line_cache *l, int xs, int xe);
static void draw_line_cached_2x(struct line_cache *l, int xs, int xe);

static BYTE crtc[19];
static ADDRESS scraddr;
static BYTE *chargen_ptr;
static BYTE *screenmem;

static int crsrpos;
static int scrpos;
static int crsrrel;
static int crsrmode;	/* 0=blank, 1=continously, 2=1/32, 3=1/16 frame rate */
static int crsrstart;	/* 1st cursor scan line */
static int crsrend;	/* last cursor scan line */
static int crsrstate;	/* 0 = off, 1 = on, toggled by int_* */
static int crsrcnt;

static int redraw_screen = 0;

PIXEL4 dwg_table_0[256], dwg_table_1[256];
PIXEL4 dwg_table2x_0[256], dwg_table2x_1[256];
PIXEL4 dwg_table2x_2[256], dwg_table2x_3[256];

#include "raster.c"

/* -------------------------------------------------------------------------- */

canvas_t crtc_init(void)
{
#ifdef __MSDOS__
    if (SCREEN_XPIX > 320) {
	/* Force double height for 80 column mode. */
	app_resources.doubleSize = 1;
    }
#endif
    
    init_raster(1, 2, 2);
    video_resize();
    if (open_output_window(CRTC_WINDOW_TITLE,
			   SCREEN_XPIX + 10, SCREEN_YPIX + 10,
			   color_defs,
			   (canvas_redraw_t) crtc_ArrangeWindow)) {
	fprintf(stderr, "fatal error: can't open window for CRTC emulation.\n");
	return NULL;
    }
    video_mode = CRTC_STANDARD_MODE;
    refresh_all();
    chargen_ptr = char_rom;
    screenmem = ram;
    border_color = 0;
    background_color = 0;

    crtc_init_dwg_tables();
    display_ystart = CRTC_SCREEN_BORDERHEIGHT;
    display_ystop = CRTC_SCREEN_BORDERHEIGHT + CRTC_SCREEN_YPIX;
    return canvas;
}

static void crtc_init_dwg_tables(void)
{
    int byte, p;
    BYTE msk;

    for (byte = 0; byte < 0x0100; byte++) {
	*((PIXEL *) (dwg_table2x_0 + byte))
	    = *((PIXEL *) (dwg_table2x_0 + byte) + 1)
	    = PIXEL(byte & 0x80 ? 1 : 0);
	*((PIXEL *) (dwg_table2x_0 + byte) + 2)
	    = *((PIXEL *) (dwg_table2x_0 + byte) + 3)
	    = PIXEL(byte & 0x40 ? 1 : 0);
	*((PIXEL *) (dwg_table2x_1 + byte))
	    = *((PIXEL *) (dwg_table2x_1 + byte) + 1)
	    = PIXEL(byte & 0x20 ? 1 : 0);
	*((PIXEL *) (dwg_table2x_1 + byte) + 2)
	    = *((PIXEL *) (dwg_table2x_1 + byte) + 3)
	    = PIXEL(byte & 0x10 ? 1 : 0);
	*((PIXEL *) (dwg_table2x_2 + byte))
	    = *((PIXEL *) (dwg_table2x_2 + byte) + 1)
	    = PIXEL(byte & 0x08 ? 1 : 0);
	*((PIXEL *) (dwg_table2x_2 + byte) + 2)
	    = *((PIXEL *) (dwg_table2x_2 + byte) + 3)
	    = PIXEL(byte & 0x04 ? 1 : 0);
	*((PIXEL *) (dwg_table2x_3 + byte))
	    = *((PIXEL *) (dwg_table2x_3 + byte) + 1)
	    = PIXEL(byte & 0x02 ? 1 : 0);
	*((PIXEL *) (dwg_table2x_3 + byte) + 2)
	    = *((PIXEL *) (dwg_table2x_3 + byte) + 3)
	    = PIXEL(byte & 0x01 ? 1 : 0);
    }

    for (byte = 0; byte < 0x0100; byte++) {
	for (msk = 0x80, p = 0; p < 4; msk >>= 1, p++)
	    *((PIXEL *)(dwg_table_0 + byte) + p) = PIXEL(byte & msk ? 1 : 0);
	for (p = 0; p < 4; msk >>= 1, p++)
	    *((PIXEL *)(dwg_table_1 + byte) + p) = PIXEL(byte & msk ? 1 : 0);
    }
}

/* Set proper functions and constants for the current video settings. */
void video_resize(void)
{
    static int old_size = 0;

    if (app_resources.doubleSize) {
	pixel_height = 2;
	if (crtc_cols == 40) {
	    pixel_width = 2;
	    video_modes[CRTC_STANDARD_MODE].fill_cache = fill_cache;
	    video_modes[CRTC_STANDARD_MODE].draw_line_cached = draw_line_cached_2x;
	    video_modes[CRTC_STANDARD_MODE].draw_line = draw_line_2x;
	    if (old_size == 1) {
		window_width *= 2;
		window_height *= 2;
		if (canvas)
		    canvas_resize(canvas, window_width, window_height);
	    }
	} else {
	    /* When in 80 column mode, only the height is doubled. */
	    pixel_width = 1;
	    video_modes[CRTC_STANDARD_MODE].fill_cache = fill_cache;
	    video_modes[CRTC_STANDARD_MODE].draw_line_cached = draw_line_cached;
	    video_modes[CRTC_STANDARD_MODE].draw_line = draw_line;
	    if (old_size == 1)
		window_height *= 2;
	}
    } else {
	pixel_width = 1;
	pixel_height = 1;
	video_modes[CRTC_STANDARD_MODE].fill_cache = fill_cache;
	video_modes[CRTC_STANDARD_MODE].draw_line_cached = draw_line_cached;
	video_modes[CRTC_STANDARD_MODE].draw_line = draw_line;
	if (old_size == 2) {
	    if (crtc_cols == 40)
		window_width /= 2;
	    window_height /= 2;
	}
    }
    old_size = app_resources.doubleSize ? 2 : 1;

    if (canvas) {
	resize(window_width, window_height);
	frame_buffer_clear(&frame_buffer, pixel_table[0]);
	force_repaint();
	refresh_all();
    }
}

void video_free(void)
{
    frame_buffer_free(&frame_buffer);
}

static void crtc_ArrangeWindow(int width, int height)
{
    resize(width, height);
    refresh_all();
}

/* -------------------------------------------------------------------------- */

/* CRTC interface functions. */

void store_crtc(ADDRESS addr, BYTE value)
{
    crtc[addr] = value;

    if (debugflg)
	printf("store crtc[%x] %x\n", addr, (int) value);

    switch (addr) {
      case 0:			/* R00  Horizontal total (characters + 1) */
      case 1:			/* R01  Horizontal characters displayed */
	/* crtc_update_memory_ptrs (); FIXME: not implemented */
	break;

      case 2:			/* R02  Horizontal Sync Position */

      case 3:			/* R03  Horizontal/Vertical Sync widths */
	/* crtc_update_memory_ptrs (); FIXME: not implemented */
	break;

      case 4:			/* R04  Raster line count */
	break;

      case 5:			/* R05  Vertical Total Line Adjust */
	/* crtc_update_memory_ptrs (); FIXME: not implemented */
	break;

      case 6:			/* R06  Number of display lines on screen */
      case 7:			/* R07  Vertical Sync Position */
	break;

      case 8:			/* R08  unused: Interlace and Skew */
	break;

      case 9:			/* R09  Row Scan Lines (-1) */
	break;

      case 10:			/* R10  Cursor Start Line, and blink mode */
	crsrstart = value & 0x1f;
	value = ((value >> 5) & 0x03) ^ 0x01;
	if(crsrmode != value) { 
	  printf("crtc: write R10 new cursormode = %d\n",value);
	  crsrmode = value;
	  crsrstate = 1;
	  crsrcnt = 16; 
	}
	break;

      case 11:			/* R11  Cursor End Line */
	crsrend = value & 0x1f;
	break;

      case 12:			/* R12  Control register */

	/* These descriptions seem to be for the 6845. (AF) */
	/* Bit 0: 1=add 256 to screen start address ( 512 for 80-columns)
	 * Bit 1: 1=add 512 to screen start address (1024 for 80-columns)
	 * Bit 2: invert flyback
	 * Bit 3: invert video signal
	 * Bit 4: use top half of 4K character generator
	 * Bit 5: (not implemented on the PET)
	 * Bit 6: (not implemented on the PET)
	 * Bit 7: not used.
	 */
	/* The 6545 used in the CS/A65 computer says: */
	/* R12 and R13 together form a 14-bit register whose contents
	 * are the memory address of the first character to be displayed...
	 * R12 is high byte, R13 is low byte.
  	 */
#ifdef PET
	scraddr = (scraddr & 0xfffffcff) | ((value << 8) & 0x0300);
#elif defined(CSA)
	scraddr = (scraddr & 0xffffc0ff) | ((value << 8) & 0x3f00);
#endif
printf("write crtc R12 (%d): scraddr -> %x\n",value, scraddr);
	crtc_update_memory_ptrs();
	scrpos = (scrpos & 0x00ff) | ((value << 8) & 0x3f00);
	crsrrel = crsrpos - scrpos;
	redraw_screen |= 2;
	break;

      case 13:			/* R13  Address of first character */
	/* Value + 32786 (8000) */
	scraddr = (scraddr & 0xffffff00) | (value & 0x00ff);
printf("crtc: write crtc R13 (%d): scraddr -> %x\n",value, scraddr);
	crtc_update_memory_ptrs();
	scrpos = (scrpos & 0x3f00) | (value & 0xff);
	crsrrel = crsrpos - scrpos;
	redraw_screen |= 2;
	break;

      case 14:			/* R14-5 Cursor location HI/LO */
	crsrpos = (crsrpos & 0x00ff) | ((value << 8) & 0x3f00);
	crsrrel = crsrpos - scrpos;
	redraw_screen |= 2;
	break;
      case 15:		
	crsrpos = (crsrpos & 0x3f00) | (value & 0xff);
	crsrrel = crsrpos - scrpos;
	redraw_screen |= 2;
	break;

      case 16:
      case 17:			/* R16-7 Light Pen HI/LO -- read only */
	break;

      case 18:
      case 19:			/* R18-9 Update address HI/LO (only 6545)  */
	break;
    }
}

BYTE read_crtc(ADDRESS addr)
{
    switch (addr) {
      case 14:
      case 15:			/* Cursor location HI/LO */
	return crtc[addr];

      case 16:
      case 17:			/* Light Pen X,Y */
	return 0xff;

      default:
	return 0;		/* All the rest are write-only registers */
    }
}

#ifdef CSA
/*
 * The video control port is a write-only port with several control bits:
 *	Bit 0	Video Address bit VA14
 *	Bit 1	Video Address bit VA15
 *	Bit 2	Invert H/V(?) Sync (not emulated)
 *	Bit 3	Invert V/H(?) Sync (not emulated)
 *	Bit 4	Character Adress bit CA11
 *	Bit 5	Character Adress bit CA12
 *	Bit 6	1 = Hires mode (not emulated)
 *	Bit 7   ---
 */
static BYTE crtcport;
static int crtcinvca11;

void store_crtcport(BYTE value) {
	crtcport = value;

printf("store_crtcport(value=%02x), VA14-5 = %02x, CA11-2 = %02x, invert=%d\n",
		crtcport, crtcport & 0x03, (crtcport >> 4) & 0x03, crtcinvca11);

	scraddr = 0x8000 	/* position of video bank in emulator ram */
		+ ((scraddr & 0x03fff) | ((crtcport << 14) & 0xc000));

	chargen_ptr = char_rom 
		+ 0x800 * (((crtcinvca11 ^ crtcport) & 0x10) ? 1 : 0)
		+ 0x1000 * ((crtcport & 0x20) ? 1 : 0);
	crtc_update_memory_ptrs();

}
#endif

void store_colorram(ADDRESS addr, BYTE value)
{
    /* No color RAM. */
}

BYTE read_colorram(ADDRESS addr)
{
    /* Bogus. */
    return 0;
}

void crtc_set_char(int crom)
{
#ifdef CSA
    crtcinvca11 = crom ? 0x10 : 0;
    store_crtcport(crtcport);
#else
    chargen_ptr = char_rom + (crom ? 0x800 : 0);
#endif
}

void reset_crtc(void)
{
    /* spec says to initialize "all internal scan counter circuits.
     * When /RES is low, all internal counters stop and clear and all
     * scan and video output go low; control registers are unaffected.
     * All scan timing initiates when /RES goes high. "
     * "In this way, /RES can synchronize display frame timing with 
     * line frequency."
     *
     * Well, we just emulate...
     */

    crsrpos = 0;
    scrpos = 0;
    crsrrel = 0;
    crsrmode = 0;
    crsrstart = 0;
    crsrend = 0;
    crsrstate = 0;
    crsrcnt = 0;

    /* store_crtc (5, 240); */

    /* This is for PET 3032 - to get it working without any crtc register
     * setting, as the older PETs don't know about them.
     */
    scraddr = 0x8000;
#ifdef CSA
    store_crtcport(0x20);
#else
    crtc_update_memory_ptrs();
#endif

    maincpu_set_alarm_clk(A_RASTERDRAW, CYCLES_PER_LINE);
    return;
}

int crtc_offscreen(void)
{
    return rasterline >= YPIX;
}

void crtc_set40(void)
{
    int w, h;

    crtc_cols = 40;

    w = crtc_cols * 8 * pixel_width + 2 * SCREEN_BORDERWIDTH;
    h = 25 * pixel_width + 2 * SCREEN_BORDERHEIGHT;

    display_xstart = SCREEN_BORDERWIDTH;
    display_xstop = SCREEN_BORDERWIDTH + SCREEN_XPIX;
    display_ystart = SCREEN_BORDERHEIGHT;
    display_ystop = SCREEN_BORDERHEIGHT + SCREEN_YPIX;

    if (canvas) {
	canvas_resize(canvas, w, h);
	crtc_ArrangeWindow(w, h);
	video_resize();
    }
}

void crtc_set80(void)
{
    int w, h;

    crtc_cols = 80;

    w = crtc_cols * 8 * pixel_width + 2 * SCREEN_BORDERWIDTH;
    h = SCREEN_YPIX * pixel_height + 2 * SCREEN_BORDERHEIGHT;
    display_xstart = SCREEN_BORDERWIDTH;
    display_xstop = SCREEN_BORDERWIDTH + SCREEN_XPIX;
    display_ystart = SCREEN_BORDERHEIGHT;
    display_ystop = SCREEN_BORDERHEIGHT + SCREEN_YPIX;

    if (canvas) {
	canvas_resize(canvas, w, h);
	crtc_ArrangeWindow(w, h);
	video_resize();
    }
}

static void crtc_update_memory_ptrs(void)
{

#ifdef DEBUG
    if (debugflg)
	printf("scraddr:%x\n", scraddr);
#endif

    screenmem = ram + scraddr;
}

/* -------------------------------------------------------------------------- */

void int_rasterdraw(long offset)
{
    maincpu_set_alarm(A_RASTERDRAW, CYCLES_PER_LINE - offset);
    emulate_line();

    if (!rasterline && clk > 1000) {
      redraw_screen = redraw_screen >> 1;
      if(crsrmode & 0x02) {
	if(crsrcnt) crsrcnt--;
	else {
	  redraw_screen = 1;
	  crsrcnt = (crsrmode & 0x01) ? 16 : 32;
	  crsrstate ^= 1;
	}
      }
      /* This generates one raster interrupt per frame. */
      strobe_irq(&maincpu_int_status);
    }
}

static int fill_cache(struct line_cache *l, int *xs, int *xe, int r)
{
    return _fill_cache_text(l->fgdata, screenmem + memptr, chargen_ptr,
			    crtc_cols, ycounter, xs, xe, r);
}

static void draw_line(void)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH;
    register int i, d;
#ifdef CSA
    if(crsrmode)
    for (i = 0; i < crtc_cols; i++, p += 8) {
	d = GET_CHAR_DATA(chargen_ptr, (screenmem + memptr)[i], ycounter);
	if(crsrstate 
		&& (memptr+i)==crsrrel 
		&& ycounter >= crsrstart 
		&& ycounter <=crsrend) 
	  d^=0xff;
	*((PIXEL4 *) p) = dwg_table_0[d];
	*((PIXEL4 *) p + 1) = dwg_table_1[d];
    }
    else
#endif
    for (i = 0; i < crtc_cols; i++, p += 8) {
	d = GET_CHAR_DATA(chargen_ptr, (screenmem + memptr)[i], ycounter);
	*((PIXEL4 *) p) = dwg_table_0[d];
	*((PIXEL4 *) p + 1) = dwg_table_1[d];
    }
}

static void draw_line_2x(void)
{
    PIXEL *p = (frame_buffer_ptr + SCREEN_BORDERWIDTH * pixel_width);
    register int i, d;

#ifdef CSA
    if(crsrmode)
    for (i = 0; i < crtc_cols; i++, p += 16) {
	d = GET_CHAR_DATA(chargen_ptr, (screenmem + memptr)[i], ycounter);
	if(crsrstate 
		&& (memptr+i)==crsrrel
		&& ycounter >= crsrstart 
		&& ycounter <= crsrend) 
	  d^=0xff;
	*((PIXEL4 *) p) = dwg_table2x_0[d];
	*((PIXEL4 *) p + 1) = dwg_table2x_1[d];
	*((PIXEL4 *) p + 2) = dwg_table2x_2[d];
	*((PIXEL4 *) p + 3) = dwg_table2x_3[d];
    }
    else
#endif
    for (i = 0; i < crtc_cols; i++, p += 16) {
	d = GET_CHAR_DATA(chargen_ptr, (screenmem + memptr)[i], ycounter);
	*((PIXEL4 *) p) = dwg_table2x_0[d];
	*((PIXEL4 *) p + 1) = dwg_table2x_1[d];
	*((PIXEL4 *) p + 2) = dwg_table2x_2[d];
	*((PIXEL4 *) p + 3) = dwg_table2x_3[d];
    }
}

static void draw_line_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xs * 8;
    register int i;
#ifdef CSA
    register int mempos = ((l->n+1)/8 ) * crtc_cols;
    register int ypos = (l->n+1) & 7;
#endif
    for (i = xs; i <= xe; i++, p += 8) {
#ifdef CSA
	if(mempos+i==crsrrel && crsrmode && crsrstate
		&& ypos >= crsrstart && ypos <=crsrend) {
	  *((PIXEL4 *) p) = dwg_table_0[0xff ^ l->fgdata[i]];
	  *((PIXEL4 *) p + 1) = dwg_table_1[0xff ^ l->fgdata[i]];
	} else 
#endif
	{
	  *((PIXEL4 *) p) = dwg_table_0[l->fgdata[i]];
	  *((PIXEL4 *) p + 1) = dwg_table_1[l->fgdata[i]];
	}
    }
}

static void draw_line_cached_2x(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + 2 * (SCREEN_BORDERWIDTH + xs * 8);
    register int i;
#ifdef CSA
    register int mempos = ((l->n+1)/8 ) * crtc_cols;
    register int ypos = (l->n+1) & 7;
#endif
    for (i = xs; i <= xe; i++, p += 16) {
#ifdef CSA
	if(mempos+i==crsrrel && crsrmode && crsrstate
		&& ypos >= crsrstart && ypos <=crsrend) {
	  *((PIXEL4 *) p) = dwg_table2x_0[0xff ^ l->fgdata[i]];
	  *((PIXEL4 *) p + 1) = dwg_table2x_1[0xff ^ l->fgdata[i]];
	  *((PIXEL4 *) p + 2) = dwg_table2x_2[0xff ^ l->fgdata[i]];
	  *((PIXEL4 *) p + 3) = dwg_table2x_3[0xff ^ l->fgdata[i]];
	} else 
#endif
	{
	  *((PIXEL4 *) p) = dwg_table2x_0[l->fgdata[i]];
	  *((PIXEL4 *) p + 1) = dwg_table2x_1[l->fgdata[i]];
	  *((PIXEL4 *) p + 2) = dwg_table2x_2[l->fgdata[i]];
	  *((PIXEL4 *) p + 3) = dwg_table2x_3[l->fgdata[i]];
	}
    }
}

/* -------------------------------------------------------------------------- */

void crtc_prevent_clk_overflow(void)
{
    oldclk -= PREVENT_CLK_OVERFLOW_SUB;
}
