/*
 * $Id: serial.h,v 1.13 1997/05/22 21:34:38 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 *
 * Written by
 *   Teemu Rantanen  (tvr@cs.hut.fi)
 *   Andre Fachat    (a.fachat@physik.tu-chemnitz.de)
 *
 *
 * $Log: serial.h,v $
 * Revision 1.13  1997/05/22 21:34:38  ettore
 * Some IEEE488 fixes.
 *
 * Revision 1.12  1996/04/01  09:01:41  jopi
 * Return values corrected
 * IEEE488 declarations.
 *
 * Revision 1.11  1995/11/07  16:51:00  jopi
 * PET
 *
 * Revision 1.10  1995/06/28  19:40:56  jopi
 * More Disk Drive and Printer types introduced.
 *
 * Revision 1.9  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * New serial device control.
 *
 * Revision 1.8  1994/12/12  16:59:44  jopi
 * *** empty log message ***
 *
 * Revision 1.7  1994/08/10  18:34:13  jopi
 * More changeability
 *
 * Revision 1.6  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.5  1994/06/08  02:06:23  jopi
 * Patchlevel 2
 * Serial device types
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:39:24  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 *
 */

#ifndef X64_SERIAL_H
#define X64_SERIAL_H

#include "types.h"

#define MAXDEVICES		16


/*
 * Serial Error Codes
 */

#define SERIAL_OK		0
#define SERIAL_WRITE_TIMEOUT	1
#define SERIAL_READ_TIMEOUT	2
#define SERIAL_FILE_NOT_FOUND	64
#define SERIAL_NO_DEVICE	128

#define SERIAL_ERROR		(2)
#define SERIAL_EOF		(64)


/*
 * Device types
 */

#define DT_FS			0x0100	/* Filesystem Drive */
#define DT_DISK			0x0200
#define DT_PRINTER		0x0400

#define DT_TAPE			0x0800

#define DT_MASK			0xFF


/* Disk Drives */

#define DT_1540			 0	
#define DT_1541			 1	/* Default */
#define DT_1542			 2
#define DT_1551			 3

#define DT_1570			 4
#define DT_1571			 5
#define DT_1572			 6

#define DT_1581			 8

#define DT_2031			16
#define DT_2040			17
#define DT_2041			18
#define DT_3040			17	/* Same as 2040 */
#define DT_4031			16	/* Same as 2031 */

/* #define DT_2081			*/

#define DT_4040			24

#define DT_8050			32
#define DT_8060			33
#define DT_8061			34

#define DT_SFD1001		48
#define DT_8250			49
#define DT_8280			50


/* Printers */

#define DT_ASCII		0	/* No printer commands nor graphics */
#define DT_MPS803		1
#define DT_STAR10CCL		2



#if defined(__STDC__)
typedef struct serial_s
{
    int inuse;
    int isopen;
    char *info;					/* pointer to run-time data */
    char *name;					/* name of the device */
    int (*getf)(void *, BYTE *, int);		/* serial read function */
    int (*putf)(void *, BYTE, int);		/* serial write function */
    int (*openf)(void *, char *, int, int);	/* serial open function */
    int (*closef)(void *, int);			/* serial close function */
    void (*flushf)(void *, int);		/* tell device that write completed */
    BYTE nextbyte[16];				/* next byte to send to emulator */
    char nextok[16];				/* flag if nextbyte is valid */
#if defined(PET) || defined(IEEE488) || defined(CSA)
    /* These definitions have to be at the end of the struct - 
       it's included in some files that don't define PET... */
    int nextst[16];
		/* The PET hardware emulation can be interrupted while 
		   transferring a byte. Thus we also have to save the byte
		   and status last sent, to be able to send it again. */
    BYTE lastbyte[16];
    char lastok[16];
    int lastst[16];
#endif
} serial_t;

#else
typedef struct serial_s
{
    int inuse;
    int isopen;
    char *info;			/* pointer to run-time data */
    char *name;			/* name of the device */
    int (*getf)();		/* serial read function */
    int (*putf)();		/* serial write function */
    int (*openf)();		/* serial open function */
    int (*closef)();		/* serial close function */
    void (*flushf)();		/* tell device that write completed */
    BYTE nextbyte[16];		/* next byte to send to emulator */
    char nextok[16];		/* flag if nextbyte is valid */
#if defined(PET)||defined(IEEE488) || defined(CSA)
    /* These definitions have to be at the end of the struct - 
       it's included in some files that don't define PET... */
    int nextst[16];
		/* The PET hardware emulation can be interrupted while 
		   transferring a byte. Thus we also have to save the byte
		   and status last sent, to be able to send it again. */
    BYTE lastbyte[16];
    char lastok[16];
    int lastst[16];
#endif
} serial_t;

#endif

#endif  /* X64_SERIAL_H */


