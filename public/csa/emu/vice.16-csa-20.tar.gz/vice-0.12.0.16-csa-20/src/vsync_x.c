/*
 * $Id: vsync_x.c,v 1.1 1997/05/22 22:22:41 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli	(ettore@comm2000.it)
 *
 * $Log: vsync_x.c,v $
 * Revision 1.1  1997/05/22 22:22:41  ettore
 * Initial revision
 *
 */

/* This does what has to be done at the end of each screen frame (50 times per
   second on PAL machines). */

#ifdef __hpux
#define _INCLUDE_HPUX_SOURCE
#define _INCLUDE_POSIX_SOURCE
#define _INCLUDE_XOPEN_SOURCE
#endif

#include <sys/time.h>
#include <signal.h>
#include <unistd.h>
#include <stdio.h>

#ifdef __hpux
#define _INCLUDE_XOPEN_SOURCE
#define _XPG2
#include <limits.h>
#undef  _INCLUDE_XOPEN_SOURCE
#undef  _XPG2
#else
#include <limits.h>
#endif

#include "vsync.h"
#include "vmachine.h"
#include "extern.h"
#include "ui.h"
#include "interrupt.h"
#include "sid.h"
#include "true1541.h"
#include "video.h"

#ifndef SA_RESTART
#define SA_RESTART 0
#endif

/* ------------------------------------------------------------------------- */

static volatile int elapsed_frames = 0;
static int timer_disabled = 1;
static int timer_speed = 0;

/* This simple SIGALRM handler is used to control the emulation speed. */
static void timer_handler(int unused)
{
    elapsed_frames++;
}

/* Install the SIGALRM handler, setting the timer to keep the emulation speed
   around `speed' percent. */
static int set_timer_speed(int speed)
{
    struct itimerval i;
    static struct sigaction sigaction_struct;
    static double timer_seconds;
    
    if (speed > 0) {
	sigaction_struct.sa_handler = timer_handler;
	sigemptyset(&sigaction_struct.sa_mask);
	sigaction_struct.sa_flags = SA_RESTART;
	if (sigaction(SIGALRM, &sigaction_struct, NULL) < 0) {
	    perror("sigaction");
	    return -1;
	}
	timer_seconds = (100.0 / (double)RFSH_PER_SEC) / (double)speed;
	i.it_interval.tv_sec = i.it_value.tv_sec = 0L;
	i.it_interval.tv_usec = i.it_value.tv_usec = timer_seconds * 1000000.0;
	if (setitimer(ITIMER_REAL, &i, NULL) < 0) {
	    perror("setitimer");
	    return -1;
	}
    } else {			/* Disable the timer. */
	i.it_interval.tv_usec = i.it_interval.tv_sec = 0L;
	i.it_value.tv_usec = i.it_value.tv_sec = 0L;
	if (setitimer(ITIMER_REAL, &i, NULL) < 0) {
	    perror("setitimer");
	    return -1;
	}
	speed = 0;
    }
    timer_speed = speed;
    timer_disabled = speed ? 0 : 1;
    return 0;
}

int vsync_disable_timer(void)
{
    if (!timer_disabled)
	return set_timer_speed(0);
    else
	return 0;
}

/* ------------------------------------------------------------------------- */

static int speed_eval_suspended = 1;

/* This should be called whenever something that has nothing to do with the
   emulation happens, so that we don't display bogus speed values. */
void suspend_speed_eval(void)
{
    speed_eval_suspended = 1;
}

void vsync_init(void)
{
    suspend_speed_eval();
    vsync_disable_timer();
}

static CLOCK speed_eval_prev_clk;

static void display_speed(int num_frames)
{
#ifdef HAVE_GETTIMEOFDAY
    static double prev_time;
    struct timeval tv;
    double curr_time;

    gettimeofday(&tv, NULL);
    curr_time = (double)tv.tv_sec + ((double)tv.tv_usec) / 1000000.0;
    if (!speed_eval_suspended) {
	CLOCK diff_clk;
	double speed_index;
	double frame_rate;
	    
	diff_clk = clk - speed_eval_prev_clk;
	frame_rate = (double)num_frames / (curr_time - prev_time);
	speed_index = ((((double)diff_clk / (curr_time - prev_time))
			/ (double)CYCLES_PER_SEC)) * 100.0;
	UiDisplaySpeed((float)speed_index, (float)frame_rate);
    }
    prev_time = curr_time;
    speed_eval_prev_clk = clk;
    speed_eval_suspended = 0;
#else
    return;
#endif
}

/* This prevents the clock counters from overflowing. */
inline static void vsync_prevent_clk_overflow()
{
    if (maincpu_prevent_clk_overflow()) {
#ifdef CBM64
	extern void vic_ii_prevent_clk_overflow(void);
	extern void cia1_prevent_clk_overflow(void);
	extern void cia2_prevent_clk_overflow(void);
	vic_ii_prevent_clk_overflow();
	cia1_prevent_clk_overflow();
	cia2_prevent_clk_overflow();
#ifdef SOUND
	sid_prevent_clk_overflow();
#endif
#elif defined(VIC20)
	extern void vic_prevent_clk_overflow(void);
	extern void via1_prevent_clk_overflow(void);
	extern void via2_prevent_clk_overflow(void);
	vic_prevent_clk_overflow();
	via1_prevent_clk_overflow();
	via2_prevent_clk_overflow();
#elif defined(PET) 
	extern void crtc_prevent_clk_overflow(void);
	extern void via_prevent_clk_overflow(void);
	crtc_prevent_clk_overflow();
	via_prevent_clk_overflow();
#elif defined(CSA)
	extern void crtc_prevent_clk_overflow(void);
	extern void viaC_prevent_clk_overflow(void);
	crtc_prevent_clk_overflow();
	viaC_prevent_clk_overflow();
#elif defined(C128)
	extern void vic_ii_prevent_clk_overflow(void);
	extern void vdc_prevent_clk_overflow(void);
	extern void cia1_prevent_clk_overflow(void);
	extern void cia2_prevent_clk_overflow(void);
	vic_ii_prevent_clk_overflow();
	/* vdc_prevent_clk_overflow(); */
	cia1_prevent_clk_overflow();
	cia2_prevent_clk_overflow();
#ifdef SOUND
	sid_prevent_clk_overflow();
#endif
#else  /* !SOUND */
#error
#endif /* !SOUND */

	speed_eval_prev_clk -= PREVENT_CLK_OVERFLOW_SUB;
	/* printf("PREVENT CLK OVERFLOW!\n"); */
    }

#ifdef HAVE_TRUE1541
    true1541_prevent_clk_overflow();
#endif
}

#ifdef HAVE_TRUE1541
/* Actually update the LED status only if the `trap idle' idling method is
   being used, as the LED status could be incorrect otherwise. */
static void update_drive_led(void)
{
    static int old_status = -1;
    int my_status;

    if (app_resources.true1541IdleMethod == TRUE1541_IDLE_TRAP_IDLE)
	my_status = true1541_led_status;
    else
	my_status = 0;
    
    if (my_status != old_status) {
#if 0
	/* FIXME: this does not seem to work with all X11 servers. */
	static XKeyboardControl kbd_control;
	kbd_control.led_mode = my_status ? LedModeOn : LedModeOff;
	kbd_control.led = 16;
	XChangeKeyboardControl(display, KBLedMode | KBLed, &kbd_control);
#else
	printf("1541: LED %s\n", my_status ? "On" : "Off");
#endif
	old_status = my_status;
    }
}
#endif

/* ------------------------------------------------------------------------- */

/* This is called at the end of each screen frame.  It flushes the audio buffer
   and keeps control of the emulation speed. */
int do_vsync(int been_skipped)
{
    static unsigned short frame_counter = USHRT_MAX;
    static unsigned short num_skipped_frames;
    static int skip_counter;
    static int refresh_rate = 1;
    int skip_next_frame = 0;
#ifdef SOUND
    int adjusting = adjusting_sound();
#else
    int adjusting = 0;
#endif
    
#ifdef HAVE_TRUE1541
    if (app_resources.true1541
	&& app_resources.true1541IdleMethod == TRUE1541_IDLE_TRAP_IDLE) {
	true1541_cpu_execute();
    }
#endif

    if (been_skipped)
	num_skipped_frames++;
    
    if (timer_speed != app_resources.speed && !adjusting) {
	frame_counter = USHRT_MAX;
	if (set_timer_speed(app_resources.speed) < 0) {
	    fprintf(stderr, "Trouble setting timers... giving up.\n");
	    exit(-1);
	}
    }

    UiDispatchEvents();
    
#if defined(HAS_JOYSTICK) && !defined(PET) && !defined(CSA)
    /* Handle `real' joystick. */
    joystick();
#endif
    
    if (refresh_rate != 0) {
#ifdef SOUND
	/* Fixed refresh rate. flush_sound() or pause() block when needed to
	   keep the correct speed. */
	if (adjusting)
	    vsync_disable_timer();
	if (app_resources.sound)
	    flush_sound();
#endif
	if (timer_speed && skip_counter >= elapsed_frames)
	    pause();
	if (skip_counter < (refresh_rate - 1)) {
	    skip_next_frame = 1;
	    skip_counter++;
	} else {
	    skip_counter = elapsed_frames = 0;
	}
    } else {
	/* Dynamically adjusted refresh rate. */
	if (!adjusting)	{
	    /* Everything here is done using timers. */
#ifdef SOUND
	    if (app_resources.sound)
		flush_sound();
#endif
	    if (skip_counter >= elapsed_frames) {
		pause();
		elapsed_frames = 0;
		skip_counter = 0;
	    } else {
		if (skip_counter < 10) {
		    skip_counter++;
		    skip_next_frame = 1;
		} else
		    skip_counter = elapsed_frames = 0;
	    }
	} else {
#ifdef SOUND
	    vsync_disable_timer();
	    /* flush_sound() returns nonzero when sid needs temporarily more
	       speed and we skip frames. */
	    if (flush_sound()) {
		if (skip_counter < 10) {
		    skip_next_frame = 1;
		    skip_counter++;
		} else
		    skip_counter = 0;
	    }
#endif
	}
    }

    if (frame_counter >= RFSH_PER_SEC * 2) {
	display_speed(frame_counter + 1 - num_skipped_frames);
	num_skipped_frames = 0;
	frame_counter = 0;
    } else
	frame_counter++;

    vsync_prevent_clk_overflow();
#ifdef HAVE_TRUE1541
    update_drive_led();
#endif

    refresh_rate = app_resources.refreshRate;
    
    return skip_next_frame;
}
