/*
 * $Id: via2.h,v 1.1 1997/05/22 21:42:37 fachat Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Andre' Fachat (fachat@physik.tu-chemnitz.de)
 *
 * $Log: via2.h,v $
 * Revision 1.1  1997/05/22 21:42:37  fachat
 * Initial revision
 *
 */

/* Header for building via2.c (VIC20 VIA 2 emulation) */


INCLUDES()
{
#include "true1541.h"
}


#define	GLOBALS

#define	via_set_int		maincpu_set_nmi
#define	VIA2_INT		IK_NMI

/* #define VIA2_TIMER_DEBUG */

#define	PRE_VIA_FUNCS


#define STORE_PRB 	via2[addr] = byte;

#define	STORE_PCR
#define	STORE_ACR
#define	STORE_SR
#define	STORE_T2L

RESET_VIA()
{
	serial_bus_pa_write(0xff);
}


STORE_PRA()
{
	via2[addr] = byte;
	serial_bus_pa_write(via2[VIA_PRA] | (~via2[VIA_DDRA]));
}

READ_PRA() 
{
        return ((via2[VIA_PRA] & via2[VIA_DDRA]) 
		| ( (serial_bus_pa_read() | 0x7c) & (~via2[VIA_DDRA]) ) );
}

READ_PRB() 
{
        return ((via2[VIA_PRB] & via2[VIA_DDRB]) | (0xff & ~via2[VIA_DDRB]));
}

#define POST_VIA_FUNCS

