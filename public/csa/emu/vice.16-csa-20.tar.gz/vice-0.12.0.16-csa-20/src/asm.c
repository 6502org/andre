/*
 * $Id: asm.c,v 1.8 1996/04/01 09:01:41 jopi Exp $
 *
 * This file is part of Commodore 64 emulator.
 * See README for copyright notice
 *
 * This file contains functions to implement simple MOS6502
 * Machine Language Interpreter.
 *
 *
 * Written by
 *   Vesa-Matti Puro (vmp@lut.fi)
 *   Jarkko Sonninen (sonninen@lut.fi)
 *   Jouko Valta (jopi@stekt.oulu.fi)
 *
 *
 * $Log: asm.c,v $
 * Revision 1.8  1996/04/01 09:01:41  jopi
 * Zilog Z80 and 65CE02 support
 *
 * Revision 1.7  1995/04/01  07:53:25  jopi
 * Prototypes corrected.
 *
 * Revision 1.6  1994/12/12  16:59:44  jopi
 * operation fixed
 *
 * Revision 1.5  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * asm bug fixes
 *
 * Revision 1.3  93/06/21  13:37:56  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:19:36  sonninen
 * *** empty log message ***
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#include "cpu.h"
#include "asm.h"
#include "misc.h"
#include "mshell.h"
#include "extern.h"


static char *modename[] = {
    "IMPLIED", "ACCUMULATOR", "IMMEDIATE",
#ifdef EXTENDED_CPU
    "IMMEDIATE_WORD", "ZERO_PAGE", "ZERO_PAGE_X", "ZERO_PAGE_Y", "ABSOLUTE",
    "ABSOLUTE_X", "ABSOLUTE_Y", "INDIRECT", "INDIRECT_X", "INDIRECT_Y",
    "INDIRECT_Z", "ABS_INDIRECT", "ABS_INDIR_X", "RELATIVE", "RELATIVE_LONG", 
    "ZERO_RELATIVE", "STACK_RELATIVE_Y",
#else
    "ZERO_PAGE", "ZERO_PAGE_X", "ZERO_PAGE_Y", "ABSOLUTE", "ABSOLUTE_X",
    "ABSOLUTE_Y", "ABS_INDIRECT", "INDIRECT_X", "INDIRECT_Y", "RELATIVE",
#endif
    "ASS_CODE"
};	       /* ADDRESSING MODES */


/* ------------------------------------------------------------------------- */


#ifndef __CEXTRACT__

extern int     ass( ADDRESS addr, int mode );

#ifdef HAS_ZILOG_Z80
extern int  parse_z80_instr ( char *line, ADDRESS adr, char *arg, int mode );
#endif
#endif


/* local */

static int interpret_line(char *, ADDRESS *, int );
static int interpret_instr(char *, ADDRESS , int );
int find_instr(char *);
static int parse_arguments(ADDRESS , int , char *, BYTE *, int *, int );


/*
 * This function implements a simple MOS6502 assembler.
 * The interpreter selects default number base according to the
 * value of hexflg.
 */

int     ass(ADDRESS addr, int mode)
{
    char   *line, prompt[10];
    int     cnt;
    int     errors = 0;

    for (;;) {
	sprintf(prompt, ".%04x ", addr);
	line = read_line(prompt, 0);    /* mode & MODE_INF */

	if (line == NULL || *line == 'x')
	    break;

	else
	    if ((cnt = interpret_line(line, &addr, mode)) >= 0) {
		/* addr += cnt; */
	    }
	    else {
		printf("**** %04X ", addr);
		switch(cnt) {

		    /* Line syntax */
		  case E_SYNTAX: printf(EM_SYNTAX);
		    break;
		  case E_PARSE_ERROR: printf(EM_PARSE_ERROR);
		    break;
		  case E_TOO_MANY_ERRORS: /* Don't print */
		    break;

		    /* Assembler */
		  case E_BAD_IDENTIFIER: printf(EM_BAD_IDENTIFIER);
		    break;
		  case E_SYMBOL_UNDEFINED: printf(EM_SYMBOL_UNDEFINED);
		    break;
		  case E_SYMBOL_REDEF: printf(EM_SYMBOL_REDEF);
		    break;
		  case E_PC_DECREMENT: printf(EM_PC_DECREMENT); /*non-intract*/
		    break;

		    /* Mnemonic */
		  case E_BAD_MNEM: printf(EM_BAD_MNEM);
		    break;
		  case E_LONG_BRANCH: printf(EM_LONG_BRANCH);
		    break;
		  case E_MISSING_OPER: printf(EM_MISSING_OPER);
		    break;

		    /* Operand syntax */
		  case E_PARAMETER_SYNTAX: printf(EM_PARAMETER_SYNTAX);
		    break;
		  case E_TOO_MANY_COMMAS: printf(EM_TOO_MANY_COMMAS);
		    break;
		  case E_RIGHT_PARENTHESIS: printf(EM_RIGHT_PARENTHESIS);
		    break;
		  case E_LEFT_PARENTHESIS: printf(EM_LEFT_PARENTHESIS);
		    break;
		  case E_PARENTHESIS: printf(EM_PARENTHESIS);
		    break;
		  case E_MIXED_XY: printf(EM_MIXED_XY);
		    break;
		  case E_MISSING_XY: printf(EM_MISSING_XY);
		    break;
		  case E_BAD_INDEX: printf(EM_BAD_INDEX);
		    break;
		  default:
		    printf("SYNTAX ERROR (%d)", cnt);
		}
 		printf(": %s ****\n", line);

		if ( ++errors >= ERRORS_TO_STOP) {
		    printf("%s\nStop.\n\n", EM_TOO_MANY_ERRORS);
		    return (E_TOO_MANY_ERRORS);
		}
	    }
    } /* for */

    return (E_OK);
}


/*
 * This routine interprets assembly lines which are not direct mode
 * commands for the program itself.
 * Second iteration is done if the line contains address declaration.
 */

static int interpret_line(char *line, ADDRESS *addr, int mode)
{
    int     len = 0;
    int attempt = 0;

    ADDRESS adr = *addr;

    do {
	while (*line && isspace(*line))
	    line++;

	if (!*line)
	    return 0; /* line doesn't contain any text */

	/*
	 * Machine language commands
	 * Return if any mnemonic is found or error occurred.
	 */

#ifdef HAS_ZILOG_Z80
	if (mode & MODE_ZILOG) {
	    if ((len =  parse_z80_instr(line, adr, ram, mode)) > 0) {
		*addr = (len + adr);   /* addr is changed only on success */
		return (len);
	    }
	} else
#endif
	if ((len =  interpret_instr(line, adr, mode)) > 0) {
	    *addr = (len + adr);   /* addr is changed only on success */
	    return (len);
	}

	if (len != E_BAD_MNEM)
	    return (len);

	/*
	 * Change address
	 */

	if (!*line || !sconv(line, 0, mode | MODE_QUERY))
	    return(E_BAD_IDENTIFIER);

	adr = sconv(line, 0, mode);
	while(*++line > ' ');

	if (mode & MODE_VERBOSE)
	    printf("\nrescan %04x ===>%s<===\n", adr, line);

    } while(*line && !attempt++);

    return (E_SYNTAX);
}	/* end of interpret_line  */


/*
 * Machine language commands
 * This routine interprets all 6502 intructions. On success data is
 * stored to memory and number of bytes is returned, otherwise possible
 * error code is returned.
 */

static int interpret_instr(char *line, ADDRESS adr, int mode)
{
    int     i = 0;
    int     instr = 0;
    int     len = 0;
    unsigned char arg[4];

    /*
     * First all legal mnemonics are searched and if right instruction is
     * found the remaining line is parsed. The numeric code of  the
     * instruction is returned and arguments are returned in arg array.
     */

    if ((i = find_instr(line)) >= 0) {

	if (lookup[i].mnemonic[3]) ++line;	/* USBC, NOOP, RBMn ... */

	instr = parse_arguments
	    (adr, i, (strlen(line) > 3 ? &line[3] : NULL), arg, &len, mode);

	if (instr < 0)
	    return (instr);	/* Error code from parse_arguments */

	ram[adr] = instr;
	if (len)
	    memcpy(ram + adr + 1, arg, len);

	if (!(mode & MODE_QUIET)) {
	    printf(".%04X %02X ", adr, instr);
	    switch (len) {
	      case 0:
		printf("\t%s\n", sprint_opcode(adr, 1));
		break;
	      case 1:
		printf("%02X\t%s\n", arg[0], sprint_opcode(adr, 1));
		break;
	      case 2:
		printf("%02X %02X\t%s\n", arg[0], arg[1],
		       sprint_opcode(adr, 1));
	    }
	}
	return (++len);

    }  /* end of matching mnemonic */

    return (E_BAD_MNEM);
}	/* end of interpret_instr */



int find_instr(char *line)
{
    int i;

    while (*line && isspace(*line))
        line++;
 
    if (!*line)
        return (-1); /* line doesn't contain any mnemonic */
 
    for (i = 0; line[i] && i < 3; i++) {
        if (isalpha (line[i]))
            line[i] = toupper (line[i]);
    }       
 
        for (i = 0; i < TOTAL_CODES; i++)
            if (0 == strncmp(lookup[i].mnemonic, line, 3) &&
		(lookup[i].mnemonic[3] < ' ' ||	lookup[i].mnemonic[3] == line[3]))
		return (i);		/* USBC, NOOP, RBMn ... */

    return (-1);
}


static int parse_arguments(ADDRESS adr, int code, char *line, BYTE *arg, int *len, int mode)
{
    int     tstflg = mode & MODE_VERBOSE;
    int     comma_found = 0;	/* True if argument contains comma. */
    int     right_parenthesis = 0;
    int     left_parenthesis = 0;
    int     x_found = 0;
    int     y_found = 0;
    int     z_found = 0;
    int     zero_page = 0;
    int     addr_mode = 0;
    int     i, ival;
    char   *linep;

    while (line && *line && isspace(*line))
	line++;

    if (NULL == line || !*line) {	/* IMPLIED addressing mode. */
	for (i = code; i <= OP_IMPL_MAX; i += OP_IMPL_SPC)
	    if (((IMPLIED == lookup[i].addr_mode) ||
		 (ACCUMULATOR == lookup[i].addr_mode)) &&
		0 == strcmp(lookup[code].mnemonic, lookup[i].mnemonic)) {
		*len = 0;
		return i;
	    }
	return (E_MISSING_OPER);
    }

    if (tstflg)
	printf("CODE %d strlen %d --%s--\n", code, (int)strlen(line), line);

    /*
     * Explicit ACCUMULATOR addressing. If the length of the argument is 1
     * and if this argument is A, appropriate machine code with right address
     * mode is right is chosen, otherwise E_PARAMETER_SYNTAX is returned.
     * This errorcode means that argument is A (=accumulator), but this
     * instruction does not support accumulator addressing. If the parameter
     * A is not present then it matches IMPLIED address mode above.
     */

    if (mode & MODE_SYMBOL) {
	if (1 == strlen(line) && (*line == 'A' || *line == 'a')) {
	    for (i = code; i <= OP_ACCU_MAX; i += OP_MNEM_SPC)
		if (ACCUMULATOR == lookup[i].addr_mode &&
		    0 == strcmp(lookup[code].mnemonic, lookup[i].mnemonic)) {
		    *len = 0;
		    return i;
		}
	    return E_PARAMETER_SYNTAX;
	}
	if (tstflg)
	    printf("ACCU testattu\n");
    }

    /* IMMEDIATE addressing mode */

    if (*line == '#') {
	for (i = code; i < OP_IMM_MAX; ++i)
	    if (IMMEDIATE == lookup[i].addr_mode &&
		0 == strcmp(lookup[code].mnemonic, lookup[i].mnemonic)) {
		*len = 1;
		*arg = (BYTE) sconv(&line[1], 0, mode);
		return i;
	    }
	return E_PARAMETER_SYNTAX;
    }

    /* Next check if relative addressing mode was used. */

    if (RELATIVE == lookup[i = code].addr_mode) {
	if ((mode & MODE_HEX) && *line == '$')		/* Skip if not prefix */
	    ++line;
	ival = sconv(line, 0, mode);
	*len = 1;

	if (tstflg) {
	    printf("addressing mode RELATIVE\n");
	    printf("rel disp %d  %04x\n", ival - adr - 2, ival - adr - 2);
	}

	if ((ival -= (adr + 2)) <= 127 && ival >= -128) {
	    *arg = (BYTE) ((ival) & 0xFF);
	    return i;
	}
	return E_LONG_BRANCH;
    }
    /*
     * Now it's time to parse absolute and zeropage addressing modes with
     * their indexed and indirect versions. First check if there are any
     * commas. And count also parenthesis.
     *
     * There are some addressing modes not implemented on each processor,
     * but they are not #ifdef'ed out to keep the parser more consistent.
     * With 6510 family, the additional modes will be filtered out via
     * failing to find any command actually using those addressing modes.
     */

    linep = line;

    while (*linep)
	switch (*linep++) {

	  case ')':
	    ++right_parenthesis;
	    break;
	  case '(':
	    ++left_parenthesis;
	    break;

	  case ',':
	    ++comma_found;
	    while (*linep == ' ')
		linep++;

	    if (*linep) {
		switch (toupper(*linep)) {
		  case 'X':
		    ++x_found;
		    ++linep;
		    break;
		  case 'Y':
		    ++y_found;
		    ++linep;
		    break;
		  case 'Z':
		    ++z_found;
		    ++linep;
#ifdef EXTENDED_CPU
		    break;
		  case 'S':			/* (disp,sp),y */
		    if (!strncmp ("sp),y", linep, 5)) {
			addr_mode = STACK_RELATIVE_Y;
			linep += 5;
			/* To implement other modes, set  comma_found = 0; */
		    }
#endif
		}  /* switch */

		if (*linep && !isspace(*linep) && *linep != ')')
		    return E_BAD_INDEX;
	    }
	}

    if (comma_found > 1)	/* There cannot be more than 1 comma found! */
	return E_TOO_MANY_COMMAS;

    if (left_parenthesis > 1)		/* Only one '(' can be found. */
	return E_LEFT_PARENTHESIS;

    if (right_parenthesis > 1)		/* Only one ')' can be found. */
	return E_RIGHT_PARENTHESIS;

    if (left_parenthesis != right_parenthesis)	/* Must be equal. */
	return E_PARENTHESIS;

    if (comma_found && !(x_found || y_found || z_found))
	return E_MISSING_XY;

    if ((x_found + y_found + z_found) > 1)
	return E_MIXED_XY;		/* Only one index register allowed */

    linep = line;
    if (right_parenthesis)
	while (*linep && (*linep++ != '('));

    ival = sconv(linep, 0, mode);

    if (tstflg)
	printf("integer: %d\n", ival);


    if (right_parenthesis && !comma_found)
	addr_mode = ABS_INDIRECT;

    if (ival < 256)
	zero_page = 1;

    if (zero_page) {
	if (!right_parenthesis && !comma_found)
	    addr_mode = ZERO_PAGE;
	if (x_found)
	    addr_mode = (!right_parenthesis ? ZERO_PAGE_X : INDIRECT_X);
	if (y_found)
	    addr_mode = (!right_parenthesis ? ZERO_PAGE_Y : INDIRECT_Y);
#ifdef EXTENDED_CPU
	if (z_found && right_parenthesis)
	    addr_mode = INDIRECT_Z;
	if (right_parenthesis && !comma_found)
	    addr_mode = INDIRECT;
#endif
    }
    else {
	if (!right_parenthesis) {
	    if (!comma_found)
		addr_mode = ABSOLUTE;
	    if (x_found)
		addr_mode = ABSOLUTE_X;
	    if (y_found)
		addr_mode = ABSOLUTE_Y;
	}
#ifdef EXTENDED_CPU
	else if (x_found && right_parenthesis)
	    addr_mode = ABS_INDIR_X;
#endif
    }


    if (tstflg)
	printf("addressing mode 1 : %s  -- code $%02x\n",
	    modename[addr_mode], code);

    if (!addr_mode)
	return E_SYNTAX;

    /*
     * Addressing mode was found and the appropriate opcode is being selected
     */

    for (i = code; i < TOTAL_CODES; ++i)
	if (addr_mode == lookup[i].addr_mode &&
	    0 == strcmp(lookup[code].mnemonic, lookup[i].mnemonic)) {
	    switch (addr_mode) {

	      case ZERO_PAGE:
	      case ZERO_PAGE_X:
	      case ZERO_PAGE_Y:
	      case INDIRECT_X:
	      case INDIRECT_Y:
#ifdef EXTENDED_CPU
	      case INDIRECT_Z:
	      case INDIRECT:
	      case STACK_RELATIVE_Y:
#endif
		*len = 1;
		*arg = (BYTE) ival;
		break;

	      case ABS_INDIRECT:
		if ((ival & 0xff) == 0xff)
		    printf("%04X: Warning: Indirect JMP($%04X)\n", adr, ival);
		/* The famous bug in jmp($indirect) */
		/* fall trough */

#ifdef EXTENDED_CPU
	      case ABS_INDIR_X:
#endif
	      case ABSOLUTE:
	      case ABSOLUTE_X:
	      case ABSOLUTE_Y:
		*len = 2;
		*arg++ = (BYTE) ival & 0xFF;
		*arg = (BYTE) (ival >> 8) & 0xFF;
	    }
	    return i;
	}
    /*
     * If machine code has not zeropage addressing mode, absolute addressing
     * mode is tried instead.
     */

    if (tstflg)
	printf("addressing mode 2 : ABSOLUTE\n");


    if (ZERO_PAGE == addr_mode || ZERO_PAGE_Y == addr_mode) {
	addr_mode += (ABSOLUTE - ZERO_PAGE);
	for (i = code; i <= OP_ABS_MAX; i += OP_ABS_SPC)
	    if (addr_mode == lookup[i].addr_mode &&
		0 == strcmp(lookup[code].mnemonic, lookup[i].mnemonic)) {
		*len = 2;
		*arg++ = (BYTE) ival & 0xFF;
		*arg = (BYTE) (ival >> 8) & 0xFF;
		return i;
	    }
    }
    if(tstflg)
	fprintf(stderr, "addressing mode failed\n");

    return E_SYNTAX;	/* Illegal address mode */
}
