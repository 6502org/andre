/*
 * $Id: vic.c,v 1.1 1997/05/22 21:55:38 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README files for copyright notice.
 *
 * VIC-I video chip emulation.
 *
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: vic.c,v $
 * Revision 1.1  1997/05/22 21:55:38  ettore
 * Initial revision
 *
 */

#ifndef VIC20 
#define VIC20
#endif

#define _VIC_C

#include "extern.h"
#include "vic.h"
#include "vmachine.h"
#include "interrupt.h"
#include "raster.h"
#include "sid.h"

#include <stdlib.h>
#include <stdio.h>

/* #define VIC_REGISTERS_DEBUG */

static void set_memory_ptrs(void);
static void init_drawing_table(void);
static int fill_cache(struct line_cache *l, int *xs, int *xe, int r);
static void draw_line(void);
static void draw_line_2x(void);
static void draw_line_cached(struct line_cache *l, int xs, int xe);
static void draw_line_cached_2x(struct line_cache *l, int xs, int xe);

static BYTE vic[64];
static BYTE auxiliary_color;
static BYTE *colormem;
static BYTE *screenmem;
static BYTE *chargen_ptr = char_rom;

#include "raster.c"

/* -------------------------------------------------------------------------- */

/* Initialization. */
canvas_t vic_init(void)
{
    int width, height;

    init_raster(1, 4, 2);
    video_resize();
    
#ifdef __MSDOS__
    width = 180;
    height = 240;
#else
    width = VIC_SCREEN_BORDERWIDTH + 22 * 8;
    height = VIC_SCREEN_BORDERHEIGHT + 23 * 8;
#endif

    if (open_output_window(VIC_WINDOW_TITLE,
			   width, height, color_defs,
			   (canvas_redraw_t)vic_exposure_handler)) {
	fprintf(stderr,
		"fatal error: cannot open window for the VIC emulation.\n");
	return NULL;
    }
    video_mode = VIC_STANDARD_MODE;
    set_memory_ptrs();
    refresh_all();
    init_drawing_table();
    
    return canvas;
}

/* This hook is called whenever the screen parameters (eg. window size) are
   changed. */
void video_resize(void)
{
    static int old_size = 0;

    if (app_resources.doubleSize) {
	pixel_width = 4;
	pixel_height = 2;
	video_modes[VIC_STANDARD_MODE].fill_cache = fill_cache;
	video_modes[VIC_STANDARD_MODE].draw_line_cached = draw_line_cached_2x;
	video_modes[VIC_STANDARD_MODE].draw_line = draw_line_2x;
	if (old_size == 1) {
	    window_width *= 2;
	    window_height *= 2;
	}
    } else {
	pixel_width = 2;
	pixel_height = 1;
	video_modes[VIC_STANDARD_MODE].fill_cache = fill_cache;
	video_modes[VIC_STANDARD_MODE].draw_line_cached = draw_line_cached;
	video_modes[VIC_STANDARD_MODE].draw_line = draw_line;
	if (old_size == 2) {
	    window_width /= 2;
	    window_height /= 2;
	}
    }
    old_size = app_resources.doubleSize ? 2 : 1;

    if (canvas) {
	resize(window_width, window_height);
	frame_buffer_clear(&frame_buffer, PIXEL(0));
	force_repaint();
    }
}

void video_free(void)
{
    frame_buffer_free(&frame_buffer);
}

/* -------------------------------------------------------------------------- */

/* VIC access functions. */

void store_vic(ADDRESS addr, BYTE value)
{
    addr &= 0xf;
    vic[addr] = value;

#ifdef VIC_REGISTERS_DEBUG
    printf("VIC: write $90%02X, value = $%02X\n", addr, value);
#endif

    switch (addr) {
      case 0:			/* $9000  Screen X Location
				   (not implemented). */
#ifdef VIC_REGISTERS_DEBUG
	printf("\t(screen X location, not implemented)\n");
#endif
	return;
      case 1:			/* $9001  Screen Y Location
				   (not implemented). */
#ifdef VIC_REGISTERS_DEBUG
	printf("\t(screen Y location, not implemented)\n");
	return;
#endif
	return;

      case 2:			/* $9002  Columns Displayed. */
	colormem = ram + ((value & 0x80) ? 0x9600 : 0x9400);
	text_cols = value & 0x7f;
	if (text_cols > VIC_SCREEN_MAX_TEXTCOLS)
	    text_cols = VIC_SCREEN_MAX_TEXTCOLS;
	display_xstart = VIC_SCREEN_BORDERHEIGHT;
	display_xstop = VIC_SCREEN_BORDERHEIGHT + text_cols * 8;
	set_memory_ptrs();
#ifdef VIC_REGISTERS_DEBUG
	printf("\tcolor RAM at $%04X\n", colormem - ram);
	printf("\tcolumns displayed: %d\n", text_cols);
#endif
	break;

      case 3:			/* $9003  Rows Displayed, Character size . */
	text_lines = (value & 0x7e) >> 1;
	if (text_lines > VIC_SCREEN_MAX_TEXTLINES)
	    text_lines = VIC_SCREEN_MAX_TEXTLINES;
	char_height = (value & 0x1) ? 16 : 8;
	display_ystart = VIC_SCREEN_BORDERHEIGHT;
	display_ystop = VIC_SCREEN_BORDERHEIGHT + text_lines * char_height;
#ifdef VIC_REGISTERS_DEBUG
	printf("\trows displayed: %d\n", text_lines);
	printf("\tcharacter height: %d\n", char_height);
#endif
	set_memory_ptrs();
	return;

      case 4:			/* $9004  Raster line count -- read only. */
#ifdef VIC_REGISTERS_DEBUG
	printf("\t(raster line counter, read-only)\n");
#endif
	return;

      case 5:			/* $9005  Video and char matrix base address. */
	set_memory_ptrs();
	return;

      case 6:			/* $9006. */
      case 7:			/* $9007  Light Pen X,Y. */
#ifdef VIC_REGISTERS_DEBUG
	printf("\t(light pen register, read-only)\n");
#endif
	return;

      case 8:			/* $9008. */
      case 9:			/* $9009  Paddle X,Y. */
#ifdef VIC_REGISTERS_DEBUG
	printf("\t(paddle, read-only)\n");
#endif
	return;

      case 10:			/* $900A  Bass Enable and Frequency. */
      case 11:			/* $900B  Alto Enable and Frequency. */
      case 12:			/* $900C  Soprano Enable and Frequency. */
      case 13:			/* $900D  Noise Enable and Frequency. */
#ifdef VIC_REGISTERS_DEBUG
	printf("\t(sound register, not implemented)\n");
#endif
#ifdef SOUND
	store_vic20sid(addr, value);
#endif
	return;

      case 14:			/* $900E  Auxiliary Colour, Master Volume. */
	auxiliary_color = value >> 4;
#ifdef VIC_REGISTERS_DEBUG
	printf("\tauxiliary color set to $%02X\n", auxiliary_color);
	printf("\t(master volume not implemented)\n");
#endif
#ifdef SOUND
	store_vic20sid(addr, value);
#endif
	return;

      case 15:			/* $900F  Screen and Border Colors,
				   Reverse Video. */
	border_color = value & 0x7;
	background_color = HI_NIBBLE(value);
#ifdef VIC_REGISTERS_DEBUG
	printf("\tborder color: $%02X\n", border_color);
	printf("\tbackground color: $%02X\n", background_color);
	if (!(value & 0x8))
	    printf("\t(reverse video requested but not implemented)\n");
#endif
	return;
    }
}

BYTE read_vic(ADDRESS addr)
{
    addr &= 0xf;

    switch (addr) {
      case 4:
	return rasterline >> 1;
      case 3:
	return ((rasterline & 1) << 7) | (vic[3] & ~0x80);
      default:
	return vic[addr];
    }
}

BYTE read_colorram(ADDRESS addr)
{
    return colormem[addr & 0x3ff];
}

void store_colorram(ADDRESS addr, BYTE value)
{
    colormem[addr & 0x3ff] = value;
}

/* -------------------------------------------------------------------------- */

/* Set the memory pointers according to the values stored in the VIC
   registers. */
static void set_memory_ptrs(void)
{
    int tmp;
    ADDRESS charaddr;

    tmp = vic[0x5] & 0xf;
    charaddr = (tmp & 0x8) ? 0x0000 : 0x8000;
    charaddr += (tmp & 0x7) * 0x400;
    if (charaddr >= 0x8000 && charaddr < 0x9000) {
	chargen_ptr = char_rom + (charaddr & 0xfff);
#ifdef VIC_REGISTERS_DEBUG
	printf("\tcharacter memory at $%04X (character ROM + $%04X)\n",
	       charaddr, charaddr & 0xfff);
#endif
    } else {
	chargen_ptr = ram + charaddr;
#ifdef VIC_REGISTERS_DEBUG
	printf("\tcharacter memory at $%04X\n", charaddr);
#endif
    }
    colormem = ram + 0x9400 + (vic[0x2] & 0x80 ? 0x200 : 0x0);
    screenmem = ram + (((vic[0x2] & 0x80) << 2) | ((vic[0x5] & 0x70) << 6));
#ifdef VIC_REGISTERS_DEBUG
    printf("\tcolor memory at $%04X\n", colormem - ram);
    printf("\tscreen memory at $%04X\n", screenmem - ram);
#endif
}

/* -------------------------------------------------------------------------- */

/* Here comes the part that actually repaints each raster line.  This table is
   used to speed up the drawing. */
static WORD dwg_table[256][256][8];	/* [byte][color][position] */

static void init_drawing_table(void)
{
    int byte, color, pos;

    for (byte = 0; byte < 0x100; byte++) {
	for (color = 0; color < 0x100; color++) {
	    if (color & 0x8) {	/* Multicolor mode. */
		for (pos = 0; pos < 8; pos += 2) {
		    dwg_table[byte][color][pos]
			= dwg_table[byte][color][pos + 1]
			= (byte >> (6 - pos)) & 0x3;
		}
	    } else {		/* Standard mode. */
		for (pos = 0; pos < 8; pos++) {
		    dwg_table[byte][color][pos] = ((byte >> (7 - pos))
						   & 0x1) * 2;
		}
	    }
	}
    }
}

/* As we don't emulate the X position register, VIC_SCREEN_BORDERWIDTH is
   constant and thus accesses are always aligned. */
#if !defined(ALLOW_UNALIGNED_ACCESS) && VIC_SCREEN_BORDERWIDTH % 4 == 0
#define ALLOW_UNALIGNED_ACCESS
#endif

/* If unaligned 32-bit access is not allowed, store the graphics in a
   temporary aligned buffer.  It will be later copied to the real frame
   buffer.
   This is ugly, but should be hopefully faster than accessing 8-bits at a
   time anyway. */
#ifndef ALLOW_UNALIGNED_ACCESS
static PIXEL4 _aligned_line_buffer[VIC_SCREEN_MAX_XPIX];
static PIXEL * const aligned_line_buffer = (PIXEL *)_aligned_line_buffer;
#endif

void int_rasterdraw(long offset)
{
    maincpu_set_alarm(A_RASTERDRAW, CYCLES_PER_LINE - offset);
    emulate_line();
}

static int fill_cache(struct line_cache *l, int *xs, int *xe, int r)
{
    if (l->bgdata[0] != background_color || l->colordata2[0] != auxiliary_color
	|| l->numcols != text_cols) {
	l->bgdata[0] = background_color;
	l->colordata2[0] = auxiliary_color;
	l->numcols = text_cols;
	*xs = 0;
	*xe = text_cols;
	r = 1;
    }
    r = _fill_cache(l->colordata1, colormem + memptr, VIC_SCREEN_TEXTCOLS, 1,
		    xs, xe, r);
    r = _fill_cache_text(l->fgdata, screenmem + memptr, chargen_ptr,
			 VIC_SCREEN_TEXTCOLS, ycounter, xs, xe, r);
    return r;
}

#define PUT_PIXEL(p, d, c, b, x) \
      *((PIXEL2 *)(p) + (x)) = (c)[dwg_table[(d)][(b)][(x)]]

#define DRAW_LINE(p, xs, xe)						     \
  do {									     \
      static PIXEL2 c[4];			    			     \
      int b, i;								     \
      BYTE d;								     \
      PIXEL *pp = (PIXEL *)(p) + (xs) * 16;				     \
									     \
      c[0] = PIXEL2(background_color);					     \
      c[1] = PIXEL2(border_color);					     \
      c[3] = PIXEL2(auxiliary_color);					     \
      for (i = (xs); i <= (xe); i++, pp += 16) {			     \
	  b = (colormem + memptr)[i];					     \
	  c[2] = PIXEL2(b & 0x7);					     \
	  d = GET_CHAR_DATA (chargen_ptr, (screenmem + memptr)[i], ycounter);\
	  PUT_PIXEL(pp, d, c, b, 0); PUT_PIXEL(pp, d, c, b, 1);		     \
	  PUT_PIXEL(pp, d, c, b, 2); PUT_PIXEL(pp, d, c, b, 3);	             \
	  PUT_PIXEL(pp, d, c, b, 4); PUT_PIXEL(pp, d, c, b, 5);		     \
	  PUT_PIXEL(pp, d, c, b, 6); PUT_PIXEL(pp, d, c, b, 7);		     \
      }									     \
  } while (0)

static void draw_line(void)
{
    PIXEL *p = frame_buffer_ptr + VIC_SCREEN_BORDERWIDTH * 2;

#ifndef ALLOW_UNALIGNED_ACCESS
    DRAW_LINE(aligned_line_buffer, 0, text_cols - 1);
    vid_memcpy(p, aligned_line_buffer, text_cols * 16);
#else
    DRAW_LINE(p, 0, text_cols - 1);
#endif
}

static void draw_line_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + VIC_SCREEN_BORDERWIDTH * 2;

#ifndef ALLOW_UNALIGNED_ACCESS
    DRAW_LINE(aligned_line_buffer, xs, xe);
    vid_memcpy(p + xs * 16, aligned_line_buffer + xs * 16, (xe - xs + 1) * 16);
#else
    DRAW_LINE(p, xs, xe);
#endif
}

#define PUT_PIXEL_2x(p, d, c, b, x) \
      *((PIXEL4 *)(p) + (x)) = (c)[dwg_table[(d)][(b)][(x)]]

#define DRAW_LINE_2x(p, xs, xe)						     \
  do {									     \
      static PIXEL4 c[4];						     \
      BYTE d, b;							     \
      int i;								     \
      PIXEL *pp = (PIXEL *)(p) + (xs) * 32;				     \
									     \
      c[0] = PIXEL4(background_color);				             \
      c[1] = PIXEL4(border_color);					     \
      c[3] = PIXEL4(auxiliary_color);				             \
      for (i = (xs); i <= (xe); i++, pp += 32) {			     \
	  b = (colormem + memptr)[i];					     \
	  c[2] = PIXEL4(b & 0x7);					     \
	  d = GET_CHAR_DATA (chargen_ptr, (screenmem + memptr)[i], ycounter);\
	  PUT_PIXEL_2x(pp, d, c, b, 0); PUT_PIXEL_2x(pp, d, c, b, 1);	     \
	  PUT_PIXEL_2x(pp, d, c, b, 2); PUT_PIXEL_2x(pp, d, c, b, 3);	     \
	  PUT_PIXEL_2x(pp, d, c, b, 4); PUT_PIXEL_2x(pp, d, c, b, 5);	     \
	  PUT_PIXEL_2x(pp, d, c, b, 6); PUT_PIXEL_2x(pp, d, c, b, 7);	     \
      }									     \
  } while (0)

static void draw_line_2x(void)
{
    PIXEL *p = frame_buffer_ptr + VIC_SCREEN_BORDERWIDTH * 4;

#ifndef ALLOW_UNALIGNED_ACCESS
    DRAW_LINE_2x(aligned_line_buffer, 0, text_cols - 1);
    vid_memcpy(p, aligned_line_buffer, text_cols * 32);
#else
    DRAW_LINE_2x(p, 0, text_cols - 1);
#endif
}

static void draw_line_cached_2x(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + VIC_SCREEN_BORDERWIDTH * 4;

#ifndef ALLOW_UNALIGNED_ACCESS
    DRAW_LINE_2x(aligned_line_buffer, xs, xe);
    vid_memcpy(p + xs * 32, aligned_line_buffer + xs * 32, (xe - xs + 1) * 32);
#else
    DRAW_LINE_2x(p, xs, xe);
#endif
}

/* -------------------------------------------------------------------------- */

void vic_exposure_handler(unsigned int width, unsigned int height)
{
    resize(width, height);
    force_repaint();
}

void vic_prevent_clk_overflow(void)
{
    oldclk -= PREVENT_CLK_OVERFLOW_SUB;
}
