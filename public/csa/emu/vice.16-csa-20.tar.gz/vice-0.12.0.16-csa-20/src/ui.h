#ifdef __MSDOS__
#include "ui_d.h"
#else
#include "ui_xaw.h"
#endif
