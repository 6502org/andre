/*
 * $Id: kbdef_x.h,v 1.1 1997/05/22 21:22:28 fachat Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Jouko Valta (jopi@stekt.oulu.fi)
 *   Andre' Fachat (fachat@physik.tu-chemnitz.de)
 *
 * $Log: kbdef_x.h,v $
 * Revision 1.1  1997/05/22 21:22:28  fachat
 * Initial revision
 *
 */

/* Keyboard definitions for the X11 keyboard driver. */

#ifndef _KBDEF_X_H
#define _KBDEF_X_H

typedef struct {
    KeySym sym;
    BYTE row;
    BYTE keybit;
    short shift;
} keyconv;

#ifdef VIC20
#define ROW0	7
#define ROW7	0
#define COL3	128
#define COL7	8
#else
#define ROW0	0
#define ROW7	7
#define COL3	8
#define COL7	128
#endif

/*
   For all the keyboards, the shift flag has the following meaning:
   
   0    no shift involved
   1    normal, but shifted key
   2    left shift key
   4    right shift key
   8    allow shift key to be combined with the normal key
   (currently used for TAB, BackSpace,...)

   An additional kbd_shiftflag is supported to save the state of the shift
   keys - to let the shift state not be overridden by some key combinations,
   if the shift keys are explicitely pressed

   the variables kbd_*shiftrow and kbd_*shiftbit contain the position of 
   the left and right shift keys 
 */


/* VIC20/C64/C128 keyboard maps. */

#if !(defined(PET) || defined(CSA))
static keyconv keyconvmap[] =
{
    {XK_Delete, ROW0, 1, 8},	/* del */
    {XK_Return, ROW0, 2, 8},
    {XK_Right, ROW0, 4, 8},
    {XK_F7, ROW0, COL3, 8},
    {XK_F1, ROW0, 16, 8},
    {XK_F3, ROW0, 32, 8},
    {XK_F5, ROW0, 64, 8},
    {XK_Down, ROW0, COL7, 8},

    {XK_3, 1, 1, 8},
    {XK_w, 1, 2, 8},
    {XK_a, 1, 4, 8},
    {XK_4, 1, COL3, 8},
    {XK_z, 1, 16, 8},
    {XK_s, 1, 32, 8},
    {XK_e, 1, 64, 8},
    {XK_Shift_L, 1, COL7, 2},

    {XK_5, 2, 1, 8},
    {XK_r, 2, 2, 8},
    {XK_d, 2, 4, 8},
    {XK_6, 2, COL3, 8},
    {XK_c, 2, 16, 8},
    {XK_f, 2, 32, 8},
    {XK_t, 2, 64, 8},
    {XK_x, 2, COL7, 8},

    {XK_7, 3, 1, 8},
    {XK_y, 3, 2, 8},
    {XK_g, 3, 4, 8},
    {XK_8, 3, COL3, 8},
    {XK_b, 3, 16, 8},
    {XK_h, 3, 32, 8},
    {XK_u, 3, 64, 8},
    {XK_v, 3, COL7, 8},

    {XK_9, 4, 1, 8},
    {XK_i, 4, 2, 8},
    {XK_j, 4, 4, 8},
    {XK_0, 4, COL3, 8},
    {XK_m, 4, 16, 8},
    {XK_k, 4, 32, 8},
    {XK_o, 4, 64, 8},
    {XK_n, 4, COL7, 8},

    {XK_plus, 5, 1, 0},
    {XK_p, 5, 2, 8},
    {XK_l, 5, 4, 8},
    {XK_minus, 5, COL3, 8},
    {XK_period, 5, 16, 8},
    {XK_colon, 5, 32, 0},
    {XK_at, 5, 64, 0},		/* shifted @ gives 'grave' */
    {XK_comma, 5, COL7, 8},

    {XK_sterling, 6, 1, 8},	/* Sterling Pound sign */
    {XK_bar, 6, 1, 8},		/* Sterling Pound sign */
    {XK_asterisk, 6, 2, 0},
    {XK_semicolon, 6, 4, 0},
    {XK_Home, 6, COL3, 8},

    {XK_Shift_R, 0, 0, 4},

    {XK_equal, 6, 32, 0},
    
#ifdef US_KBD
    {XK_asciicircum, 6, 64, 0},	/* Up arrow (US kbd) */
#else
    {XK_asciitilde, 6, 64, 8},	/* Up arrow (scandinavian kbd) */
#endif

    {XK_slash, 6, COL7, 0},

    {XK_1, ROW7, 1, 8},
    {XK_underscore, ROW7, 2, 8},	/* Left arrow */
    {XK_Control_L, ROW7, 4, 8},	/* CNTRL */
    {XK_2, ROW7, COL3, 8},
    {XK_space, ROW7, 16, 8},
    {XK_Alt_L, ROW7, 32, 8},	/* CBM */
    {XK_q, ROW7, 64, 8},
    {XK_Escape, ROW7, COL7, 8},	/* STOP */

    {XK_BackSpace, ROW0, 1, 8},	/* Del */

  /*
   * Some keys for DECstations
   */
    {XK_KP_F1, ROW0, 16, 8},	/* F1 */
    {XK_KP_F2, ROW0, 32, 8},	/* F3 */
    {XK_KP_F3, ROW0, 64, 8},	/* F5 */
    {XK_KP_F4, ROW0, 4, 8},	/* F7 */
    {XK_Insert, ROW0, 1, 16},	/* Inst */
    {XK_Find, 6, COL3, 8},	/* Home */

#ifdef DECMAP
    {DXK_Remove, ROW0, 1, 8},	/* del (DECkeysym.h) */
    {XK_Help, ROW7, COL7, 8},	/* because no real ESC-key on the keyboard /RH/ */
#endif

  /*
   * C128 Keyboard Extension
   * C128 Special keys, rows K1, K2 and K3 from the VIC-IIe
   *
   * Kx d02f    dc01:
   * 08  fe     KP_1    KP_7    KP_4    KP_2    Tab     KP_5    KP_8    Help
   * 09  fd     KP_3    KP_9    KP_6    KP_Entr LineFd KP_Minus KP_Plus Esc 
   * 10  fb  NoScroll   Right   Left    Down    Up      KP_Dot  KP_0    Alt
   *
   */

#ifdef C128
    {XK_KP_1, 8, 128, 8},	/* Numpad 1 */
    {XK_KP_2, 8, 16, 8},	/* Numpad 2 */
    {XK_KP_3, 9, 128, 8},	/* Numpad 3 */
    {XK_KP_4, 8, 32, 8},	/* Numpad 4 */
    {XK_KP_5, 8, 4, 8},		/* Numpad 5 */
    {XK_KP_6, 9, 32, 8},	/* Numpad 6 */
    {XK_KP_7, 8, 64, 8},	/* Numpad 7 */
    {XK_KP_8, 8, 2, 8},		/* Numpad 8 */
    {XK_KP_9, 9, 64, 8},	/* Numpad 9 */
    {XK_KP_0, 10, 2, 8},	/* Numpad 0 */
    {XK_KP_Subtract, 9, 4, 8},	/* Numpad - */
    {XK_KP_Add, 0, 2, 8},	/* Numpad + */
    {XK_KP_Separator, 10, 4, 8},	/* Numpad . */
#endif				/* C128 */

  /*
   * Shifted C64/128 keys
   */

    {XK_Linefeed, ROW0, 2, 1},
    {XK_Left, ROW0, 4, 1},
    {XK_F8, ROW0, COL3, 1},
    {XK_F2, ROW0, 16, 1},
    {XK_F4, ROW0, 32, 1},
    {XK_F6, ROW0, 64, 1},
    {XK_Up, ROW0, COL7, 1},

    {XK_numbersign, 1, 1, 1},
    {XK_W, 1, 2, 1},
    {XK_A, 1, 4, 1},
    {XK_dollar, 1, COL3, 1},
    {XK_Z, 1, 16, 1},
    {XK_S, 1, 32, 1},
    {XK_E, 1, 64, 1},

    {XK_percent, 2, 1, 1},
    {XK_R, 2, 2, 1},
    {XK_D, 2, 4, 1},
    {XK_ampersand, 2, COL3, 1},
    {XK_C, 2, 16, 1},
    {XK_F, 2, 32, 1},
    {XK_T, 2, 64, 1},
    {XK_X, 2, COL7, 1},

    {XK_quoteright, 3, 1, 1},	/* apostrophe */
    {XK_Y, 3, 2, 1},
    {XK_G, 3, 4, 1},
    {XK_parenleft, 3, COL3, 1},
    {XK_B, 3, 16, 1},
    {XK_H, 3, 32, 1},
    {XK_U, 3, 64, 1},
    {XK_V, 3, COL7, 1},

    {XK_parenright, 4, 1, 1},
    {XK_I, 4, 2, 1},
    {XK_J, 4, 4, 1},
    {XK_M, 4, 16, 1},
    {XK_K, 4, 32, 1},
    {XK_O, 4, 64, 1},
    {XK_N, 4, COL7, 1},

    {XK_P, 5, 2, 1},
    {XK_L, 5, 4, 1},
    {XK_greater, 5, 16, 1},
    {XK_bracketleft, 5, 32, 1},
    {XK_grave, 5, 64, 1},	/* shifted @ */
    {XK_less, 5, COL7, 1},

    {XK_backslash, 6, 1, 1},
    {XK_bracketright, 6, 4, 1},
#ifdef US_KBD
    {XK_asciitilde, 6, 64, 0},	/* shift up arrow (US kbd) */
#else
    {XK_asciicircum, 6, 64, 8},	/* shift up arrow (scandinavian kbd) */
#endif
    {XK_question, 6, COL7, 1},

    {XK_exclam, ROW7, 1, 1},
    {XK_quotedbl, ROW7, COL3, 1},
    {XK_Q, ROW7, 64, 1},
    {0, 0, 0, 0}
};

/* End of VIC20/C64/C128 keyboard */


#else

/* ------------------------------------------------------------------------- */

/* PET keyboard(s). */

/* PET 8032 Business Keyboard. */

static keyconv pet80map[] =
{
    {XK_0, 1, 8, 0},
    {XK_1, 1, 1, 0},
    {XK_2, 0, 1, 0},
    {XK_3, 9, 2, 0},
    {XK_4, 1, 2, 0},
    {XK_5, 0, 2, 0},
    {XK_6, 9, 4, 0},
    {XK_7, 1, 4, 0},
    {XK_8, 0, 4, 0},
    {XK_9, 9, 8, 0},

    {XK_Control_L, 9, 16, 8},	/* left Ctrl maps to run/stop */

    {XK_Home, 8, 16, 8},
    {XK_Right, 0, 32, 8},
    {XK_Down, 5, 16, 8},
    {XK_Delete, 4, 128, 0},	/* del */
    {XK_BackSpace, 4, 128, 8},	/* inst/del */
    {XK_Shift_L, 6, 1, 2},
    {XK_Shift_R, 6, 64, 4},
    {XK_Return, 3, 16, 0},
    {XK_Escape, 2, 1, 0},	/* Escape */

    {XK_Tab, 8, 1, 8},		/* Tab -> rev/off */
#ifdef hpXK_BackTab
    {hpXK_BackTab, 8, 1, 1},	/* Tab -> rev/off */
#endif
    {XK_KP_Tab, 8, 1, 8},
#ifdef hpXK_KP_BackTab
    {hpXK_KP_BackTab, 8, 1, 1},
#endif

    {XK_KP_0, 7, 16, 8},	/* Numpad 0 */
    {XK_KP_1, 8, 128, 8},	/* Numpad 1 */
    {XK_KP_2, 7, 128, 8},	/* Numpad 2 */
    {XK_KP_3, 6, 128, 8},	/* Numpad 3 */
    {XK_KP_4, 5, 128, 8},	/* Numpad 4 */
    {XK_KP_5, 2, 128, 8},	/* Numpad 5 */
    {XK_KP_6, 3, 128, 8},	/* Numpad 6 */
    {XK_KP_7, 1, 16, 8},	/* Numpad 7 */
    {XK_KP_8, 0, 16, 8},	/* Numpad 8 */
    {XK_KP_9, 1, 128, 8},	/* Numpad 9 */
    {XK_KP_Separator, 7, 8, 0},
    {XK_KP_Multiply, 9, 32, 1},
    {XK_KP_Divide, 8, 64, 0},
    {XK_KP_Add, 2, 64, 1},
    {XK_KP_Subtract, 0, 8, 0},
    {XK_KP_Enter, 3, 16, 0},
    {XK_KP_Decimal, 6, 16, 0},	/* Numpad . */

    {XK_period, 6, 16, 0},
    {XK_minus, 0, 8, 0},
    {XK_space, 8, 4, 0},
    {XK_colon, 9, 32, 0},
    {XK_underscore, 9, 1, 0},	/* Left arrow */
    {XK_comma, 7, 8, 0},

    {XK_slash, 8, 64, 0},
    {XK_semicolon, 2, 64, 0},

    {XK_at, 3, 64, 0},		/* shifted @ gives 'grave' */
    {XK_a, 3, 1, 0},
    {XK_b, 6, 4, 0},
    {XK_c, 6, 2, 0},
    {XK_d, 3, 2, 0},
    {XK_e, 5, 2, 0},
    {XK_f, 2, 4, 0},
    {XK_g, 3, 4, 0},
    {XK_h, 2, 8, 0},
    {XK_i, 4, 32, 0},
    {XK_j, 3, 8, 0},
    {XK_k, 2, 32, 0},
    {XK_l, 3, 32, 0},
    {XK_m, 8, 8, 0},
    {XK_n, 7, 4, 0},
    {XK_o, 5, 32, 0},
    {XK_p, 4, 64, 0},
    {XK_q, 5, 1, 0},
    {XK_r, 4, 4, 0},
    {XK_s, 2, 2, 0},
    {XK_t, 5, 4, 0},
    {XK_u, 5, 8, 0},
    {XK_v, 7, 2, 0},
    {XK_w, 4, 2, 0},
    {XK_x, 8, 2, 0},
    {XK_y, 4, 8, 0},
    {XK_z, 7, 1, 0},

    {XK_asciicircum, 1, 32, 0},	/* Up arrow (US kbd) */
    {XK_asciitilde, 1, 32, 0},	/* Up arrow (scandinavian kbd) */

    {XK_bracketright, 2, 32, 0},
    {XK_bracketleft, 5, 64, 0},

  /*
   * Shifted PET keys
   */

    {XK_Insert, 4, 128, 1},
    {XK_Left, 0, 32, 1},
    {XK_Up, 5, 16, 1},

    {XK_A, 3, 1, 1},
    {XK_B, 6, 4, 1},
    {XK_C, 6, 2, 1},
    {XK_D, 3, 2, 1},
    {XK_E, 5, 2, 1},
    {XK_F, 2, 4, 1},
    {XK_G, 3, 4, 1},
    {XK_H, 2, 8, 1},
    {XK_I, 4, 32, 1},
    {XK_J, 3, 8, 1},
    {XK_K, 2, 32, 1},
    {XK_L, 3, 32, 1},
    {XK_M, 8, 8, 1},
    {XK_N, 7, 4, 1},
    {XK_O, 5, 32, 1},
    {XK_P, 4, 64, 1},
    {XK_Q, 5, 1, 1},
    {XK_R, 4, 4, 1},
    {XK_S, 2, 2, 1},
    {XK_T, 5, 4, 1},
    {XK_U, 5, 8, 1},
    {XK_V, 7, 2, 1},
    {XK_W, 4, 2, 1},
    {XK_X, 8, 2, 1},
    {XK_Y, 4, 8, 1},
    {XK_Z, 7, 1, 1},

    {XK_exclam, 1, 1, 1},
    {XK_quotedbl, 0, 1, 1},
    {XK_numbersign, 9, 2, 1},
    {XK_dollar, 1, 2, 1},
    {XK_percent, 0, 2, 1},
    {XK_ampersand, 9, 4, 1},
    {XK_quoteright, 1, 4, 1},	/* apostrophe = shift 7 */
    {XK_parenleft, 0, 4, 1},
    {XK_parenright, 9, 8, 1},
    {XK_asterisk, 9, 32, 1},
    {XK_plus, 2, 64, 1},

    {XK_less, 7, 8, 1},
    {XK_equal, 0, 8, 1},
    {XK_greater, 6, 8, 1},
    {XK_question, 8, 64, 1},

    {0, 0, 0, 0}
};


/* PET 3032/4032 Graphics Keyboard. */

keyconv pet40map[] =
{
    {XK_Return, 6, 32, 0},
    {XK_Down, 1, 64, 8},
    {XK_Right, 0, 128, 8},
    {XK_Home, 0, 64, 8},
    {XK_BackSpace, 1, 128, 8},
    {XK_Delete, 1, 128, 0},

    {XK_Tab, 9, 1, 8},		/* Tab -> rev/off */
#ifdef hpXK_BackTab
    {hpXK_BackTab, 9, 1, 1},	/* Tab -> rev/off */
#endif
    {XK_KP_Tab, 9, 1, 8},
#ifdef hpXK_KP_BackTab
    {hpXK_KP_BackTab, 9, 1, 1},	/* Tab -> rev/off */
#endif

    {XK_Escape, 9, 16, 8},	/* Escape -> Run/Stop */
    {XK_Find, 0, 64, 0},	/* Home */

    {XK_Shift_L, 8, 1, 2},
    {XK_Shift_R, 8, 32, 4},

#ifdef DECMAP
    {DXK_Remove, 1, 128, 0},	/* del (DECkeysym.h) */
    {XK_Help, 9, 16, 8},	/* because there is no real ESC-key
				   on the keyboard /RH/ */
#endif				/* DECMAP */

    {XK_a, 4, 1, 0},
    {XK_b, 6, 4, 0},
    {XK_c, 6, 2, 0},
    {XK_d, 4, 2, 0},
    {XK_e, 2, 2, 0},
    {XK_f, 5, 2, 0},
    {XK_g, 4, 4, 0},
    {XK_h, 5, 4, 0},
    {XK_i, 3, 8, 0},
    {XK_j, 4, 8, 0},
    {XK_k, 5, 8, 0},
    {XK_l, 4, 16, 0},
    {XK_m, 6, 8, 0},
    {XK_n, 7, 4, 0},
    {XK_o, 2, 16, 0},
    {XK_p, 3, 16, 0},
    {XK_q, 2, 1, 0},
    {XK_r, 3, 2, 0},
    {XK_s, 5, 1, 0},
    {XK_t, 2, 4, 0},
    {XK_u, 2, 8, 0},
    {XK_v, 7, 2, 0},
    {XK_w, 3, 1, 0},
    {XK_x, 7, 1, 0},
    {XK_y, 3, 4, 0},
    {XK_z, 6, 1, 0},

    {XK_KP_0, 8, 64, 8},
    {XK_KP_1, 6, 64, 8},
    {XK_KP_2, 7, 64, 8},
    {XK_KP_3, 6, 128, 8},
    {XK_KP_4, 4, 64, 8},
    {XK_KP_5, 5, 64, 8},
    {XK_KP_6, 4, 128, 8},
    {XK_KP_7, 2, 64, 8},
    {XK_KP_8, 3, 64, 8},
    {XK_KP_9, 2, 128, 8},

    {XK_KP_Separator, 7, 8, 8},
    {XK_KP_Multiply, 5, 128, 8},
    {XK_KP_Divide, 3, 128, 8},
    {XK_KP_Add, 7, 128, 8},
    {XK_KP_Subtract, 8, 128, 8},
    {XK_KP_Enter, 6, 32, 8},
    {XK_KP_Decimal, 9, 64, 8},	/* Numpad . */

    {XK_0, 8, 64, 0},
    {XK_1, 6, 64, 0},
    {XK_2, 7, 64, 0},
    {XK_3, 6, 128, 0},
    {XK_4, 4, 64, 0},
    {XK_5, 5, 64, 0},
    {XK_6, 4, 128, 0},
    {XK_7, 2, 64, 0},
    {XK_8, 3, 64, 0},
    {XK_9, 2, 128, 0},

    {XK_slash, 3, 128, 0},
    {XK_bracketright, 1, 16, 0},
    {XK_bracketleft, 0, 16, 0},
    {XK_parenright, 1, 16, 0},
    {XK_parenleft, 0, 16, 0},
    {XK_question, 7, 16, 0},
    {XK_dollar, 1, 2, 0},
    {XK_asterisk, 5, 128, 0},
    {XK_colon, 5, 16, 0},
    {XK_comma, 7, 8, 0},
    {XK_quotedbl, 1, 1, 0},
    {XK_sterling, 1, 8, 0},
    {XK_backslash, 1, 8, 0},
    {XK_bar, 1, 8, 0},
    {XK_numbersign, 0, 2, 0},
    {XK_exclam, 0, 1, 0},
    {XK_percent, 0, 4, 0},
    {XK_plus, 7, 128, 0},
    {XK_underscore, 0, 32, 0},
    {XK_ampersand, 0, 8, 0},
    {XK_semicolon, 6, 16, 0},
    {XK_minus, 8, 128, 0},
    {XK_equal, 9, 128, 0},
    {XK_space, 9, 4, 0},
    {XK_greater, 8, 16, 0},
    {XK_less, 9, 8, 0},
    {XK_period, 9, 64, 0},
    {XK_at, 8, 2, 0},
    {XK_asciicircum, 2, 32, 0},	/* up arrow (US kbd) */
    {XK_asciitilde, 2, 32, 0},	/* up arrow (scandinavian kbd) */

    /* shifted keys */
    {XK_Left, 0, 128, 1},
    {XK_Up, 1, 64, 1},
    {XK_Insert, 1, 128, 1},
    {XK_Clear, 0, 64, 1},

    {XK_grave, 8, 2, 1},	/* shifted @ */

    {XK_W, 3, 1, 1},
    {XK_A, 4, 1, 1},
    {XK_Z, 6, 1, 1},
    {XK_S, 5, 1, 1},
    {XK_E, 2, 2, 1},
    {XK_R, 3, 2, 1},
    {XK_D, 4, 2, 1},
    {XK_C, 6, 2, 1},
    {XK_F, 5, 2, 1},
    {XK_T, 2, 4, 1},
    {XK_X, 7, 1, 1},
    {XK_Y, 3, 4, 1},
    {XK_G, 4, 4, 1},
    {XK_B, 6, 4, 1},
    {XK_H, 5, 4, 1},
    {XK_U, 2, 8, 1},
    {XK_V, 7, 2, 1},
    {XK_I, 3, 8, 1},
    {XK_J, 4, 8, 1},
    {XK_M, 6, 8, 1},
    {XK_K, 5, 8, 1},
    {XK_O, 2, 16, 1},
    {XK_N, 7, 4, 1},
    {XK_P, 3, 16, 1},
    {XK_L, 4, 16, 1},
    {XK_Q, 2, 1, 1},

    {0, 0, 0, 0}
};

static keyconv *keyconvmap = pet80map;
static int CONV_KEYS = sizeof(pet80map) / sizeof(keyconv);

#endif				/* PET */

#if !(defined(PET) || defined(CSA))
#define CONV_KEYS (sizeof(keyconvmap)/sizeof(keyconv))
#endif

#endif /* !_KBDEF_X_H */
