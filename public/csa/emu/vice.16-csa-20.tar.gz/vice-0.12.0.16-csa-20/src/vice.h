/*
 * $Id: vice.h,v 1.1 1997/05/22 21:13:58 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *   Jouko Valta (jopi@stekt.oulu.fi)
 *
 * $Log: vice.h,v $
 * Revision 1.1  1997/05/22 21:13:58  ettore
 * Initial revision
 *
 */

#ifndef _VICE_H

#include "autoconf.h"	  /* automagically created by the `configure' script  */

#define _CONFIG_H
#if !defined(C128) && !defined(VIC20) && !defined(PET) && !defined(CBM64) \
							&& !defined(CSA)
#define CBM64
#endif 

#if defined(VIC20)
#define APPLICATION_NAME "xvic"
#define EMULATOR	 "VIC20"
#elif defined(PET)
#define APPLICATION_NAME "xpet"
#define EMULATOR         "PET"
#elif defined(CSA)
#define APPLICATION_NAME "xcsa"
#define EMULATOR         "CSA"
#elif defined(C128)
#define APPLICATION_NAME "x128"
#define EMULATOR	 "C128"
#else
#define APPLICATION_NAME "x64"
#define EMULATOR	 "C64"
#endif

#define APPLICATION_CLASS "VICE"

/* ------------------------------------------------------------------------- */

/* Define the default system directory (where the ROMs are). */

#define LIBDIR		PREFIX "/lib/VICE"

/* These are relative to LIBDIR. */

#ifdef C128
#define PROJECTDIR	"C128"
#endif

#ifdef CBM64
#define PROJECTDIR	"C64"
#endif

#ifdef VIC20
#define PROJECTDIR	"VIC20"
#endif

#ifdef PET
#define PROJECTDIR	"PET"
#endif

#ifdef CSA
#define PROJECTDIR	"CSA"
#endif

#define DOCDIR		"doc"


/* These are the default image file name, to be searched for under LIBDIR "/"
   PROJECTDIR. */

#ifndef RAMNAME
#define RAMNAME		"ram"
#endif

#ifndef BASICNAME
#define BASICNAME	"basic"
#endif

#if defined(PET) 

#define KERNAL8032NAME	"kernal8032"
#define KERNAL4032NAME	"kernal4032"
#define KERNAL3032NAME	"kernal3032"
#ifndef KERNALNAME
#define KERNALNAME	KERNAL8032NAME /* Default */
#endif
#define PET_COLS	80

#elif defined(CSA)

#ifndef KERNALNAME
#define KERNALNAME	"csarom"
#endif
#define PET_COLS	80	/* we use PET i/o */

#else  /* !PET  && !CSA */

#ifndef KERNALNAME
#define KERNALNAME	"kernal"
#endif

#endif /* !PET */

#ifndef REUNAME
#define REUNAME		"reu.c64"
#endif

#ifndef EXROMNAME
#define EXROMNAME	"exrom"
#endif

#ifndef DOSNAME
#define DOSNAME		"dos1541"
#endif

#ifndef BIOSNAME
#define BIOSNAME  	"Z80_BIOS"
#endif

#ifndef CHARNAME
#define CHARNAME	"chargen"
#endif

/* ------------------------------------------------------------------------- */

#define XDEBUGGER
#define PAL

#ifdef CBM64
#define	IEEE488
#endif

/*
 * Which way to copy files ?
 * Since C1541 disk drive copies files to the first filename, whereas
 * they normally go to the last file, one can change the 'c1541' copy
 * syntax via this option.
 *   UNIX:  copy    oldname [oldname2 ...] newname
 *   1541:  copy    newname oldname [oldname2 ...]
 */

/*#define COPY_TO_LEFT*/	/* no */


/* Enable T64 support. */

#if defined(CBM64) || defined(C128)
#define CBMTAPE
#endif


/*
 * Shall Virtual RAM Expander be installed ?
 * Sizes available are 128, 256 and 512 KB
 * (C128 internal RAM may be expanded in vmachine.h)
 */

#if !(defined(VIC20) || defined(PET) || defined(CSA))

#define REU			/* yes */
#define REUSIZE 512

#endif


/* Utility to patch between ROM revisions.
 * Supports 0, 3, 67 and 100 for the C64, but user can define more.  */

#if !(defined(VIC20) || defined(PET) || defined(CSA))

#define PATCH_ROM		/* yes */

#endif


/* Emulator Identification Utility. */

#define EMULATOR_ID		/* yes */


/* Printer. */

#define PRN_CS_DEFAULT  0	/* 0 */


#if 1  /* European A4 Papersize */
#define PS_WIDTH	595
#define PS_HEIGHT	842

#else  /* American Letter Papersize */
#define PS_WIDTH	612
#define PS_HEIGHT	792
#endif

#if defined(CBM64) || defined(C128) || defined(PET) || defined(VIC20) \
							|| defined(CSA)
#define SOUND
#endif

#ifdef __MSDOS__
#undef SOUND
#endif

/* Sound defaults. */

#define SOUND_SAMPLE_RATE		22050	/* Hz */
#define SOUND_SAMPLE_BUFFER_SIZE	500	/* ms */


/* Trap idle. */

/* #define IDLE_TRAP */		/* no */

/* Debugging info. */

/* #define DEBUG */		/* no */

/* ------------------------------------------------------------------------- */

/* Portability... */

#ifdef __hpux
#ifndef _POSIX_SOURCE
#define _POSIX_SOURCE
#endif
#ifndef _INCLUDE_POSIX_SOURCE
#define _INCLUDE_POSIX_SOURCE
#endif
#endif  /* __hpux */

#ifdef DEBUG
#undef LED_ARRAY
#endif

#ifdef __MSDOS__
#undef EDIT
#elif !defined(EDIT)
#define EDIT
#endif

#if defined(HAVE_X11_EXTENSIONS_XSHM_H) && defined(HAVE_LIBXEXT)
#define MITSHM
#endif

#if defined(HAVE_JOYSTICK_H) && defined(__linux__)
#define JOYSTICK
#endif

#if defined(HAVE_LIBXPM) && defined(HAVE_X11_XPM_H)
#define XPM
#endif

#if defined(HAVE_SYSTEMINFO_H)
#define SYSINFO
#endif

#if !defined(HAVE_MEMMOVE)
#define memmove memmov
#endif

#undef TRACE

#if defined(CBM64) || defined(VIC20) || defined(C128)
#define HAVE_TRUE1541
#endif

#if defined(HAVE_SYSTEMINFO_H)
#define SYSINFO			/* yes */
#endif

#endif  /* _VICE_H */

