/*
 * $Id: kbd_x.c,v 1.1 1997/05/22 20:00:41 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README file for copyright notice.
 *
 * Written by
 *   Jouko Valta        (jopi@stekt.oulu.fi)
 *   Andre Fachat       (fachat@physik.tu-chemnitz.de)
 *   Ettore Perazzoli   (ettore@comm2000.it)
 *   Bernhard Kuhn	(kuhn@eikon.e-technik.tu-muenchen.de)
 *
 * $Log: kbd_x.c,v $
 * Revision 1.1  1997/05/22 20:00:41  ettore
 * Initial revision
 *
 */

/* X11 keyboard driver. */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

#include <sys/time.h>
#include <signal.h>
#include <unistd.h>

#include "vmachine.h"
#include "extern.h"
#include "video.h"
#include "ui.h"

#include "kbd.h"
#include "kbdef_x.h"
#include "interrupt.h"

/* -------------------------------------------------------------------------- */

BYTE keyarr[KBD_ROWS];
static int keypressed = -1;
static int keys_down = 0;

/* Keymap definition structure */

BYTE keyarr[KBD_ROWS];

/* Joystick status */

BYTE joy[3] = { 0, 0, 0 };

/* Shift status */
#if defined(PET) || defined(CSA)
static short kbd_shiftflag = 0;
static short kbd_lshiftrow = 6;
static short kbd_lshiftbit = 1;
static short kbd_rshiftrow = 6;
static short kbd_rshiftbit = 64;
#else
static short kbd_shiftflag = 0;
static short kbd_lshiftrow = 1;
static short kbd_lshiftbit = COL7;
static short kbd_rshiftrow = 6;
static short kbd_rshiftbit = 16;
#endif

#if !(defined(PET) || defined(CSA))
/* Each element in this array is set to 0 if the corresponding key in the
   numeric keypad is pressed. */
static int numpad_status[10];
#endif

/* -------------------------------------------------------------------------- */

/* Select between different PET keyboards. */
#if defined(PET) || defined(CSA)

void set80key(void)
{
    kbd_lshiftrow = 6;
    kbd_lshiftbit = 1;
    kbd_rshiftrow = 6;
    kbd_rshiftbit = 64;

    keyconvmap = pet80map;
    CONV_KEYS = sizeof(pet80map) / sizeof(keyconv);
}

void set40key(void)
{
    kbd_lshiftrow = 8;
    kbd_lshiftbit = 1;
    kbd_rshiftrow = 8;
    kbd_rshiftbit = 32;

    keyconvmap = pet40map;
    CONV_KEYS = sizeof(pet40map) / sizeof(keyconv);
}

#endif

/* -------------------------------------------------------------------------- */

/* Joystick emulation via numeric keypad. VIC20 has one single joystick
   port. */
#if !(defined(PET) || defined(CSA))

static int handle_joy_emu(KeySym key, int event_type)
{
    int do_port_1, do_port_2;
    int value;
    int num;
    
#ifdef HAS_JOYSTICK
    do_port_1 = (app_resources.joyDevice1 == 5);
    do_port_2 = (app_resources.joyDevice2 == 5);
#else
    do_port_1 = (app_resources.joyPort == 1);
    do_port_2 = (app_resources.joyPort == 2);
#endif

    switch (event_type) {
	
      case KeyPress:
	switch (key) {
	  case XK_KP_7: case XK_KP_Home:
	    value = 0x5; num = 7;
	    break;
	  case XK_KP_8: case XK_KP_Up:
	    value = 0x1; num = 8;
	    break;
	  case XK_KP_9: case XK_KP_Page_Up:
	    value = 0x9; num = 9;
	    break;
	  case XK_KP_4: case XK_KP_Left:
	    value = 0x4; num = 4;
	    break;
	  case XK_KP_6: case XK_KP_Right:
	    value = 0x8; num = 6;
	    break;
	  case XK_KP_1: case XK_KP_End:
	    value = 0x6; num = 1;
	    break;
	  case XK_KP_2: case XK_KP_Down:
	    value = 0x2; num = 2;
	    break;
	  case XK_KP_3: case XK_KP_Page_Down:
	    value = 0xa; num = 3;
	    break;
	  case XK_KP_0: case XK_KP_Insert: case XK_Control_R:
	    value = 0x10; num = 0;
	    break;
	  default:
	    return 0;
	}
	if (do_port_1)
	    joy[1] |= value;
	if (do_port_2)
	    joy[2] |= value;
	numpad_status[num] = 1;
	break;			/* KeyPress */
	
      case KeyRelease:
	switch (key) {
	  case XK_KP_7: case XK_KP_Home:
	    value = ((numpad_status[8] ? 0 : 0x1)
		     | (numpad_status[4] ? 0 : 0x4));
	    num = 7;
	    break;
	  case XK_KP_8: case XK_KP_Up:
	    value = 0x1; num = 8;
	    break;
	  case XK_KP_9: case XK_KP_Page_Up:
	    value = ((numpad_status[8] ? 0 : 0x1)
		     | (numpad_status[6] ? 0 : 0x8));
	    num = 9;
	    break;
	  case XK_KP_4: case XK_KP_Left:
	    value = 0x4; num = 4;
	    break;
	  case XK_KP_6: case XK_KP_Right:
	    value = 0x8; num = 6;
	    break;
	  case XK_KP_1: case XK_KP_End:
	    value = ((numpad_status[2] ? 0 : 0x2)
		     | (numpad_status[4] ? 0 : 0x4));
	    num = 1;
	    break;
	  case XK_KP_2: case XK_KP_Down:
	    value = 0x2; num = 2;
	    break;
	  case XK_KP_3: case XK_KP_Page_Down:
	    value = ((numpad_status[2] ? 0 : 0x2)
		     | (numpad_status[6] ? 0 : 0x8));
	    num = 3;
	    break;
	  case XK_KP_0: case XK_KP_Insert: case XK_Control_R:
	    value = 0x10; num = 0;
	    break;
	  default:
	    return 0;
	}
	if (do_port_1)
	    joy[1] &= ~value;
	if (do_port_2)
	    joy[2] &= ~value;
	numpad_status[num] = 0;
	break;			/* KeyRelease */
    }

    return 0;
}
#endif

void kbd_event_handler(Widget w, XtPointer client_data, XEvent *report,
		       Boolean *ctd)
{
    static char buffer[20];
    KeySym key;
    XComposeStatus compose;
    int count, i;
    
    count = XLookupString(&report->xkey, buffer, 20, &key, &compose);

#if !(defined(PET) || defined(CSA))
    if (handle_joy_emu(key, report->type))
	return;
    if (key == XK_Tab) {	/* Restore */
	if (report->type == KeyPress)
	    maincpu_strobe_nmi();
	return;
    }
#endif
	
    switch (report->type) {

      case KeyPress:
	for (i = 0; keyconvmap[i].sym; ++i) {
	    if (key == keyconvmap[i].sym) {
		keyarr[keyconvmap[i].row] |= keyconvmap[i].keybit;
		kbd_shiftflag |= keyconvmap[i].shift;

		/* The following code keeps up with shift keys. */

		if (!keyconvmap[i].shift) { /* non-shifted */
		    keyarr[kbd_lshiftrow] &= ~kbd_lshiftbit;
		    keyarr[kbd_rshiftrow] &= ~kbd_rshiftbit;
		} else {
		    if (keyconvmap[i].shift & 2)
			keyarr[kbd_lshiftrow] |= kbd_lshiftbit;
		    if (keyconvmap[i].shift & 4)
			keyarr[kbd_rshiftrow] |= kbd_rshiftbit;
		    if (keyconvmap[i].shift & 1)
			keyarr[kbd_lshiftrow] |= kbd_lshiftbit;
		}
		
		keypressed = i;
		keys_down++;

#ifdef DEBUG
		if (debugflg)
		    printf("KEY FOUND %ld\n", report->xkey.time);
#endif
		break;
	    }
	}

#ifdef DEBUG
	if (debugflg) {
	    show_keyarr();
	    printf("count %d Key %d %lx\n", count, (int) *buffer, key);
	}
#endif

#ifdef KBDBUG2
	printf("queue %d \n", keys_down);
	for (i = 0; i < MAXDOWN; i++)
	    printf("%02x%c  ", kptr->key, kptr->ack + '@');
	printf("\n");

	printf("%2d keys: %02X %02X %02X %02X  %02X %02X %02X %02X\n",
	       keys_down, keyarr[0], keyarr[1], keyarr[2], keyarr[3],
	       keyarr[4], keyarr[5], keyarr[6], keyarr[7]);
#endif

	break;

      case KeyRelease:
	for (i = 0; i < CONV_KEYS; i++)
	    if (key == keyconvmap[i].sym) {
		keypressed = i;
		break;
	    }
	if (keypressed >= 0) {
	    if (!(--keys_down)) {
#ifdef KBDBUG
		printf("release: no keys left\n");
#endif
		memset(keyarr, 0, sizeof(keyarr));
		keypressed = -1;
		kbd_shiftflag = 0;
	    } else {
		/* do not use "XOR" here... */
		keyarr[keyconvmap[keypressed].row] &=
		    ~keyconvmap[keypressed].keybit;
		kbd_shiftflag &= ~keyconvmap[keypressed].shift;
		/* test if keyrelease removed all (left) shift keys */
		if ((kbd_shiftflag & 3) == 0)
		    keyarr[kbd_lshiftrow] &= ~kbd_lshiftbit;
		if ((kbd_shiftflag & 4) == 0)
		    keyarr[kbd_rshiftrow] &= ~kbd_rshiftbit;
	    }
#ifdef DEBUG
	    if (debugflg)
		printf("KEY RELEASED %d\n", keypressed);
#endif
	}
#ifdef DEBUG
	if (debugflg)
	    printf("count %d Key %d %lx\n", count, (int) *buffer, key);
#endif
	break;

      case LeaveNotify:
	/* Clean up. */
	keys_down = 0;
	memset(keyarr, 0, sizeof(keyarr));
	memset(joy, 0, sizeof(joy));
#if !(defined(PET) || defined(CSA))
	memset(numpad_status, 0, sizeof(numpad_status));
#endif
	kbd_shiftflag = 0;
	keypressed = -1;
	break;
	
      default:
	break;
    }				/* End switch */
}

/* ------------------------------------------------------------------------- */

void kbd_init()
{
    /* Do nothing.  In the X11 version, the keyboard handler is a callback
       function for the emulation window, so we just cannot do anything useful
       here. */
}
