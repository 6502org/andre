/*
 * $Id: extern.h,v 1.13 1997/05/22 21:15:54 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * Written by
 *   Vesa-Matti Puro (vmp@lut.fi)
 *   Teemu Rantanen (tvr@cs.hut.fi)
 *   Jarkko Sonninen (sonninen@lut.fi)
 *
 * Patches by
 *   Andre Fachat     (a.fachat@physik.tu-chemnitz.de)
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: extern.h,v $
 * Revision 1.13  1997/05/22 21:15:54  ettore
 * Code cleanup.
 *
 * Revision 1.12  1996/07/29 21:05:18  fachat
 * Interrupt-specific stuff moved to interrupt.h
 *
 * Revision 1.11  1996/04/01  09:01:41  jopi
 * *** empty log message ***
 *
 * Revision 1.10  1995/11/07  16:51:00  jopi
 * *** empty log message ***
 *
 * Revision 1.9  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * Linux joystick.
 * VIC drawing routines renamed appropriately.
 *
 * Revision 1.8  1994/12/12  16:59:44  jopi
 * *** empty log message ***
 *
 * Revision 1.7  1994/08/10  18:34:13  jopi
 * More changeability
 *
 * Revision 1.6  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.5  1994/02/18  16:10:57  jopi
 * New debugger & arg parser, x20 and x128
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:38:30  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 *
 */

#ifndef X64_EXTERN_H
#define X64_EXTERN_H

#include <stdio.h>      /* just for FILE */

#include "types.h"	/* for BYTE, ADDRESS, etc. types and structures */
#include "proto.h"
#include "resources.h"

#ifdef __cplusplus
#ifdef __STDC__
#undef __STDC__
#endif
define __STDC__ 0
#endif

extern const char  *progname;
extern int    clength[];

extern BYTE   accumulator;
extern BYTE   x_register;
extern BYTE   y_register;
extern BYTE   stack_pointer;
extern BYTE   status_register;
extern ADDRESS program_counter;
extern CLOCK  clk;

extern int    zero_flag;
extern int    sign_flag;
extern int    overflow_flag;
extern int    break_flag;
extern int    decimal_flag;
extern int    interrupt_flag;
extern int    carry_flag;
extern int    rmw_flag;


/* Debugging */
extern int    hexflg;
extern int    runflg;
extern int    traceflg;
extern int    ledflg;
extern int    debugflg;
extern int    pardebug;
extern int    verflg;

extern int    autodump;

/* Memory */

extern int module;

extern BYTE  ram[];
extern BYTE  *pagezero;
extern BYTE  *pageone;
extern BYTE  kernal_rom[];
extern BYTE  basic_rom[];
extern BYTE   char_rom[];
extern BYTE  external_rom[];
extern BYTE   sid[];
extern BYTE   cia1[];
extern BYTE   cia2[];
extern BYTE   keyarr[];
extern BYTE   joy1, joy2;
extern BYTE   memconfig;

extern void  (*(memwr[])) ( ADDRESS, BYTE );
extern BYTE  (*(memrd[])) ( ADDRESS );


/* Keyboard & joystick */

#ifdef HAS_JOYSTICK
extern void   joystick(void) ;
extern void   joyini(void) ;
extern void   joyclose(void);
extern void   joyset(void);

extern int    joyfd ;
#endif

/* Numpad joystick emulation */

extern BYTE   joy[3];
extern int    joyport;
extern int    hjoyport[2];

/* C64 performance */

extern int    rd[];
extern int    wr[];
extern long   instructions[];

extern int    ledarr[];

/* C128 video chips enable/disable */

extern int    video80;
extern int    video40;

/* video refresh rate */

#if defined (C128)
extern int    vdcrefrate;
extern int    vicrefrate;
#else
extern int    refrate;
#endif

extern int    mitshm;

extern const char *progname;

#endif  /* X64_EXTERN_H */
