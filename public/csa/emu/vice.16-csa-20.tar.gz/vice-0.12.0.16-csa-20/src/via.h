/*
 * $Id: via.h,v 1.2 1997/05/22 21:41:35 fachat Exp $
 *
 * This file is part of Commodore 64 emulator.
 * See README for copyright notice
 *
 * VIA 6522 register number declarations.
 * Interrupt signals are defined in vmachine.h.
 *
 * Written by
 *    Andre Fachat (a.fachat@physik.tu-chemnitz.de)
 *
 *
 * I really don't like using the same names for the registers in 
 * different chips. So I moved the via 6522 stuff here, for the 
 * PET things at least. And then I'm mostly using the register 
 * name definitions as given in the Rockwell specs.
 *
 * $Log: via.h,v $
 * Revision 1.2  1997/05/22 21:41:35  fachat
 * Edge signals added.
 *
 */


#ifndef X64_VIA_H
#define X64_VIA_H

/*
 * MOS 6522 registers
 */
#define VIA_PRB		0  /* Port B */
#define VIA_PRA		1  /* Port A */
#define VIA_DDRB	2  /* Data direction register for port B */
#define VIA_DDRA	3  /* Data direction register for port A */

#define VIA_T1CL	4  /* Timer 1 count low */
#define VIA_T1CH	5  /* Timer 1 count high */
#define VIA_T1LL	6  /* Timer 1 latch low */
#define VIA_T1LH	7  /* Timer 1 latch high */
#define VIA_T2CL	8  /* Timer 2 count low - read only */
#define VIA_T2LL	8  /* Timer 2 latch low - write only */
#define VIA_T2CH	9  /* Timer 2 latch/count high */

#define VIA_SR		10 /* Serial port shift register */
#define VIA_ACR		11 /* Auxiliary control register */
#define VIA_PCR		12 /* Peripheral control register */

#define VIA_IFR		13 /* Interrupt flag register */
#define VIA_IER		14 /* Interrupt control register */
#define VIA_PRA_NHS	15 /* Port A with no handshake */

/*
 * Interrupt Masks
 */

/* MOS 6522 */
#define VIA_IM_IRQ	128	/* Control Bit */
#define VIA_IM_T1	64	/* Timer 1 underflow */
#define VIA_IM_T2	32	/* Timer 2 underflow */
#define VIA_IM_CB1	16	/* Handshake */
#define VIA_IM_CB2	8	/* Handshake */
#define VIA_IM_SR	4	/* Shift Register completion */
#define VIA_IM_CA1	2	/* Handshake */
#define VIA_IM_CA2	1	/* Handshake */


/* 
 * signal values (for signaling edges on the control lines)
 */

#define	VIA_SIG_CA1	0
#define	VIA_SIG_CA2	1
#define	VIA_SIG_CB1	2
#define	VIA_SIG_CB2	3

#define	VIA_SIG_FALL	0
#define	VIA_SIG_RISE	1


#endif  /* X64_CIA_H */

