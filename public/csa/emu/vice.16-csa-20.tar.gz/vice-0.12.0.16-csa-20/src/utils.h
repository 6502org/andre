/*
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli	(ettore@comm2000.it)
 *
 * Miscellaneous utility functions.
 */

#ifndef _UTILS_H
#define _UTILS_H

#include <stdlib.h>

char *stralloc(const char *str);
void *xmalloc(size_t s);
void *xrealloc(void *p, size_t s);
char *bufcat(char *buf, int *buf_size, int *max_buf_size, const char *src,
	     int src_size);
char *make_backup_filename(const char *fname);
int make_backup_file(const char *fname);
int spawn(const char *name, char **argv,
	  const char *stdout_redir, const char *stderr_redir);

#endif /* UTILS_H */
