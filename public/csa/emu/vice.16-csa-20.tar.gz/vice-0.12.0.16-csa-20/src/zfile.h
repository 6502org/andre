/*
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * Trasparent handling of compressed files.
 */

#ifndef _ZFILE_H
#define _ZFILE_H

#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <stdio.h>

int zopen(const char *name, mode_t mode, int flags);
int zclose(int fd);
FILE *zfopen(const char *name, const char *mode);
int zfclose(FILE *stream);
int zclose_all(void);

#endif /* _ZFILE_H */
