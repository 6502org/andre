/*
 * $Id: main.c,v 2.0 1997/05/22 20:02:44 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * Main builds up the emulation and controls its operation.
 *
 * Written by
 *   Vesa-Matti Puro  (vmp@lut.fi)
 *   Jarkko Sonninen  (sonninen@lut.fi)
 *   Jouko Valta      (jopi@stekt.oulu.fi)
 *   Ettore Perazzoli (ettore@comm2000.it)
 *   Andre Fachat     (a.fachat@physik.tu-chemnitz.de)
 *
 * $Log: main.c,v $
 * Revision 2.0  1997/05/22 20:02:44  ettore
 * General cleanup and support for the new features in 0.12.0.
 *
 * Revision 1.13  1996/07/29 21:20:20  ettore
 * Miscellaneous fixes.
 * Handles environment variables.
 * SID-ready.
 *
 * Revision 1.12  1996/04/01  09:01:41  jopi
 * PET and VIC-20 implemented
 * Emulator Information screen added
 *
 * Revision 1.11  1995/11/07  16:51:00  jopi
 * different emulators, emuinfo
 * resource debug
 *
 * Revision 1.10  1995/06/28  19:40:56  jopi
 * PET, emu info
 *
 * Revision 1.9  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * Options and control for Printer, Serial and ROM patcher updated.
 * Signal calls end64 for decent exit.
 *
 * Revision 1.8  1994/12/12  16:59:44  jopi
 * *** empty log message ***
 *
 * Revision 1.7  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.6  1994/02/18  16:10:57  jopi
 * New debugger & arg parser, x20 and x128
 *
 * Revision 1.5  1994/01/26  16:08:37  jopi
 * X64 version 0.2 PL 1
 * load file reorganised
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:38:36  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 */

#include "maincpu.h"
#include "vmachine.h"
#include "memory.h"
#include "serial.h"
#include "extern.h"
#include "proto.h"
#include "patchlevel.h"
#include "vice.h"
#include "interrupt.h"
#include "sid.h"
#include "ui.h"
#include "true1541.h"
#include "vsync.h"
#include "video.h"
#include "kbd.h"
#include "resources.h"

#ifdef __hpux
#ifndef _INCLUDE_POSIX_SOURCE
#define _INCLUDE_POSIX_SOURCE
#endif
#ifndef _POSIX_SOURCE
#define _POSIX_SOURCE
#endif
#endif  /* __hpux */

#include <stdio.h>
#include <stdlib.h>
#include <signal.h>

/* system info */
#include <string.h>
#include <unistd.h>

#ifdef __hpux
#define _INCLUDE_XOPEN_SOURCE
#define _XPG2
#include <limits.h>
#undef  _INCLUDE_XOPEN_SOURCE
#undef  _XPG2
#else
#include <limits.h>
#endif

#include <sys/utsname.h>	/* Needs "vice.h" */
#ifdef SYSINFO
#include <sys/systeminfo.h>
#endif

#include <sys/types.h>
#include <dirent.h>

#ifdef __GO32__
#include <fcntl.h>
#endif

#ifdef PET
#include "crtc.h"
#define EI_M  0 
#endif
#ifdef VIC20
#include "vic.h"
#define EI_M  1
#endif
#ifdef CBM64
#include "vicii.h"
#define EI_M  2
#endif
#ifdef PLUS_SERIES
#define EI_M  3
#endif
#ifdef C128
#define EI_M  4
#endif
#ifdef CSA
#include "crtc.h"
#define	EI_M  5
#endif

#define EMULATED_MACHINE emutypes[EI_M]

static char *cputypes[] = { "6502", "6502", "6510", "7501", "8502", "6502" };
static char *emutypes[] = { "PET", "VIC-20", "C=64", "C=16", "C=128", "CSA65" };


const char *progname;

extern CLOCK   clk;
extern int     halt;

#ifdef PET
extern int kernal_rev;
#endif
/*extern void set80key(void), set40key(void);*/

/* FIXME: should be removed! */
int     module = 0;
int     hexflg = 1;
int     runflg = 0;		/* ==> app_resources */
int     traceflg = 0;		/* CPU */
int     debugflg = 0;		/* CIA */
int     verflg = 0;		/* VIC */
int     video80 = 0;		/* enable/disable VDC (C128 only) */
int	video40 = 0;		/* enable/disable VIC-II (C128 only) */

int     autodump = 0;

#ifdef NEW_TIMER_CODE
extern int new_alarm_number;
extern void new_alarm_trap(int i);
extern void update_intr_alarm(void);
#endif /* NEW_TIMER_CODE */

#ifdef SUN
extern int getpagesize(void);
#endif

static void emuinfo(int emu);
static RETSIGTYPE break64(int sig);

static void exit64(void);

/* -------------------------------------------------------------------------- */

#ifdef __MSDOS__

static char *orig_workdir;

static void restore_workdir(void)
{
    if (orig_workdir)
	chdir(orig_workdir);
}

static void preserve_workdir(void)
{
    orig_workdir = getcwd(NULL, PATH_MAX);
    atexit(restore_workdir);
}

#endif


/* -------------------------------------------------------------------------- */

int main(int argc, char **argv)
{
    ADDRESS start_addr;

    if (atexit (exit64) < 0) {
	perror ("atexit");
	return -1;
    }

#ifdef __GO32__
    /* Set the default file mode. */
    _fmode = O_BINARY;
#endif
#ifdef __MSDOS__
    /* Avoid exiting to a different directory than the one we were called
       from. */
    preserve_workdir();
#endif

    progname = strrchr(argv[0], '/');
    if (!progname)
	progname = argv[0];
    else
	progname++;

    /* VICE boot sequence. */
    
    printf ("\n*** VICE Version %s ***\n", VERSION);
    printf ("Welcome to %s, the Commodore %s Emulator for the X-Window System."
	    "\n\n", progname, EMULATED_MACHINE);
    printf ("Copyright (c) 1993-1997\n"
	    "E. Perazzoli, T. Rantanen, A. Fachat, J. Valta, D. Sladic and "
	    "J. Sonninen.\n\n");

    /* Initialize the user interface.  UiInit() might need to handle the
       command line somehow, so we call it before parsing the options.
       (e.g. under X11, the `-display' option is handled independently). */
    if (UiInit (&argc, argv) < 0)
	exit (-1);

    /* Initialize the resources. */
    resources_set_defaults(0);

    /* Load the user's configuration file. */
    if (resources_load(NULL, EMULATOR) == -1) {
	fprintf(stderr,
		"Couldn't find user's configuration file: "
		"using default settings.\n");
	/* The resource file might contain errors, and thus certain resources
	   might have been initialized anyway. */
	resources_set_defaults();
    }

    putchar('\n');
    
    /* Parse the command line. */
    if (parse_cmd_line(&argc, argv))
	exit(-1);
    
    /* Complete the GUI initialization if necessary. */
    if (UiInitFinish() < 0)
	exit(-1);

    putchar('\n');

    signal(SIGINT,   break64);
    signal(SIGSEGV,  break64);
    signal(SIGHUP,   break64);
    signal(SIGQUIT,  break64);
    signal(SIGILL,   break64);
    signal(SIGTERM,  break64);
    signal(SIGPIPE,  break64);
    
    if (app_resources.module)
	module = atoi(app_resources.module);

    /* FIXME: this is not good.  It would be better to always use
       app_resources, without mirroring the values in the *flg variables. */
    hexflg = app_resources.hexflag;
    runflg = app_resources.asmflag;
    traceflg = app_resources.traceflag;	/* CPU */
    debugflg = app_resources.debugflag;	/* CIA */
    verflg = app_resources.verboseflag;	/* VIC */

#if defined (C128)
    video80 = app_resources.video80;
    video40 = app_resources.video40;
    if (!video80 && !video40)
#if defined (_USE_VDC)
	video80 = 1;
#else
    video40 = 1;
#endif
#else  /* !defined (c128) */
#endif


    if (load_mem() < 0 && !app_resources.asmflag)
	exit (1);

#ifdef PET
    printf("Loaded kernal, checksum is %d ($%04X).\n", kernal_rev, kernal_rev);

#if 0
    video80 = app_resources.video80;
    video40 = app_resources.video40;
#endif
    
    if(!video80 && !video40) {
	/* printf("No command line switch for screen width!\n"); */
	if(kernal_rev == PET8032_CHECKSUM_A 
	   || kernal_rev == PET8032_CHECKSUM_B) {
	    printf("Identified PET 8032 kernal by checksum.\n");
	    video80 = 1;
	} else if(kernal_rev == PET3032_CHECKSUM) {
	    printf("Identified PET 3032 kernal by checksum.\n");
	    video40 = 1;
	} else if (kernal_rev == PET4032_CHECKSUM) { 
	    printf("Identified PET 4032 kernal by checksum.\n");
	    video40 = 1;
	}
    }
    
    if(!video80 && !video40) {
	printf("Couldn't identify PET kernal, trying default.\n");
#if PET_COLS == 80
	video80 = 1;
#else
	video40 = 1;
#endif
    }
    /* Setup PET keyboard. */
    if(video80) {
	crtc_set80();
	set80key();
    } else {
	crtc_set40();
	set40key();
    }
    
#elif defined(CSA)
    set40key();		/* we have graphics keyboard all the time */

    video80 = app_resources.video80;
    video40 = app_resources.video40;
			/* no cmdline switch? try default */
    if(!video40 && !video80) video80 = 1;

    if(video80) {
	video40 = 0;
	crtc_set80();
    } else {
	crtc_set40();	/* needed for PET emu */
    }
#endif

#if defined(PET) || defined(CSA)
    printf("Setting screen width to %d columns.\n", video80 ? 80 : 40);
#endif

#ifdef PATCH_ROM
#ifdef C128
    if (app_resources.basicRev) {
	(void)patch_rom (app_resources.basicRev);
    }
#endif
    if (app_resources.kernalRev) {
	(void)patch_rom (app_resources.kernalRev);
    }
#endif  /* PATCH_ROM */

#ifndef NO_SERIAL
    
    printf("\nInitializing Serial Bus:\n");

    /* Setup trap handling. */
    initialize_traps();

    /* Initialize serial traps.  If user does not want them, or if the
       ``true1541'' emulation is used, do not install them. */
    initialize_serial(app_resources.notraps || app_resources.true1541);

    /* Initialize peripherals that are connected to the IEC serial line. */
    initialize_printer(4, app_resources.PrinterLang,
		       app_resources.Locale );
    initialize_1541(8, DT_DISK | DT_1541);
    initialize_1541(9, DT_DISK | DT_1541);
    initialize_1541(11, DT_FS | DT_1541);

#ifdef HAVE_TRUE1541
    putchar('\n');
    
    /* Fire up the hardware-level 1541 emulation. */
    initialize_true1541();
#endif

    /* Attach specified disk images. */
    
    if (app_resources.floppyName
	&& serial_select_file(DT_DISK | DT_1541, 8,
			      app_resources.floppyName) < 0)
	fprintf (stderr, "\nFloppy attach failed.\n");
    if (app_resources.floppy9Name
	&& serial_select_file(DT_DISK | DT_1541, 9,
			      app_resources.floppy9Name) < 0)
	fprintf (stderr, "\nFloppy attach failed.\n");
    if (app_resources.floppy10Name
	&& serial_select_file(DT_DISK | DT_1541, 10,
			      app_resources.floppy10Name) < 0)
	fprintf (stderr, "\nFloppy attach failed.\n");

#ifdef CBMTAPE
    if (!app_resources.notraps)
	initialize_tape (1);
    if (app_resources.tapeName && *app_resources.tapeName)
	if (serial_select_file(DT_TAPE, 1, app_resources.tapeName) < 0) {
	    fprintf (stderr, "No Tape.\n");
	}
#endif

#endif  /* NO_SERIAL */

#ifdef SOUND
    /* Fire up the sound emulation. */
    initialize_sound();
#endif

    putchar ('\n');

#if defined(HAS_JOYSTICK) && !defined(PET)
    /* Initialize real joystick. */
    joyini();
#endif

#ifndef MITSHM
    app_resources.mitshm = 0;
#endif

#ifndef __MSDOS__
    printf ("Initializing graphics (MITSHM %s)...\n\n",
	    app_resources.mitshm ? "enabled" : "disabled");
#else
    puts ("Initializing graphics...\n");
#endif

    if (video_init () < 0)
	exit (-1);
   
#ifdef VIC20
    vic_init ();
#elif defined (PET) || defined(CSA)
    crtc_init ();
#elif defined (C128)
    vic_ii_init ();
#else  /* C64 */
    vic_ii_init ();
#endif

    /* Use the specified start address for booting up. */
    if (app_resources.startAddr)
	start_addr = (ADDRESS) strtol(app_resources.startAddr, NULL,
				      hexflg ? 16 : 10);
    else
        start_addr = 0;		/* Use normal RESET vector. */

    /* Print all values from resources and command line options if
       requested. */
    if (app_resources.verboseflag || app_resources.debugflag) {
	emuinfo(EI_M);
	printf ("\n");
    }

#ifdef HAS_ZILOG_Z80
    initialize (app_resources.testflag);
#endif

#ifdef NEW_TIMER_CODE
    new_alarm_number = new_alarm();
    update_intr_alarm();
#endif  /* NEW_TIMER_CODE */

    /* Here we go ... */

    if (app_resources.asmflag)
	mon(start_addr);

    vsync_init();
    kbd_init();

    maincpu_trigger_reset();

    mainloop(start_addr);
    printf("perkele!\n");
    exit(0);   /* never reached */
}

static RETSIGTYPE break64(int sig)
{
#ifdef SYS_SIGLIST_DECLARED
    fprintf(stderr, "Received signal %d (%s).\n", sig, sys_siglist[sig]);
#else
    fprintf(stderr, "Received signal %d.\n", sig);
#endif
    exit (-1);
}

static void exit64(void)
{
    printf("\nExiting...\n");		/* add return for C-c */
    video_free ();

#ifndef NO_SERIAL
    if (!app_resources.notraps)
	remove_serial(-1);
#endif

#if defined(HAS_JOYSTICK) && !defined(PET) && !defined(CSA)
    joyclose();
#endif

#ifdef REU
    if (app_resources.reu)
	close_reuc(app_resources.reuName);
#endif

    if (autodump)
      dump (create_name(NULL, RAMNAME));

#ifdef SOUND
    close_sound();
#endif

#ifdef DEBUG
    /*
     * This routine stores cumulated count of different instructions
     * if profiler is enabled.
     */

    if (debugflg) {
	int     i;
	long    total = 0;
	char   *bufp;
	FILE   *fp;

	bufp = create_name(NULL, "inst");
	if (NULL == (fp = fopen(bufp, "w")))
	    return;

	fprintf(fp, "\n\tCPU0 Statistics\n\n");

	for (i = 0; i < 256; i++) {
	    total += instructions[i];
	    fprintf(fp, "%02X %-4s %8ld\n", i, lookup[i].mnemonic,
		instructions[i]);
	}
	fprintf(fp, "----------------\n\tTotal %8ld\n", total);
	fprintf(fp, "\tClock: %5ld cycles\n", clk);
	fclose(fp);

	/* Store C64 memory access log file */
	/* if ((bufp = create_name(NULL, "mem")) == NULL ||
	 *   ( fp = fopen( "mem", "w" )) == NULL) return 1;
	 * for ( i=0; i<65536; i++ )
	 *   fprintf( fp, "%04X %10d %10d\n", i, rd[i], wr[i]); fclose( fp );
	 */
    }
#endif

    putchar ('\n');
}

void end64()
{
    exit (-1);
}


/* ------------------------------------------------------------------------- */

/*
 * X64 Information screen inspired by Michael A. Cooper's sysinfo(1).
 * uname(2) and sysconf(2) give the needed values.
 */


static void emuinfo(int emu)
{
#ifdef SYSINFO
    char buf[256];
#endif
    long count = 31;
    struct utsname host;

    /*
     * Host Info
     */

    printf("\nHost System:\n\n");

    if (uname (&host) >= 0) {
      printf("    Host Name\t\t\t   : %s\n", host.nodename);
      printf("    OS Version\t\t\t   : %s Release %s\n",
	     host.sysname, host.release /*, host.version */);
      printf("    Architecture\t\t   : %s\n", host.machine);
    }

#ifdef SYSINFO
    sysinfo(SI_ARCHITECTURE, buf, count);
    printf ("    CPU Architecture\t\t   : %s\n", buf);
#endif
#ifdef _SC_NPROCESSORS_ONLN
    printf ("    Number of CPUs in use\t   : %ld\n",
	    sysconf(_SC_NPROCESSORS_ONLN));	/* Number of CPUs alive */
#endif

#ifndef __hpux
#if defined (_SC_PAGESIZE) && defined (_SC_PHYS_PAGES)
    count = (long) sysconf(_SC_PAGESIZE);
    count *= (long)sysconf(_SC_PHYS_PAGES);
#else
    count = (long) getpagesize();		/* System memory page size */
    count *= (long)1;
#endif  /* _SC_PAGESIZE */

    if (count >> 20)
      printf ("\n    RAM Installed total\t\t   : %ld MB\n", count >> 20);
#endif /* __hpux */

    /*
     * Emulator Info
     */

    printf("\n\nEmulator:\n\n");

    printf ("    Emulator Version\t\t   : %s\n", VERSION);

#ifndef REUSIZE
#define REUSIZE 0
#endif

       printf ("\
    CBM %s Kernal Version\t   :  d  s\n\
    Main Memory                    : %3d KB\n\
    REU Expansion Memory           : %3d KB (%s)\n\n\
    Total number of CPUs emulated  : 1\n\
    CPU Type                       : %s\n",
	       emutypes[emu],
	       (RAMSIZE >> 10), (REUSIZE >>10),
	       app_resources.reuName ? app_resources.reuName : "disabled",
	       cputypes[emu]);


    printf("\n\nPeripheral Information:\n\n");

    printf("    Max Serial Address  : 15\n");

#ifndef NO_SERIAL
    remove_serial(-2);		/* QUERY mode */
    printf("\n\n");
#endif  /* NO_SERIAL */
}
