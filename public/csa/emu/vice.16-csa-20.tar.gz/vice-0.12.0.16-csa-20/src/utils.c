/*
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli	(ettore@comm2000.it)
 *
 * Miscellaneous utility functions.
 */

#include <unistd.h>
#include <stdio.h>
#include <wait.h>

#include "utils.h"

/* ------------------------------------------------------------------------- */

/* Like malloc, but abort if not enough memory is available. */
void *xmalloc(size_t size)
{
    void *p = malloc(size);

    if (p == NULL) {
	fprintf(stderr, "Virtual memory exhausted.\n");
	exit(-1);
    }
    
    return p;
}

/* Like realloc, but abort if not enough memory is available. */
void *xrealloc(void *p, size_t size)
{
    void *new_p = realloc(p, size);

    if (new_p == NULL) {
	fprintf(stderr, "Virtual memory exhausted.\n");
	exit(-1);
    }
    
    return new_p;
}

/* Malloc enough space for `str', copy `str' into it and return its
   address. */
char *stralloc(const char *str)
{
    int l = strlen(str);
    char *p = (char *)xmalloc(l + 1);

    memcpy(p, str, l + 1);
    return p;
}

/* Add the first `src_size' bytes of `src' to the end of `buf', which is a
   malloc'ed block of `max_buf_size' bytes of which only the first `buf_size'
   ones are used.  If the `buf' is not large enough, realloc it.  Return a 
   pointer to the new block. */
char *bufcat(char *buf, int *buf_size, int *max_buf_size,
	     const char *src, int src_size)
{
#define BUFCAT_GRANULARITY 0x1000
    if (*buf_size + src_size > *max_buf_size) {
	char *new_buf;
	
	*max_buf_size = (((*buf_size + src_size) / BUFCAT_GRANULARITY + 1)
			  * BUFCAT_GRANULARITY);
	new_buf = (char *)xrealloc(buf, *max_buf_size);
	buf = new_buf;
    }
    memcpy(buf + *buf_size, src, src_size);
    *buf_size += src_size;
    return buf;
}

/* ------------------------------------------------------------------------- */

/* Return a malloc'ed backup file name for file `fname'. */
char *make_backup_filename(const char *fname)
{
#ifndef __MSDOS__
    /* Just add a '~' to the end of the name. */
    int l = strlen(fname);
    char *p = (char *)xmalloc(l + 2);

    memcpy(p, fname, l);
    *(p + l) = '~';
    *(p + l + 1) = '\0';
    return p;
#else  /* !__MSDOS__ */
    /* FIXME: MS-DOS version missing. */
    return NULL;
#endif /* !__MSDOS__ */
}

/* Make a backup for file `fname'. */
int make_backup_file(const char *fname)
{
    char *backup_name = make_backup_filename(fname);
    int retval;
    
    /* Cannot do it... */
    if (backup_name == NULL)
	return -1;

    retval = rename(fname, backup_name);
    
    free(backup_name);
    return retval;
}

/* ------------------------------------------------------------------------- */

/* Launch program `name' (searched via the PATH environment variable) passing 
   `argv' as the parameters, wait for it to exit and return its exit status.  
   If `stdout_redir' or `stderr_redir' are != NULL, redirect stdout or stderr 
   to the corresponding file.  */
int spawn(const char *name, char **argv,
	  const char *stdout_redir, const char *stderr_redir)
{
#ifndef __MSDOS__
    pid_t child_pid;
    int child_status;

    child_pid = vfork();
    if (child_pid < 0) {
	perror("vfork");
	return -1;
    } else if (child_pid == 0) {
	if (stdout_redir && freopen(stdout_redir, "w", stdout) == NULL) {
	    perror(stdout_redir);
	    return -1;
	}
	if (stderr_redir && freopen(stderr_redir, "w", stderr) == NULL) {
	    perror(stderr_redir);
	    return -1;
	}
	execvp(name, argv);
	_exit(-1);
    }

    if (waitpid(child_pid, &child_status, 0) != child_pid) {
	perror("waitpid");
	return -1;
    }
    
    if (WIFEXITED(child_status))
	return WEXITSTATUS(child_status);
    else
	return -1;
#else
    /* FIXME: MS-DOS version has no redirection! */
    return spawnvp(P_WAIT, name, argv);
#endif
}
