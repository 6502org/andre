/*
 * $Id: vsync.h,v 1.1 1997/05/22 21:45:44 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli	(ettore@comm2000.it)
 *
 * $Log: vsync.h,v $
 * Revision 1.1  1997/05/22 21:45:44  ettore
 * Initial revision
 *
 */

#ifndef _VSYNC_H
#define _VSYNC_H

extern void suspend_speed_eval(void);
extern void vsync_init(void);
extern int do_vsync(int been_skipped);
extern int vsync_disable_timer(void);

#endif /* !_VSYNC_H */
