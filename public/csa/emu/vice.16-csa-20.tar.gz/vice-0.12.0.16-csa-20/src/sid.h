/*
 * $Id: sid.h,v 1.1 1997/05/22 21:35:25 tvr Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * SID 6581 interfacing.
 *
 * Written by
 *   Teemu Rantanen      (tvr@cs.hut.fi)
 *
 * $Log: sid.h,v $
 * Revision 1.1  1997/05/22 21:35:25  tvr
 * Initial revision
 *
 */


#ifndef _SID_H
#define _SID_H

#include "types.h"

#if defined(CBM64) || defined(C128) || defined(VIC20)
#define SID
#endif

#if defined(CBM64) || defined(C128)
void store_sid(ADDRESS address, BYTE byte);
BYTE read_sid(ADDRESS address);
#endif
#if defined(VIC20)
void store_vic20sid(ADDRESS address, BYTE byte);
#endif
#if defined(PET) || defined(CSA)
void store_petsnd_onoff(int value);
void store_petsnd_rate(CLOCK t);
void store_petsnd_sample(BYTE value);
#endif

#ifdef SOUND
int flush_sound(void);
int adjusting_sound(void);
void close_sound(void);
void initialize_sound(void);
void sid_prevent_clk_overflow(void);
#endif

#endif /* !defined (_SID_H) */
