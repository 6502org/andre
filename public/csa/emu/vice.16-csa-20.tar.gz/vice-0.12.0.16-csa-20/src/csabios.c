/*
 * csabios.c
 *
 * This file emulates the I/O port on a CS/A65 BIOS card.
 * A CS/A65 system can run on a CPU and a BIOS card alone,
 * but that would need emulation of the serial line (6551 or 16550) too,
 * which we don't have (yet?).
 * So only the BIOSport is emulated now.
 *
 * The BIOSport is a one-byte port with some bits read-only, others
 * read-write. It is set to all 0 at reset.
 *
 * Bit 0   ro	 /IRQ		direct reading of the CPU /IRQ line
 * Bit 1   rw	 irqen		1 = 50 Hz IRQ from BIOS port enabled
 * Bit 2   rw	 -		(used to be RTS replacement for 6551)
 * Bit 3   rw    LED		0 = LED on, 1 = LED off (not enabled)
 * Bit 4   rw	 extioen	0 = enable /EXTIO activation on physical
 *				addresses $0?000 (not enabled)
 * Bit 5   rw    IOINH		1 = inhibit CPU mapping of I/O at CPU 
 *				$e800-$efff (not enabled)
 * Bit 6   ro	 key		read button - 0 = pressed (not enabled)
 * Bit 7   ro  	 50HzIRQ	1 = 50Hz interrupt is active (but passed
 *				to /IRQ only if irqen = 1)
 *
 * So currently only the 50Hz interrupt and the reading of the /IRQ line
 * is enabled.
 */

#include <stdio.h>
#include "vmachine.h"
#include "interrupt.h"
#include "proto.h"

/* this value should give an approximately 50 Hz interrupt. */
/* We emulate 1 MHz with 40 cols, and 2 MHz with 80 cols */
extern int video80;
#define	BIOSTICKS	(video80 ? 40000 : 20000)

static BYTE biosport = 0;
static int irqactive = 0;

void reset_csabios(void) {
	biosport = 0;
	irqactive = 0;
	maincpu_set_alarm(A_CSABIOS, BIOSTICKS);
	maincpu_set_irq(I_CSABIOS, 0);
}

BYTE read_csabios(ADDRESS addr) {
	BYTE b = biosport & 0x3e;

/*printf("read_csabios(): nirq=%d, strobe_status=%d\n",maincpu_int_status.nirq,
		maincpu_int_status.strobe_status);*/
	b |= 0x40;	/* key not pressed */

	if(irqactive) b |= 0x80;

	if(! (maincpu_int_status.nirq 
		/* || (maincpu_int_status.strobe_status & IK_IRQ) */ )) {
	  b|= 0x01;
	}

	return b;
}

void store_csabios(ADDRESS addr, BYTE val) {
	irqactive = 0;	
/*printf("store_csabios(%02x), clk=%ld\n",val,clk);*/
	maincpu_set_irq(I_CSABIOS, 0);

	biosport = val;
}

int int_csabios(long offset) {

/*printf("int_csabios(rclk=%ld)\n",clk-offset);*/

	irqactive = 1;

	if(biosport & 0x02) {
	  maincpu_set_irq(I_CSABIOS, IK_IRQ);
	}

	maincpu_set_alarm(A_CSABIOS, BIOSTICKS);

	return 0;
}

