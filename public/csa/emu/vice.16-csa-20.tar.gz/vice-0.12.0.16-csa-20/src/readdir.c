/*
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 */

/*
 * File:		readdir.c
 * Date:		Mon Aug 18 11:22:29 1997
 * Author:		Martin Pottendorfer
 * 
 * Abstract:
 *	read directory contents of disk/tape images
 *
 * Modifications:
 *	<tbs>
 */

#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>

#include "zfile.h"
#include "fs_cbm.h"
#include "proto.h"
#include "utils.h"

static char *curr_dst = NULL, *dst_base;
static int junk = 4096;
static BYTE curr[256];
static struct
{
    char *type;
} ft_tab [] = { {"del"}, {"seq"}, {"prg"}, {"usr"}, {"rel"} };

static struct 
{
    char *magic;
} tape_magics [] = {{ "C64 tape image file" }, { "C64S tape image file" }, 
		    { "C64S tape file" }, { NULL }};

/* external functions */
extern int  check_header ( int fd, hdrinfo *hdr );
extern int  get_diskformat(int);
extern int  num_blocks (int, int);
extern void set_disk_geometry(DRIVE *, int);

/* ------------------------------------------------------------------------- */

char *read_disk_image_contents(const char *fname)
{
    char x, line[512], *buf;
    int buf_size, max_buf_size;
    int fd, i, no_entries, len;
    hdrinfo hdr;
    DRIVE floppy;

    fd = zopen(fname, O_RDONLY, 0);
    if (fd < 0)
	return NULL;
    if (check_header(fd, &hdr))
	return NULL;

    if (hdr.v_major > HEADER_VERSION_MAJOR 
	|| (hdr.v_major == HEADER_VERSION_MAJOR
	    && hdr.v_minor > HEADER_VERSION_MINOR)) 
    {
	printf("Disk image file %s (V %d.%02d) version higher than emulator (V %d.%02d)\n",
	       fname, hdr.v_major, hdr.v_minor,
	       HEADER_VERSION_MAJOR, HEADER_VERSION_MINOR);

	zclose(fd);
	return 0;
    }

    /* Initialize floppy struct... (not all of it) */
    floppy.ImageFormat = get_diskformat(hdr.devtype);
    if (floppy.ImageFormat < 0)
    {
	fprintf(stderr, "\nError: Disk drive type mismatch.\n");
	zclose(fd);
	return NULL;
    }
    floppy.ActiveFd = fd;
    floppy.NumTracks = hdr.tracks;
    floppy.NumBlocks = num_blocks(floppy.ImageFormat, hdr.tracks);
    floppy.ErrFlg    = hdr.errblk;
    floppy.D64_Header= hdr.d64;
    floppy.ReadOnly = 1;	/* Just to be sure... */

    /* Initialise format constants. */
    set_disk_geometry(&floppy, floppy.ImageFormat);

#if 0
    if (hdr.d64)
	printf ("D64 disk image: %s%s\n", image,
		floppy.ReadOnly ? " (read only)" : "");
    else
	printf ("VICE disk image version %d.%02d (CBM%d format%s): %s\n",
		hdr.v_major, hdr.v_minor, DType,
		floppy.ReadOnly ? ", read only" : "",
		image);
#endif

    /* Allocate buffer. */
    max_buf_size = 4096;
    buf = xmalloc(max_buf_size);
    buf_size = 0;
    
    /* Get directory header. */
    if (floppy_read_block(floppy.ActiveFd, 
			  floppy.ImageFormat,
			  (BYTE *) &curr[0],
			  floppy.Bam_Track,
			  floppy.Bam_Sector,
			  floppy.D64_Header) < 0)
    {
	fprintf(stderr, "Error reading from disk image.\n");
	free(buf);
	zclose(fd);
	return NULL;
    }
    
    /* Print it. */
    x = curr[162];
    curr[162] = curr[167] = '\0';
    len = sprintf(line, "[ \"%s\", \"%c%s\" ]\n", &curr[144], x, &curr[163]);
    buf = bufcat(buf, &buf_size, &max_buf_size, line, len);

    /* Sanity check. */
    if ((curr[0] != 18) || (curr[1] != 1))
    {
	printf ("Warning: directory seems to be broken, trying anyway...\n");
	curr[0] = (char)floppy.Dir_Track;
	curr[1] = (char)floppy.Dir_Sector;
    }
    
    /* Follow links... */
    while (curr[0] != 0)
    {
	if (floppy_read_block(floppy.ActiveFd, 
			      floppy.ImageFormat,
			      (BYTE *) &curr[0],
			      (int) curr[0], (int) curr[1],
			      floppy.D64_Header) < 0)
	{
	    fprintf(stderr, "Error reading from disk image.\n");
	    free(buf);
	    zclose(fd);
	    return NULL;
	}
	
	for (no_entries = 0, i = 2; i <= 226; i+= 32)
	{
	    int len, j;

	    if ((curr[i+1] == 0) && (curr[i+2] == 0))
		break;
	    
	    no_entries++;

	    /* Cut name away ($A0 - terminated). */
	    for (j = 0; j < 16 && curr[j + i + 3] != 0xa0; j++)
		;
	    curr[j + i + 3] = '\0';
		
	    len = sprintf(line, "%5d \"%s\" ",
			  ((int)curr[i+29]) * 256 + ((int)curr[i+28]),
			  curr + i + 3);
	    
	    while (len < 25)
		line[len++] = ' ';

	    if ((curr[i] & 0xf) > 4)
		curr[i] = 3;
	    
	    len += sprintf(line + len, "%s%s\n", 
			   ft_tab[curr[i] & 0x0f].type,
			   (curr[i] & 64) ? "<" : "");
	    
	    buf = bufcat(buf, &buf_size, &max_buf_size, line, len);
	}

	/* Protect against broken dirs... */
	if (no_entries > 144)
	{
	    fprintf(stderr, "Directory seems to be circular, giving up !\n");
	    break;
	}
    }

    /* Add trailing zero. */
    *(buf + buf_size) = '\0';

    /* Convert from PETSCII to ASCII. */
    petconvstring(buf, 1);
    
    zclose(fd);
    return buf;
}

#if 0

static int
do_tapedir(int f)
{
    int no_entries, max_entries, res;
    char *ext;
    static char line[512];	/* tmp buffer */
    
    curr[40 + 24] = '\0';

    max_entries = (int)curr[34] + (int)curr[35] * 256;
    no_entries = (int)curr[36] + (int)curr[37] * 256;

    sprintf(line, "[ \"%s\" ]\n", &curr[40]);
    if (curr_dst + strlen(line) >= dst_base + junk)
    {
	printf("reallocation needed, giving up !");
	return -1;
    }
    strcat(curr_dst, line);
    curr_dst += strlen(line);

    /* check a little bit */
    if (no_entries > max_entries)
    {
	printf("tape inconsistency, giving up !\n");
	return -1;
    }
    if (!no_entries)
	no_entries = max_entries;
	
    /* seek to start of file records */
    if (lseek (f, 64, SEEK_SET) < 0)
    {
	perror("lseek to file records failed");
	return -1;
    }
    
    while (no_entries--)
    {
	res = read(f, &curr[0], 32);
	if (res != 32)
	{
	    perror("read of file record failed");
	    return -1;
	}
	curr[32] = '\0';
	if (curr[0] == 0)
	    /* don't print free slots */
	    continue;
	else if (curr[0] == 1)
	    ext = "prg";
	else if (curr[0] == 3)
	    ext = "sna";
	else
	    ext = "res";
		
	sprintf(line, "  \"%s\" %s\n", &curr[16], ext);
	if (curr_dst + strlen(line) >= dst_base + junk)
	{
	    printf("reallocation needed, giving up !");
	    return -1;
	}
	strcat(curr_dst, line);
	curr_dst += strlen(line);
    }
    
    return 0;
}

char *
vice_readdir (char *image)
{
    int f, res = 0, is_tape = 0, DType;
    char *basename;
    hdrinfo hdr;
    DRIVE flpy;
    DRIVE *floppy = &flpy;
    
#ifdef __MSDOS__
    basename = strrchr(image, '\\');
#else
    basename = strrchr(image, '/');
#endif
    if (!basename)
	basename = image;
    else 
	basename++;

    /* check if this is a disk-image */
    {
	int tmp;
	
#if 0
	if (is_t64name(image) < 0)
	    goto invalid_image;
#endif

    }
    else			
    {
	/* this is a valid disk header */
    }

    curr_dst = dst_base = (char *) malloc(junk * sizeof(char));
    *curr_dst = '\0';
    
    if (is_tape)
	res = do_tapedir(f);
    else
	res = do_diskdir(floppy);

    zclose (f);
    
    if (res < 0)
    {
	free(dst_base);
	return NULL;
    }
    else
    {
	petconvstring(dst_base, 1);
	return dst_base;
    }
}
#endif
