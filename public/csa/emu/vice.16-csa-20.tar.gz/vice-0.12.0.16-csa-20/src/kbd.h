/*
 * $Id: kbd.h,v 1.1 1997/05/22 21:23:02 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README file for copyright notice.
 *
 * Written by
 *   Jouko Valta        (jopi@stekt.oulu.fi)
 *   Andre Fachat       (fachat@physik.tu-chemnitz.de)
 *   Ettore Perazzoli   (ettore@comm2000.it)
 *
 * $Log: kbd.h,v $
 * Revision 1.1  1997/05/22 21:23:02  ettore
 * Initial revision
 *
 */

/* Generic header file for keyboard drivers. */

#ifndef _KBD_H
#define _KBD_H

#ifdef __MSDOS__
#include "kbd_d.h"
#else
#include "kbd_x.h"
#endif

#endif
