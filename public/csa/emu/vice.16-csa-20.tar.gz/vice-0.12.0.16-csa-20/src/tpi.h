/* $Id: tpi.h,v 1.1 1996/04/21 10:38:53 fachat Exp $ 
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README file for copyright notice.
 *
 *
 * Register definitions for the 6525 TPI Tri Port Interface
 *
 * Written by
 *   Andre Fachat (a.fachat@physik.tu-chemnitz.de)
 *
 * $Log: tpi.h,v $
 * Revision 1.1  1996/04/21 10:38:53  fachat
 * Initial revision
 * 
 */

#define	TPI_PA		0
#define	TPI_PB		1
#define	TPI_PC		2
#define	TPI_ILR		2
#define	TPI_DDPA	3
#define	TPI_DDPB	4
#define	TPI_DDPC	5
#define	TPI_MIR		5
#define	TPI_CREG	6
#define	TPI_AIR		7

