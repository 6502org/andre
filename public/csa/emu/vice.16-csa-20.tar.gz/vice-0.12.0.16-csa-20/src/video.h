#ifdef __MSDOS__
#include "video_d.h"
#else
#include "video_x.h"
#endif
