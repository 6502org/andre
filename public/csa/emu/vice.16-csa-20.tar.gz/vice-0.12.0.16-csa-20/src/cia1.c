
/*
 * cia1.c
 * This file is generated from cia-tmpl.c and cia1.h,
 * Do not edit!
 */
/*
 * $Id: cia-tmpl.c,v 1.5 1997/06/08 19:27:29 fachat Exp fachat $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * Written by
 *   Andre Fachat     (a.fachat@physik.tu-chemnitz.de)
 *
 * Fixes by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: cia-tmpl.c,v $
 * Revision 1.5  1997/06/08 19:27:29  fachat
 * started working on PB6/PB7 timer output
 *
 * Revision 1.4  1997/06/08 16:40:29  fachat
 * TA, TB and ICR now seem to be correct with the CIA test suite (CIA1TAB)
 *
 * Revision 1.3  1997/06/08 12:24:17  fachat
 * set CNT to high by default. Also timers are now loaded when timer
 * stopped and store to high byte of latch.
 *
 * Revision 1.2  1997/06/07 19:22:15  fachat
 * Skip timer alarms when already known that they do nothing...
 *
 * Revision 1.1  1997/06/07 18:40:21  fachat
 * Initial revision
 *
 */

/*
 * 03jun1997 a.fachat
 * complete timer rewrite 
 *
 * There now is a new function, update_cia1(). It computes all differences
 * from one given state to a new state at rclk. 
 * Well, not everything. For the cascade mode (timer B counting timer A)
 * as well as the shift register the interrupt function is being used.
 *
 * The update routine computes, completely independent from the 
 * interrupt stuff, the timer register values. The update routines are
 * only called when a timer register is touched.
 * int_*() is now called only _once_ per interrupt, and it is much smaller
 * than the last version. It is disabled when the interrupt flag
 * is not set (at least timer B. For timer A there must not be 
 * a shift register operation and not timer B counting timer A) 
 *
 * The timer B when counting timer A and the Shift register interrupt flags 
 * may be set a few cycles too late due to late call of int_cia1t*() due 
 * to opcode execution time. This can be fixed by checking in the beginning
 * of read_* and write_* if an int_* is scheduled and executing it before.
 * Then the setting of the ICR could also be moved from update to int_*().
 * But the bug only affects the contents of the ICR. The interrupt is 
 * generated at the right time (hopefully).
 *
 * There are two HACKS (tm) to make two different games work:
 * a) in update_cia1() a fix is done for arkanoid. This game counts 
 *    shift register bits (i.e. TA underflows) by setting TA to one-shot.
 *    The ICR is read just before the int_cia1ta() function is called, and
 *    the int bit is missed, so there is a check in update_cia1()
 *    (this is probably a fix and not a hack... :-)
 * b) Pacland doesn not really clear the interrupt flag of CIA1 TA by 
 *    reading ICR. It seems to be a timing problem, as FrodoSC runs it, 
 *    but Frodo does not. If the CIA interrupt is issued too early 
 *    it is not cleared and the video interrupts have no way through.
 *    pacland is to my knowledge the only thing that writes 0 to the ICR,
 *    so this hack clears the interrupt flags when writing 0 to it...
 *
 * Still some work has to be put into the dump functions, to really show
 * the state of the chip and not the state of the emulation. I.e. we
 * need to compute the bits described in the emulator test suite.
 */

#include <stdio.h>
#include <time.h>
#include <string.h>

#include "extern.h"
#include "vmachine.h"
#include "extern.h"
#include "cpu.h"
#include "cia.h"


	
#include "interrupt.h"

#undef CIA1_TIMER_DEBUG
#undef CIA1_IO_DEBUG

/* The following two time values correct the incorrect (but faster) clk
   increment in one piece in the CPU. It doesn't work for opcode
   fetches */
#define	STORE_OFFSET 0	/* store_cia called one cycle after actual store */
#define	READ_OFFSET 0 	/* read_cia called one cycle after actual read */

#define	CIAT_STOPPED	0
#define	CIAT_RUNNING	1
#define	CIAT_COUNTTA	2

#ifdef CIA1_TIMER_DEBUG
#define	my_set_int(a,b)						\
	do {							\
	  if(debugflg)						\
		printf("set_int(rclk=%d, int=%d, d=%d pc=%04x)\n", rclk,(a),(b),*reg_pcp); \
	  maincpu_set_irq_clk((a),(b),rclk+2);			\
	  if(b) {						\
	    force_interrupt_check(&maincpu_int_status,clk);	\
	    cia1int |= 0x80;					\
	  }							\
	} while(0)
#else
#define	my_set_int(a,b)						\
	do {							\
	  maincpu_set_irq_clk((a),(b),rclk+2);			\
	  if(b) {						\
	    force_interrupt_check(&maincpu_int_status,clk);	\
	    cia1int |= 0x80;					\
	  }							\
	} while(0)
#endif

/* global */

BYTE cia1[16];
extern BYTE keyarr[KBD_ROWS];
extern unsigned int *reg_pcp;

/* local functions */

static int update_cia1 ( CLOCK realclk );

static void check_cia1todalarm( void );

void cia1_dump(FILE *fp);

/*
 * Local variables
 */

#define	cia1ier	cia1[CIA_ICR]
static int cia1int;	/* Interrupt Flag register for cia 1 */

static CLOCK rclk;	/* real clock = clk-offset */
static CLOCK cia1rdi;	/* real clock = clk-offset */

static CLOCK 		cia1_tau;	/* when is the next underflow? */
static unsigned int 	cia1_tal;	/* latch value */
static unsigned int 	cia1_tac;	/* counter value */
static unsigned int 	cia1_tat;	/* timer A toggle bit */
static unsigned int 	cia1_tap;	/* timer A port bit */
static int		cia1_tas;	/* timer state (CIAT_*) */

static CLOCK 		cia1_tbu;	/* when is the next underflow? */
static unsigned int 	cia1_tbl;	/* latch value */
static unsigned int 	cia1_tbc;	/* counter value */
static unsigned int 	cia1_tbt;	/* timer B toggle bit */
static unsigned int 	cia1_tbp;	/* timer B port bit */
static int		cia1_tbs;	/* timer state (CIAT_*) */

static int cia1sr_bits;	/* number of bits still to send * 2 */

static BYTE cia1todalarm[4];
static BYTE cia1todlatch[4];
static char cia1todstopped;
static char cia1todlatched;
static int cia1todticks = 100000;          /* approx. a 1/10 sec. */

/* ------------------------------------------------------------------------- */
/* CIA1 */



static int update_cia1(CLOCK xclk) {
	register unsigned int tmp = 0;
	register unsigned int ista = 0;
	register BYTE sif = (cia1int & cia1ier & 0x7f);
	/* when did we virtually add an interrupt flag first */
	CLOCK added_int_clk = (cia1int & 0x80) ? xclk-3 : CLOCK_MAX;

#ifdef CIA1_TIMER_DEBUG
if(debugflg) printf("CIA1: update: xclk=%d, tas=%d, tau=%d, tal=%u, ",
				xclk, cia1_tas, cia1_tau, cia1_tal);
#endif

	if(cia1_tas == CIAT_RUNNING) {
	  if(xclk < cia1_tau) {
	    cia1_tac = cia1_tau - xclk;
	    tmp = 0;
	  } else {
	    if(cia1[CIA_CRA] & 0x08) {
	      tmp = 1;
	      if((cia1ier & CIA_IM_TA) && (cia1_tau < added_int_clk)) 
		added_int_clk = cia1_tau;
	      cia1_tau = 0;
	      maincpu_unset_alarm(A_CIA1TA);
	      cia1_tac = cia1_tal;
	      cia1_tas = CIAT_STOPPED;
	      cia1[CIA_CRA] &= 0xfe;

	      /* this is a HACK for arkanoid... */
	      if(cia1sr_bits) {
		cia1sr_bits--;
		if(!cia1sr_bits) {
		  cia1int |= CIA_IM_SDR;
		  if((cia1ier & CIA_IM_SDR) && (cia1_tau < added_int_clk))
		    added_int_clk = cia1_tau;
		}
	      }
	    } else {
	      tmp = (xclk - cia1_tau - 1) / (cia1_tal+1);
	      cia1_tau += tmp * (cia1_tal + 1);
	      if((cia1ier & CIA_IM_TA) && (cia1_tau < added_int_clk)) 
		added_int_clk = cia1_tau;
	      cia1_tau += 1 * (cia1_tal + 1);
	      cia1_tac = cia1_tau - xclk;
	    }

	    cia1int |= CIA_IM_TA;
	    if(cia1_tac == cia1_tal) ista = 1;
	  }
	}

#ifdef CIA1_TIMER_DEBUG
if(debugflg) printf("aic=%d, tac-> %u, tau-> %d\n              tmp=%u, ", added_int_clk, cia1_tac, cia1_tau,tmp);
#endif

	if(cia1[CIA_CRA] & 0x04) {
	  cia1_tap = cia1_tat;
	} else {
	  cia1_tap = cia1_tac ? 0 : 1;
	}

	cia1_tbp = 0;
	if(cia1_tbs == CIAT_RUNNING) {
	  if(xclk < cia1_tbu) {
	    cia1_tbc = cia1_tbu - xclk;
	  } else {
	    if(cia1[CIA_CRB] & 0x08) {
	      tmp = 1;
	      if((cia1ier & CIA_IM_TB) && (cia1_tbu < added_int_clk)) 
		added_int_clk = cia1_tbu;
	      cia1_tbu = 0;
	      maincpu_unset_alarm(A_CIA1TB);
	      cia1_tbc = cia1_tbl;
	      cia1_tbs = CIAT_STOPPED;
	      cia1[CIA_CRB] &= 0xfe;
	    } else {
	      tmp = (xclk - cia1_tbu - 1) / (cia1_tbl+1);
	      cia1_tbu += tmp * (cia1_tbl + 1);
	      if((cia1ier & CIA_IM_TB) && (cia1_tbu < added_int_clk)) 
	        added_int_clk = cia1_tbu;
	      cia1_tbu += 1 * (cia1_tbl + 1);
	      cia1_tbc = cia1_tbu - xclk;
	    }
	    if(!cia1_tbc) cia1_tbc = cia1_tbl;

	    cia1int |= CIA_IM_TB;
	  }
	} else 
	if(cia1_tbs == CIAT_COUNTTA) {
	  /* missing: set added_int */
	  if( (!cia1_tbc) && ista ) {
	    cia1_tbp = 1;
	    cia1_tbc = cia1_tbl;
	    cia1int |= CIA_IM_TB;
	  }
	}

	if(cia1[CIA_CRB] & 0x04) {
	  cia1_tbp ^= cia1_tbt;
	} else {
	  cia1_tbp = cia1_tbc ? 0 : 1;
	}

#ifdef CIA1_TIMER_DEBUG
if(debugflg) printf("tbc-> %u, tbu-> %d, int %02x ->", 
				cia1_tbc, cia1_tbu, cia1int);
#endif

	/* have we changed the interrupt flags? */
	if(sif != (cia1ier & cia1int & 0x7f)) {
	  /* if we do not read ICR, do standard operation */
	  if(xclk != cia1rdi) {
	    if(cia1ier & cia1int & 0x7f) {
	      /* sets bit 7 */
	      my_set_int(I_CIA1FL, IK_IRQ);
	    }
	  } else {
	    if(added_int_clk == cia1rdi) {
	      cia1int &= 0x7f;
#ifdef CIA1_TIMER_DEBUG
	      if(debugflg) 
	        printf("CIA1: TA Reading ICR at rclk=%d prevented IRQ\n",
									xclk);
#endif
	    } else {
	      if(cia1ier & cia1int & 0x7f) {
	        /* sets bit 7 */
	        my_set_int(I_CIA1FL, IK_IRQ);
	      }
	    }
	  }
	}
#ifdef CIA1_TIMER_DEBUG
if(debugflg) printf("%02x\n", cia1int);
#endif

 	/* return true sif interrupt line is set at this clock time */
	return ( !sif ) && (cia1int & cia1ier & 0x7f);
}

/* ------------------------------------------------------------------------- */

void    reset_cia1(void)
{
	int i;
	for(i=0;i<16;i++) cia1[i] = 0;

	/* FIXME: Is this actually correct? */
	cia1[CIA_TAL] = cia1[CIA_TBL] = 1;

	cia1rdi = 0;	
	cia1sr_bits = 0;
	cia1_tac = cia1_tal = 0x0;
	cia1_tbc = cia1_tbl = 0x0;
	cia1_tas = CIAT_STOPPED;
	cia1_tbs = CIAT_STOPPED;
	cia1_tat = 0;
	cia1_tbt = 0;

	maincpu_unset_alarm(A_CIA1TB);
	maincpu_unset_alarm(A_CIA1TA);

        memset(cia1todalarm, 0, sizeof(cia1todalarm));
        cia1todlatched = 0;
        cia1todstopped = 0;
        maincpu_set_alarm(A_CIA1TOD, cia1todticks);

	cia1int = 0;

}


void    store_cia1(ADDRESS addr, BYTE byte)
{
    addr &= 0xf;
       
    rclk = clk - STORE_OFFSET;

#ifdef CIA1_TIMER_DEBUG
    if(debugflg /* && (addr>=4) */ ) 
		printf("store cia1[%02x] %02x @ clk=%d, pc=%04x\n", 
				(int) addr, (int) byte, rclk, *reg_pcp);
#endif

    switch (addr) {

      case CIA_PRA: /* port A */
      case CIA_DDRA: 
	cia1[addr] = byte;
	break;
      case CIA_PRB: /* port B */
      case CIA_DDRB: 
	if( (cia1[CIA_CRA] | cia1[CIA_CRB]) & 0x02) {
	  update_cia1(rclk);
	  if(cia1[CIA_CRA] & 0x02) {
	    byte &= 0xbf;
	    if(cia1_tap) byte |= 0x40;
	  }
	  if(cia1[CIA_CRB] & 0x02) {
	    byte &= 0x7f;
	    if(cia1_tbp) byte |= 0x80;
	  }
	}
	cia1[addr] = byte;
	break;

      case CIA_TAL:
	update_cia1(rclk);
	cia1_tal = (cia1_tal & 0xff00) | byte;
	break;
      case CIA_TAH:
	update_cia1(rclk);
	cia1_tal = (cia1_tal & 0x00ff) | (byte << 8);
	if(cia1_tas == CIAT_STOPPED) cia1_tac = cia1_tal;
#ifdef CIA1_TIMER_DEBUG
	debugflg = (cia1_tac<4) ? 1 : 0;
#endif
	break;
      case CIA_TBL:
	update_cia1(rclk);
	cia1_tbl = (cia1_tbl & 0xff00) | byte;
	break;
      case CIA_TBH:
#if 0 /*def CIA1_TIMER_DEBUG*/
	debugflg = (byte==1) ? 1 : 0;
	printf("+++++++++++ store 1 to tbh ++++++++++++++++\n");
#endif
	update_cia1(rclk);
	cia1_tbl = (cia1_tbl & 0x00ff) | (byte << 8);
	if(cia1_tbs == CIAT_STOPPED) cia1_tbc = cia1_tbl;
	break;

	/*
	 * TOD clock is stopped by writing Hours, and restarted
	 * upon writing Tenths of Seconds.
	 *
	 * REAL:  TOD register + (wallclock - cia1todrel)
	 * VIRT:  TOD register + (cycles - begin)/cycles_per_sec
	 */
      case CIA_TOD_TEN: /* Time Of Day clock 1/10 s */
      case CIA_TOD_HR:  /* Time Of Day clock hour */
      case CIA_TOD_SEC: /* Time Of Day clock sec */
      case CIA_TOD_MIN: /* Time Of Day clock min */
        if(cia1[CIA_CRB] & 0x80) cia1todalarm[addr-CIA_TOD_TEN]=byte;
        else {
          if(addr == CIA_TOD_TEN) cia1todstopped = 0;
          if(addr == CIA_TOD_HR) cia1todstopped = 1;
          cia1[addr] = byte;
        }
	check_cia1todalarm();
        break;

      case CIA_SDR: /* Serial Port output buffer */
	cia1[addr] = byte;
	if( ((cia1[CIA_CRA] & 0x40)==0x40) && (cia1sr_bits < 16)) {
	  cia1sr_bits += 16;

	  /* switch timer A alarm on again, if necessary */
	  update_cia1(rclk);
	  if(cia1_tau) maincpu_set_alarm_clk(A_CIA1TA, cia1_tau);

#if defined (CIA1_TIMER_DEBUG)
	  if(debugflg) printf("CIA1: start SDR rclk=%d\n",rclk);
#endif
	}
	break;

	/* Interrupts */

      case CIA_ICR: /* Interrupt Control Register */
#if defined (CIA1_TIMER_DEBUG)
        if(debugflg) printf ("CIA1 set CIA_ICR: 0x%x\n", byte);
#endif
	update_cia1(rclk);

	if(byte & CIA_IM_SET) {
	  cia1ier |= (byte & 0x7f);
	} else {
	  cia1ier &= ~(byte & 0x7f);
	}
	/* This must actually be delayed one cycle! */
#if defined(CIA1_TIMER_DEBUG)
	if(debugflg) printf("    set icr: ifr & ier & 0x7f -> %02x, int=%02x\n",
				cia1ier & cia1int & 0x7f, cia1int);
#endif
	if(cia1ier & cia1int & 0x7f) {
	  my_set_int(I_CIA1FL, IK_IRQ);
	}
#if 0
	/* this is a bad HACK! It is against the emulator test suite. 
	   It breaks Arkanoid, but fixes agent USA... */
	else {
	  my_set_int(I_CIA1FL, 0);
	}
#endif
#if 1
	if(!byte) {
	  /* HACK for pacland */
	  cia1int = 0; 
	  my_set_int(I_CIA1FL, 0);
	}
#endif
	if(cia1ier & (CIA_IM_TA + CIA_IM_TB)) {
	  if((cia1ier & CIA_IM_TA) && cia1_tau)
	    maincpu_set_alarm_clk(A_CIA1TA, cia1_tau);
	  if((cia1ier & CIA_IM_TB) && cia1_tbu)
	    maincpu_set_alarm_clk(A_CIA1TB, cia1_tbu);
	}
	/* Control */
        break;

      case CIA_CRA: /* control register A */
	update_cia1(rclk);
#if defined (CIA1_TIMER_DEBUG)
        if(debugflg) 
	  printf ("CIA1 set CIA_CRA: 0x%x (clk=%d, pc=%04x, tal=%u, tac=%u)\n", 
			byte, rclk, program_counter, cia1_tal, cia1_tac);
#endif

	/* bit 7 tod frequency */
	/* bit 6 serial port mode */

	/* bit 4 force load */
	if (byte & 0x10) {
	  cia1_tac = cia1_tal;
	  if(cia1_tas == CIAT_RUNNING) {
	    cia1_tau = rclk + cia1_tac + 2;
	    maincpu_set_alarm_clk(A_CIA1TA, cia1_tau);
	  }
	}
	/* bit 3 timer run mode */
	/* bit 2 & 1 timer output to PB6 */

	/* bit 0 start/stop timer */
	/* bit 5 timer count mode */
	if( (byte & 1) && !(cia1[CIA_CRA] & 1) ) cia1_tat = 1;
	if( (byte ^ cia1[addr]) & 0x21) {
	  if( (byte & 0x21) == 0x01 ) {		/* timer just started */
	    cia1_tas = CIAT_RUNNING;
	    cia1_tau = rclk + (cia1_tac + 1) + 1;
	    maincpu_set_alarm_clk(A_CIA1TA, cia1_tau);
	  } else {				/* timer just stopped */
	    cia1_tas = CIAT_STOPPED;
	    cia1_tau = 0;
	    maincpu_unset_alarm(A_CIA1TA);
	  }
	}
#if defined (CIA1_TIMER_DEBUG)
	if(debugflg) printf("    -> tas=%d, tau=%d\n",cia1_tas, cia1_tau);
#endif
	cia1[addr] = byte & 0xef;	/* remove strobe */

	break;

      case CIA_CRB: /* control register B */
	update_cia1(rclk);

#if defined (CIA1_TIMER_DEBUG)
        if(debugflg) 
	  printf ("CIA1 set CIA_CRB: 0x%x (clk=%d, pc=%04x, tbl=%u, tbc=%u)\n", 
			byte, rclk, *reg_pcp, cia1_tbl, cia1_tbc);
#endif


	/* bit 7 set alarm/tod clock */
	/* bit 4 force load */
	if (byte & 0x10) {
	  cia1_tbc = cia1_tbl;
	  if(cia1_tbs == CIAT_RUNNING) {
	    cia1_tbu = rclk + cia1_tbc + 2;
#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: rclk=%d force load: set tbu alarm to %d\n",rclk,cia1_tbu);
#endif
	    maincpu_set_alarm_clk(A_CIA1TB, cia1_tbu);
	  }
	}
	/* bit 3 timer run mode */
	/* bit 2 & 1 timer output to PB6 */

	/* bit 0 stbrt/stop timer */
	/* bit 5 & 6 timer count mode */
	if( (byte & 1) && !(cia1[CIA_CRB] & 1) ) cia1_tbt = 1;
	if( (byte ^ cia1[addr]) & 0x61) {
	  if( (byte & 0x61) == 0x01 ) {		/* timer just started */
	    cia1_tbu = rclk + (cia1_tbc + 1) + 1;
#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: rclk=%d start timer: set tbu alarm to %d\n",rclk,cia1_tbu);
#endif
	    maincpu_set_alarm_clk(A_CIA1TB, cia1_tbu);
	    cia1_tbs = CIAT_RUNNING;
	  } else {				/* timer just stopped */
#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: rclk=%d stop timer: set tbu alarm\n",rclk);
#endif
	    maincpu_unset_alarm(A_CIA1TB);
	    cia1_tbu = 0;
	    /* this should actually read (byte & 0x61), but as CNT is high
	       by default, bit 0x20 is a `don't care' bit */
	    if( (byte & 0x41) == 0x41) {
	      cia1_tbs = CIAT_COUNTTA;
	      /* switch timer A alarm on if necessary */
	      if(cia1_tau) maincpu_set_alarm_clk(A_CIA1TA, cia1_tau);
	    } else {
	      cia1_tbs = CIAT_STOPPED;
	    }
	  }
	}

	cia1[addr] = byte & 0xef;	/* remove strobe */

	break;
      default:
	cia1[addr] = byte;

    }  /* switch */
}


/* ------------------------------------------------------------------------- */

BYTE    read_cia1(ADDRESS addr) {

#if defined( CIA1_TIMER_DEBUG )

	BYTE read_cia1_(ADDRESS addr);
	BYTE tmp = read_cia1_(addr);
        if(debugflg /* && ((addr&0x0f)>=4) */ ) 
	    printf("read cia1[%x] returns %02x @ clk=%d, pc=%04x\n",
				 addr, tmp, clk - READ_OFFSET, *reg_pcp);
	return tmp;
}
 
BYTE    read_cia1_(ADDRESS addr) {

#endif

    static BYTE byte;
    addr &= 0xf;
    
    rclk = clk - READ_OFFSET;


    switch (addr) {

      case CIA_PRA: /* port A */

	{
	    BYTE val = cia1[CIA_PRA] | ~cia1[CIA_DDRA];
	    BYTE msk = (cia1[CIA_PRB] | ~cia1[CIA_DDRB]) & ~joy[1];
	    int m, i;

	    /* FIXME: this is sloooow! */
	    for (m = 0x1; m <= 0x80; m <<= 1) {
		if (!(msk & m)) {
		    for (i = 0; i < KBD_ROWS; i++)
			if (keyarr[i] & m) {
			    val &= ~(1 << i);
			    break;
			}
		}
	    }
	    byte= val & ~joy[2];
	}
	return byte;
	break;

      case CIA_PRB: /* port B */

	{
	    BYTE val = ~cia1[CIA_DDRB];
	    BYTE msk = (cia1[CIA_PRA] | ~cia1[CIA_DDRA]) & ~joy[2];
	    BYTE m;
	    int i;
	    
	    for (m = 0x1, i = 0; i < KBD_ROWS; m <<= 1, i++)
		if (!(msk & m))
		    val &= ~keyarr[i];
	    byte= (val | (cia1[CIA_PRB] & cia1[CIA_DDRB])) & ~joy[1];
	}
	if( (cia1[CIA_CRA] | cia1[CIA_CRB]) & 0x02) {
	  update_cia1(rclk);
	  if(cia1[CIA_CRA] & 0x02) {
	    byte &= 0xbf;
	    if(cia1_tap) byte |= 0x40;
	  }
	  if(cia1[CIA_CRB] & 0x02) {
	    byte &= 0x7f;
	    if(cia1_tbp) byte |= 0x80;
	  }
	}
	return byte;
	break;
	/* Timers */

      case CIA_TAL: /* timer A low */
	update_cia1(rclk);
	return ((cia1_tac ? cia1_tac : cia1_tal) & 0xff);

      case CIA_TAH: /* timer A high */
	update_cia1(rclk);
	return ((cia1_tac ? cia1_tac : cia1_tal) >> 8) & 0xff;

      case CIA_TBL: /* timer B low */
	update_cia1(rclk);
	return cia1_tbc & 0xff;

      case CIA_TBH: /* timer B high */
	update_cia1(rclk);
	return (cia1_tbc >> 8) & 0xff;

	/*
	 * TOD clock is latched by reading Hours, and released
	 * upon reading Tenths of Seconds. The counter itself
	 * keeps ticking all the time.
	 * Also note that this latching is different from the input one.
	 */
      case CIA_TOD_TEN: /* Time Of Day clock 1/10 s */
      case CIA_TOD_SEC: /* Time Of Day clock sec */
      case CIA_TOD_MIN: /* Time Of Day clock min */
      case CIA_TOD_HR:  /* Time Of Day clock hour */
        if(!cia1todlatched) memcpy(cia1todlatch, cia1+CIA_TOD_TEN, sizeof(cia1todlatch));
        if(addr == CIA_TOD_TEN) cia1todlatched = 0;
        if(addr == CIA_TOD_HR) cia1todlatched = 1;
        return cia1[addr];

      case CIA_SDR: /* Serial Port Shift Register */
#if 0 /*def DEBUG*/
	cia1_dump(stdout);
	/* little hack .... */
	{ int i; printf("\nmaincpu_ints:");
	for(i=0;i<NUMOFINT;i++) {
	  printf(" %d",maincpu_int_status.pending_int[i]);
	}
	printf("\n"); }
#endif
	return (cia1[addr]);

	/* Interrupts */

      case CIA_ICR: /* Interrupt Flag Register */
	{
	    BYTE t=0;

	    cia1rdi = rclk;
	    update_cia1(rclk);
	    t = cia1int;

#ifdef DEBUG
	    if(debugflg) 
		printf("CIA1 read intfl gives cia1int=%02x -> %02x @"
		   	" PC = %04x, sr_bits=%d, clk=%d, ta=%d, tb=%d\n", 
			cia1int, t, PC, cia1sr_bits, clk, readta(), readtb());
#endif
	    cia1int = 0;
	    my_set_int(I_CIA1FL, 0);

	    return (t);
	}
    }  /* switch */

    return (cia1[addr]);
}


/* ------------------------------------------------------------------------- */

int    int_cia1ta(long offset)
{
    if(offset<0) return 0; 

    rclk = clk - offset;

#if defined(CIA1_TIMER_DEBUG)
    if(debugflg) printf("CIA1: int_cia1ta(rclk = %u, tal = %u, cra=%02x\n", 
					rclk, cia1_tal, cia1[CIA_CRA]);
#endif

    cia1_tat = (cia1_tat + 1) & 1;

    if((cia1_tas == CIAT_RUNNING) && !(cia1[CIA_CRA] & 8)) {
      /* if we do not need alarm, no PB6, no shift register, and not timer B
	 counting timer A, then we can savely skip alarms... */
      if( (cia1ier & CIA_IM_TA) 
		|| (cia1[CIA_CRA] & 0x42) 
		|| (cia1_tbs == CIAT_COUNTTA)) {
        maincpu_set_alarm_clk(A_CIA1TA, rclk + cia1_tal + 1);
      } else {
        maincpu_unset_alarm(A_CIA1TA);
      }
    } else {
#if 0
      cia1_tas = CIAT_STOPPED;
      cia1[CIA_CRA] &= 0xfe;	/* clear run flag. Correct? */
      cia1_tau = 0;
#endif
      maincpu_unset_alarm(A_CIA1TA);
    }

    if(cia1[CIA_CRA] & 0x40) {
      if(cia1sr_bits) {
#if defined(CIA1_TIMER_DEBUG)
	if(debugflg) printf("CIA1: rclk=%d SDR: timer A underflow, bits=%d\n",
							rclk, cia1sr_bits);
#endif
        if(!(--cia1sr_bits)) {
          cia1int |= CIA_IM_SDR;
        }
      }
    }

    if(cia1_tbs == CIAT_COUNTTA) {
      if( !cia1_tbc ) {
	cia1_tbc = cia1_tbl;
	cia1_tbu = rclk;
#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: timer B underflow when counting timer A occured, rclk=%d!\n", rclk);
#endif
	cia1int |= CIA_IM_TB;
        maincpu_set_alarm_clk(A_CIA1TB, rclk);
      } else {
	cia1_tbc--;
      }
    }

    /* CIA_IM_TA is not set here, as it can be set in update(), reset
       by reading the ICR and then set again here because of delayed
       calling of int() */
    if((!cia1rdi) || (cia1rdi <= rclk-1))  
    	if((cia1int | CIA_IM_TA) & cia1ier & 0x7f) 
			my_set_int(I_CIA1FL, IK_IRQ);

    return 0; 
}


/*
 * Timer B can run in 2 (4) modes
 * cia1[f] & 0x60 == 0x00   count system 02 pulses
 * cia1[f] & 0x60 == 0x40   count timer A underflows
 * cia1[f] & 0x60 == 0x20 | 0x60 count CNT pulses => counter stops
 */


int    int_cia1tb(long offset)
{

    if(offset<0) return 0;

    rclk = clk - offset;

#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: timer B int_cia1tb(rclk=%d, tbs=%d)\n",rclk, cia1_tbs);
#endif

    cia1_tbt = (cia1_tbt + 1) & 1;

    /* running and continous, then next alarm */
    if(cia1_tbs == CIAT_RUNNING) {
      if( !(cia1[CIA_CRB] & 8) ) {
#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: rclk=%d cia1tb: set tbu alarm to %d\n",rclk,rclk + cia1_tbl +1);
#endif
	/* if no interrupt flag we can safely skip alarms */
	if(cia1ier & CIA_IM_TB) {
          maincpu_set_alarm_clk(A_CIA1TB, rclk + cia1_tbl + 1);
	} else {
          maincpu_unset_alarm(A_CIA1TB);	
	}
      } else {
/*        cia1_tbs = CIAT_STOPPED;*/
/*        cia1[CIA_CRB] &= 0xfe;*/		/* clear start bit */
/*        cia1_tbu = 0;*/
#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: rclk=%d cia1tb: unset tbu alarm\n",rclk);
#endif
        maincpu_unset_alarm(A_CIA1TB);	
      }
    } else {
      if(cia1_tbs == CIAT_COUNTTA) {
        if( (cia1[CIA_CRB] & 8) ) {
	  cia1_tbs = CIAT_STOPPED;
          cia1[CIA_CRB] &= 0xfe;		/* clear start bit */
          cia1_tbu = 0;
	}
      }
      maincpu_unset_alarm(A_CIA1TB);	
#if defined(CIA1_TIMER_DEBUG)
if(debugflg) printf("CIA1: rclk=%d cia1tb: unset tbu alarm\n",rclk);
#endif
    }

    if((!cia1rdi) || (cia1rdi <= rclk-1))  
    	if((cia1int | CIA_IM_TB) & cia1ier & 0x7f) 
			my_set_int(I_CIA1FL, IK_IRQ);

    return 0; 
}

/* ------------------------------------------------------------------------- */

int int_cia1tod(long offset) {
        register int t, pm;
	
#ifdef DEBUG
if (debugflg)
  printf("CIA1: TOD timer event (1/10 sec tick), tod=%02x:%02x,%02x.%x\n",
                cia1[CIA_TOD_HR], cia1[CIA_TOD_MIN], cia1[CIA_TOD_SEC],
                cia1[CIA_TOD_TEN]);
#endif
	
        /* set up new int */
        maincpu_set_alarm(A_CIA1TOD, cia1todticks);

        if(!cia1todstopped) {
          /* inc timer */
          t = bcd2byte(cia1[CIA_TOD_TEN]);
          t++;
          cia1[CIA_TOD_TEN] = byte2bcd(t%10);
          if( t>= 10 ) {
            t = bcd2byte(cia1[CIA_TOD_SEC]);
            t++;
            cia1[CIA_TOD_SEC] = byte2bcd(t%60);
            if(t >= 60) {
              t = bcd2byte(cia1[CIA_TOD_MIN]);
              t++;
              cia1[CIA_TOD_MIN] = byte2bcd(t%60);
              if(t>= 60) {
                pm = cia1[CIA_TOD_HR] & 0x80;
                t = bcd2byte(cia1[CIA_TOD_HR]&0x1f);
                if(!t) pm ^= 0x80;      /* toggle am/pm on 0:59->1:00 hr */
                t++;
                t = t%12 | pm;
                cia1[CIA_TOD_HR] = byte2bcd(t);
              }
            }
          }
#ifdef DEBUG
if (debugflg)
  printf("CIA1: TOD after event :tod=%02x:%02x,%02x.%x\n",
                cia1[CIA_TOD_HR], cia1[CIA_TOD_MIN], cia1[CIA_TOD_SEC],
                cia1[CIA_TOD_TEN]);
#endif
          /* check alarm */
	  check_cia1todalarm();
        }
        return 0;
}

static void check_cia1todalarm(void) {
          if(!memcmp(cia1todalarm, cia1+CIA_TOD_TEN, sizeof(cia1todalarm))) {
            cia1int |= CIA_IM_TOD;
            if(cia1[CIA_ICR] & CIA_IM_TOD) {
	      my_set_int(I_CIA1TOD, IK_IRQ);
	    }
          }
}

/* -------------------------------------------------------------------------- */


void cia1_prevent_clk_overflow()
{
    update_cia1(clk);

    rclk -= PREVENT_CLK_OVERFLOW_SUB;
    if(cia1_tau) cia1_tau -= PREVENT_CLK_OVERFLOW_SUB;
    if(cia1_tbu) cia1_tbu -= PREVENT_CLK_OVERFLOW_SUB; 
    if(cia1rdi > PREVENT_CLK_OVERFLOW_SUB) 
		cia1rdi -= PREVENT_CLK_OVERFLOW_SUB; 
    else
		cia1rdi = 0;
}

#if 1

void cia1_dump(FILE *fp) {

	update_cia1(clk);
	fprintf(fp, "[CIA1]\n");
	fprintf(fp, "PA %d %d\n", cia1[CIA_PRA], cia1[CIA_DDRA]);
	fprintf(fp, "PB %d %d\n", cia1[CIA_PRB], cia1[CIA_DDRB]);
	fprintf(fp, "TA %u %u %d [$%02x = ", cia1_tac, cia1_tal, 
					cia1[CIA_CRA], cia1[CIA_CRA]);
	fprintf(fp, "%s%s%s%s%s]\n", 
		(cia1[CIA_CRA] & 1) ? "running " : "stopped ",
		(cia1[CIA_CRA] & 8) ? "one-shot " : "continous ",
		(cia1[CIA_CRA] & 16) ? "force-load " : "",
		(cia1[CIA_CRA] & 32) ? "cnt " : "phi2 ",
		(cia1[CIA_CRA] & 64) ? "sr_out " : "sr_in " );
		
	fprintf(fp, "TB %u %u %d [$%02x = ", cia1_tbc, cia1_tbl, 
					cia1[CIA_CRB], cia1[CIA_CRB]);
	fprintf(fp, "%s%s%s%s]\n", 
		(cia1[CIA_CRB] & 1) ? "running " : "stopped ",
		(cia1[CIA_CRB] & 8) ? "one-shot " : "continous ",
		(cia1[CIA_CRB] & 16) ? "force-load " : "",
		(cia1[CIA_CRB] & 32)   
			? ((cia1[CIA_CRB] & 64) ? "timerA+cnt" : "cnt ")
			: ((cia1[CIA_CRB] & 64) ? "timerA" : "phi2 ")
		);
	
	fprintf(fp, "ICR %u %u %u", cia1int, cia1ier, 
				maincpu_int_status.pending_int[I_CIA1FL]);
	fprintf(fp, " [fl= %s%s%s%s%s] ",
		(cia1int & 1) ? "TA " : "",
		(cia1int & 2) ? "TB " : "",
		(cia1int & 4) ? "Alarm " : "",
		(cia1int & 8) ? "SDR " : "",
		(cia1int & 16) ? "Flag " : "" );
	fprintf(fp, "[mask= %s%s%s%s%s]\n",
		(cia1ier & 1) ? "TA " : "",
		(cia1ier & 2) ? "TB " : "",
		(cia1ier & 4) ? "Alarm " : "",
		(cia1ier & 8) ? "SDR " : "",
		(cia1ier & 16) ? "Flag " : "" );
			
	fprintf(fp, "SR %d %d\n", cia1[CIA_SDR], cia1sr_bits);
	fprintf(fp, "TOD %d %d %d %d\n", cia1[CIA_TOD_HR],
		cia1[CIA_TOD_MIN], cia1[CIA_TOD_SEC], cia1[CIA_TOD_SEC]);

#ifdef CIA1_TIMER_DEBUG
	debugflg = (debugflg + 1) & 1;
	printf("debugflg now %d\n", debugflg);
#endif
}


void cia1_undump_line(char *s) {
	unsigned int d1, d2, d3, d4;

	if(s==strstr(s,"PA")) {
	  sscanf(s+2, "%u %u", &d1, &d2);
	  cia1[CIA_PRA] = d1; cia1[CIA_DDRA] = d2;
	  store_cia1(CIA_PRA, cia1[CIA_PRA]);
	} else
	if(s==strstr(s,"PB")) {
	  sscanf(s+2, "%u %u", &d1, &d2);
	  cia1[CIA_PRB] = d1; cia1[CIA_DDRB] = d2;
	  store_cia1(CIA_PRB, cia1[CIA_PRB]);
	} else 
	if(s==strstr(s,"TA")) {
	  sscanf(s+2, "%u %u %u", &cia1_tac, &cia1_tal, &d1);
	  cia1[CIA_CRA] = d1;
	  if((cia1[CIA_CRA] & 0x21) == 0x01) {
	    cia1_tau = clk + cia1_tac;
	    cia1_tas = CIAT_RUNNING;
	    maincpu_set_alarm_clk(A_CIA1TA, cia1_tau);
	  } else {
	    cia1_tau = 0;
	    cia1_tas = CIAT_STOPPED;
	  }
	} else 
	if(s==strstr(s,"TB")) {
	  sscanf(s+2, "%u %u %u", &cia1_tbc, &cia1_tbl, &d1);
	  cia1[CIA_CRB] = d1;
	  if((cia1[CIA_CRB] & 0x61) == 0x01) {
	    cia1_tbu = clk + cia1_tbc;
	    cia1_tbs = CIAT_RUNNING;
	    maincpu_set_alarm_clk(A_CIA1TB, cia1_tbu);
	  } else {
	    cia1_tbu = 0;
	    if((cia1[CIA_CRB] & 0x61) == 0x41) {
	      cia1_tbs = CIAT_COUNTTA;
	    } else {
	      cia1_tbs = CIAT_STOPPED;
	    }
	  }
	} else 
	if(s==strstr(s,"ICR")) {
	  sscanf(s+3, "%d %d", &d1, &d2);
	  cia1int = d1; cia1ier = d2;
	  if(cia1int & cia1ier & 0x7f) {
	    my_set_int(I_CIA1FL, IK_IRQ);
	  } else {
	    my_set_int(I_CIA1FL, 0);
	  }
	} else
	if(s==strstr(s,"SR")) {
	  sscanf(s+2, "%d %d", &d1, &cia1sr_bits);
	  cia1[CIA_SDR] = d1;
	} else
	if(s==strstr(s,"TOD")) {
	  sscanf(s+3, "%u %u %u %u", &d1, &d2, &d3, &d4);
	  cia1[CIA_TOD_HR] = d1; cia1[CIA_TOD_MIN] = d2;
	  cia1[CIA_TOD_SEC] = d3; cia1[CIA_TOD_TEN] = d4;
	} else {
	  printf("unknown dump format line for CIA1: \n%s\n",s);
	}
}

#endif



int     show_keyarr(void)
{
    int     i, j;
    for (j = 0; j < KBD_ROWS; j++) {
	printf("%d:", j);
	for (i = 0x80; i; i >>= 1)
	    printf(" %d", keyarr[j] & i);
	printf("\n");
    }
    return (0);
}



