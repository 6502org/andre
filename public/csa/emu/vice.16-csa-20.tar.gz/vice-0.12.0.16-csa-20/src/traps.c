/*
 * $Id: traps.c,v 1.8 1997/05/22 21:01:41 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 *
 * Written by
 *   Teemu Rantanen (tvr@cs.hut.fi)
 *   Jarkko Sonninen (sonninen@lut.fi)
 *
 * $Log: traps.c,v $
 * Revision 1.8  1997/05/22 21:01:41  ettore
 * Adapted to the new CPU emulation.
 *
 * Revision 1.7  1997/02/25 15:57:07  ettore
 * remove_trap() fixed.
 * trap_handler() checks PC instead of PC - 2.
 *
 * Revision 1.6  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * Prototypes.
 *
 * Revision 1.5  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:39:40  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 *
 */

/*
 * traps.c -- This file implements ROM traps that makes possible to replace
 *            some ROM code with C-language functions.
 */

#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

#include "cpu.h"
#include "maincpu.h"
#include "macro.h"
#include "extern.h"
#include "memory.h"
#include "interrupt.h"

#undef DEBUG

typedef struct _traplist_t {
    struct _traplist_t *next;
    trap_t *trap;
} traplist_t;

static traplist_t *traplist;

#ifdef IDLE_TRAP
static void trap_idle_E5D4();

static trap_t idle_trap =
{
    "Idle trap",
    0xE5D4,
    {0xF0, 0xF7, 0x78},
    trap_idle_E5D4,
};
#endif

void    initialize_traps()
{
    traplist = NULL;

#ifdef IDLE_TRAP
    set_trap(&idle_trap);
#endif
}


int     set_trap(trap_t *t)
{
    int     i;
    traplist_t *p;

#ifdef DEBUG
    printf("setting up trap %s at 0x%x\n", t -> name, t -> address);
#endif

    for (i = 0; i < 3; i++) {
	if (load_rom(t -> address + i) != t -> check[i]) {
	    printf("incorrect checkbyte for trap %s. not installed\n",
		t -> name);
	    return 1;
	}
    }

    /*
     * BRK (0x00) is trap-opcode
     */
    save_rom(t -> address, 0x00);
    
    p = (traplist_t *) malloc (sizeof (traplist_t));
    p->next = traplist;
    p->trap = t;
    traplist = p;

    return 0;
}


int     remove_trap(trap_t *t)
{
    traplist_t *p = traplist, *prev = NULL;


#ifdef DEBUG
    printf("removing trap %s at 0x%x\n", t -> name, t -> address);
#endif

    if (load_rom(t -> address) != 0x00)
	printf("incorrect checkbyte for trap %s.\n", t -> name);

    save_rom(t -> address, t->check[0]);
    
    
    while (p) {
	if (p -> trap -> address == t -> address)
	    break;
	prev = p;
	p = p -> next;
    }
    
    if (!p) {
	printf("cannot remove trap %s.\n", t -> name);
	return -1;
    }

    if (prev)
	prev -> next = p -> next;
    else
	traplist = p -> next;

    free ((char *)p);
    return 0;
}

int     trap_handler(void)
{
    traplist_t *p = traplist;
    
    while (p) {
	if (p -> trap -> address == PC) {
	    (*p -> trap -> func) ();
	    return 0;
	}
	p = p -> next;
    }

    return 1;
}



#ifdef IDLE_TRAP
static void trap_idle_E5D4()
{
    if (!IF_ZERO())
    {
	PC = 0xe5d6;
	clk += 2;
    }
    else {
	clk = next_alarm_clk(&maincpu_int_status);
	if (LOAD(0xc6))
	    PC = 0xe5cd;
    }
}

#endif  /* IDLE_TRAP */
