/*
 * $Id: op.c,v 1.12 1997/05/22 20:32:16 ettore Exp $
 *
 * This file is part of VICE, the versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file contains 6502 machine language instructions.
 * Undocumented features are emulated as close as reasonable.
 * Anyway, all reports on deviations in operation are welcome.
 *
 *
 * Written by
 *   Vesa-Matti Puro (vmp@lut.fi)
 *   Jarkko Sonninen (sonninen@lut.fi)
 *   Jouko Valta     (jopi@stekt.oulu.fi)
 *
 * Patch by
 *   Marko Makela (msmakela@hylk.helsinki.fi)
 *   James Fidell (jfid@micro-focus-ltd.co.uk)  /JF/
 *   Ettore Perazzoli (ettore@comm2000.it)      /EP/
 *
 *
 * $Log: op.c,v $
 * Revision 1.12  1997/05/22 20:32:16  ettore
 * Usage of `intr()' removed (not supported anymore).
 *
 * Revision 1.11  1996/12/10 23:50:56  ettore
 * BRK and ANC problems fixed.
 *
 * Revision 1.10  1996/07/30 08:36:27  ettore
 * Better Decimal Mode.
 * ANC is emulated with a separate u_anc() function.
 *
 * Revision 1.9  1996/04/01 09:01:41  jopi
 * Decimal mode on SBC corrected
 *
 * Revision 1.8  1995/11/07  16:51:00  jopi
 * traceflag
 *
 * Revision 1.7  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * Bug in interrupt vs. RTI fixed.
 * Some inconsistency removed.
 *
 * Revision 1.6  1994/12/12  16:59:44  jopi
 * 16-bit portability
 *
 * Revision 1.5  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:38:52  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 *
 */

#include <stdio.h>

#include "cpu.h"
#include "macro.h"
#include "vmachine.h"
#include "extern.h"
#include "op.h"
#include "interrupt.h"


unsigned int temp;

unsigned int setf(unsigned int src)
{
    return (1);
}


unsigned int clrf(unsigned int src)
{
    return (0);
}


unsigned int load_reg(unsigned int src)
{
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int store(unsigned int src)
{
    return (src);
}


unsigned int nop(unsigned int src)
{
    return (src);
}


/* Logic */

unsigned int ora(unsigned int src)
{
    src |= AC;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int and(unsigned int src)
{
    src &= AC;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int eor(unsigned int src)
{
    src ^= AC;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src & 0xff);
}


unsigned int asl(unsigned int src)
{
    SET_CARRY(src & 0x80);
    src <<= 1;
    src &= 0xff;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int lsr(unsigned int src)
{
    SET_CARRY(src & 0x01);
    src >>= 1;

    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int rol(unsigned int src)
{
    src <<= 1;
    if (IF_CARRY())
	src |= 0x1;
    SET_CARRY(src > 0xff);
    src &= 0xff;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int ror(unsigned int src)
{
    if (IF_CARRY())
	src |= 0x100;
    SET_CARRY(src & 0x01);
    src >>= 1;

    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int inc(unsigned int src)
{
    src = (src + 1) & 0xff;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int dec(unsigned int src)
{
    src = (src - 1) & 0xff;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int adc(unsigned int src)
{
    temp = src + AC + (IF_CARRY() ? 1 : 0);

    SET_ZERO(temp & 0xff);	/* This is not valid in decimal mode */

    /*
     * In decimal mode this is "correct" but not exact emulation. However,
     * the probability of different result when using undefined BCD codes is
     * less than 6%
     * Sign and Overflow are set between BCD fixup of the two digits  -MSM
     */

    if (IF_DECIMAL()) {
        if (((AC & 0xf) + (src & 0xf) + (IF_CARRY() ? 1 : 0)) > 9)
            temp += 6;

	SET_SIGN(temp);
	SET_OVERFLOW(!((AC ^ src) & 0x80) && ((AC ^ temp) & 0x80));

	if (temp > 0x99)
	    temp += 96;

	SET_CARRY(temp > 0x99);
    } else {
	SET_SIGN(temp);
	SET_OVERFLOW(!((AC ^ src) & 0x80) && ((AC ^ temp) & 0x80));
	SET_CARRY(temp > 0xff);
    }
    return ((BYTE) temp);
}
 

unsigned int sbc(unsigned int src)
{
    /*
     * SBC is not exact either. It has 6% different results too.
     */

    src ^= 0xff;
    temp = AC + src + (IF_CARRY() ? 1 : 0);

    SET_SIGN(temp);
    SET_ZERO(temp & 0xff);	/* Sign and Zero are invalid in decimal mode */

    SET_OVERFLOW(((AC ^ temp) & 0x80) && ((AC ^ src) & 0x80));

    if (IF_DECIMAL()) {
#if 0
	if ( ((AC & 0xf) - (IF_CARRY() ? 0 : 1)) < (src & 0xf))	/* EP */
#endif
	if ((temp & 0xf) > 0x9)
	    temp -= 6;
	if ((temp & 0xf0) > 0x90)
	    temp -= 0x60;
    }
    SET_CARRY(temp >= 0x100);
    return (temp & 0xff);
}


/* Test */

unsigned int cmp(unsigned int src)
{
    src = AC - src;
    SET_CARRY(src < 0x100);
    SET_SIGN(src);
    SET_ZERO(src &= 0xff);
    return (src);
}


unsigned int cpx(unsigned int src)
{
    src = XR - src;
    SET_CARRY(src < 0x100);
    SET_SIGN(src);
    SET_ZERO(src &= 0xff);
    return (src);
}


unsigned int cpy(unsigned int src)
{
    src = YR - src;
    SET_CARRY(src < 0x100);
    SET_SIGN(src);
    SET_ZERO(src &= 0xff);
    return (src);
}


unsigned int bit(unsigned int src)
{
    SET_SIGN(src);
    SET_OVERFLOW(0x40 & src);	/* Copy bit 6 to OVERFLOW flag. */
    SET_ZERO(src & AC);
    return (src);
}


/* BRANCH instructions. */

unsigned int bcc(unsigned int src)
{	       /* Branch if carry flag is clear. */
    if (!IF_CARRY()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


unsigned int bcs(unsigned int src)
{	       /* Branch if carry flag is set. */
    if (IF_CARRY()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


unsigned int bne(unsigned int src)
{	       /* Branch if  zero flag is clear. */
    if (!IF_ZERO()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


unsigned int beq(unsigned int src)
{	       /* Branch if  zero flag is set. */
    if (IF_ZERO()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


unsigned int bpl(unsigned int src)
{	       /* Branch if sign flag is clear. */
    if (!IF_SIGN()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


unsigned int bmi(unsigned int src)
{	       /* Branch if sign flag is set. */
    if (IF_SIGN()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


unsigned int bvc(unsigned int src)
{	       /* Branch if overflow flag is clear. */
    if (!IF_OVERFLOW()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


unsigned int bvs(unsigned int src)
{	       /* Branch if overflow flag is set. */
    if (IF_OVERFLOW()) {
	clk += ((PC & 0xFF00) != (REL_ADDR(PC, src) & 0xFF00) ? 2 : 1);
	PC = REL_ADDR(PC, src);
    }
    return (src);
}


/* Stack */

unsigned int push(unsigned int src)
{
    PUSH(src);
    /* First push item onto stack and then decrement SP. */
    return (src);
}


unsigned int pull(unsigned int src)
{
    /* First increment stack pointer and then pull item from stack. */
    src = PULL();
    SET_SIGN(src);	/* Change sign and zero flag accordingly. */
    SET_ZERO(src);
    return (src);
}


unsigned int plp(unsigned int src)
{
    /* First increment stack pointer and then pull item from stack. */
    src = PULL();
    return (src);
}


unsigned int jsr(unsigned int src)
{	       /* Jump to subroutine. */
    PC--;
    PUSH((PC >> 8) & 0xff);	/* Push return address onto the stack. */
    PUSH(PC & 0xff);

#ifdef DEBUG
    if (traceflg)
	print_stack(SP);
#endif

    return (src);
}


unsigned int rts(unsigned int src)
{	       /* Return from subroutine. */
    src = PULL();
    src += ((PULL()) << 8) + 1;	/* Load return address from stack and add 1. */

#ifdef DEBUG
    if (traceflg)
	print_stack(SP);
#endif

    return (src);
}


unsigned int rti(unsigned int src)
{	       /* Return from interrupt. */
    /* Load program status and program counter from stack. */
    src = PULL();
    SET_SR(src);
    src = PULL();
    src |= (PULL() << 8);	/* Load return address from stack. */

#ifdef DEBUG
    if (traceflg)
	print_stack(SP);
#endif

    return (src);
}


unsigned int brki(unsigned int src)
{	       /* Force break. */

    PC++;
#ifdef DEBUG
    if (verflg) {
	printf("BRK %ld\n", clk);
	show();
    }
#endif

    if (runflg) {
	PC-=2;
	printf("BRK\n");
	mon(PC);
	return (PC);
    }

#if 0
    if (trap_handler())
      intr(I_BRK, PC);
#endif
    
    return (PC);
}


unsigned int noop(unsigned int src)
{	       /* No such opcode. */
    (void) printf("Illegal instruction.\n");
    verflg = 1;
    --PC;
    show();
    mon(PC);
    return (PC);
}


#ifndef NO_UNDOC_CMDS
/*
 * MOS 6510 undocumented commands
 * If you are emulating the 8502, be careful with these since it may get
 * the xxxxxx10's in undocumented codes the other way around.
 *
 * These functions emulate a 6510 (manuf. week 5183) and 8502 R0 (week 4685).
 * However, your CPU may have them differently.
 *
 * BTW: I used 68000 based 80286 emulator to run this editor.
 */

unsigned int u_rlan(unsigned int src)
{
    /* src = rol(src); AC = and(src); */

#ifdef DEBUG_UNDOC
    puts ("RLAN -- PC is now $%04X\n", PC);
#endif
  
    src <<= 1;
    if (IF_CARRY())	/* ROL+AND */
	src |= 0x1;
    SET_CARRY(src > 0xff);
    src &= 0xff;

    AC &= src;
    SET_SIGN(AC);
    SET_ZERO(AC);
    return (src);	/* rotated, not disturbed */
}


unsigned int u_rrad(unsigned int src)
{
    /* src = ror(src); AC = adc(src);
     * the real operation discovered by msmakela
     * ADC only does the BCD fixup */

#ifdef DEBUG_UNDOC
    puts ("RRAD -- PC is now $%04X\n", PC);
#endif

    temp = src >>1;	/* ROR+ADC */
    if (IF_CARRY())
	temp |= 0x80;

    SET_SIGN(temp);
    SET_ZERO(temp);			/* Set flags like ROR does */

    SET_OVERFLOW((temp ^ src) & 0x40);	/* ROR causes this ? */

    if (IF_DECIMAL()) {
        if ((src & 0x0f) > 4)		/* half of the normal */
            temp = (temp & 0xf0) | ((temp + 6) & 0xf);
        if (src > 0x4f)
            temp += 96;

	SET_CARRY(src > 0x4f);
    } else {
	SET_CARRY(src & 0x80);		/* 8502 behaviour */
    }

    return ((BYTE) temp);
}


unsigned int u_slor(unsigned int src)
{
    /* src = asl(src); AC = ora(src); */

#ifdef DEBUG_UNDOC
    puts ("SLOR -- PC is now $%04X\n", PC);
#endif

    SET_CARRY(src & 0x80);	/* ASL+ORA */
    src <<= 1;
    src |= AC;
    src &= 0xff;
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int u_sreo(unsigned int src)
{
    /* src = lsr(src); AC = eor(src); */

#ifdef DEBUG_UNDOC
    puts ("SREO -- PC is now $%04X\n", PC);
#endif

    SET_CARRY(src & 0x01);	/* LSR+EOR */
    src >>= 1;
    src &= 0xff;

    AC ^= src;		/* JF */
    SET_SIGN(src);
    SET_ZERO(src);

    return (src);
}


unsigned int u_decp(unsigned int src)
{
    /* cmp(--src & 0xff)); return (src); */

#ifdef DEBUG_UNDOC
    puts ("DECP -- PC is now $%04X\n", PC);
#endif

    src = (src - 1) & 0xff;	/* DEC+CMP */
    SET_CARRY(AC >= src);
    SET_SIGN(AC - src);
    SET_ZERO(AC != src);
    return (src);
}


unsigned int u_isbc(unsigned int src)
{
    /* src = ++src & 0xff; AC = sbc(src); */

#ifdef DEBUG_UNDOC
    puts ("ISBC -- PC is now $%04X\n", PC);
#endif

    src = ((src + 1) & 0xff);	/* INC+SBC */

    temp = AC - src - (IF_CARRY() ? 0 : 1);

    SET_SIGN(temp);
    SET_ZERO(temp & 0xff);	/* Sign and Zero are invalid in decimal mode */

    SET_OVERFLOW(((AC ^ temp) & 0x80) && ((AC ^ src) & 0x80));

    if (IF_DECIMAL()) {
	if ( ((AC & 0xf) - (IF_CARRY() ? 0 : 1)) < (src & 0xf))	/* EP */
	    temp -= 6;
	if (temp > 0x99)
	    temp -= 0x60;
    }
    SET_CARRY(temp < 0x100);

    AC = temp;
    return (src);	/* src saved */
}


unsigned int u_sbx(unsigned int src)
{
#ifdef DEBUG_UNDOC
    puts ("SBX -- PC is now $%04X\n", PC);
#endif

    src = (AC & XR) - src;	/* Carry is ignored (CMP) */
    /* Overflow flag may be affected */
    SET_CARRY(src < 0x100);

    src &= 0xff;	/* No decimal mode */
    SET_SIGN(src);
    SET_ZERO(src);
    return (src);
}


unsigned int u_anc(unsigned int src)
{
#ifdef DEBUG_UNDOC
    puts ("ANC -- PC is now $%04X\n", PC);
#endif

    src &= AC;
    SET_ZERO(src);
    SET_SIGN(src);
    SET_CARRY (IF_SIGN());
    return (src);
}

#endif  /* undoc */
