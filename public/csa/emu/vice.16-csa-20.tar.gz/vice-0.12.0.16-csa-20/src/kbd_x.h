/*
 * $Id: kbd_x.h,v 1.1 1997/05/22 21:20:34 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README file for copyright notice.
 *
 * Written by
 *   Jouko Valta        (jopi@stekt.oulu.fi)
 *   Andre Fachat       (fachat@physik.tu-chemnitz.de)
 *   Ettore Perazzoli   (ettore@comm2000.it)
 *
 * $Log: kbd_x.h,v $
 * Revision 1.1  1997/05/22 21:20:34  ettore
 * Initial revision
 *
 */

/* X11 keyboard driver. */

#ifndef _KBD_X_H
#define _KBD_X_H

#include <X11/Intrinsic.h>

extern void kbd_init(void);
extern void kbd_event_handler(Widget w, XtPointer client_data, XEvent *report,
			      Boolean *ctd);

#endif
