/*
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 */

/* Global VICE release version. */
#define VERSION		"0.12.0.16"

/* Petcat version. */
#define PETCATVERSION	2.02
#define PETCATLEVEL	1

/* Petlp version. */
#define PETLPVERSION	1.00
#define PETLPLEVEL	0
