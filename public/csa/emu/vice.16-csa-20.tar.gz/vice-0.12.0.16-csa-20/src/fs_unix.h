/*
 * $Id: fs_unix.h,v 1.3 1995/04/01 07:54:09 jopi Exp $
 *
 * This file is part of Commodore 64 emulator.
 * See README for copyright notice
 *
 * Definitions for native mode disk drive emulation.
 *
 * Written by
 *   Teemu Rantanen (tvr@cs.hut.fi)
 *   Dan Miner (dminer@nyx10.cs.du.edu)
 *
 * $Log: fs_unix.h,v $
 * Revision 1.3  1995/04/01 07:54:09  jopi
 * X64 0.3 PL 0
 * Prototypes.
 *
 * Revision 1.2  1994/12/12  16:59:44  jopi
 * *** empty log message ***
 *
 * Revision 1.1  1994/08/10  17:46:41  jopi
 * Initial revision
 *
 *
 *
 */

#ifndef X64_FS_UNIX_H
#define X64_FS_UNIX_H


#ifdef sco
#define MAXPATHLEN PATHSIZE
#include <sys/ndir.h>
#else
#ifndef GEMDOS
#include <dirent.h>
#endif
#endif

#if (defined(CRAY) || defined(SYSV))  /* Solaris */
#define d_namlen d_reclen
#endif

#ifdef CRAY
#define MAXPATHLEN PATH_MAX
#endif


#endif  /* X64_FS_UNIX_H */
