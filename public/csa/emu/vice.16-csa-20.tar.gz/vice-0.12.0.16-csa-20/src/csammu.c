
/*
 *
 * $Log$
 *
 *
 * This is the handling of the CSA MMU chip.
 *
 * It consists of 16 eight bit registers, each of which holds the
 * upper 8 bits of the physical address for one of the 16 4k pages
 * in CPU address space
 *
 */

#include <stdio.h>
#include <memory.h>

#include "vice.h"
#include "memory.h"

#undef	DEBUG

extern BYTE ram[];
extern BYTE rom[];
extern BYTE openaddress[];

/*
 * Some constants be better defined here
 *
 * The IO area must be contained in _one_ MMU page, and
 * it must be located at the end of this page (see set_mapping())
 */

#define	BLKSIZ	0x1000		/* the size of one MMU-mapped page */
#define	IOADDR	0xe800		/* address of I/O in CPU address space */
#define	IOSIZE	0x800		/* size of I/O space */
				/* MMU page where I/O is in */
#define	IOPAGE	((IOADDR >> 12) & 0x0f)

/*
 * static variables 
 */

/* the MMU register values */
static BYTE mmu[16];

/* MMU mode: 0 = map mode, 1 = pass-through mode */
static int pass_through = 1;

/* here go stray writes to write-protected pages...*/
static BYTE nowrite[0x1000];


/* 
 * physbase_*() returns the emulator-internal address for the first
 * byte of the 6502 physical page whose upper 8 bit (of 20) are
 * given as parameter.
 * We need one for writing and one for reading, of course.
 * 
 * This is the function that know about the actual mapping.
 *
 * In case of no mapping, it should return 0 and the caller should replace
 * it with openaddress + register_no * 0x100, but we do this mapping here
 * for checking.
 *
 * both must always return a non-zero pointer value.
 */
static BYTE *physbase_r(int addr) {
/*printf("physbase_r: addr=%d, ram=%p, rom=%p\n",addr,ram,rom);*/
	addr &= 0xff;
	if(addr<8) return &ram[addr * 0x1000];
	if(addr<16) return &rom[(addr-8) * 0x1000];
	if(addr<32) return &ram[(addr-8) * 0x1000];
	return &openaddress [addr * 0x100];
}

static BYTE *physbase_w(BYTE addr) {
	addr &= 0xff;
	if(addr<8) return &ram[addr * 0x1000];
	if(addr<16) return nowrite;
	if(addr<32) return &ram[(addr-8) * 0x1000];
	return nowrite;
}

/*
 * set mapping sets one page of memory hooks
 * parameter are the page (0-15), the (6502) physical address page
 * (i.e. the upper 8 address bits, A12-A19) to map to, and a read-only 
 * flag, but read-only is not yet implemented here.
 * (a newer CPU-board version can map pages read-only :-))
 *
 * This functions only calls physbase, which does the 'mapping'
 * (i.e. knows which page is RAM and which is ROM etc).
 * and only sets memory_tabs_*[] accordingly.
 * 
 */

static void set_mapping(int page, int phys, int ro) {
	int i;
	BYTE **p, *q; 

	p = &blktab_r[(page * BLKSIZ)>>BLKSHIFT];
	q = physbase_r(phys);
	if(!page) { pagezero = q; pageone = q+0x100; }
	/* check I/O space */
	i = (page==IOPAGE) ? (BLKSIZ-IOSIZE-1) >> BLKSHIFT 
						: (BLKSIZ-1) >> BLKSHIFT;
	do {
	  *(p++) = q;
	  q+= (1<<BLKSHIFT);
	} while(i--);

	p = &blktab_w[(page * BLKSIZ)>>BLKSHIFT];
	q = physbase_w(phys);
	/* check I/O space */
	i = (page==IOPAGE) ? (BLKSIZ-IOSIZE-1) >> BLKSHIFT 
						: (BLKSIZ-1) >> BLKSHIFT;
	do {
	  *(p++) = q;
	  q+= (1<<BLKSHIFT);
	} while(i--);
#ifdef DEBUG
printf("set_mapping(page=%d, phys=%d)\n",page,phys);
#endif

	if(page==IOPAGE) {
/*
printf("page=%d, clr %p[%d], %p[%d]\n",
		page, &blktab_r[IOADDR], IOSIZE*sizeof(BYTE*),
		&blktab_w[IOADDR], IOSIZE*sizeof(BYTE*));
*/
	  /* use hooks for I/O space */
	  memset(&blktab_r[IOADDR>>BLKSHIFT], 0, 
				(IOSIZE>>BLKSHIFT) * sizeof(BYTE*));
	  memset(&blktab_w[IOADDR>>BLKSHIFT], 0, 
				(IOSIZE>>BLKSHIFT) * sizeof(BYTE*));
	} 
}

/* 
 * The functions below only call set_mapping(), and don't use any 
 * memory hooks.
 */

/*
 * RESET sets the MMU to a through-state, i.e. the upper 4 physical
 * address bits are set to 0, while the 4 CPU address bits, which 
 * are normally used to select the register, are passed as the lower
 * 4 physical address bits. 
 * Upon the first write to a MMU register, the pass-through mode is
 * replaced by real mapping.
 * 
 * The MMU registers are not changed during reset.
 */
extern void reset_csammu( void ) {
	int i;

	pass_through = 1;

	for(i=0;i<16;i++) {

/* This is bug, actually. We just hope that noone - except my PET3032 
 * emulator - needs this ROM page before writing some values to the MMU...
 * for the PET emulator, we map some video RAM here */
if(i==8) set_mapping(i, 0x10,0); else

	  set_mapping(i, i, 0);
	}
	set_mapping(16, mmu[0], 0);
}

/*
 * sets a new register value for an MMU register. If pass-through mode is
 * enabled, it is switched to map mode
 */
extern void store_csammu( ADDRESS addr, BYTE byte ) {
	int i;

	addr &= 0x0f;

	/* map mode and page not changed -> return */
	if((!pass_through) && (mmu[addr] == byte)) return;

	mmu[addr] = byte;

	if(pass_through) {
	  pass_through = 0;

	  for(i=0;i<16;i++) {
	    set_mapping(i, mmu[i], 0);
	  }
	  set_mapping(16, mmu[0], 0);
	} else {
	  set_mapping(addr, byte, 0);
	  if(!addr) set_mapping(16, mmu[0], 0);
	}
}

/*
 * returns MMU register value 
 */
extern BYTE read_csammu( ADDRESS addr ) { return mmu[addr & 0x0f]; }



