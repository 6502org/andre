/* Define to your X11 display depth. */
#undef X_DISPLAY_DEPTH

/* Define if you want to use Rober W. McMullen's TextField widget. */
#undef ENABLE_TEXTFIELD

/* The number of bytes in an unsigned long. */
#undef SIZEOF_UNSIGNED_LONG

/* The number of bytes in an unsigned int. */
#undef SIZEOF_UNSIGNED_INT

/* The number of bytes in an unsigned short. */
#undef SIZEOF_UNSIGNED_SHORT
