
/*
 * This is the RS232 emulation. 
 *
 * Written by A. Fachat
 *
 * The RS232 emulation captures the bytes sent to the RS232 interfaces
 * available (currently only ACIA 6551, later UART 16550A, std C64, 
 * and Daniel Dallmanns fast RS232 with 9600 Baud). 
 * The characters captured are displayed in a special terminal window.
 * Characters typed in the terminal window are sent back to the 
 * chip emulations. 
 *
 */

#include <stdio.h>
#include "types.h"
#include "rs232.h"

#define	MAXRS232	4

typedef struct RS232 {
	int	inuse;
} RS232;

static RS232 fds[MAXRS232];

/* initializes all RS232 stuff */
void rs232_reset(void) {
	int i;

	for(i=0;i<MAXRS232;i++) {
	  fds[i].inuse = 0;
	}
}


/* opens a rs232 window, returns handle to give to functions below. */
int rs232_open(void) {
	int i;

	for(i=0;i<MAXRS232;i++) {
	  if(!fds[i].inuse) break;
	}
	if(i>=MAXRS232) return -1;

	fds[i].inuse = 1;

	return i;
}

/* closes the rs232 window again */
void rs232_close(int fd) {

	if(fd<0 || fd>=MAXRS232) {
	  printf("RS232: close with invalid fd %d!\n", fd);
	  return;
	}

	if(!fds[fd].inuse) {
	  printf("RS232: close with non-open fd %d!\n", fd);
	  return;
	} 

	fds[fd].inuse = 0;
}
 
/* sends a byte to the RS232 line */
int rs232_putc(int fd, BYTE b) {

	if(fd<0 || fd>=MAXRS232 || !fds[fd].inuse) {
	  printf("RS232: putc with invalid or non-open fd %d!\n", fd);
	  return -1;
	}

	/* for the beginning... */
	printf("%c",b);	
	return 0;
}

/* gets a byte to the RS232 line, returns !=1 if byte received, byte in *b. */
int rs232_getc(int fd, BYTE *b) {

	if(fd<0 || fd>=MAXRS232 || !fds[fd].inuse) {
	  printf("RS232: getc with invalid or non-open fd %d!\n", fd);
	  return 0;
	}

	return 0;
}


