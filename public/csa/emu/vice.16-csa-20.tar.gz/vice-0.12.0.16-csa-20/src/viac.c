
/*
 * viac.c
 * This file is generated from via-tmpl.c and viac.h,
 * Do not edit!
 */
/*
 * $Id: via-tmpl.c,v 1.1 1997/05/22 21:03:18 fachat Exp ettore $
 *
 * This file is part of VICE, the versatile Commodore 
 * Emulator. See README for copyright notice
 *
 * Written by
 *   Andre Fachat (a.fachat@physik.tu-chemnitz.de)
 *
 * $Log: via-tmpl.c,v $
 * Revision 1.1  1997/05/22 21:03:18  fachat
 * Initial revision
 *
 */

/* 
 * 24jan97 a.fachat
 * new interrupt handling, hopefully according to the specs now.
 * All interrupts (note: not timer events (i.e. alarms) are put
 * into one interrupt flag, I_VIACFL.
 * if an interrupt condition changes, the function (i.e. cpp macro)
 * update_viaCirq() id called, that checks the IRQ line state.
 * This is now possible, as ettore has decoupled A_* alarm events
 * from I_* interrupts for performance reasons.
 *
 * A new function for signaling rising/falling edges on the 
 * control lines is introduced:
 *      viaC_signal(VIA_SIG_[CA1|CA2|CB1|CB2], VIA_SIG_[RISE|FALL])
 * which signals the corresponding edge to the VIA. The constants
 * are defined in via.h.
 *
 * Except for shift register and input latching everything should be ok now.
 */

#define update_viaCirq() \
        maincpu_set_irq(I_VIACFL, (viaCifr & viaCier & 0x7f) ? IK_IRQ : 0)


#include <stdio.h>
#include <time.h>

#include "vmachine.h"
#include "extern.h"
#include "via.h"


#include "parallel.h"
#include "sid.h"

#include "interrupt.h"

/*#define VIAC_TIMER_DEBUG */

/* global */

BYTE    viaC[16];
#if 0
int     viaCta_stop = 0; /* maybe 1? */
int     viaCtb_stop = 0; /* maybe 1? */
int     viaCta_interrupt = 0;
int     viaCtb_interrupt = 0;
#endif


BYTE keyarr[KBD_ROWS];

/* local functions */

static void update_viaCta ( int );
static void update_viaCtb ( int );

/*
 * Local variables
 */

static int   viaCifr;	/* Interrupt Flag register for viaC */
static int   viaCier;	/* Interrupt Enable register for viaC */

static int   viaCta;	/* value of viaC timer A at last update */
static int   viaCtb;	/* value of viaC timer B at last update */

static CLOCK viaCtau;	/* time when viaC timer A is updated */
static CLOCK viaCtbu;	/* time when viaC timer B is updated */


/* ------------------------------------------------------------------------- */
/* VIAC */



/* 
 * according to Rockwell, all internal registers are cleared, except
 * for the Timer (1 and 2, counter and latches) and the shift register.
 */ 
void    reset_viaC(void)
{
    int i;
#ifdef VIAC_TIMER_DEBUG
    if(debugflg) printf("VIAC: reset\n");
#endif
    /* clear registers */
    for(i=0;i<4;i++) viaC[i]=0;
    for(i=11;i<16;i++) viaC[i]=0;

    viaCier = 0;
    viaCifr = 0;

    /* disable vice interrupts */
#ifdef OLDIRQ
    maincpu_set_irq(I_VIACT1, 0); maincpu_unset_alarm(A_VIACT1);
    maincpu_set_irq(I_VIACT2, 0); maincpu_unset_alarm(A_VIACT2);
    maincpu_set_irq(I_VIACSR, 0);
    maincpu_set_irq(I_VIACFL, 0);
#else
    maincpu_unset_alarm(A_VIACT1);
    maincpu_unset_alarm(A_VIACT2);
    update_viaCirq();
#endif


    /* set IEC output lines */
    par_set_atn(0);
    par_set_ndac(0);
    par_set_eoi(0);

}

void viaC_signal(int line, int edge) {
        switch(line) {
        case VIA_SIG_CA1:
                viaCifr |= ((edge ^ viaC[VIA_PCR]) & 0x01) ? 
                                                        0 : VIA_IM_CA1;
                update_viaCirq();
                break;
        case VIA_SIG_CA2:
                if( !(viaC[VIA_PCR] & 0x08)) {
                  viaCifr |= (((edge<<2) ^ viaC[VIA_PCR]) & 0x04) ? 
                                                        0 : VIA_IM_CA2;
                  update_viaCirq();
                }
                break;
        case VIA_SIG_CB1:
                viaCifr |= (((edge<<4) ^ viaC[VIA_PCR]) & 0x10) ? 
                                                        0 : VIA_IM_CB1;
                update_viaCirq();
                break;
        case VIA_SIG_CB2:
                if( !(viaC[VIA_PCR] & 0x80)) {
                  viaCifr |= (((edge<<6) ^ viaC[VIA_PCR]) & 0x40) ?
                                                        0 : VIA_IM_CB2;
                  update_viaCirq();
                }
                break;
        }
}

void    store_viaC(ADDRESS addr, BYTE byte)
{
    addr &= 0xf;
#ifdef VIAC_TIMER_DEBUG
    if (debugflg)
	printf("store viaC[%x] %x\n", (int) addr, (int) byte);
#endif

    switch (addr) {

	/* these are done with saving the value */
      case VIA_PRA: /* port A */
        viaCifr &= ~VIA_IM_CA1;
        if( (viaC[VIA_PCR] & 0x0a) != 0x2) {
          viaCifr &= ~VIA_IM_CA2;
        }
#ifndef OLDIRQ
        update_viaCirq();
#endif
      case VIA_PRA_NHS: /* port A, no handshake */
	viaC[VIA_PRA_NHS] = byte;
	addr = VIA_PRA;
      case VIA_DDRA: 
	viaC[addr] = byte;
	break;

      case VIA_PRB: /* port B */
        viaCifr &= ~VIA_IM_CB1;
        if( (viaC[VIA_PCR] & 0xa0) != 0x20) {
          viaCifr &= ~VIA_IM_CB2;
        }
#ifndef OLDIRQ
        update_viaCirq();
#endif
      case VIA_DDRB:

	viaC[addr] = byte;
	byte = viaC[VIA_PRB] | ~viaC[VIA_DDRB];
        par_set_atn(!(byte & 0x04));
        par_set_ndac(!(byte & 0x08));
        par_set_eoi(!(byte & 0x10));
	break;

      case VIA_SR: /* Serial Port output buffer */
	viaC[addr] = byte;

#ifdef SOUND
	store_petsnd_sample(byte);
#endif
	break;

	/* Timers */

      case VIA_T1CL:
      case VIA_T1LL:
	viaC[VIA_T1LL] = byte;
	break;

      case VIA_T1CH /*TIMER_AH*/: /* Write timer A high */
#ifdef VIAC_TIMER_DEBUG
	if(debugflg) printf("Write timer A high: %02x\n",byte);
#endif
	viaC[VIA_T1LH] = byte;
        /* load counter with latch value */
        viaC[VIA_T1CL] = viaC[VIA_T1LL];
        viaC[VIA_T1CH] = viaC[VIA_T1LH];
        /* Clear T1 interrupt */
        viaCifr &= ~VIA_IM_T1;
#ifdef OLDIRQ
        maincpu_set_irq(I_VIACT1, 0);
#else
        update_viaCirq();
#endif
        update_viaCta(1);
        break;

      case VIA_T1LH: /* Write timer A high order latch */
        viaC[addr] = byte;
        /* Clear T1 interrupt */
        viaCifr &= ~VIA_IM_T1;
#ifdef OLDIRQ
        maincpu_set_irq(I_VIACT1, 0);
#else
	update_viaCirq();
#endif
        break;

      case VIA_T2LL:	/* Write timer 2 low latch */
	viaC[VIA_T2LL] = byte;

#ifdef SOUND
        store_petsnd_rate(2*byte+4);
	if(!byte) {
	  store_petsnd_onoff(0);
	} else {
	  store_petsnd_onoff(((viaC[VIA_ACR] & 0x1c)==0x10)?1:0);
	}
#endif
	break;

      case VIA_T2CH: /* Write timer 2 high */
        viaC[VIA_T2CH] = byte;
        viaC[VIA_T2CL] = viaC[VIA_T2LL]; /* bogus, both are identical */
        update_viaCtb(1);
        /* Clear T2 interrupt */
        viaCifr &= ~VIA_IM_T2;
#ifdef OLDIRQ
        maincpu_set_irq(I_VIACT2, 0);
#else
	update_viaCirq();
#endif
        break;

	/* Interrupts */

      case VIA_IFR: /* 6522 Interrupt Flag Register */
        viaCifr &= ~byte;
#ifdef OLDIRQ
        if(!viaCifr & VIA_IM_T1) maincpu_set_irq(I_VIACT1, 0);
        if(!viaCifr & VIA_IM_T2) maincpu_set_irq(I_VIACT2, 0);
#else
	update_viaCirq();
#endif
        break;

      case VIA_IER: /* Interrupt Enable Register */
#if defined (VIAC_TIMER_DEBUG)
        printf ("Via#1 set VIA_IER: 0x%x\n", byte);
#endif
        if (byte & VIA_IM_IRQ) {
            /* set interrupts */
#ifdef OLDIRQ
            if ((byte & VIA_IM_T1) && (viaCifr & VIA_IM_T1)) {
                maincpu_set_irq(I_VIACT1, IK_IRQ);
            }
            if ((byte & VIA_IM_T2) && (viaCifr & VIA_IM_T2)) {
                maincpu_set_irq(I_VIACT2, IK_IRQ);
            }
#endif
            viaCier |= byte & 0x7f;
        }
        else {
            /* clear interrupts */
#ifdef OLDIRQ
            if( byte & VIA_IM_T1 ) maincpu_set_irq(I_VIACT1, 0);
            if( byte & VIA_IM_T2 ) maincpu_set_irq(I_VIACT2, 0);
#endif
            viaCier &= ~byte;
        }
#ifndef OLDIRQ
	update_viaCirq();
#endif
        break;

	/* Control */

      case VIA_ACR:
	viaC[addr] = byte;


#ifdef SOUND
	store_petsnd_onoff(viaC[VIA_T2LL] ? (((byte & 0x1c)==0x10)?1:0) : 0);
#endif

	/* bit 7 timer 1 output to PB7 */
	/* bit 6 timer 1 run mode -- default seems to be continuous */

	/* bit 5 timer 2 count mode */
	if (byte & 32) {
/* TODO */
/*	    update_viaCtb(0);*/	/* stop timer if mode == 1 */
	}

	/* bit 4, 3, 2 shift register control */

	/* bit 1, 0  latch enable port B and A */
	break;

      case VIA_PCR:

/*        if(viadebug) printf("VIA1: write %02x to PCR\n",byte);*/

	/* bit 7, 6, 5  CB2 handshake/interrupt control */
	/* bit 4  CB1 interrupt control */

	/* bit 3, 2, 1  CA2 handshake/interrupt control */
	/* bit 0  CA1 interrupt control */


        if(byte != viaC[VIA_PCR]) {
          register BYTE tmp = byte;
          /* first set bit 1 and 5 to the real output values */
          if((tmp & 0x0c) != 0x0c) tmp |= 0x02;
          if((tmp & 0xc0) != 0xc0) tmp |= 0x20;
          crtc_set_char( byte & 2 ); /* switching PET charrom */
	}
	viaC[addr] = byte;
	break;

      default:
	viaC[addr] = byte;

    }  /* switch */
}


/* ------------------------------------------------------------------------- */

BYTE    read_viaC(ADDRESS addr)
{
    addr &= 0xf;
#ifdef VIAC_TIMER_DEBUG
    if (debugflg)
	printf("read viaC[%d]\n", addr);
#endif
    switch (addr) {

      case VIA_PRA: /* port A */
        viaCifr &= ~VIA_IM_CA1;
        if( (viaC[VIA_PCR] & 0x0a) != 0x02) {
          viaCifr &= ~VIA_IM_CA2;
        }
#ifndef OLDIRQ
        update_viaCirq();
#endif
      case VIA_PRA_NHS: /* port A, no handshake */

        {
            BYTE    j = 255;
            /* nothing to read yet */
            if (debugflg) {
                printf("read port A %d\n", j);
                printf("a: %x b:%x  ca: %x cb: %x joy: %x\n",
                       (int) j, (int) viaC[VIA_PRB],
                       (int) viaC[VIA_DDRA], (int) viaC[VIA_DDRB], joy[2]);
            }
            return ((j & ~viaC[VIA_DDRA]) | (viaC[VIA_PRA] & viaC[VIA_DDRA]));
        }

      case VIA_PRB: /* port B */
        viaCifr &= ~VIA_IM_CB1;
        if( (viaC[VIA_PCR] & 0xa0) != 0x20) {
          viaCifr &= ~VIA_IM_CB2;
        }
#ifndef OLDIRQ
        update_viaCirq();
#endif

        {
            BYTE    j;
            /* read parallel IEC interface line states */
            j = 255 
		- (par_nrfd ? 128:0) 
		- (par_eoi ? 2:0) 
		- (par_ndac ? 1:0) 
		- (par_dav ? 64:0);
            if (0 /*pardebug*/) {
                printf("read port B %d\n", j);
                printf("a: %x b:%x  ca: %x cb: %x joy: %x\n",
                       (int) viaC[VIA_PRA], (int) j,
                       (int) viaC[VIA_DDRA], (int) viaC[VIA_DDRB], joy[1]);
            }
            return ((j & ~viaC[VIA_DDRB]) | (viaC[VIA_PRB] & viaC[VIA_DDRB]));
        }

	/* Timers */

      case VIA_T1CL /*TIMER_AL*/: /* timer A low */
        viaCifr &= ~VIA_IM_T1;
#ifdef OLDIRQ
        maincpu_set_irq(I_VIACT1, 0);
#else
	update_viaCirq();
#endif
        return ((viaCta - clk + viaCtau) & 0xff);


      case VIA_T1CH /*TIMER_AH*/: /* timer A high */
        return (((viaCta - clk + viaCtau) >> 8) & 0xff);

      case VIA_T2CL /*TIMER_BL*/: /* timer B low */
        viaCifr &= ~VIA_IM_T2;
#ifdef OLDIRQ
        maincpu_set_irq(I_VIACT2, 0);
#else
	update_viaCirq();
#endif
        return ((viaCtb - clk + viaCtbu) & 0xff);

      case VIA_T2CH /*TIMER_BH*/: /* timer B high */
        return (((viaCtb - clk + viaCtbu) >> 8) & 0xff);

      case VIA_SR: /* Serial Port Shift Register */
	return (viaC[addr]);

	/* Interrupts */

      case VIA_IFR: /* Interrupt Flag Register */
	{
	    BYTE    t = viaCifr; 
	    if (viaCifr & viaCier /*[VIA_IER]*/)
		t |= 0x80;
	    return (t);
	}

      case VIA_IER: /* 6522 Interrupt Control Register */
	    return (viaCier /*[VIA_IER]*/ | 0x80);

    }  /* switch */

    return (viaC[addr]);
}


/* ------------------------------------------------------------------------- */

int    int_viaCt1(long offset)
{
#ifdef VIAC_TIMER_DEBUG
    if (debugflg)
	printf("viaC timer A interrupt\n");
#endif

    if (!(viaC[VIA_ACR] & 0x40)) { /* one-shot mode */
#if defined (VIAC_TIMER_DEBUG)
        printf ("VIAC Timer A interrupt -- one-shot mode: next int won't happen\n");
#endif
	viaCta = 0;
	viaCtau = clk;
	maincpu_unset_alarm(A_VIACT1);		/*int_clk[I_VIACT1] = 0;*/
    }
    else {		/* continuous mode */
        /* load counter with latch value */
        viaC[VIA_T1CL] = viaC[VIA_T1LL];
        viaC[VIA_T1CH] = viaC[VIA_T1LH];
	update_viaCta(1);
/*	int_clk[I_VIACT1] = viaCtau + viaCta;*/
    }
    viaCifr |= VIA_IM_T1;
#ifdef OLDIRQ
    if(viaCier /*[VIA_IER]*/ & VIA_IM_T1 )
	maincpu_set_irq(I_VIACT1, IK_IRQ);
#else
    update_viaCirq();
#endif
    return 0; /*(viaier & VIA_IM_T1) ? 1:0;*/
}

/*
 * Timer B is always in one-shot mode
 */

int    int_viaCt2(long offset)
{
#ifdef VIAC_TIMER_DEBUG
    if (debugflg)
	printf("VIAC timer B interrupt\n");
#endif
    viaCtb = 0;
    viaCtbu = clk;
    maincpu_unset_alarm(A_VIACT2);	/*int_clk[I_VIACT2] = 0;*/

    viaCifr |= VIA_IM_T2;
#ifdef OLDIRQ
    if( viaCier & VIA_IM_T2 ) maincpu_set_irq(I_VIACT2, IK_IRQ);
#else
    update_viaCirq();
#endif

    return 0; 
}


/* ------------------------------------------------------------------------- */

static void update_viaCta(int force)
{
    if(force) {
#ifdef VIAC_TIMER_DEBUG
       if(debugflg)
          printf("update via timer A : latch=%d, counter =%d, clk = %d\n",
                viaC[VIA_T1CL] + (viaC[VIA_T1CH] << 8),
                viaC[VIA_T1LL] + (viaC[VIA_T1LH] << 8),
                clk);
#endif
      viaCta = viaC[VIA_T1CL] + (viaC[VIA_T1CH] << 8);
      viaCtau = clk;
      maincpu_set_alarm(A_VIACT1, viaCta);
    }
}

static void update_viaCtb(int force)
{
    if(force) {
      viaCtb = viaC[VIA_T2CL] + (viaC[VIA_T2CH] << 8);
      viaCtbu = clk;
      maincpu_set_alarm(A_VIACT2, viaCtb);
    }
}

void viaC_prevent_clk_overflow(void)
{
    viaCtau -= PREVENT_CLK_OVERFLOW_SUB;
    viaCtbu -= PREVENT_CLK_OVERFLOW_SUB;
}


int     show_keyarr(void)
{
    int     i, j;
    for (j = 0; j < KBD_ROWS; j++) {
        printf("%d:", j);
        for (i = 0x80; i; i >>= 1)
            printf(" %d", keyarr[j] & i);
        printf("\n");
    }
    return (0);
}

