/*
 * $Id: viad2.h,v 1.1 1997/05/22 21:43:04 fachat Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Andre' Fachat (fachat@physik.tu-chemnitz.de)
 *   Daniel Sladic (sladic@eecg.toronto.edu)
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: viad2.h,v $
 * Revision 1.1  1997/05/22 21:43:04  fachat
 * Initial revision
 *
 */

/* 1541 VIA 2 header.  viad2.c is built by convvia from this file and
   via-tmpl.c. */

INCLUDES()
{
	#include "true1541.h"
}

#define	GLOBALS

#define	via_set_int		true1541_set_irq
#define	VIAD2_INT		IK_IRQ

/* #define VIAD2_TIMER_DEBUG */

PRE_VIA_FUNCS()
{
}

STORE_PRA()
{
	viaD2[addr] = byte;
	true1541_write_gcr(viaD2[VIA_PRA] | ~viaD2[VIA_DDRA]);
}

STORE_PRB()
{	
	{
	  BYTE oldval = viaD2[VIA_PRB] | ~viaD2[VIA_DDRB];

	  viaD2[addr] = byte;
	  byte = viaD2[VIA_PRB] | ~viaD2[VIA_DDRB];	/* newval */

	  true1541_led_status = byte & 8;
	  if ((oldval ^ byte) & 0x3)      /* Stepper motor */
	  {
	    if ((oldval & 0x3) == ((byte + 1) & 0x3))
              true1541_move_head(-1);
            else if ((oldval & 0x3) == ((byte - 1) & 0x3))
              true1541_move_head(+1);
	  }
	  /* motor on = byte & 0x04  (4 = on, 0 = off) */
	}
}

STORE_PCR()
{
        if(byte != viaD2[VIA_PCR]) {
          register BYTE tmp = byte;
          /* first set bit 1 and 5 to the real output values */
          if((tmp & 0x0c) != 0x0c) tmp |= 0x02;
          if((tmp & 0xc0) != 0xc0) tmp |= 0x20;
          /* insert_your_favourite_true1541_function_here(tmp);
	     bit 5 is the write output to the analog circuitry: 
	     0 = writing, 0x20 = reading */
        }
}

#define	STORE_ACR

#define	STORE_SR

#define	STORE_T2L

#define	RESET_VIA

READ_PRA()
{
       return (true1541_read_disk_byte() & ~viaD2[VIA_DDRA])
				| (viaD2[VIA_PRA] & viaD2[VIA_DDRA]);
}

READ_PRB() 
{
	{
	  /* I hope I got the polarities right */
	  BYTE byte = (true1541_sync_found() ? 0 : 0x80) 
			| (true1541_write_protect_sense() ? 0 : 0x10);
	  return (byte & ~viaD2[VIA_DDRB]) 
			| (viaD2[VIA_PRB] & viaD2[VIA_DDRB]);
	}
}

#define POST_VIA_FUNCS
