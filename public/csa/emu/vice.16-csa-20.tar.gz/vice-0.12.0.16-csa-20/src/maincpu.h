/*
 * $Id: maincpu.h,v 1.1 1997/05/22 21:24:25 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: maincpu.h,v $
 * Revision 1.1  1997/05/22 21:24:25  ettore
 * Initial revision
 *
 */

/* This is the header for the MOS 6510 CPU emulation. */

#ifndef _MAINCPU_H
#define _MAINCPU_H

#include "types.h"
#include "memory.h"

extern WORD program_counter;
extern BYTE accumulator;
extern BYTE x_register, y_register, stack_pointer;
extern int zero_flag;
extern int sign_flag;
extern int overflow_flag;
extern int break_flag;
extern int decimal_flag;
extern int interrupt_flag;
extern int carry_flag;
extern CLOCK clk;


/* Memory access. */

extern BYTE rom[];

#if defined(CSA)
#  define LOAD(a)	(\
/*printf("LOAD(%04x): &blktab_r[%02x]=%p[%02x]=%p (rom=%p), ret=%02x\n",\
a,(a)>>BLKSHIFT,blktab_r[(a)>>BLKSHIFT],\
(a)&BLKMAP,&(blktab_r[(a)>>BLKSHIFT][(a)&BLKMAP]),rom,\
(blktab_r[(a)>>BLKSHIFT] ? blktab_r[(a)>>BLKSHIFT][(a)&BLKMAP] : -1)),*/\
	(blktab_r[(a)>>BLKSHIFT] ? blktab_r[(a)>>BLKSHIFT][(a)&BLKMAP] \
	: (*memrd[(a)>>8])(a)) )
#elif defined(C128) 
#  define LOAD(a)	(*memrd[(a)>>12])(a)
#else
#  define LOAD(a)	(memtab_r[(a)] ? *memtab_r[(a)]		\
					       : (*memrd[(a) >> 8])(a))
#endif

#define LOAD_ZERO(a) 	pagezero[(a) & 0xff]
#define LOAD_ZERO_ADDR(a)\
			((pagezero[((a) + 1) & 0xff] << 8) \
			 | pagezero[(a) & 0xff])
#define LOAD_ADDR(a)	((LOAD (a + 1) << 8) | LOAD (a))

#if defined(CSA)
#  define STORE(a,b)	(blktab_w[(a)>>BLKSHIFT] \
			 ? (void)(blktab_w[(a)>>BLKSHIFT][(a)&BLKMAP] = (b)) \
	                 : (*memwr[(a)>>8])((a),(b)))
#elif defined(C128)
#  define STORE(a,b) 	((*memwr[(a)>>12]) ((a),(b)))
#else
#  define STORE(a,b)	(memtab_w[(a)] ? (void)(*memtab_w[(a)] = (b)) \
		         : (*memwr[(a)>>8])((a),(b)))
#endif

#if defined(C128)
#  define STORE_ZERO(a,b)       ((*memwr[0]) ((a) & 0xff, (b)))
#else
#  define STORE_ZERO(a,b)	(STORE((a) & 0xff, (b)))
#endif


#endif /* !defined(_MAINCPU_H) */
