/*
 * $Id: charsets.h,v 1.2 1995/11/07 16:51:00 jopi Exp ettore $
 *
 * This file is part of Commodore 64 emulator.
 * See README for copyright notice
 *
 * Some definitions for Character set conversions.
 *
 *
 * Written by
 *   Jouko Valta  (jopi@stekt.oulu.fi)
 *
 *
 * $Log: charsets.h,v $
 * Revision 1.2  1995/11/07 16:51:00  jopi
 * *** empty log message ***
 *
 * Revision 1.1  1995/04/01  07:50:52  jopi
 * Initial revision
 *
 *
 *
 */

#ifndef X64_CHARSETS_H
#define X64_CHARSETS_H


#define CS_CBM		0
#define CS_USA		1
#define CS_GER		2
#define CS_DEN1		3
#define CS_FRA		4
#define CS_SWE1		5
#define CS_ITA		6
#define CS_SPA		7
#define CS_DEN2		8
#define CS_SWE2		9
#define CS_FIN		10
#define CS_NOR		11
#define CS_UK		12	/* Ascii */
#define CS_CBMDIN	13	/* CS_CBM differs DIN mode */

#define NUM_LANGUAGES	14

extern char *ctrl1[], *ctrl2[], *cbmkeys[];

#endif  /* X64_CHARSETS_H */

