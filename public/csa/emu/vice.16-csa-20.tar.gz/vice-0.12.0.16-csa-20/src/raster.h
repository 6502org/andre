/*
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 * 
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 */


#ifndef _RASTER_H

#define _RASTER_H

#include "types.h"
#include "vmachine.h"
#include "video.h"

/* ------------------------------------------------------------------------- */

#ifndef BYTES_PER_CHAR
#define BYTES_PER_CHAR 	SCREEN_CHARHEIGHT
#endif

#define GET_CHAR_DATA(m, c, l)  (m)[((c) * BYTES_PER_CHAR) + (l)]

#define LO_NIBBLE(c)   ((c) & 0xf)
#define HI_NIBBLE(c)   (((c) & 0xf0) >> 4)

/* ------------------------------------------------------------------------- */

/* This defines the cache for one sprite line. */
struct sprite_line_cache {
    /* Sprite colors. */
    BYTE c1, c2, c3;

    /* Data used on the current line. */
    DWORD data;

    /* X expansion flag. */
    int x_expanded;

    /* X coordinate. */
    int x;

    /* Activation flag. */
    int visible;

    /* Priority flag. */
    int in_background;

    /* Multicolor flag. */
    int multicolor;
};

/* This defines the screen cache.  It includes the sprite cache too. */
struct line_cache {
    /* Number of line shown (referred to drawable area) */
    int n;

    /* Bitmap representation of the graphics in foreground. */
    BYTE fgdata[SCREEN_MAX_TEXTCOLS];

    /* Color information. */
    BYTE border_color;
    BYTE bgdata[SCREEN_MAX_TEXTCOLS];

    /* The following are generic and are used differently by the video
       emulators. */
    BYTE colordata1[SCREEN_MAX_TEXTCOLS];
    BYTE colordata2[SCREEN_MAX_TEXTCOLS];
    BYTE colordata3[SCREEN_MAX_TEXTCOLS];

    /* X smooth scroll offset. */
    int xsmooth;

    /* Video mode. */
    int video_mode;

    /* Blank mode flag. */
    int blank;

    /* This defines the borders. */
    int display_xstart, display_xstop;

    /* Number of columns enabled on this line (VIC-I & VDC only). */
    int numcols;

    /* Number of sprites on this line. */
    int numsprites;

    /* Bit mask for the sprites that are visible on this line. */
    int sprmask;

#if SCREEN_NUM_SPRITES > 0
    /* Sprite cache. */
    struct sprite_line_cache sprites[SCREEN_NUM_SPRITES];
    BYTE gfx_msk[SCREEN_GFXMSK_SIZE];
#endif

    /* Sprite-sprite and sprite-background collisions that were detected on
       this line. */
    BYTE ss_collmask;
    BYTE sb_collmask;

    BYTE *chargen_ptr;
    int ycounter;
};
static struct line_cache cache[SCREEN_MAX_HEIGHT];

struct sprite {
    /* X, Y coordinates. */
    int x, y;

    /* Expansion flags. */
    int x_expanded, y_expanded;

    /* Multicolor mode flag. */
    int multicolor;

    /* If 0, the sprite is in in foreground; if 1, it is in background. */
    int in_background;

    /* Primary sprite color. */
    BYTE color;

    /* Sprite memory pointer. */
    int memptr;

    /* Value to add to memptr at the next memory fetch. */
    int memptr_inc;

    /* DMA activation flag. If != 0, memory access is enabled for this
       sprite. */
    int dma_flag;
};

/* With this structure, we can define different drawing and fetching functions
   for each video mode.  One constant IDLE_MODE must be defined to the special
   mode used in the idle state. */
struct video_mode_def {
    /* Fill the cache with the screen data and check for differences.
       If nothing has changed, return 0.  Otherwise, return the smallest
       interval that contains the changed parts and return 1.
       If no_check != 0, fill the cache without checking for differences
       and return 1. */
    int (*fill_cache) (struct line_cache * l, int *changed_start,
		       int *changed_end, int no_check);

    /* Draw part of one line to the buffer. */
    void (*draw_line_cached) (struct line_cache * l, int start, int end);

    /* Draw the whole line to the buffer. */
    void (*draw_line) (void);
};
static struct video_mode_def video_modes[SCREEN_NUM_VMODES];

/* This defines the smallest rectangle that contains the areas that have
   changed since the latest refresh. */
struct frame_rect {
    /* This flag indicates that we have a null-sized rectangle. */
    int is_null;

    /* Coordinates of the upper left and lower right corners. */
    int xs, ys;
    int xe, ye;
};
static struct frame_rect changed_area;

/* Buffer containing the current frame.  Each frame is calculated line-wise in
   this buffer and then displayed each time we reach the last line. */
static frame_buffer_t frame_buffer;
static PIXEL *frame_buffer_ptr;

/* These tables translate each color number to the corresponding pixel value in
   the frame_buffer.  `pixel_table' gives one pixel, `double_pixel_table' two
   pixels and `quad_pixel_table' four pixels. */
static PIXEL pixel_table[256];
static PIXEL2 double_pixel_table[256];
static PIXEL4 quad_pixel_table[256];
#ifndef __MSDOS__
#define PIXEL(c)	pixel_table[c]
#define PIXEL2(c)	double_pixel_table[c]
#define PIXEL4(c)	quad_pixel_table[c]
#else
#define PIXEL(c)	(c)
#define PIXEL2(c)	((c) | ((c) << 8))
#define PIXEL4(c)	((c) | ((c) << 8) | ((c) << 16) | ((c) << 24))
#endif

/* Output window. */
static canvas_t canvas;

/* Size of the output window. */
static int window_width, window_height;

/* First and last lines shown in the output window. */
static int window_first_line, window_last_line;

/* First pixel in one line of the frame buffer to be shown on the output
   window. */
static int window_x_offset;

/* Size of pixels in the output window. */
static unsigned int pixel_width, pixel_height;

/* Smooth scroll values for the graphics (not the whole screen). */
static int xsmooth, ysmooth;

/* If nonzero, we should skip the next frame. (used for automatic refresh rate
   setting) */
static int skip_next_frame;

/* Next line to be calculated. */
static int rasterline;

/* Clock value of the last line update. */
static CLOCK oldclk;

/* Border and background colors. */
static BYTE border_color, background_color;

/* If this is != 0, no graphics is drawn and the whole line is painted with
   border_color. */
static int blank_enabled;

/* blank_enabled is set when line display_ystop is reached and reset when line
   display_ystart is reached and blank is 0. */
static int blank;
static int display_ystart, display_ystop;

/* These define the borders for the current line. */
static int display_xstart, display_xstop;

/* Flag: are we in idle state? */
static int idle_state;

/* Flag: were we in idle state when emulate_line() was last called? */
static int old_idle_state;

/* Count character lines (i.e. RC on the VIC-II). */
static int ycounter;

/* Internal memory pointer (i.e. VCBASE in the VIC-II). */
static int memptr;

/* Internal memory counter (i.e. VC in the VIC-II). */
static int mem_counter;

/* Flag: is the current line a `bad' line? */
static int bad_line;

/* Current video mode. */
static int video_mode;

/* This flag is set if a memory fetch has already happened on this line. */
static int memory_fetch_done;

/* If this flag is set, do not emulate at all. */
static int asleep;

/* This is != 0 if we cannot use the values in the cache anymore. */
static int dont_cache = 1;

/* Number of lines that have been recalculated.  When this value reaches the
   number of lines that are displayed in the output, then the cache is valid
   again. */
static int num_cached_lines = 0;

/* Bit mask for the sprites that are activated. */
static BYTE visible_sprite_msk = 0;

/* Bit mask for the sprites that have DMA enabled. */
static BYTE dma_msk = 0;

/* Pointer to the start of the video bank. */
static BYTE *vbank_ptr;

#if SCREEN_NUM_SPRITES > 0

/* Sprites. */
static struct sprite sprites[SCREEN_NUM_SPRITES];

/* Additional colors for multicolor sprites. */
static BYTE mc_sprite_color_1, mc_sprite_color_2;

/* Place where the sprite memory pointers are. */
static BYTE *sprite_ptr_base;

#endif

#endif /* defined( _RASTER_H ) */
