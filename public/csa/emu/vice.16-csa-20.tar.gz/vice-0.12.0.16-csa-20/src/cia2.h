/*
 * $Id: cia2.h,v 1.1 1997/05/22 21:12:41 fachat Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Andre' Fachat (fachat@physik.tu-chemnitz.de)
 *
 * $Log: cia2.h,v $
 * Revision 1.1  1997/05/22 21:12:41  fachat
 * Initial revision
 *
 */

/* Header for building cia2.c (CIA #2 emulation in the C64). */

/* #define CIA2_TIMER_DEBUG */

#define	cia2_set_int_clk		maincpu_set_nmi_clk
#define	CIA2_INT			IK_NMI

#define INCLUDES #include "true1541.h"

#define	PRE_CIA_FUNCS   
#define	POST_CIA_FUNCS

STORE_CIAPA()
{
        if (cia2[addr] != byte) {
	    static BYTE cia2pa = 0;
	    BYTE tmp;
	    extern int vbank;
	    cia2[addr] = byte;
	    tmp = cia2[CIA_PRA] | ~cia2[CIA_DDRA];
	    if(tmp != cia2pa) {
	      cia2pa = tmp;
	      vbank = ((cia2pa /*cia2[CIA_PRA]*/ & 3) ^ 3) << 14;
	      screen_init();
	    }
	    serial_bus_cpu_write(cia2[CIA_PRA] | ~cia2[CIA_DDRA]);
        }
}

#define	STORE_CIAPB 	cia2[addr] = byte;

#define	READ_CIAPB	byte= ((cia2[CIA_PRB] & cia2[CIA_DDRB]) | (0xff & ~cia2[CIA_DDRB]));

#define READ_CIAPA	byte= ((cia2[CIA_PRA] & cia2[CIA_DDRA]) | ((0x3f | serial_bus_cpu_read(	)) & ~cia2[CIA_DDRA]));

