/* 
 * This file is part of VICE, the Versatile Commodore Emulator. 
 * See README file for copyright notice. 
 * 
 * Written by 
 *   Ettore Perazzoli (ettore@comm2000.it) 
 *
 */

/* This defines some common routines for handling a line-based video chip
   emulation. */

#define _RASTER_C

#if defined( __hpux)
#define _INCLUDE_HPUX_SOURCE
#endif
#include <sys/time.h>
#if defined( __hpux)
#undef _INCLUDE_HPUX_SOURCE
#endif
#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdarg.h>
#include <string.h>

#include "vice.h"
#include "extern.h"
#include "vmachine.h"

#ifndef _RASTER_H
#include "raster.h"
#endif

#include "vsync.h"

#undef MIN
#undef MAX
#define MIN(a, b)	((a) < (b) ? (a) : (b))
#define MAX(a, b)	((a) > (b) ? (a) : (b))

/* XShmPutImage is a bit more picky about its parameters than XPutImage.
   This is useful to debug XLib failures caused by wrong calls. */
/* #define RASTER_DEBUG_PUTIMAGE_CALLS */

inline static void refresh_all(void);

/* -------------------------------------------------------------------------- */

#define vid_memcpy(dst, src, cnt) memcpy(dst, src, cnt * sizeof(PIXEL))

#if X_DISPLAY_DEPTH > 8
inline static void vid_memset(PIXEL *dst, PIXEL c, int cnt)
{
    int i;
    
    for (i = 0; i < cnt; i++)
	dst[i] = c;
}

/* This is used to paint borders and blank lines. */
#define DRAW_BLANK(p, start, end, pixel_width)		\
    do {						\
	PIXEL *dst; 					\
	int i; 						\
	dst=(PIXEL *)p + start * pixel_width;		\
	for(i=0;i<((end)-(start)+1)*pixel_width;i++)	\
	       *(dst++)=PIXEL((int)border_color);	\
    } while(0)

#else  /* 8 bit depth */
#define vid_memset(dst, c, cnt) memset(dst,c,cnt)

/* This is used to paint borders and blank lines. */
#define DRAW_BLANK(p, start, end, pixel_width)		\
    vid_memset(((BYTE *)(p) + (start) * pixel_width),	\
	       PIXEL(border_color),			\
	       ((end) - (start) + 1) * pixel_width)

#endif
      
/* -------------------------------------------------------------------------- */

/* Initialization. */
static void reset_raster(void)
{
    int i;
    
    frame_buffer_ptr = FRAME_BUFFER_START(frame_buffer);

    rasterline = 0;
    oldclk = 0;
    xsmooth = ysmooth = 0;
    blank = 0;
    mem_counter = memptr = 0;
    ycounter = 0;
    asleep = 0;

    changed_area.is_null = 1;
    for (i = 0; i < SCREEN_HEIGHT; i++) {
#if SCREEN_NUM_SPRITES > 0
	int j;
	for (j = 0; j < SCREEN_NUM_SPRITES; j++)
	    memset(&(cache[i].sprites[j]), 0, sizeof(struct sprite_line_cache));
#endif
	cache[i].numsprites = cache[i].sprmask = 0;
	cache[i].border_color = cache[i].video_mode = 0xff;
    }

#if SCREEN_NUM_SPRITES > 0
    for (i = 0; i < SCREEN_NUM_SPRITES; i++)
	memset(&(sprites[i]), 0, sizeof(struct sprite));
#endif
}

static int init_raster(int active, int max_pixel_width, int max_pixel_height)
{
#if SCREEN_NUM_SPRITES > 0
    if (frame_buffer_alloc(&frame_buffer,
			   (SCREEN_WIDTH + 48) * max_pixel_width,
			   (SCREEN_HEIGHT + 1) * max_pixel_height))
	return -1;
#else
    if (frame_buffer_alloc(&frame_buffer,
			   SCREEN_WIDTH * max_pixel_width,
			   (SCREEN_HEIGHT + 1) * max_pixel_height))
	return -1;
#endif

    reset_raster();

    return 0;
}

/* Resize the canvas with the specified values and center the screen image on
   it.  The actual size can be different if the parameters are not suitable. */
static void resize(unsigned int width, unsigned int height)
{
    width = MIN(width, SCREEN_WIDTH * pixel_width);
    height = MIN(height, SCREEN_HEIGHT * pixel_height);

    if (canvas)
	canvas_resize(canvas, width, height);

    if (width / pixel_width < SCREEN_XPIX)
	window_x_offset = SCREEN_BORDERWIDTH;
    else {
	window_x_offset = SCREEN_BORDERWIDTH - (width / pixel_width
						- SCREEN_XPIX) / 2;
	if (window_x_offset < 0)
	    window_x_offset = 0;
    }
    if (height / pixel_height < SCREEN_YPIX)
	window_first_line = SCREEN_BORDERHEIGHT;
    else {
	window_first_line = SCREEN_BORDERHEIGHT - (height / pixel_height
						   - SCREEN_YPIX) /2;
	if (window_first_line < 0)
	    window_first_line = 0;
    }

    window_last_line = window_first_line + (height / pixel_height);
    window_width = width;
    window_height = height;
}

/* Open the emulation window. */
static int open_output_window(char *win_name, unsigned int width,
			      unsigned int height, color_def_t color_defs[],
			      canvas_redraw_t exposure_handler)
{
    int i;

    window_width = width * pixel_width;
    window_height = height * pixel_height;

    canvas = canvas_create(win_name, &window_width, &window_height, !asleep,
			   exposure_handler, SCREEN_NUM_COLORS, color_defs,
			   pixel_table);

    /* Prepare the double and quad pixel tables. */
    for (i = 0; i < 0x100; i++)
	*((PIXEL *)(double_pixel_table + i))
	    = *((PIXEL *)(double_pixel_table + i) + 1) = pixel_table[i];
    for (i = 0; i < 0x100; i++)
	*((PIXEL2 *)(quad_pixel_table + i))
	    = *((PIXEL2 *)(quad_pixel_table + i) + 1) = double_pixel_table[i];

    if (!canvas)
	return 1;

    resize(window_width, window_height);

    frame_buffer_clear(&frame_buffer, PIXEL(0));

    refresh_all();
    return 0;
}

/* -------------------------------------------------------------------------- */

/* Read length bytes from src and store them in dest, checking for differences
   between the two arrays.  The smallest interval that contains different bytes
   is returned as [*xs; *xe]. */
inline static int _fill_cache(BYTE * dest, BYTE * src, int length, int srcstep,
			      int *xs, int *xe, int no_check)
{
    if (no_check) {
	int i;

	*xs = 0;
	*xe = length - 1;
	if (srcstep == 1)
	    memcpy(dest, src, length);
	else
	    for (i = 0; i < length; i++, src += srcstep)
		dest[i] = src[0];
	return 1;
    } else {
	int x = 0, i;

	for (i = 0; dest[i] == src[0] && i < length; i++, src += srcstep)
	    /* do nothing */ ;

	if (i < length) {
	    if (*xs > i)
		*xs = i;
	    for (; i < length; i++, src += srcstep)
		if (dest[i] != src[0]) {
		    dest[i] = src[0];
		    x = i;
		}
	    if (*xe < x)
		*xe = x;
	    return 1;
	} else
	    return 0;
    }
}

/* Do as _fill_cache(), but split each byte into low and high nibble.  These
   are stored into different destinations. */
inline static int _fill_cache_nibbles(BYTE * desthi, BYTE * destlo, BYTE * src,
				      int length, int srcstep, int *xs, int *xe,
				      int no_check)
{
    if (no_check) {
	int i;

	*xs = 0;
	*xe = length - 1;
	for (i = 0; i < length; i++, src += srcstep) {
	    desthi[i] = HI_NIBBLE(src[0]);
	    destlo[i] = LO_NIBBLE(src[0]);
	}
	return 1;
    } else {
	int i, x = 0;
	BYTE b;

	for (i = 0;
	     desthi[i] == HI_NIBBLE(src[0])
	     && destlo[i] == LO_NIBBLE(src[0]) && i < length;
	     i++, src += srcstep)
	    /* do nothing */ ;

	if (i < length) {
	    if (*xs > i)
		*xs = i;
	    for (; i < length; i++, src += srcstep)
		if (desthi[i] != (b = HI_NIBBLE(src[0]))) {
		    desthi[i] = b;
		    x = i;
		} else if (destlo[i] != (b = LO_NIBBLE(src[0]))) {
		    destlo[i] = b;
		    x = i;
		}
	    if (*xe < x)
		*xe = x;
	    return 1;
	} else
	    return 0;
    }
}


/* This function is used for text modes.  It checks for differences in the
   character memory too. */
inline static int _fill_cache_text(BYTE * dest, BYTE * src, BYTE * charmem,
				   int length, int l, int *xs, int *xe,
				   int no_check)
{
    if (no_check) {
	int i;

	*xs = 0;
	*xe = length - 1;
	for (i = 0; i < length; i++, src++)
	    dest[i] = GET_CHAR_DATA(charmem, src[0], l);
	return 1;
    } else {
	BYTE b;
	int i;

	for (i = 0;
	     dest[i] == GET_CHAR_DATA(charmem, src[0], l) && i < length;
	     i++, src++)
	    /* do nothing */ ;

	if (i < length) {
	    *xs = *xe = i;
	    for (; i < length; i++, src++)
		if (dest[i] != (b = GET_CHAR_DATA(charmem, src[0], l))) {
		    dest[i] = b;
		    *xe = i;
		}
	    return 1;
	} else
	    return 0;
    }
}


#if SCREEN_NUM_SPRITES > 0
/* Fill the sprite cache with the new sprite data. [*xs; *xe] is the changed
   interval (expressed in pixels). */
inline static int _fill_sprite_cache(struct line_cache *ll, int *xs, int *xe)
{
    int rr = 0, i, r, sxe, sxs, sxe1, sxs1, n = 0, msk;
    struct sprite spr;
    struct sprite_line_cache *l = ll->sprites;
    struct sprite_line_cache *sprl;
    int xs_return = SCREEN_WIDTH, xe_return = 0;

    ll->numsprites = SCREEN_NUM_SPRITES;
    ll->sprmask = 0;
    for (msk = 1, i = 0; i < SCREEN_NUM_SPRITES; i++, msk <<= 1) {
	spr = sprites[i];
	sprl = l + i;
	r = 0;
	if (spr.dma_flag) {
	    DWORD tmp;
	    BYTE *data;
	    ll->sprmask |= msk;
	    data = vbank_ptr + (sprite_ptr_base[i] << 6) + spr.memptr;
	    sxe = spr.x + (spr.x_expanded ? 48 : 24);
	    sxs = spr.x;
	    if (spr.x != sprl->x) {
		if (sprl->visible) {
		    sxe1 = sprl->x + (sprl->x_expanded ? 48 : 24);
		    sxs1 = sprl->x;
		    n++;
		    if (sxs1 < sxs)
			sxs = sxs1;
		    if (sxe1 > sxe)
			sxe = sxe1;
		}
		sprl->x = spr.x;
		r = 1;
	    }
	    if (!sprl->visible) {
		sprl->visible = 1;
		r = 1;
	    }
	    if (spr.x_expanded != sprl->x_expanded) {
		sprl->x_expanded = spr.x_expanded;
		r = 1;
	    }
	    if (spr.multicolor != sprl->multicolor) {
		sprl->multicolor = spr.multicolor;
		r = 1;
	    }
	    if (mc_sprite_color_1 != sprl->c1) {
		sprl->c1 = mc_sprite_color_1;
		r = 1;
	    }
	    if (mc_sprite_color_2 != sprl->c2) {
		sprl->c2 = mc_sprite_color_2;
		r = 1;
	    }
	    if (spr.color != sprl->c3) {
		sprl->c3 = spr.color;
		r = 1;
	    }
	    if (spr.in_background != sprl->in_background) {
		sprl->in_background = spr.in_background;
		r = 1;
	    }
	    
	    /* Byte ordering is really not important here, since this is
	       not actually used for the drawing.  Just do it as fast
	       as possible... */
#ifdef ALLOW_UNALIGNED_ACCESS
	    tmp = *((DWORD *)data);
#else
	    tmp = data[0] | (data[1] << 8) | (data[2] << 16);
#endif

	    if (sprl->data != tmp) {
		sprl->data = tmp;
		r = 1;
	    }
	    if (r) {
		xs_return = MIN(xs_return, sxs);
		xe_return = MAX(xe_return, sxe);
		rr = 1;
	    }
	} else if (sprl->visible) {
	    sprl->visible = 0;
	    sxe = sprl->x + (sprl->x_expanded ? 24 : 48);
	    xs_return = MIN(xs_return, sprl->x);
	    xe_return = MAX(xe_return, sxe);
	    rr = 1;
	}
    }

    if (xe_return >= SCREEN_WIDTH)
	*xe = SCREEN_WIDTH - 1;
    else
	*xe = xe_return;
    *xs = xs_return;

    return rr;
}
#endif				/* SCREEN_NUM_SPRITES > 0 */

/* -------------------------------------------------------------------------- */

/* Increase the size of the rectangle to be refreshed so that it also includes
   the interval [xs; xe] of line y.  The lines must be added in order: from
   top to bottom. */
inline static void add_line(int y, int xs, int xe)
{
#ifdef RASTER_DEBUG_PUTIMAGE_CALLS
    printf("add_line(): y = %d, xs = %d, xe = %d\n", y, xs, xe);
#endif

    if (changed_area.is_null) {
	changed_area.ys = changed_area.ye = y;
	changed_area.xs = xs;
	changed_area.xe = xe;
	changed_area.is_null = 0;
    } else {
	changed_area.xs = MIN(xs, changed_area.xs);
	changed_area.xe = MAX(xe, changed_area.xe);
	changed_area.ye = y;
    }

#ifdef RASTER_DEBUG_PUTIMAGE_CALLS
    printf("add_line(): current changed_area has "
	   "ys = %d, ye = %d, xs = %d, xe = %d\n",
     changed_area.ys, changed_area.ye, changed_area.xs, changed_area.xe);
#endif
}

/* Refresh the changed rectangle. */
inline static void refresh_changed(void)
{
    int x, y, xx, yy;
    int w, h;

    if (changed_area.is_null)
	return;

    x = changed_area.xs;
    y = changed_area.ys;
    xx = changed_area.xs - window_x_offset;
    yy = changed_area.ys - window_first_line;
    w = changed_area.xe - changed_area.xs + 1;
    h = changed_area.ye - changed_area.ys + 1;

    if (xx < 0) {
	x -= xx;
	w += xx;
	xx = 0;
    }
    if (yy < 0) {
	y -= yy;
	h += yy;
	yy = 0;
    }

    x *= pixel_width;
    xx *= pixel_width;
    w *= pixel_width;

    y *= pixel_height;
    yy *= pixel_height;
    h *= pixel_height;
    
#if defined (RASTER_DEBUG_PUTIMAGE_CALLS)
    printf("Refresh %d %d %d %d %d %d \n", x, y, xx, yy, w, h);
#endif

    canvas_refresh(canvas, frame_buffer, x, y, xx, yy, w, h);

    changed_area.is_null = 1;
}

/* Unconditionally refresh the whole screen. */
inline static void refresh_all(void)
{
#if defined (RASTER_DEBUG_PUTIMAGE_CALLS)
    printf("Global refresh %d %d %d %d %d %d\n", window_x_offset * pixel_width,
    window_first_line * pixel_height, 0, 0, window_width, window_height);
#endif
    canvas_refresh(canvas, frame_buffer, window_x_offset * pixel_width,
		   window_first_line * pixel_height, 0, 0, window_width,
		   window_height);
}

/* -------------------------------------------------------------------------- */

/* Emulate a sprite memory access sequence.  Unlike the real VIC-II, all the
   accesses are done at once.  Yes, this can cause trouble! */
#ifdef __VIC_II__
inline static int do_sprite_fetch(void)
{
    int i;
    int cycles = 0;

    /* If there are no sprites to handle, do nothing. */
    if (!visible_sprite_msk && !dma_msk)
	return 0;

    for (i = 0; i < SCREEN_NUM_SPRITES; i++) {
	if ((visible_sprite_msk & (1 << i))
	    && (sprites[i].y == (rasterline & 0xff))) {
	    /* Enable the DMA access for this sprite. */
	    sprites[i].dma_flag = 1;
	    sprites[i].memptr = 0;
	    sprites[i].memptr_inc = 3;
	    dma_msk |= 1 << i;
	    cycles += 2;
	    continue;
	}
	if (sprites[i].dma_flag) {
	    if (sprites[i].y_expanded)
		sprites[i].memptr_inc = ~sprites[i].memptr_inc & 3;
	    else
		sprites[i].memptr_inc = 3;
	    sprites[i].memptr += sprites[i].memptr_inc;
	    if (sprites[i].memptr >= 63) {
		/* We reached the end of the sprite: disable the DMA access. */
		sprites[i].dma_flag = 0;
		dma_msk &= ~(1 << i);
	    } else /* if (sprites[i].memptr_inc) */
		cycles += 2;
	}
    }

#if 0
    if (traceflg)
	printf("do_sprite_fetch: stealing %d cycles\n", cycles);
#endif
    return cycles;
}
#endif /* defined (__VIC_II__) */

/* -------------------------------------------------------------------------- */

inline static void handle_blank_line(void)
{
    /* Even when the actual caching is disabled, redraw blank lines only if
       it is really necessary to do so. */
    if (dont_cache || border_color != cache[rasterline].border_color
	|| !cache[rasterline].blank) {
	cache[rasterline].border_color = border_color;
	cache[rasterline].blank = 1;
	DRAW_BLANK(frame_buffer_ptr, 0, SCREEN_WIDTH - 1, pixel_width);
	if (pixel_height == 2 && app_resources.doubleScan)
	    DRAW_BLANK(FRAME_BUFFER_LINE_START(frame_buffer, 2*rasterline + 1),
		       0, SCREEN_WIDTH - 1, pixel_width);
	add_line(rasterline, 0, SCREEN_WIDTH - 1);
    }
}

inline static void handle_visible_line_with_cache(void)
{
    int needs_update = 0;
    int line;
    int vm = idle_state ? SCREEN_IDLE_MODE : video_mode;
    int changed_start = SCREEN_TEXTCOLS, changed_end = -1;
    struct line_cache *l = &cache[rasterline];

    line = rasterline - SCREEN_BORDERHEIGHT - ysmooth - 1;

    /* Check for `major' changes first.  If there is any, just write straight
       to the cache without any comparisons and redraw the whole line. */
    if (dont_cache || l->n != line || l->xsmooth != xsmooth
#ifdef CSA
	|| (redraw_screen & 1)
#endif
	|| l->video_mode != vm || l->blank || l->ycounter != ycounter
	|| l->border_color != border_color
	|| l->display_xstart != display_xstart
	|| l->display_xstop != display_xstop) {
	needs_update = 1;
	l->n = line;
	l->video_mode = vm;
	l->blank = 0;
	l->xsmooth = xsmooth;
	l->ycounter = ycounter;
	l->border_color = border_color;
	l->display_xstart = display_xstart;
	l->display_xstop = display_xstop;

#if SCREEN_NUM_SPRITES > 0
	_fill_sprite_cache(l, &changed_start, &changed_end);
#endif

	video_modes[vm].fill_cache(l, &changed_start, &changed_end, 1);

	/* [ `changed_start' ; `changed_end' ] now covers the whole line, as
	   we have called fill_cache() with `1' as the last parameter (no
	   check). */
	video_modes[vm].draw_line_cached(l, changed_start, changed_end);

	changed_start = 0;
	changed_end = SCREEN_WIDTH - 1;

	/* Fill the space between the border and the graphics with the
	   background color (necessary if xsmooth is != 0). */
	vid_memset(frame_buffer_ptr + SCREEN_BORDERWIDTH * pixel_width,
		   PIXEL(background_color), xsmooth * pixel_width);

	/* Draw the borders. */
	DRAW_BLANK(frame_buffer_ptr, 0, display_xstart - 1, pixel_width);
	DRAW_BLANK(frame_buffer_ptr, display_xstop, SCREEN_WIDTH - 1,
		   pixel_width);
    } else {

	/* There are no `major' changes: try to do some optimization. */

#if SCREEN_NUM_SPRITES > 0

	int sprites_need_update;
	int sprite_changed_start, sprite_changed_end;

	sprites_need_update = _fill_sprite_cache(l, &sprite_changed_start,
						 &sprite_changed_end);
	/* If sprites have changed, do not bother trying to reduce the amount
	   of recalculated data, but simply redraw everything. */
	needs_update = video_modes[vm].fill_cache(l, &changed_start,
						  &changed_end,
						  sprites_need_update);

	if (needs_update) {
	    video_modes[vm].draw_line_cached(l, changed_start, changed_end);

	    /* Fill the space between the border and the graphics with the
	       background color (necessary if xsmooth is > 0). */
	    vid_memset(frame_buffer_ptr + SCREEN_BORDERWIDTH * pixel_width,
		       PIXEL(background_color), xsmooth * pixel_width);

	    /* If xsmooth > 0, drawing the graphics might have corrupted
	       part of the border... fix it here. */
	    DRAW_BLANK(frame_buffer_ptr, SCREEN_BORDERWIDTH + SCREEN_XPIX,
		       SCREEN_BORDERWIDTH + SCREEN_XPIX + 8, pixel_width);

	    /* Convert from character to pixel coordinates. */
	    changed_start = SCREEN_BORDERWIDTH + xsmooth + 8 * changed_start;
	    changed_end = (SCREEN_BORDERWIDTH + xsmooth + 8 * (changed_end + 1)
			   - 1);
	    
	    if (sprites_need_update) {
		/* Even if we have recalculated the whole line, we will refresh
		   only the part that has actually changed when writing to the
		   window. */
		changed_start = MIN(changed_start, sprite_changed_start);
		changed_end = MAX(changed_end, sprite_changed_end);

		/* The borders have not changed, so do not repaint them even
		   if there are sprites under them. */
		changed_start = MAX(changed_start, display_xstart);
		changed_end = MIN(changed_end, display_xstop);
	    }
	}
	
#else  /* no sprites */

	needs_update = video_modes[vm].fill_cache(l, &changed_start,
						  &changed_end, 0);

	if (needs_update) {
	    video_modes[vm].draw_line_cached(l, changed_start, changed_end);

	    /* Convert from character to pixel coordinates. */
	    changed_start = SCREEN_BORDERWIDTH + xsmooth + 8 * changed_start;
	    changed_end = (SCREEN_BORDERWIDTH + xsmooth + 8 * (changed_end + 1)
			   - 1);
	}
#endif				/* no sprites */

	/* Draw the lateral borders. */
	DRAW_BLANK(frame_buffer_ptr, 0, display_xstart - 1, pixel_width);
	DRAW_BLANK(frame_buffer_ptr, display_xstop, SCREEN_WIDTH - 1,
		   pixel_width);

    }

    if (needs_update) {
	add_line(rasterline, changed_start, changed_end);

	if (pixel_height == 2 && app_resources.doubleScan) {
	    vid_memcpy(FRAME_BUFFER_LINE_START(frame_buffer,
					       2 * rasterline + 1)
		       + changed_start * pixel_width,
		       frame_buffer_ptr + changed_start * pixel_width,
		       (changed_end - changed_start + 1) * pixel_width);
	}
    }
}

inline static void handle_visible_line_without_cache()
{
    /* If screen is scrolled to the right, we need to fill with the background 
       color the blank part on the left. */
    vid_memset(frame_buffer_ptr + SCREEN_BORDERWIDTH * pixel_width,
	       PIXEL(background_color), xsmooth * pixel_width);

    /* Draw the graphics and sprites. */
    if (idle_state)
	video_modes[SCREEN_IDLE_MODE].draw_line();
    else
	video_modes[video_mode].draw_line();

    /* Draw the borders. */
    DRAW_BLANK(frame_buffer_ptr, 0, display_xstart - 1, pixel_width);
    DRAW_BLANK(frame_buffer_ptr, display_xstop, SCREEN_WIDTH - 1, pixel_width);

    /* Do some minimal caching (still). */
    if (dont_cache || cache[rasterline].blank
	|| border_color != cache[rasterline].border_color || dma_msk) {
	cache[rasterline].blank = 0;
	cache[rasterline].border_color = border_color;
	add_line(rasterline, 0, SCREEN_WIDTH - 1);

	if (pixel_height == 2 && app_resources.doubleScan)
	    vid_memcpy(FRAME_BUFFER_LINE_START(frame_buffer, rasterline*2 + 1),
		       frame_buffer_ptr, SCREEN_WIDTH * pixel_width);
    } else {
	add_line(rasterline, SCREEN_BORDERWIDTH,
		 SCREEN_BORDERWIDTH + SCREEN_XPIX);
	if (pixel_height == 2 && app_resources.doubleScan)
	    vid_memcpy((FRAME_BUFFER_LINE_START(frame_buffer, rasterline*2 + 1)
			+ SCREEN_BORDERWIDTH * pixel_width),
		       frame_buffer_ptr + SCREEN_BORDERWIDTH * pixel_width,
		       SCREEN_XPIX * pixel_width);
    }
}

inline static void handle_visible_line(void)
{
    if (app_resources.videoCache)
	handle_visible_line_with_cache();
    else
	handle_visible_line_without_cache();

#if !defined (__VIC_II__) && !defined (__VDC__)
    if (++ycounter >= SCREEN_CHARHEIGHT) {
	ycounter = 0;
	memptr += SCREEN_TEXTCOLS;
	/* clk += SCREEN_TEXTCOLS + 3; */
    }
#endif
}

inline static void handle_end_of_frame(void)
{
    frame_buffer_ptr = FRAME_BUFFER_START(frame_buffer);
    memptr = rasterline = 0;
#ifndef __VIC_II__
    ycounter = 0;
#endif
    if (!skip_next_frame) {
	if (dont_cache)
	    refresh_all();
	else
	    refresh_changed();
    }
    skip_next_frame = do_vsync(skip_next_frame);
    
#ifdef __MSDOS__
    if (window_width == SCREEN_XPIX && window_height == SCREEN_YPIX)
	canvas_set_border_color(canvas, border_color);
#endif
}

/* Emulate one raster line. */
inline static void emulate_line(void)
{
    if (oldclk > clk)
	oldclk = CYCLES_PER_LINE;
    else
	oldclk += CYCLES_PER_LINE;

    /* Emulate the vertical blank flip-flops. (Well, sort of) */
    if (rasterline == display_ystart && !blank)
	blank_enabled = 0;
    else if (rasterline == display_ystop)
	blank_enabled = 1;

    if (rasterline >= SCREEN_FIRST_DISPLAYED_LINE
	&& rasterline <= SCREEN_LAST_DISPLAYED_LINE) {
	if (!skip_next_frame && !asleep && rasterline >= window_first_line
	    && rasterline <= window_last_line) {
	    if (blank_enabled)
		handle_blank_line();
	    else
		handle_visible_line();

	    if (++num_cached_lines == (window_last_line - window_first_line)) {
		dont_cache = 0;
		num_cached_lines = 0;
	    }
	}

#ifdef __VIC_II__
	if (!idle_state)
	    mem_counter = (mem_counter + SCREEN_TEXTCOLS) & 0x3ff;
#endif
	
#ifndef __VDC__
	old_idle_state = idle_state;
	/* `ycounter' makes the chip go to idle state when it reaches the
	   maximum value. */
	if (ycounter == 7 && !idle_state) {
	    idle_state = 1;
	    memptr = mem_counter;
	}
	if (!idle_state || bad_line)
	    ycounter = (ycounter + 1) & 0x7;
	bad_line = 0;
#endif

	rasterline++;
	frame_buffer_ptr = FRAME_BUFFER_LINE_START(frame_buffer,
						   rasterline * pixel_height);

#ifdef __VIC_II__
	/* On the real VIC-II sprites are checked for the DMA condition at
	   cycles 55 and 56 and each of them fetches memory at different
	   cycles.  In order to simplify (and make it faster), we do everything
	   together instead, and this is NOT exact emulation! */
#if SCREEN_NUM_SPRITES > 0
	clk += do_sprite_fetch();
#endif
 	if (rasterline == 0x30)
	    allow_bad_lines = !blank;
#endif
	
    } else {
	rasterline++;
	if (rasterline == SCREEN_HEIGHT)
	    handle_end_of_frame();
	else
	    frame_buffer_ptr = FRAME_BUFFER_LINE_START(frame_buffer,
						    rasterline * pixel_height);
#ifdef __VIC_II__
	/* Handle sprites, but don't steal cycles. */
	/* FIXME: is this correct? */
	do_sprite_fetch();
#endif	
    }

    memory_fetch_done = 0;
}

/* Disable all the caching for the next frame. */
inline static void force_repaint(void)
{
    dont_cache = 1;
    num_cached_lines = 0;
}
