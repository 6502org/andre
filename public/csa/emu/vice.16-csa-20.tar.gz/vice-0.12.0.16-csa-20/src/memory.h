/*
 * $Id: memory.h,v 2.1 1997/05/22 21:24:48 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file contains the Commodore OS constants and such.
 *
 * Included are:
 *	o memory banking
 *	o BASIC constants
 *
 *
 * Written by
 *   Jarkko Sonninen  (sonninen@lut.fi)
 *   Jouko Valta      (jopi@stekt.oulu.fi)
 *   Andre Fachat     (a.fachat@physik.tu-chemnitz.de)
 *
 *
 * $Log: memory.h,v $
 * Revision 2.1  1997/05/22 21:24:48  ettore
 * *** empty log message ***
 *
 * Revision 2.0  1996/07/29 21:22:32  ettore
 * New faster memory address scheme.
 *
 * Revision 1.6  1996/04/01  09:01:41  jopi
 * PET and VIC-20 implemented
 *
 * Revision 1.5  1995/11/07  16:51:00  jopi
 * some C16 settings
 *
 * Revision 1.4  1995/06/28  19:40:56  jopi
 * PET 40xx/80xx Emulator
 *
 * Revision 1.3  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * C128 ROM checksums done better way.
 *
 * Revision 1.2  1994/12/12  16:59:44  jopi
 * 16-bit portability
 *
 *
 *
 */

#ifndef X64_MEMORY_H
#define X64_MEMORY_H


#include "vice.h"
#include "types.h"
#include "file.h"



/* System Memory Constants and OS Constants for Monitor
 * (The latter are only for convenience, since x64 boots from FFFC vector)
 * Also checksums for all *known* revisions are provided, except for
 * those third party turbo systems.
 */

#define CHARGEN_SIZE		0x1000   /* Character Generator ROM */


#ifndef PLUS_SERIES
#define HIROM_SIZE		0x2000   /* Kernel */

#else
#define HIROM_SIZE		0x4000   /* Kernel */

#define RAMSIZE			0x10000
#define BASICROM_SIZE		0x4000
#define LOROM_BASE		0x8000

#define EDITROM_SIZE		0x0
#define LOROM_SIZE		BASICROM_SIZE
#define LOROM_MASK		0x3FFF	/* 12K */
#define CHARGEN_BASE		0xD000	/* Not used */


#define BASIC_CHECKSUM		0
#define KERNAL_CHECKSUM		0

#define RESTART_BASIC		0x0
#define CBM_TXT_DEFAULT		"0x1001"

#define EXROM_SIZE		0x1000	/* 4 K */
#define BASIC_ADDRESS(a) 	((a) & LOROM_MASK)

/*
 * BASIC Pointers
 */
#define CBM_TXTTAB		0x28	/* Basic Text */
#define CBM_VARTAB		0x2A	/* Basic Variables */
#define CBM_ARYTAB		0x2C	/* Basic Arrays */
#define CBM_STREND		0x2E	/* End of Arrays +1 */
#define CBM_FRETOP		0x30	/* Bottom of String Storage */
#endif


#ifdef C128
#define RAMSIZE			0x20000  /* x128 supports 0x40000 too */
#define BASICROM_SIZE		0x8000
#define EDITROM_SIZE		0x1000
#define LOROM_SIZE	0x9000 /* load Basic (LO,HI) and Editor at once */
#define LOROM_MASK		0x3FFF /* 16K + 16K + 4K */

#define EXROM_SIZE	0x4000  /* C128 function rom is 2*16 KB slots */

#define CHARGEN_BASE		0xD000
#define LOROM_BASE		0x4000
#define BASIC_ADDRESS(a) 	((a) - LOROM_BASE)

#define BASIC_CHECKSUM_85	38592
#define BASIC_CHECKSUM_86	2496
#define EDITOR_CHECKSUM_R01	56682
#define EDITOR_CHECKSUM_R01swe	9364
#define EDITOR_CHECKSUM_R01ger	9619
#define KERNAL_CHECKSUM_R01	22353
#define KERNAL_CHECKSUM_R01swe	24139
#define KERNAL_CHECKSUM_R01ger	22098

#define RESTART_BASIC		0x4000  /* or 4003 */

/*
 * BASIC Pointers
 */
#define CBM_TXTTAB		0x2D	/* Basic Text */
#define CBM_VARTAB		0x2F	/* Basic Variables */
#define CBM_ARYTAB		0x31	/* Basic Arrays */
#define CBM_STREND		0x33	/* End of Arrays +1 */
#define CBM_FRETOP		0x35	/* Bottom of String Storage */
#define CBM_TXT_DEFAULT		"0x1C01"

#define NUM_MEMCONFIGS          1       /* x128 does not use the new memory access method */

#else  /* C64 & VIC-20 */
#if !(defined(PET) || defined(CSA))

#ifdef CBM64
#define RAMSIZE			0x10000
#define BASICROM_SIZE		0x2000
#define LOROM_SIZE		BASICROM_SIZE
#define LOROM_MASK		0x1FFF
#define CHARGEN_BASE		0xD000
#define LOROM_BASE		0xA000

#define BASIC_CHECKSUM		15702
#define KERNAL_CHECKSUM_R00	50955
#define KERNAL_CHECKSUM_R03	50954
#define KERNAL_CHECKSUM_R03swe	50633
#define KERNAL_CHECKSUM_R43	50955
#define KERNAL_CHECKSUM_R64	49680

#define RESTART_BASIC		0xA474
#define CBM_TXT_DEFAULT		"0x0801"

#define NUM_MEMCONFIGS          8       /* number of possible memory configurations */

/*#define RESTART_COLD		0xFCE2*/
/*#define RESTART_WARM		0xFCFE*/

#endif  /* C64 */

#ifdef VIC20
#define RAMSIZE			0x10000	/* for easier module handling... */
#define BASICROM_SIZE		0x2000
#define LOROM_SIZE		BASICROM_SIZE
#define LOROM_MASK		0x1FFF
#define CHARGEN_BASE		0x8000
#define LOROM_BASE		0xC000

#define BASIC_CHECKSUM		33073
#define KERNAL_CHECKSUM		38203

#define RESTART_BASIC		0x0
#define CBM_TXT_DEFAULT		"0x1201"

#define NUM_MEMCONFIGS          1       /* number of possible memory configurations */

#endif


#define EXROM_SIZE		0x2000  /* C64/VIC20 module is 2*8 KB slots */
#define BASIC_ADDRESS(a) 	((a) & LOROM_MASK)

/*
 * BASIC Pointers
 */
#define CBM_TXTTAB		0x2B	/* Basic Text */
#define CBM_VARTAB		0x2D	/* Basic Variables */
#define CBM_ARYTAB		0x2F	/* Basic Arrays */
#define CBM_STREND		0x31	/* End of Arrays +1 */
#define CBM_FRETOP		0x33	/* Bottom of String Storage */


#else  /* PET or CSA */

#ifdef PET
#define RAMSIZE			0x10000
#define ROMSIZE			0x8000

#define	PET3032_CHECKSUM	31319
#define	PET4032_CHECKSUM	1643
#define	PET8032_CHECKSUM_A	8647	/* my kernel (a.fachat) */
#define	PET8032_CHECKSUM_B	8227	/* jouko's kernel */

#define CBM_TXT_DEFAULT		"0x0401"

#define NUM_MEMCONFIGS          1       /* number of possible memory configurations */

/*
 * BASIC Pointers
 */
#define CBM_TXTTAB		0x28	/* Basic Text */
#define CBM_VARTAB		0x2A	/* Basic Variables */
#define CBM_ARYTAB		0x2C	/* Basic Arrays */
#define CBM_STREND		0x2E	/* End of Arrays +1 */
#define CBM_FRETOP		0x30	/* Bottom of String Storage */

#endif /* PET */

#ifdef CSA
/*
 * The CSA has a more advanced MMU, it can map any of the 16 4k pages
 * at addresses $*000 in CPU address space to somewhere at $xy000 in 
 * physical address space. Currently we emulate the BIOS board
 * with 32k RAM at $00000 physical address, and 32k ROM at $08000, plus
 * the video board at $10000, with 64k RAM.
 *
 * Memory configurations are reloaded when a MMU register is changed,
 * 'config caching' would be usesless with this type of MMU.
 * We don't really care for speed here, but want a development model
 * for our software, which is as compatible as possible.
 *
 * The I/O area is constantly mapped at $0e** in CPU address space.
 */
#define RAMSIZE			0x18000	/* video board at $10000, w/ 64k RAM */
#define ROMSIZE			0x8000	/* std ROM at $8000 */

#define NUM_MEMCONFIGS          1       /* number of possible memory configs */

#endif /* CSA */
#endif 
#endif /* not C128 */


/*
 * Functions
 */

extern BYTE    load_rom( ADDRESS a );
extern void    save_rom( ADDRESS a, BYTE x );

extern void    ram_powerup( void );

extern BYTE   *allocate_mem ( int size );
extern char   *create_name ( char *path, char *name );
extern int     Load_Sys_File ( char *path, char *name, BYTE *var, int reloc, int siz );
extern int     LoadFile ( char *path, char *name, BYTE *var, int reloc, int maxsiz );
extern int     SaveFile ( char *path, char *name, BYTE *var, int reloc, int siz );

extern void    store_vic ( ADDRESS addr, BYTE byte );
extern void    store_colorram ( ADDRESS addr, BYTE byte );
extern BYTE    read_colorram ( ADDRESS addr );

#ifdef C128
extern void store_io2 (ADDRESS address, BYTE byte);
extern BYTE read_io2 (ADDRESS address);
#endif

/* RAM expansion */
/* FIXME: This should probably be moved somewhere else. */
#ifdef REU

extern int reuflg;

extern int     reset_reuc ( char *, ADDR_T );
extern void    close_reuc ( char * );
extern BYTE    read_reuc ( ADDRESS );
extern void    store_reuc ( ADDRESS, BYTE );
extern void    reu_dma ( int );
extern void    activate_reuc ( void );

#endif  /* REU */


/* rom patcher */

#ifdef PATCH_ROM

extern int patch_rom ( char * );

#endif  /* PATCH_ROM */

#ifdef CSA
#define	BLKSHIFT	11		/* lower bits to ignore for mapping */
#define	BLKMAP		0x07ff		/* lower bits mapped */
extern BYTE *blktab_r[0x11000 >> BLKSHIFT];
extern BYTE *blktab_w[0x11000 >> BLKSHIFT];
#else
/* Memory access table. */
extern BYTE *memory_tabs_r[NUM_MEMCONFIGS][RAMSIZE + 0x1000]; /* for reading */
extern BYTE *memory_tabs_w[NUM_MEMCONFIGS][RAMSIZE + 0x1000]; /* for writing */
extern BYTE **memtab_r;
extern BYTE **memtab_w;
#endif

extern BYTE *pagezero;
extern BYTE *pageone;

extern int rom_loaded;

extern void    set_text_pointers( ADDRESS ls, ADDRESS end );
extern void iowr ( ADDRESS, BYTE );
extern BYTE iord ( ADDRESS );

#endif  /* X64_MEMORY_H */
