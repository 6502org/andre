/*
 * $Id: drive.h,v 1.8 1997/05/22 21:15:11 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * Definitions for both built-in and standalone drive simulators and
 * emulators.
 *
 * Written by
 *   Teemu Rantanen   (tvr@cs.hut.fi)
 *   Dan Miner        (dminer@nyx10.cs.du.edu)
 *   Andre Fachat     (a.fachat@physik.tu-chemnitz.de)
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * Patches by
 *   Olaf Seibert     (rhialto@mbfys.kun.nl)
 *
 *
 * $Log: drive.h,v $
 * Revision 1.8  1997/05/22 21:15:11  ettore
 * `floppy_read_block()' and `floppy_write_block()' made extern.
 *
 * Revision 1.7  1996/07/29 21:03:39  ettore
 * D64_Header in DRIVE and some D64_* contants.
 *
 * Revision 1.6  1996/04/01  09:01:41  jopi
 * Version 2.0, VICE 0.10 PL 0
 * Declaratios for further device types
 *
 * Revision 1.5  1995/11/07  16:51:00  jopi
 * *** empty log message ***
 *
 * Revision 1.4  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * Prepared for Error Data handling.
 *
 * Revision 1.3  1995/01/26  13:51:18  jopi
 * Structures and control values for multiple drive handling.
 *
 * Revision 1.2  1994/12/12  16:59:44  jopi
 * Added multi-disk support
 *
 * Revision 1.1  1994/08/10  17:46:41  jopi
 * Initial revision
 *
 *
 */


#ifndef X64_DRIVE_H
#define X64_DRIVE_H


#include <time.h>

#include "types.h"


#define UPPER(ad)		(((ad)>>8)&0xff)
#define LOWER(ad)		((ad)&0xff)

#define DRIVE_RAMSIZE		0x400
#define IP_MAX_COMMAND_LEN	128   /* real 58 */


/* File Types */

#define FT_DEL		0
#define FT_SEQ		1
#define FT_PRG		2
#define FT_USR		3
#define FT_REL		4
#define FT_CBM		5	/* 1581 partition */
#define FT_DJJ		6	/* 1581 */
#define FT_FAB		7	/* 1581 - Fred's format */
#define FT_REPLACEMENT	0x20
#define FT_LOCKED	0x40
#define FT_CLOSED	0x80


/* Access Control Methods */

#define FAM_READ	0
#define FAM_WRITE	1
#define FAM_APPEND	2
#define FAM_M		4
#define FAM_F		8


/* This structure is from cbmargc.c of fvcbm by Dan Fandrich */

#ifdef __GNUC__
#define PACK __attribute__ ((packed))	/* pack structures on byte boundaries */
#else
#define PACK		/* pack using a compiler switch instead */
#endif


typedef struct {
    BYTE    Link[2];		/* On the 1st entry only */

    BYTE    FileType PACK;
    BYTE    FirstTrack PACK;
    BYTE    FirstSector PACK;
    BYTE    FileName[16] PACK;
    BYTE    FirstSideTrack PACK;
    BYTE    FirstSideSector PACK;
    BYTE    RecordSize PACK;
    BYTE    Filler[4] PACK;
    BYTE    FirstReplacementTrack PACK;
    BYTE    FirstReplacementSector PACK;
    BYTE    FileBlocks[2] PACK;
} dirslot;



typedef struct bufferinfo_s {
    int     mode;		/* Mode on this buffer */
    int     readmode;		/* Is this channel for reading or writing */
    BYTE   *buffer;		/* Use this to save data */
    BYTE   *slot;		/* Save data for directory-slot */
    int     bufptr;		/* Use this to save/read data to disk */
    int     track;		/* which track is allocated for this sector */
    int     sector;		/*   (for write files only) */
    int     length;		/* Directory-read length */
} bufferinfo_t;


/*
 *  Run-time data struct for each drive
 */

typedef struct {
    int     type;		/* Device */

    /* Current image file */

    int     mode;		/* Read/Write */
    int     ImageFormat;	/* 1541/71/81 */
    int     ActiveFd;
    char    ActiveName[256];	/* Image name */
    char    ReadOnly;

    /* Disk Format Constants */

    int D64_Header;		/* flag if file has header! */
    int Bam_Track;
    int Bam_Sector;
    int Dir_Track;
    int Dir_Sector;


    /* Drive information */

    int     NumBlocks;		/* Total Count (683) */
    int     NumTracks;
    int     BSideTrack;		/* First track on the second side (1571: 36) */

    int     ErrFlg;		/* Flag if Error Data is available */
    char   *ErrData;

    BYTE   *dosrom;
    BYTE   *dosram;
    BYTE    bam[256];
    bufferinfo_t buffers[16];


    /* File information */

    BYTE    Dir_buffer[256];	/* Current DIR sector */
    int     SlotNumber;

    char   *find_name;		/* Search pattern */
    int     find_length;
    int     find_type;

    int     Curr_track;
    int     Curr_sector;
} DRIVE;


/*
 * Actually, serial-code errors ...
 */

#define FLOPPY_COMMAND_OK	0
#define FLOPPY_ERROR		(2)


/*
 * Return values used around.
 */

#define FD_OK		0
#define FD_EXIT		1	/* -1,0, 1 are fixed values */

#define FD_NOTREADY	-2
#define FD_CHANGED	-3	/* File has changed on disk */
#define FD_NOTRD	-4
#define FD_NOTWRT	-5
#define FD_WRTERR	-6
#define FD_RDERR	-7
#define FD_INCOMP	-8	/* DOS Format Mismatch */
#define FD_BADIMAGE	-9	/* ID mismatch (Disk or tape) */
#define FD_BADNAME	-10	/* Illegal filename */
#define FD_BADVAL	-11	/* Illegal value */
#define FD_BADDEV	-12
#define FD_BAD_TS	-13	/* Track or sector */


#define CHK_NUM		0
#define CHK_RDY		1
#define CHK_EMU		2	/* Is image block based */

#define D64_FILE_SIZE_35  174848  /* D64 image, 35 tracks */
#define D64_FILE_SIZE_35E 175531  /* D64 image, 35 tracks with errors */
#define D64_FILE_SIZE_40  196608  /* D64 image, 40 tracks */
#define D64_FILE_SIZE_40E  197376  /* D64 image, 40 tracks with errors */
				  
#define IS_D64_LEN(x)     ((x) == D64_FILE_SIZE_35 || (x) == D64_FILE_SIZE_35E || \
			   (x) == D64_FILE_SIZE_40 || (x) == D64_FILE_SIZE_40E)


extern int  attach_floppy_image(DRIVE *floppy, char *name, int mode);
extern void detach_floppy_image(DRIVE *floppy);
extern int floppy_read_block(int fd, int format, BYTE *buf, int track,
			     int sector, int d64);
extern int floppy_write_block(int fd, int format, BYTE *buf, int track,
			      int sector, int d64);
extern char *floppy_read_directory(DRIVE *floppy, const char *pattern);
extern char *read_disk_image_contents(const char *fname);

#endif  /* X64_DRIVE_H */
