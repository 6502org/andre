/*
 * $Id: cia1.h,v 1.1 1997/05/22 21:12:33 fachat Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Andre' Fachat (fachat@physik.tu-chemnitz.de)
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: cia1.h,v $
 * Revision 1.1  1997/05/22 21:12:33  fachat
 * Initial revision
 *
 */

/* Header for building cia1.c (CIA #1 emulation in the C64). */

#define	cia1_set_int_clk		maincpu_set_irq_clk
#define	CIA1_INT			IK_IRQ

/* #define CIA1_TIMER_DEBUG */

#define	INCLUDES
#define PRE_CIA_FUNCS

#define STORE_CIAPA 		cia1[addr] = byte;
#define STORE_CIAPB 		cia1[addr] = byte;

READ_CIAPA() 
{
	{
	    BYTE val = cia1[CIA_PRA] | ~cia1[CIA_DDRA];
	    BYTE msk = (cia1[CIA_PRB] | ~cia1[CIA_DDRB]) & ~joy[1];
	    int m, i;

	    /* FIXME: this is sloooow! */
	    for (m = 0x1; m <= 0x80; m <<= 1) {
		if (!(msk & m)) {
		    for (i = 0; i < KBD_ROWS; i++)
			if (keyarr[i] & m) {
			    val &= ~(1 << i);
			    break;
			}
		}
	    }
	    byte= val & ~joy[2];
	}
}

READ_CIAPB() 
{
	{
	    BYTE val = ~cia1[CIA_DDRB];
	    BYTE msk = (cia1[CIA_PRA] | ~cia1[CIA_DDRA]) & ~joy[2];
	    BYTE m;
	    int i;
	    
	    for (m = 0x1, i = 0; i < KBD_ROWS; m <<= 1, i++)
		if (!(msk & m))
		    val &= ~keyarr[i];
	    byte= (val | (cia1[CIA_PRB] & cia1[CIA_DDRB])) & ~joy[1];
	}
}

POST_CIA_FUNCS() 
{

int     show_keyarr(void)
{
    int     i, j;
    for (j = 0; j < KBD_ROWS; j++) {
	printf("%d:", j);
	for (i = 0x80; i; i >>= 1)
	    printf(" %d", keyarr[j] & i);
	printf("\n");
    }
    return (0);
}

}
