/*
 * $Id: reu.c,v 2.0 1997/05/22 20:51:57 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file contains routines for RAM Expansion Controller
 * Note: The 8726 for C128 has differences in 00,01,09 and 0a.
 *
 * Written by
 *   Jouko Valta (jopi@stekt.oulu.fi)
 *   Richard Hable (K3027E7@EDVZ.UNI-Linz.AC.AT)
 *
 * Fixes by
 *   Ettore Perazzoli (ettore@comm2000.it) [EP]
 *
 *
 * $Log: reu.c,v $
 * Revision 2.0  1997/05/22 20:51:57  ettore
 * Some errors corrected and fixed address mode implemented.
 *
 * Revision 1.11  1996/04/01  09:01:41  jopi
 * *** empty log message ***
 *
 * Revision 1.10  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * REU size changed to init parameter.
 *
 * Revision 1.9  1994/12/12  16:59:44  jopi
 * *** empty log message ***
 *
 * Revision 1.8  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.7  1994/06/08  03:20:05  jopi
 * Patchlevel 2
 * Cleaned up.
 *
 * Revision 1.6  1994/02/18  16:10:57  jopi
 * New debugger & arg parser and x128
 *
 * Revision 1.5  1994/01/26  16:08:37  jopi
 * X64 version 0.2 PL 1
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:39:19  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 */


#include <stdio.h>
#include <string.h>
#include <malloc.h>

#include "maincpu.h"
#include "macro.h"
#include "memory.h"
#include "extern.h"

/* #define REU_DEBUG */

/*
 * Status and Command Registers
 * bit	7	6	5	4	3	2	1	0
 * 00	Int	EOB	Fault	RamSize	________ Version ________
 * 01	Exec	0	Load	Delayed	0	0	   Mode
 */


/* global */

static ADDR_T  ReuSize = REUSIZE << 10;
static BYTE    reuc[16];        /* REC registers */
static BYTE   *reuram = 0;


int    reset_reuc(char *file_name, ADDR_T size)
{
    int i;

    if (file_name == NULL)
	file_name = app_resources.reuName;
    
    if (size > 0)
	ReuSize = size;

    for (i=0; i < 16; i++)
	reuc[i] = 0;

    if (ReuSize >= 256)
	reuc[0] = 0x50;
    else
	reuc[0] = 0x40;

    reuc[1] = 0x4A;
	
    if (reuram == NULL) {
	reuram = allocate_mem(ReuSize);
	printf("REU: %dKB unit installed.\n", REUSIZE);
	if (Load_Sys_File("", file_name, reuram, -1, ReuSize) >= 0) {
	    printf ("REU: image `%s' loaded successfully.\n", file_name);
	} else {
	    printf ("REU: (no image loaded).\n");
	}
    }

    return 0;
}
  
void	activate_reuc(void)
{
    if (app_resources.reu && reuram == NULL)
	reset_reuc(NULL, 0);
}

void    close_reuc(char *file_name)
{
    if (reuram == NULL)
	return;
    
    if (file_name == NULL)
	file_name = app_resources.reuName;

    if (ReuSize == SaveFile("", file_name, reuram, -1, ReuSize))
	printf("REU: image `%s' saved successfully.\n", file_name);
    else
	fprintf(stderr,"REU: cannot save image `%s'.\n", file_name);
}


BYTE    read_reuc(ADDRESS addr)
{
    BYTE retval;

    if (reuram == NULL)
	reset_reuc(NULL, 0);
    
    switch (addr) {
      case 0x0:
	/* fixed by [EP], 04-16-97. */
	retval = (reuc[0] & 0x60) | (((ReuSize >> 10) >= 256) ? 0x10 : 0x00);
	reuc[0] &= ~0xe0;	/* Bits 7-5 are cleared when register is
				   read. */
	break;
	
      case 0x6:
	/* wrong address of bank register corrected - RH */
	retval = reuc[6] | 0xf8;
	break;

      case 0x9:
	retval = reuc[6] | 0x3f;
	break;

      case 0xb:
      case 0xc:
      case 0xd:
      case 0xe:
      case 0xf:
	retval = 0xff;
	break;

      default:
	retval = reuc[addr];
    }

#ifdef REU_DEBUG
    printf("REU: read [$%02X] => $%02X\n", addr, retval);
#endif
    return retval;
}


void    store_reuc(ADDRESS addr, BYTE byte)
{
    if (reuram == NULL)
	reset_reuc(NULL, 0);
    
    reuc[addr] = byte;

#ifdef REU_DEBUG
    printf("REU: store [$%02X] <= $%02X\n", addr, (int) byte);
#endif

    /* write REC command register
     * DMA only if execution bit (7) set  - RH */
    if ((addr == 0x1) && (byte & 0x80))
	reu_dma(byte & 0x10);
}

/* this function is called when write to REC command register or memory
 * location FF00 is detected. There is trigger code in memory.c too.
 *
 * If host address exceeds ffff transfer contiues at 0000.
 * If reu address exceeds 7ffff transfer continues at 00000.
 * If address is fixed the same value is used during the whole transfer.
 */ 
/* Added correct handling of fixed addresses with transfer length 1  - RH */
/* Added fixed address support - [EP] */

void    reu_dma(int immed)
{
    static int delay = 0;
    unsigned int len, reu;
    int reu_step, host_step;
    ADDRESS host;
    BYTE c;
    
    if (!immed) {
	delay++;
	return;
    }
    else {
	if (!delay && (immed < 0))
	    return;
	delay = 0;
    }

    /* wrong address of bank register & calculations corrected  - RH */
    host = (ADDRESS)(reuc[2]) | ( (ADDRESS)( reuc[3] ) << 8 );
    reu  = (int)(reuc[4]) | ((int)(reuc[5]) << 8) | ((int)(reuc[6] & 7) << 16);
    if (( len = (int)(reuc[7]) | ( (int)(reuc[8]) << 8)) == 0)
	len = 0x10000;

    /* Fixed addresses implemented -- [EP] 04-16-97. */
    host_step = reuc[0xA] & 0x80 ? 0 : 1;
    reu_step = reuc[0xA] & 0x40 ? 0 : 1;
    clk += len;

    switch (reuc[1] & 0x03) {
      case 0: /* C64 -> REU */
#ifdef REU_DEBUG
	printf("REU: copy ext $%05X %s<= main $%04X%s, $%04X (%d) bytes.\n",
	       reu, reu_step ? "" : "(fixed) ", host,
	       host_step ? "" : " (fixed)", len, len);
#endif
	for (; len--; host += host_step, reu += reu_step)
	    reuram[reu % ReuSize] = LOAD(host & 0xffff);
	break;

      case 1: /* REU -> C64 */
#ifdef REU_DEBUG
	printf("REU: copy ext $%05X %s=> main $%04X%s, $%04X (%d) bytes.\n",
	       reu, reu_step ? "" : "(fixed) ", host,
	       host_step ? "" : " (fixed)", len, len);
#endif
	for (; len--; host += host_step, reu += reu_step )
	    STORE((host & 0xffff), reuram[reu % ReuSize]);
	break;

      case 2: /* swap */
        /* for-loop corrected - RH */
	clk += len;		/* [EP] 04-16-97. */
#ifdef REU_DEBUG
	printf("REU: swap ext $%05X %s<=> main $%04X%s, $%04X (%d) bytes.\n",
	       reu, reu_step ? "" : "(fixed) ", host,
	       host_step ? "" : " (fixed)", len, len);
#endif
	for (; len--; host += host_step, reu += reu_step ) {
	    c = reuram[reu % ReuSize];
	    reuram[reu % ReuSize] = LOAD(host & 0xffff);
	    STORE((host & 0xffff), c);
	}
	break;

      case 3: /* compare */
#ifdef REU_DEBUG
	printf("REU: compare ext $%05X %s<=> main $%04X%s, $%04X (%d) bytes.\n",
	       reu, reu_step ? "" : "(fixed) ", host,
	       host_step ? "" : " (fixed)", len, len);
#endif
	while (len--) {
	    if (reuram[reu % ReuSize] != LOAD(host & 0xffff)) {
		reuc[0] |= 0x20; /* FAULT */
		break;
	    }
	    host += host_step; reu += reu_step;
	}
	break;
    }

    if (!(reuc[1] & 0x20)) {
	/* not autoload
         * incr. of addr. disabled, as already pointing to correct addr.
	 * address changes only if not fixed, correct reu base registers  -RH
	 */
#ifdef REU_DEBUG
	printf("No autoload\n");
#endif
        if ( !(reuc[0xA] & 0x80)) {
	    reuc[2] = LOWER(host);
	    reuc[3] = UPPER(host);
	}
        if ( !(reuc[0xA] & 0x40)) {
	    reuc[4] = LOWER(reu);
	    reuc[5] = UPPER(reu);
	    reuc[6] = (reu>>16);
	}

	reuc[7] = 1;
	reuc[8] = 0;
    }

    /* [EP] 04-16-97. */
    reuc[0] |= 0x40;
    reuc[1] &= 0x7f;
}

