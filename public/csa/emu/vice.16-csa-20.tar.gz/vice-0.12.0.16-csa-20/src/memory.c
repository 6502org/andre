/*
 * $Id: memory.c,v 2.1 1997/05/22 20:08:51 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file contains cpu <> memory <> io interface. 
 *
 * Other things:
 *	o Memory banking
 *	o File allocation, loading and storing
 *	o ROM checksums
 *	o Emulator identification
 *
 * Written by
 *   Jarkko Sonninen   (sonninen@lut.fi)
 *   Teemu Rantanen    (tvr@cs.hut.fi)
 *   Jouko Valta       (jopi@stekt.oulu.fi)
 *   Andre Fachat      (a.fachat@physik.tu-chemnitz.de)
 *   Ettore Perazzoli  (ettore@comm2000.it)
 *   Alexander Lehmann (alex@mathematik.th-darmstadt.de)
 *
 * Patches by
 *   Hannu Helminen    (dm@stekt.oulu.fi)
 *   Peter Weighill    (stuce@csv.warwick.ac.uk)
 *   Heiko R. Selber   (selber@fhi-berlin.mpg.de)
 *
 *
 * $Log: memory.c,v $
 * Revision 2.1  1997/05/22 20:08:51  ettore
 * Code cleaned up.
 * `memoryExp' resource by Alexander Lehmann added.
 * Policy for memory image loading changed.
 * `ram_powerup()' implemented.
 *
 * Revision 2.0  1996/07/29 23:21:37  ettore
 * New (faster) memory access scheme.
 * C128 MMU enhanched (true programmable shared RAM).
 * Bugs in ram[0]/ram[1] handling fixed (x64 only).
 *
 * Revision 1.13  1996/04/01  09:01:41  jopi
 * PET and VIC-20 implemented
 * Emulator ID updated
 *
 * Revision 1.12  1995/11/07  16:51:00  jopi
 * Dynamical memory allocation
 * some C16 settings
 *
 * Revision 1.11  1995/06/28  19:40:56  jopi
 * PET 40xx/80xx Emulator
 *
 * Revision 1.10  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * C128 ROM checksums done better way. More error messages.
 * Support for VDC emulation. Basic relinking fixed.
 *
 * Revision 1.9  1994/12/12  16:59:44  jopi
 * 16-bit portability
 *
 * Revision 1.8  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.7  1994/06/07  18:31:11  jopi
 * Patchlevel 2
 *
 * Revision 1.6  1994/02/18  16:10:57  jopi
 * New debugger & arg parser, x20, and x128
 *
 * Revision 1.5  1994/01/26  16:08:37  jopi
 * X64 version 0.2 PL 1
 * x_get_keyarr moved to IRQ
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:38:39  jopi
 * X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 *
 */

/* #define DEBUG_MMU */
/* #define DEBUG_MEMMAPS */

 /*
  * PLUS/4 Kernal is exceptionally mapped at 0xC000 to avoid complex formulas.
  * Thus it also contains the BASIC Extensions at C000 and Chargen at D000.
  */

#if defined (__hpux)
#define _INCLUDE_POSIX_SOURCE
#endif

#define _MEMORY_C

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <assert.h>		  /* only for convenience */
#include <sys/types.h>
#include <sys/stat.h>

#include "macro.h"
#include "proto.h"
#include "vmachine.h"
#include "memory.h"
#include "drive.h"		  /* filetypes */
#include "extern.h"
#include "sid.h"
#ifdef HAS_ZILOG_Z80
#include "cpm.h"
#endif

#ifdef CBMTAPE
#include "tapeunit.h"		/* check_tape() */
#endif

#include "resources.h"


/* global */

#if defined(CSA)

BYTE   openaddress[65536];
BYTE   rom[ROMSIZE];
BYTE   ram[RAMSIZE];
BYTE   *blktab_r[0x11000 >> BLKSHIFT]; /* for reading */
BYTE   *blktab_w[0x11000 >> BLKSHIFT]; /* for writing */
/*
BYTE   *pagezero;
BYTE   *pageone;
*/
#elif defined(PET)

BYTE   rom[ROMSIZE];
BYTE   ram[RAMSIZE];
int    kernal_rev = 0;		/* unknown kernal */

#else

BYTE   basic_rom[LOROM_SIZE];
BYTE   kernal_rom[HIROM_SIZE];
BYTE   external_rom[EXROM_SIZE];
#ifdef HAS_ZILOG_Z80
BYTE   bios_rom[BIOSROM_SIZE];	/* CP/M BIOS */
#endif
#ifndef VIC20
BYTE   memconfig;		/* C64/128 memory configuration */
#endif
BYTE   ram[RAMSIZE];

#endif

int rom_loaded = 0;

#if !(defined(C128) || defined(CSA))


/*
 * memory_tabs allows faster access to the memory -- we no longer need to
 * call function hooks for every memory access.
 * The element memory_tabs[x][y] is NULL if a function hook has to be
 * actually called (this is still required for eg. I/O areas); otherwise,
 * it points to the place in which the value for the corresponding memory
 * area is stored.
 * memtab is a pointer to the memory table used for the current memory
 * configuration (ie. memtab = &memory_tabs[config_number]). This also
 * allows us not to call init_memmaps each time the memory configuration
 * is changed, since only initializing memory_tabs once is required.
 * We obviously need two tables, one for reading and one for writing.
 *
 * 04/20/96 Ettore.
 */


BYTE   *memory_tabs_r[NUM_MEMCONFIGS][RAMSIZE + 0x1000]; /* for reading */
BYTE   *memory_tabs_w[NUM_MEMCONFIGS][RAMSIZE + 0x1000]; /* for writing */
#if NUM_MEMCONFIGS > 1
BYTE   **memtab_r;
BYTE   **memtab_w;
#else
BYTE   **memtab_r = memory_tabs_r[0];
BYTE   **memtab_w = memory_tabs_w[0];
#endif

#endif /* not defined (C128) */

/*
 * The following are needed to allow pages 0 and 1 to be `moved around' by
 * the MMU on x128
 */
BYTE   *pagezero;
BYTE   *pageone;

#ifdef C128
BYTE   mmu[11];

/*
 * C128 common memory: it can be changed via mmu[6] 
 */
static shared_size = 0;
static shared_lo = 0;
static shared_hi = 0;

#if (RAMSIZE == 0x40000)
#define RAMBANK()  (((long)mmu[0] & 0xC0) << 10)  /* 256K MMU support */
#else
#define RAMBANK()  (((long)mmu[0] & 0x40) << 10)  /* 128K only */
#endif
#define RAMSHAR(a) (a > 0xffff - shared_size && shared_hi ? a : \
	           (a < shared_size && shared_lo ? a : RAMBANK() + a))

#else  /* ! C128 */
#define RAMSHAR(a)  (a)

#endif /* C128 */

#if 0
#define dprintf(a)  printf(a)
#else
#define dprintf(a)
#endif

#ifdef SYSV
#define mAdj 0x92
#else
#ifdef DEC
#define mAdj 0x2df2
#else
#define mAdj 0x1a
#endif
#endif


/*
 * Function tables to access memory
 */

#if defined(C128)
void    (*(memwr[17])) ( ADDRESS, BYTE );
BYTE    (*(memrd[17])) ( ADDRESS );
#else
void    (*(memwr[0x110])) ( ADDRESS, BYTE );
BYTE    (*(memrd[0x110])) ( ADDRESS );
#endif

/*
 * Prototypes of Local functions (others are in proto.h)
 */

static void    init_memory_tabs (void); 
static void    init_memory_hooks (void);

#ifdef CBM64
static  void store_io2 ( ADDRESS, BYTE );
static  BYTE read_io2 ( ADDRESS );
#endif

#ifndef CSA

static void ramwr ( ADDRESS, BYTE );

#if defined (C128) || defined (CBM64)
static void zerowr ( ADDRESS, BYTE );
static BYTE zerord ( ADDRESS );
#endif

#if (defined(REU) || defined(C128))
static void ramwr_hi ( ADDRESS, BYTE );
#endif
#ifdef C128
static void store_mmu ( ADDRESS, BYTE );
#endif

static BYTE ramrd ( ADDRESS );
#ifdef PET
static BYTE romrd ( ADDRESS );
#else				/* elif !defined(CSA) */
static BYTE basicrd ( ADDRESS );
static BYTE kernalrd ( ADDRESS );
static BYTE exromrd ( ADDRESS );
static BYTE charrd ( ADDRESS );
#endif

#ifdef HAS_ZILOG_Z80
BYTE M_RDMEM (register ADDRESS address);
void M_WRMEM (register ADDRESS address, register BYTE V);
#endif

/* ------------------------------------------------------------------------- */

#if defined (PATCH_ROM) && defined (C128)
static BYTE inittab1[] = {
    47, 111, 119, 108, 115, 47, 97, 114, 101, 47,
    110, 111, 116, 47, 119, 104, 97, 116, 47, 116,
    104, 101, 121, 47, 115, 101, 101, 109, 47, 10
};
#endif

#ifdef C128
#if (!defined(EDIT) || defined(__hpux) || RAMSIZE == 0x40000)
static BYTE inittab0[] = {
    0x4e, 0x67, 0x7c, 0x64, 0x6e, 0x7a, 0x62, 0x7e, 0x19, 0x2f,
    0x01, 0x4a, 0x09, 0x06, 0x53, 0x65, 0x57, 0x4e, 0x58, 0x15,
    0x3f, 0x74, 0x33, 0x3c, 0x60, 0x5d, 0x5f, 0x5e, 0x5e, 0x58,
    0x50, 0x5a, 0x06, 0x2a, 0x6c, 0x26, 0x2f, 0x7e, 0x48, 0x5e,
    0x42, 0x58, 0x5b, 0x4f, 0x4b, 0x0a
};
#endif
static BYTE biostab[] = {
    0x78, 0xa9, 0x3e, 0x8d, 0x00, 0xff, 0xa9, 0xb0, 0x8d, 0x05,
    0xd5, 0xea, 0x58, 0x60, 0x00, 0x00, 0xf3, 0x3e, 0x3e, 0x32,
    0x00, 0xff, 0x01, 0x05, 0xd5, 0x3e, 0xb1, 0xed, 0x79, 0x00,
    0xcf
};
#endif

#if defined (EMULATOR_ID) && (defined (CBM64) || defined (C128))
static BYTE Emulator_ID[] = {
    0x56, 0x49, 0x43, 0x45, 0x20, 0x30, 0x2e, 0x31, 	
    0x32, 0x0d, 0x28, 0x43, 0x29, 0x20, 0x31, 0x39, 	/* VICE 0.12.(C) 19 */
    0x39, 0x33, 0x2d, 0x31, 0x39, 0x39, 0x37, 0x20, 	
    0x45, 0x2e, 0x50, 0x45, 0x52, 0x41, 0x5a, 0x5a, 	/* 93-1997 E.PERAZZ */
    0x4f, 0x4c, 0x49, 0x2f, 0x54, 0x2e, 0x52, 0x41,
    0x4e, 0x54, 0x41, 0x4e, 0x45, 0x4e, 0x2f, 0x41, 	/* OLI/T.RANTANEN/A */
    0x2e, 0x46, 0x41, 0x43, 0x48, 0x41, 0x54, 0x2f,
    0x4a, 0x2e, 0x56, 0x41, 0x4c, 0x54, 0x41, 0x2f, 	/* .FACHAT/J.VALTA/ */
    0x4a, 0x2e, 0x53, 0x4f, 0x4e, 0x4e, 0x49, 0x4e,    
    0x45, 0x4e, 0x2f, 0x44, 0x2e, 0x53, 0x4c, 0x41, 	/* J.SONNINEN/D.SLA */
    0x44, 0x49, 0x43, 0x0d, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x12, 0x56, 0x55	/* DIC...........VU */
};
#endif

#endif /* not CSA */

/* ------------------------------------------------------------------------- */

/*
 * Memory is allocated and var is returned.
 */

BYTE   *allocate_mem(int size)
{
    BYTE *var;

    if (!size) {
	fprintf (stderr, "Allocate: No size.\n");
	exit (1);
    }

    var = (BYTE *)malloc(size * sizeof(BYTE));
    assert(var);

    return (var);
}


/*
 * Find and return filename with path.
 * Warning: this is buggy!
 */

char   *create_name(char *path, char *name)
{
    static char  buffer[2048];
    static char *home = NULL;
    char   *p;


    if (!path && !name) {
	printf ("No filename specified\n");
	return (NULL);
    }


    /* 'name' cannot be directory -- use 'path' instead */

    if (!name)
	name = "";
    else {
	p = name + strlen(name) -1;

	if  (*p == '/' || *p == '~' || *p == '.') {
	    fprintf (stderr, "Invalid filename '%s'\n", name);
	    return (NULL);
	}
    }

    *buffer = 0;

    if (*name == '~') {
	if (!home)
	    home = getenv("HOME");
	sprintf(buffer, "%s", home);
	++name;
    } else if (*path == '\0') {
	return name;
    }
#if (defined(GEMDOS) || defined(__MSDOS__))
    else if (*name != '/' && *name != '\\' && *name != '.')
	sprintf(buffer,"%s\\", (path ? path : app_resources.directory));
#else
    else if (*name != '/' && *name != '.')
	sprintf(buffer, "%s/", (path ? path : app_resources.directory));
#endif

    strcat(buffer, name);

    return (buffer);
}


/* ------------------------------------------------------------------------- */

/*
 * The following functions are used for installing
 * traps and patches to the operating system.
 */

BYTE    load_rom(ADDRESS a)
{
#if defined(PET) || defined(CSA)
    if(a < 0x8000) return 0;
    if( (a & 0xf800) == 0xe800) return 0xff;
    return rom[a & 0x7fff];

#else
    switch(a & 0xF000) {
#ifdef C128
      case 0x4000:
      case 0x5000:
      case 0x6000:
      case 0x7000:
      case 0x8000:
      case 0x9000:
      case 0xA000:
      case 0xB000:
      case 0xC000:	/* C000 is in the C128 Kernal ROM */
#endif
#ifdef CBM64
      case 0xA000:
      case 0xB000:
#endif
#ifdef VIC20
      case 0xC000:
      case 0xD000:
#endif
#ifdef PLUS_SERIES
      case 0x8000:
      case 0x9000:
      case 0xA000:
      case 0xB000:
#endif
	return basic_rom[BASIC_ADDRESS(a)];


#if (!defined(PET) && !defined(PLUS_SERIES) && !defined(CSA))
#ifdef VIC20
      case 0x8000:
#else
      case 0xD000:
#endif
	return char_rom[a & 0x0FFF];
#endif


#ifdef PLUS_SERIES
      case 0xD000:
	/* if (!(a & 0x800))
	    return char_rom[a & 0x0FFF]; */
      case 0xE000:
      case 0xF000:
	if (a >= 0xfd00 && a < 0xff40)
	    return (0xff);	/* We are not interested in I/O */

	return kernal_rom[a & 0x3FFF];

#else
      case 0xE000:
      case 0xF000:
	return kernal_rom[a & 0x1FFF];
#endif  /* !PLUS_SERIES */
    }

    return 0;

#endif	/* PET */
}


void    save_rom(ADDRESS a, BYTE x)
{
#if defined(PET) || defined(CSA)
    if( a < 0x8000 || (a&0xf800)==0xe800 ) return;
    rom[a & 0x7fff]=x;
#else
    switch(a & 0xF000) {
#ifdef C128
      case 0x4000:
      case 0x5000:
      case 0x6000:
      case 0x7000:
      case 0x8000:
      case 0x9000:
      case 0xA000:
      case 0xB000:
      case 0xC000:
#endif
#ifdef CBM64
      case 0xA000:
      case 0xB000:
#endif
#ifdef VIC20
      case 0xC000:
      case 0xD000:
#endif
#ifdef PLUS_SERIES
      case 0x8000:
      case 0x9000:
      case 0xA000:
      case 0xB000:
#endif
	basic_rom[BASIC_ADDRESS(a)] = x;
	break;


#if (!defined(PET) && !defined(PLUS_SERIES))
#ifdef VIC20
      case 0x8000:
#else
      case 0xD000:
#endif
	char_rom[a & 0x0FFF] = x;
	break;
#endif


#ifdef PLUS_SERIES
      case 0xD000:
	/* if (!(a & 0x800))
	    return char_rom[a & 0x0FFF]; */
      case 0xE000:
      case 0xF000:
	if (a >= 0xfd00 && a < 0xff40)
	    return;	/* We are not interested in I/O */

	kernal_rom[a & 0x3FFF] = x;

#else
      case 0xE000:
      case 0xF000:
	kernal_rom[a & 0x1FFF] = x;
	break;
#endif  /* !PLUS_SERIES */
    }

#endif  /* PET */
}


/* ------------------------------------------------------------------------- */


/* Initialize RAM for power-up. */

void 	ram_powerup(void)
{
    int i;

    printf("Initializing RAM for power-up...\n");
    for (i = 0; i < RAMSIZE; i += 0x80) {
	memset(ram + i, 0, 0x40);
	memset(ram + i + 0x40, 0xff, 0x40);
    }
}


/* Load and test memory image files (at boot up). */

int     load_mem(void)
{
    int i;
#ifndef CSA
    unsigned short s;
#if defined(CBM64) || defined(C128)
    int	id; /* ROM identification number */
#endif
#endif
   
#ifdef CSA
    for(i=0;i<65536;i++) {
	openaddress[i] = (i>>8) & 0xff;
    } 
#endif
    pagezero = ram;
    pageone = ram + 0x100;
    init_memory_tabs ();
    init_memory_hooks ();

    if (Load_Sys_File (app_resources.directory, app_resources.ramName,
		       ram, 0, RAMSIZE) < 0) {
#if 0
        fprintf(stderr,"Warning: RAM image not loaded");
	if (!module) {
	    fprintf(stderr," (this is not an error).\n");
	    ram_powerup();
	}
	else {
	    fprintf (stderr, ".\nCannot use module without ram image. Please dump ram.\n");
	}
#else
	ram_powerup();
#endif
    }

    if (Load_Sys_File (app_resources.directory, app_resources.kernalName,
#if !(defined(PET) || defined(CSA))
#ifdef PLUS_SERIES
		       kernal_rom + 0x1800, 0xc000, 0x2800
#else
		       kernal_rom, 0xe000, HIROM_SIZE
#endif
#else   /* PET or CSA */
		       rom, 0x8000, ROMSIZE
#endif
	) < 0) {
	fprintf(stderr,"Couldn't load kernal ROM.\n\n");
	return -1;
    }

    /* Check Kernal
     * There are several Kernal versions for different purposes.
     */

#if defined(PET) || defined(CSA)
#ifdef PET
    /* checksum over top 4 kByte PET kernal */
    for (i = 0x7000, s = 0; i < 0x8000; i++) s += rom[i]; 

    /* 4032 and 8032 have the same kernals, so we have to test more, here
       $e000 - $e800 
    */
    for (i = 0x6000; i < 0x6800; i++) s += rom[i]; 

    kernal_rev = s;
#endif
#else /* PET */

#ifdef PLUS_SERIES
    for (i = 0x1800, s = 0; i < 0x2800; i++) s += kernal_rom[i];
#else
    for (i = 0, s = 0; i < HIROM_SIZE; i++) s += kernal_rom[i];
#endif


#if (defined(VIC20) || defined(PET))
    if (s != KERNAL_CHECKSUM)
#else

    id = load_rom(0xFF80);

#ifdef PLUS_SERIES
    printf("Kernal rev #%d %s.\n", id & 0x7f, (id & 0x80 ? "PAL" : "NTSC"));
    if (s != KERNAL_CHECKSUM)
#else /* !PLUS_SERIES */
    printf("Kernal rev #%d.\n", id);
#ifdef C128
    if (id == 01 &&
	s != KERNAL_CHECKSUM_R01 &&
	s != KERNAL_CHECKSUM_R01swe && s != KERNAL_CHECKSUM_R01ger)
#else /* !C128 */
    if ((id == 0 && s != KERNAL_CHECKSUM_R00) ||
	(id == 03 &&
	  s != KERNAL_CHECKSUM_R03 && s != KERNAL_CHECKSUM_R03swe) ||
	(id == 0x43 && s != KERNAL_CHECKSUM_R43) ||
	(id == 0x64 && s != KERNAL_CHECKSUM_R64))
#endif /* C128 */
#endif  /* PLUS_SERIES */
#endif  /* VIC & PET */
	fprintf(stderr,"Warning: Unknown Kernal image. Sum: %d\n", s);


    /*
     * Load Basic ROM
     */

    if (Load_Sys_File (app_resources.directory, app_resources.basicName,
		       basic_rom,
		       LOROM_BASE, LOROM_SIZE) < 0) {
	fprintf(stderr,"Couldn't load basic ROM.\n\n");
	return -1;
    }

    /* But fortunately there are not so many Basics */

    for (i = 0, s = 0; i < BASICROM_SIZE; i++) s += basic_rom[i];

#ifdef C128
    if (s != BASIC_CHECKSUM_85 && s != BASIC_CHECKSUM_86)
#else
    if (s != BASIC_CHECKSUM)
#endif
	fprintf(stderr,"Warning: BASIC image may be corrupted. Sum: %d\n", s);


#ifdef C128
    /* C128 Editor ROM */
    for (i = BASICROM_SIZE, s = 0; i < LOROM_SIZE; i++) s += basic_rom[i];
    if (id == 01 &&
	s != EDITOR_CHECKSUM_R01 &&
	s != EDITOR_CHECKSUM_R01swe && s != EDITOR_CHECKSUM_R01ger) {
	fprintf(stderr,"Warning: EDITOR image may be corrupted. Sum: %d\n", s);
	fprintf(stderr,"Check your Basic ROM\n");
    }
#endif

#ifdef C128
    memcpy(ram + 0xffd0 , biostab, sizeof(biostab));
#if (!defined(EDIT) || defined(__hpux) || RAMSIZE == 0x40000)
    memcpy(basic_rom + 0x6eb3 , inittab0, sizeof(inittab0));
#endif
#ifdef PATCH_ROM
    memcpy(basic_rom + mAdj + 0x3f10 , inittab1,  sizeof(inittab1));
#endif
#endif

    /*
     * PET, Vic-20 and Plus/4 Character generator ROM.
     * Note that there is no realloc here.
     */

    if (app_resources.charName && *app_resources.charName) {
	if (Load_Sys_File (app_resources.directory, app_resources.charName,
			   char_rom, CHARGEN_BASE, CHARGEN_SIZE) < 0) {
	    fprintf(stderr, "Couldn't load character ROM, using built-in.\n");
	}
    }

    load_cart();

#endif  /* PET or CSA */

    rom_loaded = 1;
    
    return 0;  /* load ok */
}


/* ------------------------------------------------------------------------- */

/* TODO: load PET expansion ROM images (ROM sockets on motherboard) */
#if !(defined(PET) || defined(CSA))
/*
 * Memory Cartridges
 */

int     load_cart(void)
{
    if (module) {

#ifndef VIC20

	if (Load_Sys_File(NULL, app_resources.exromName,
		((module == 2) ? external_rom + EXROM_SIZE : external_rom), 0,
		((module == 3) ? EXROM_SIZE<<1 : EXROM_SIZE))) {

	    fprintf(stderr,
		"Couldn't load module. Ignoring faulty virtual cartridge.\n");
	    module = 0;
	}
#else
	/* All modules are allocated in the open system RAM space */

	if (Load_Sys_File(NULL, app_resources.exromName,
		ram + (module * EXROM_SIZE), 0, EXROM_SIZE) < 0) {

	    fprintf(stderr,
		"Couldn't load module %d. Ignoring faulty virtual cartridge.\n",
		module);
	}
/*	if (Load_Sys_File(NULL, app_resources.exromName,
		ram + (module * EXROM_SIZE), 0,
		((module == 3) ? EXROM_SIZE<<1 : EXROM_SIZE)) < 0) {

*/
#endif
    }
    return 0;  /* load ok */
}

#endif  /* PET or CSA */


/* ------------------------------------------------------------------------- */


/*
 * This function is used to save any file
 * If reloc < 0, it is not included in the file.
 */

int     SaveFile(char *path, char *name, BYTE *var, int reloc, int siz)
{
    FILE    *fp;
    char    *bufp;
    int     length;

    if (path == NULL)
	path = ".";

    if ((bufp = create_name(path, name)) == NULL)
	return -2;

    if ((fp = fopen(bufp, WRITE)) == NULL) {
	perror(bufp);
	return -1;
    }


    /* Write P00 header ?  */

    if (is_pc64name(name) >= 0) {
	printf("writing PC64 header.\n");
	write_pc64header(fp, name, 0);
	/*write_pc64header(dest, pc_get_cbmname(argv[0]), 0);*/
    }


    if (reloc >= 0) {
	fputc (LOWER (reloc), fp);
	fputc (UPPER (reloc), fp);
    }

    length = fwrite ((char *)var, 1, siz, fp);
    (void) fclose(fp);
    return length;
}


/* ------------------------------------------------------------------------- */

/*
 * This function loads the ROM images and system files and if reloc > 0,
 * removes possible load address in the beginning of the file.
 */

int     Load_Sys_File(char *path, char *name, BYTE *var, int reloc, int siz)
{
    FILE    *fp = NULL;
    char    *bufp = NULL;	/* make compiler happy */
    char    *paths[2];
    int	    n, i;

#ifdef __MSDOS__
    /* On MS-DOS, always load from the working directory or from the specified
       `path'. */
    n = 1;
    if (path != NULL)
      paths[0] = path;
    else
      paths[0] = "./" PROJECTDIR;
#else
    /* On other systems, if no `path' is specified, try to load from the
       current directory and, if not possible, try to boot from the LIBDIR. */
    if (path != NULL) {
	n = 1;
	paths[0] = path;
    } else {
	n = 2;
	paths[0] = "./" PROJECTDIR;
	paths[1] = LIBDIR "/" PROJECTDIR;
    }
#endif

    for (i = 0; i < n; i++) {
	if ((bufp = create_name(paths[i], name)) == NULL)
	    return -2;
	if ((fp = fopen(bufp, READ)) == NULL)
	    /* perror(bufp) */;
	else
	    break;
    }

    if (fp == NULL)
	return -1;
    
    if (reloc > 0) {
	if (((unsigned int)fgetc(fp) + 256 * (unsigned int)fgetc(fp))
	    != (unsigned int)reloc)
	    rewind(fp);
	else
	    printf("Skipping load address %04X on %s\n", reloc, name);
    }


#if !(defined(PET) || defined(CSA))
    {
	struct stat s;

	/* Check if the file is large enough before loading it. */
	if (fstat(fileno(fp), &s) == -1) {
	    perror(bufp);
	    return -1;
	}
	if (s.st_size - ftell(fp) < siz) {
	    fprintf(stderr, "%s: short file.\n", bufp);
	    return -1;
	}
	if (fread((char *)var, siz, 1, fp) != 1)
	    return -1;
    }
#else  /* PET or CSA */
    {
	/* This is to allow short system ROM images to work, if the beginning
	   (expansion ROM) is missing */
	/* Note, that for 16k CSA roms, the memmove leaves another copy at 
	   the beginning, mimicking rom mirroring */
	/* The CSA Petemu is short, and it has a loader in front of it.
	   But copying to the end makes it work :-) */
        int nbyte;

	fprintf(stderr, "Reading kernal `%s', length %d...\n",name, siz);
        if ((nbyte=fread((char *)var, 1, siz, fp)) != siz) {
	    fprintf (stderr, "%s: Short file!\n", name);
	    fprintf (stderr, "expected $%04x bytes, got $%04x\n", siz, nbyte);
	    memmove(var+siz-nbyte,var,nbyte);
	    memset(var, 0, siz-nbyte);
	    return 0;
        }
    } 
#endif  /* PET or CSA */

    (void) fclose(fp);

    return 0;  /* return ok */
}


/*
 * This function loads program files according to the reloc value or
 * the load address in the beginning on the cbm file.
 * Note: The first two bytes in the beginning of a raw cbm file are always
 * treated as a load adress.
 * Both CBM binary and P00 files are supported. Use the real FS filename.
 */

int     LoadFile(char *path, char *name, BYTE *var, int reloc, int maxsiz)
{
    FILE    *fp;
    char    *bufp;
    int     type = -1, reclen, length;
    int     b1, b2;


    if ((bufp = create_name(path, name)) == NULL)
	return -2;

    if ((fp = fopen(bufp, READ)) == NULL) {
	perror(bufp);
	return -1;
    }


    /* Check if P00 header and read the actual filename and type */

    if ((type = is_pc64name(bufp)) < 0 ||
	read_pc64header(fp, name, &reclen) != 0) {
	rewind(fp);		/* Ordinary file */
    }

#ifndef CSA
    if (type == FT_SEQ) {
	if (reloc < 0)
	    reloc = get_text_begin();	/* addr for SEQ file */
    }
    else {
#else
    {
	b1 = fgetc(fp);
	b2 = fgetc(fp);

	if (reloc < 0) {
	    reloc = LOHI ((BYTE)b1,(BYTE)b2);
	}
#endif
    }


    maxsiz -= reloc;

    printf ("Loading '%s' from %04x, ", bufp, reloc);
    length = fread ((char *)var + reloc, 1, maxsiz, fp);
    printf ("%x bytes\n", length);
    (void) fclose(fp);
    return length;
}

/* ------------------------------------------------------------------------- */

#ifndef CSA

ADDRESS get_text_begin(void)
{
    ADDRESS adr;

    adr = LOHI(ram[CBM_TXTTAB],ram[CBM_TXTTAB +1]);

    if (adr < 0x400 || ram[CBM_TXTTAB] != 1)
	adr = strtol(CBM_TXT_DEFAULT, NULL, hexflg ? 16 : 10);

    return (adr);
}

void    set_text_pointers(ADDRESS ls, ADDRESS end)
{
    ADDRESS le;
    BYTE   *p;

    /* Set end of load pointers like Kernal load. */

    ram[0xae] = end & 0xff;
    ram[0xaf] = (end >> 8) & 0xff;
#ifdef C128
    ram[CBM_VARTAB] = ram[CBM_ARYTAB] = ram[CBM_STREND] = 0;
    ram[CBM_VARTAB +1] = ram[CBM_ARYTAB +1] = ram[CBM_STREND +1] = 4;
#else
    ram[CBM_VARTAB] = ram[CBM_ARYTAB] = ram[CBM_STREND] = end & 0xff;
    ram[CBM_VARTAB +1] = ram[CBM_ARYTAB +1] = ram[CBM_STREND +1] =
	(end >> 8) & 0xff;
#endif

    /* Relink BASIC */

    if (ls == get_text_begin()) {
#ifdef DEBUG
	printf("Rechaining at %04X.\n", ls);
#endif
	/*
	 * It seems to be common mistake not to terminate BASIC properly
	 * before the machine language part, so we don't check for the
	 * low byte of line link here.
	 */
	while ((/*ram[ls] ||*/ ram[ls+1]) && ls < end) {
	    p = &ram[ls +4];
	    le = ls + 5;
	    while (*(p++))
		le++;
	    ram[ls] = le & 255;
	    ram[++ls] = (le>>8) & 255;
	    ls = le;
	}
    }
}
#endif

#ifdef VIC20

/* This function parses the mem config string given as -memory and
 * returns the appropriate values or'ed together.
 *
 * basically we accept a comma separated list of options like the following:
 * ""   - no extension 
 * none - same
 * all  - all blocks
 * 3k   - 3k space in block 0 (=3k extension cartridge)
 * 8k   - 1st 8k extension block
 * 16k  - 1st and 2nd 8 extension (= 16k extension cartridge)
 * 24k  - 1-3rd extension block (=8k and 16k extension cartridges)
 *
 * 0,1,2,3,5      - memory in respective block
 * 04,20,40,60,a0 - memory at respective address (same as block #s)
 *
 * example: xvic -memory ""
 *
 *            enables unexpanded computer
 *
 *          xvic -memory 60,a0
 *
 *            enables memory in blocks 3 and 5, which is the usual
 *            configuration for 16k rom modules
 *
 * 12/27/96 Alexander Lehmann (alex@mathematik.th-darmstadt.de)
 */

#define VIC_BLK0 1
#define VIC_BLK1 2
#define VIC_BLK2 4
#define VIC_BLK3 8
#define VIC_BLK5 16
#define VIC_BLK_ALL (VIC_BLK0|VIC_BLK1|VIC_BLK2|VIC_BLK3|VIC_BLK5)

static int get_memconf(void)
{
    int memconf;
    char *memstring = app_resources.memoryExp;
    char *optend;
    char opt[100];

    if(!memstring) return VIC_BLK_ALL;

    memconf=0;

    /* Maybe we should use strtok for this? */

    while(*memstring) {
	for(optend=memstring;*optend && *optend!=',';optend++) ;

	strncpy(opt, memstring, optend-memstring);
	opt[optend-memstring]='\0';

	if(strcmp(opt, "")==0 || strcmp(opt, "none")==0) {
	    /* no extension */
	}
	else if(strcmp(opt, "all")==0) {
	    memconf=VIC_BLK_ALL;
	}
	else if(strcmp(opt, "3k")==0) {
	    memconf |= VIC_BLK0;
	}
	else if(strcmp(opt, "8k")==0) {
	    memconf |= VIC_BLK1;
	}
	else if(strcmp(opt, "16k")==0) {
	    memconf |= VIC_BLK1|VIC_BLK2;
	}
	else if(strcmp(opt, "24k")==0) {
	    memconf |= VIC_BLK1|VIC_BLK2|VIC_BLK3;;
	}
	else if(strcmp(opt, "0")==0 || strcmp(opt, "04")==0) {
	    memconf |= VIC_BLK0;
	}
	else if(strcmp(opt, "1")==0 || strcmp(opt, "20")==0) {
	    memconf |= VIC_BLK1;
	}
	else if(strcmp(opt, "2")==0 || strcmp(opt, "40")==0) {
	    memconf |= VIC_BLK2;
	}
	else if(strcmp(opt, "3")==0 || strcmp(opt, "60")==0) {
	    memconf |= VIC_BLK3;
	}
	else if(strcmp(opt, "5")==0 || strcmp(opt, "a0")==0 
		|| strcmp(opt, "A0")==0) {
	    memconf |= VIC_BLK5;
	}
	else {
	    fprintf(stderr, "unsupported memory extension option: \"%s\"\n", opt);
	    exit(1);
	}
	memstring=optend;
	if(*memstring) memstring++; /* skip , */
    }

    if(debugflg) {
	printf("extension memory enabeled: ");
	if(memconf==0) {
	    printf("none");
	} else {
	    if(memconf & VIC_BLK0) printf("blk0 ");
	    if(memconf & VIC_BLK1) printf("blk1 ");
	    if(memconf & VIC_BLK2) printf("blk2 ");
	    if(memconf & VIC_BLK3) printf("blk3 ");
	    if(memconf & VIC_BLK5) printf("blk5");
	}
	printf("\n");
    }

    return memconf;
}
#endif

/*
 * This one initializes the memory_tab[][].
 * FIXME: C64 exrom and PLUS_SERIES not implemented.
 */

void
init_memory_tabs (void)
{
#if defined (C128)

    /*
     * The C128 uses the old (slower) method, one memory hook per bank.
     * Otherwise, since the MMU allows 1024 different memory configurations, we
     * would need 4 * 1024 * 64K Bytes = 256 MBytes for the memory tables...
     * This section needs to be improved in the future, using a different
     * approach.
     */
  
    return;
  
#else

    unsigned int addr;
    int memconf;

#ifdef VIC20
    /* Map all nonexistent memory to 0xff, I'm not about the actual
       content, maybe it was value of high byte? */
    static char dummy=0xff;
    int vic_memconf;
#endif

#ifndef CSA
    /* Set everything to RAM first... */
    for (memconf = 0; memconf < NUM_MEMCONFIGS; memconf++)
	for (addr = 0x0000; addr <= 0xffff; addr++)
	    memory_tabs_w[memconf][addr] = memory_tabs_r[memconf][addr] = ram + addr;
#endif

#if defined(CBM64)

    /* Setup BASIC at $A000 - $BFFF. */
    for (addr = 0xa000; addr <= 0xbfff; addr++)
	memory_tabs_r[3][addr] = memory_tabs_r[7][addr]
	    = basic_rom + BASIC_ADDRESS (addr);

    /* Setup IO/RAM/CHARGEN at $D000 - $DFFF. */
    for (addr = 0xd000; addr <= 0xdfff; addr++) {
	memory_tabs_r[1][addr] = memory_tabs_r[2][addr]
	    = memory_tabs_r[3][addr] = char_rom + (addr & 0xfff); 
	memory_tabs_r[5][addr] = memory_tabs_r[6][addr]
	    = memory_tabs_r[7][addr] = memory_tabs_w[5][addr]
	    = memory_tabs_w[6][addr] = memory_tabs_w[7][addr] = NULL;
    }
  
    /* Setup KERNAL/RAM at $E000 - $FFFF. */
    for (addr = 0xe000; addr <= 0xffff; addr++) {
	memory_tabs_r[2][addr] = memory_tabs_r[3][addr]
	    = memory_tabs_r[6][addr] = memory_tabs_r[7][addr]
	    = kernal_rom + (addr & 0x1fff);
    }

    /* 6510 I/O ports. */
    for (memconf = 0; memconf <= 0x7; memconf++) {
	memory_tabs_w[memconf][0] = memory_tabs_w[memconf][1] = NULL;
	memory_tabs_r[memconf][0] = memory_tabs_r[memconf][1] = NULL; 
    }
  
#ifdef REU
    /* REU trigger. */
    for (memconf = 0; memconf <= 0x7; memconf++)
	memory_tabs_w[memconf][0xff00] = NULL;
#endif
  
#elif defined (PET)
  
    /* Setup BASIC, EDITOR and KERNAL at $9000 - $E7FF and $F000 - $FFFF. */
    for (addr = 0x9000; addr <= 0xffff; addr++)
	memory_tabs_r[0][addr] = rom + (addr & 0x7fff);

    /* Setup IO at $E800 - $EFFF. */
    for (addr = 0xe800; addr <= 0xefff; addr++)
	memory_tabs_w[0][addr] = memory_tabs_r[0][addr] = NULL;
  
#elif defined (VIC20)

    /* Setup KERNAL at $E000 - $FFFF. */
    for (addr = 0xe000; addr <= 0xffff; addr++)
	memory_tabs_r[0][addr] = kernal_rom + (addr & 0x1fff);

    /* Setup BASIC at $C000 - $DFFF. */
    for (addr = 0xc000; addr <= 0xdfff; addr++)
	memory_tabs_r[0][addr] = basic_rom + BASIC_ADDRESS(addr);

    /* Setup CHARGEN at $8000 - $8FFF. */
    for (addr = 0x8000; addr <= 0x8fff; addr++)
	memory_tabs_r[0][addr] = char_rom + (addr & 0x1fff);

    /* Setup IO at $9000 - $93FF and $9C00 - $$9FFF
       (color RAM at $9400 - $9BFF). */
    for (addr = 0x9000; addr <= 0x93ff; addr++)
	memory_tabs_r[0][addr] = memory_tabs_w[0][addr] = NULL;
    for (addr = 0x9c00; addr <= 0x9fff; addr++)
	memory_tabs_r[0][addr] = memory_tabs_w[0][addr] = NULL;

    vic_memconf=get_memconf();

    if(!(vic_memconf&VIC_BLK0)) {
	for(addr=0x0400;addr<0x1000;addr++) {
	    memory_tabs_r[0][addr] = &dummy;
	}
    }
    if(!(vic_memconf&VIC_BLK1)) {
	for(addr=0x2000;addr<0x4000;addr++) {
	    memory_tabs_r[0][addr] = &dummy;
	}
    }
    if(!(vic_memconf&VIC_BLK2)) {
	for(addr=0x4000;addr<0x6000;addr++) {
	    memory_tabs_r[0][addr] = &dummy;
	}
    }
    if(!(vic_memconf&VIC_BLK3)) {
	for(addr=0x6000;addr<0x8000;addr++) {
	    memory_tabs_r[0][addr] = &dummy;
	}
    }
    if(!(vic_memconf&VIC_BLK5)) {
	for(addr=0xa000;addr<0xc000;addr++) {
	    memory_tabs_r[0][addr] = &dummy;
	}
    }
  
    /* Handle cartridge module. */
    if (module) {
	printf ("Installing cartridge ROM at $%04X...\n",
		(addr = module * 0x2000));
	for (; addr <= (module * 0x2000 + 0x1fff); addr++)
	    memory_tabs_r[0][addr] = external_rom + (addr & 0x3fff);
    }

#elif defined(CSA)

    reset_csammu();

#endif

#ifndef CSA
    /* For convenience... */
    for (addr = RAMSIZE; addr <= RAMSIZE + 0xfff; addr++)
	for (memconf = 0; memconf < NUM_MEMCONFIGS; memconf++)
	{
	    memory_tabs_r[memconf][addr] = memory_tabs_r[memconf][addr & 0xfff];
	    memory_tabs_w[memconf][addr] = memory_tabs_w[memconf][addr & 0xfff];
	}
#endif

#endif
}


/*
 * init_memory_hooks() initializes the memory hooks (ie. the memrd and memwr
 * arrays).
 * x128 still uses init_memmaps() to do so.
 */

void
init_memory_hooks (void)
{
    int i, j;
#ifdef CBM64
    memrd[0x0] = zerord;
    memwr[0x0] = zerowr;
    memrd[0xd0] = memrd[0xd1] = memrd[0xd2] = memrd[0xd3] = read_vic;
    memwr[0xd0] = memwr[0xd1] = memwr[0xd2] = memwr[0xd3] = store_vic;
    memrd[0xd4] = read_sid;
    memwr[0xd4] = store_sid;
    memrd[0xd5] = memrd[0xd6] = memrd[0xd7] = read_sid;
    memwr[0xd5] = memwr[0xd6] = memwr[0xd7] = store_sid;
    memrd[0xd8] = memrd[0xd9] = memrd[0xda]= memrd[0xdb] = read_colorram;
    memwr[0xd8] = memwr[0xd9] = memwr[0xda]= memwr[0xdb] = store_colorram;
    memrd[0xdc] = read_cia1;
    memwr[0xdc] = store_cia1;
    memrd[0xdd] = read_cia2;
    memwr[0xdd] = store_cia2;
    memrd[0xde] = iord;
    memwr[0xde] = iowr;
    memrd[0xdf] = read_io2;
    memwr[0xdf] = store_io2;
    memwr[0xff] = ramwr_hi;
#elif defined (VIC20)
    memrd[0x90] = read_vic;
    memwr[0x90] = store_vic;
    memrd[0x91] = memrd[0x92] = memrd[0x93] = memrd[0x9c] = memrd[0x9d]
      = memrd[0x9e] = memrd[0x9f] = iord;
    memwr[0x91] = memwr[0x92] = memwr[0x93] = memwr[0x9c] = memwr[0x9d]
      = memwr[0x9e] = memwr[0x9f] = iowr;
#elif defined (PET) || defined(CSA)
#ifdef CSA
    for(i=0;i<0x100;i++) { 
      memrd[i] = NULL;
      memwr[i] = NULL;
    }
#endif
    memrd[0xe8] = memrd[0xe9] = memrd[0xea] = memrd[0xeb] = memrd[0xec]
      = memrd[0xed] = memrd[0xee] = memrd[0xef] = iord; 
    memwr[0xe8] = memwr[0xe9] = memwr[0xea] = memwr[0xeb] = memwr[0xec]
      = memwr[0xed] = memwr[0xee] = memwr[0xef] = iowr; 
#endif
    /* for convenience... */
    for (i = 0x100, j = 0x0; j < 0x10; j++, i++) {
	memrd[i] = memrd[j];
	memwr[i] = memwr[j];
    }
}
     
/* ------------------------------------------------------------------------- */

#if !(defined(C128) || defined(CBM64)) 

void init_memmaps(void) {
    pagezero = ram;
    pageone = ram + 0x100;
    init_memory_tabs ();
    init_memory_hooks ();
#ifndef CSA
    memtab_r = memory_tabs_r[0];
    memtab_w = memory_tabs_w[0];
#endif
}

#else 
/* #if (defined(C128) || defined(CBM64)) */

/* Set up C64 or C128 memory configuration */
/* For C64, this is useless now! - except for setting memtab_[rw] (AF) */

void    init_memmaps(void)
{
    int     i;

#if defined (C128)	 /* let's set up the C128 RAM configuration first... */
    shared_lo = mmu[6] & 0x4;
    shared_hi = mmu[6] & 0x8;
    if (!(mmu[6] & 0x3))
        shared_size = 0x400;
    else 
        shared_size = 0x1000 << (mmu[6] & 0x3);
#if defined (DEBUG_MMU)
    printf ("MMU: shared_size = %d, shared_lo = %d, shared_hi = %d\n",
	    shared_size, shared_lo, shared_hi);
#endif
#endif
    
    for (i = 1; i < 16; i++) {
	memwr[i] = ramwr;
	memrd[i] = ramrd;
    }
    memwr[0x00] = zerowr;
    memrd[0x00] = zerord;

    /*printf("InitMem PC = %04x\n", PC);*/
#ifdef C128

    /* C000 - FFFF */

    memwr[0x0f] = ramwr_hi;

    switch ((i = mmu[0]) & 0x30) {
      case 0x00:
	memrd[0xe] = memrd[0xf] = kernalrd;
	memrd[0xd] = charrd;   /* Chargen ROM */
	memrd[0xc] = basicrd;  /* Editor ROM */
dprintf("K-C-E ");
	break;
      case 0x10:
	if (module) {
	    memrd[0xe] = memrd[0xf] = exromrd; /* Int Func. ROM */
	    memrd[0xc] = memrd[0xd] = exromrd;
	}
dprintf("Fx-Hi ");
	break;
      case 0x20:
	if (module) {
	    memrd[0xe] = memrd[0xf] = exromrd; /* Ext Func. ROM */
	    memrd[0xc] = memrd[0xd] = exromrd;
	}
dprintf("EX-Hi ");
	break;
    }
    if (!(i & 1)) {
	memrd[0x0d] = iord;
	memwr[0x0d] = iowr;
dprintf("I/O ");
    }

    /* 8000 - BFFF */

    switch (i & 0x0C) {
      case 0x00:
	memrd[0xa] = memrd[0xb] = basicrd;
	memrd[0x8] = memrd[0x9] = basicrd;
dprintf("B-Hi ");
	break;
      case 0x04:
	if (module) {
	    memrd[0xa] = memrd[0xb] = exromrd; /* Int Func. ROM */
	    memrd[0x8] = memrd[0x9] = exromrd;
	}
dprintf("Fx-Lo ");
	break;
      case 0x08:
	if (module) {
	    memrd[0xa] = memrd[0xb] = exromrd; /* Ext Func. ROM */
	    memrd[0x8] = memrd[0x9] = exromrd;
	}
dprintf("EX-Lo ");
	break;
    }

    /* 4000 - 7FFF */

    if (!(i & 2)) {
	memrd[0x6] = memrd[0x7] = basicrd;
	memrd[0x4] = memrd[0x5] = basicrd;
dprintf("B-Lo ");
    }

    /* Set up common RAM */

#endif  /* C128 */


    /* Set up C64 memory configuration */

#ifdef CBM64

#ifdef REU
    if (app_resources.reu)
	memwr[0x0f] = ramwr_hi;
#endif

    /*
     * Note: ULTIMAX mode (configurations 1, 5, 9 and D) is not supported
     */

#if defined (DEBUG_MEMMAPS)
    printf ("C64 memory map: $%X\n", memconfig);
#endif

    switch (memconfig & 0x07) {
      case 7:  /* C E F */
	switch (module) {
	  case 1:
	    memrd[0x8] = memrd[0x9] = exromrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\t8000-9FFF: read from EXROM\n");
#endif

	  case 0:
	    memrd[0xa] = memrd[0xb] = basicrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\tA000-BFFF: read from BASIC\n");
#endif
	    break;

	  case 3:
	    memrd[0x8] = memrd[0x9] = exromrd;
	    memrd[0xa] = memrd[0xb] = exromrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\t8000-9FFF: read from EXROM\n");
	    printf ("\tA000-BFFF: read from BASIC\n");
#endif
	}

      case 6:  /* 4 6 7 */
	memrd[0xe] = memrd[0xf] = kernalrd;
#if defined (DEBUG_MEMMAPS)
	printf ("\tE000-FFFF: read from KERNAL\n");
#endif

	if (module == 2) {
	    memrd[0xa] = memrd[0xb] = exromrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\tA000-BFFF: read from EXROM\n");
#endif
	}

      case 5:  /* 8 A B */
	memrd[0x0d] = iord;
	memwr[0x0d] = iowr;
#if defined (DEBUG_MEMMAPS)
	printf ("\tD000-DFFF: read/write IO\n");
#endif

      case 4:  /* 0 2 3 */
	break;

      case 3:
	switch (module) {
	  case 1:
	    memrd[0x8] = memrd[0x9] = exromrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\t8000-9FFF: read from EXROM\n");
#endif

	  case 0:
	    memrd[0xa] = memrd[0xb] = basicrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\tA000-BFFF: read from BASIC\n");
#endif
	    break;

	  case 3:
	    memrd[0x8] = memrd[0x9] = exromrd;
	    memrd[0xa] = memrd[0xb] = exromrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\t8000-9FFF: read from EXROM\n");
	    printf ("\tA000-BFFF: read from EXROM\n");
#endif
	}

      case 2:
	memrd[0xe] = memrd[0xf] = kernalrd;
	memrd[0x0d] = charrd;
#if defined (DEBUG_MEMMAPS)
 	printf ("\tD000-DFFF: read from CHARGEN\n");
	printf ("\tE000-FFFF: read from KERNAL\n");
#endif

	if (module == 2) {
	    memrd[0xa] = memrd[0xb] = exromrd;
#if defined (DEBUG_MEMMAPS)
	    printf ("\tA000-BFFF: read from EXROM\n");
#endif
	}
	break;

      case 1:
        memrd[0x0d] = charrd;
#if defined (DEBUG_MEMMAPS)
        printf ("\tD000-DFFF: read from CHARGEN\n");
#endif

      case 0: /* the chargen is not accessible */
	break;
    }
    memtab_r = memory_tabs_r[memconfig & 0x7];
    memtab_w = memory_tabs_w[memconfig & 0x7];
#endif  /* CBM64 */

#if defined (DEBUG_MEMMAPS)
    printf ("\tOther: read/write RAM\n");
#endif
    /* for convenience ... */

    memrd[0x10] = memrd[0];
    memwr[0x10] = memwr[0];
}


/* ------------------------------------------------------------------------- */

#endif	/* C128 */

#if defined(C128) || defined(CBM64)

/*
 * C64/128 I/O access functions
 * these are defined differently for each mode
 */

void iowr(ADDRESS address, BYTE byte)
{
    switch ((address & 0xf00) >> 8) {
      case 0: case 1:
      case 2: case 3:	/* VIC */
	store_vic(address & 0x3f, byte);
	return;

#ifdef C128
      case 5: /* MMU */
	store_mmu(address, byte);
	return;

      case 6: /* VDC */
	if (address & 1) {
#ifdef USE_VDC
	    store_vdc(vdc_ptr, byte);
#else
#if 0
	    if (vdc_ptr < 37) {
		vdc[vdc_ptr] = byte;

		if (vdc_ptr == 0x1e) {	/* Copy/fill repetition count */
		    vdc[0x12] = LOAD(0xa3d);
		    vdc[0x13] = LOAD(0xa3c);
		}
	    }
#endif
#endif  /* USE_VDC */
	}
	else
	    vdc_ptr = byte;
	return;

#else
      case 5:
      case 6:
      case 7:
#endif	/* C128 */
      case 4:	/* SID */
	store_sid (address, byte);
	return;

      case 8:
      case 9:
      case 10:
      case 11:	/* COLOR RAM */
        store_colorram(address & 0x3ff, byte);
	return;

      case 12:	/* CIA 1 */
	store_cia1(address & 0xf, byte);
	return;

      case 13:	/* CIA 2 */
	store_cia2(address & 0xf, byte);
	return;
      case 15:	/* IO2 */
#ifdef REU
	if (app_resources.reu)
	  store_reuc(address & 0xf, byte);
#endif
#ifdef IEEE488
	if(app_resources.ieee488)
	  store_tpi(address & 0x0f, byte);
#endif
	return;
      default:
	return;
    }
}


BYTE iord(ADDRESS address)
{

    switch ((address & 0xf00) >> 8) {
	case 0:case 1:case 2:case 3:	/* VIC */
	return (read_vic(address & 0x3f));

#ifdef C128
      case 5: /* MMU */
	if ((address & 0xff) == 5 && (int)app_resources.video80) {
	  /*printf ("READ 40/80 key = DOWN  %d\n", app_resources.video80);*/
	      return (mmu[5] & 0x7f);		/* Give the 40/80 readout */
	}

	/*printf ("MMU[%x] = %02X  verify = %02x\n",
	  address, mmu[address & 0xff],
	  ((address &= 0xff) < 0x0b) ? mmu[address] : 0x0f);*/

	return (((address &= 0xff) < 0x0b) ? mmu[address] : 0x0f);

      case 6: /* VDC */
	if (address & 1) {
#ifdef USE_VDC
	    return (read_vdc(vdc_ptr));
#else
	    return ((vdc_ptr < 37) ? vdc[vdc_ptr] : 0xff);
#endif  /* USE_VDC */

	}
	else
	    return 0x9f; /* status */

#else
      case 5:
      case 6:
      case 7:  /* undefined in C128 */
#endif

      case 4: /* SID */
	return (read_sid (address));

      case 8:
      case 9:
      case 10:
      case 11:/* COLOR RAM */
	return (read_colorram(address & 0x3ff));
	break;

      case 12:/* CIA 1  dc00 */
	return (read_cia1(address & 0xf));

      case 13:/* CIA 2  dd00 */
	return (read_cia2(address & 0xf));

      case 15: /* IO2   df00 */
#ifdef EMULATOR_ID
	if (app_resources.emuID && (address & 0xff) > 0x9f) {
	    address &= 0xff;
	    if (address == 0xff)
		Emulator_ID[address - 0xa0] ^= 0xff;
	    return (Emulator_ID[address - 0xa0]);
	}
#endif
#ifdef REU
	if (app_resources.reu)
	  return (read_reuc(address & 0xf));	/* else drop trough */
#endif
#ifdef IEEE488
	if(app_resources.ieee488) 
	  return (read_tpi(address & 0x07));
#endif
      default:
	return ((BYTE)(address >>8));		/* Empty slot */
    }
}


void store_io2 (ADDRESS address, BYTE byte)
{
#ifdef REU
    if (app_resources.reu)
      store_reuc(address & 0xf, byte);
#endif
#ifdef IEEE488
    if(app_resources.ieee488)
      store_tpi(address & 0x0f, byte);
#endif
}


BYTE read_io2 (ADDRESS address)
{
#ifdef EMULATOR_ID
    if (app_resources.emuID && (address & 0xff) > 0x9f) {
	address &= 0xff;
	if (address == 0xff)
	  Emulator_ID[address - 0xa0] ^= 0xff;
	return (Emulator_ID[address - 0xa0]);
    }
#endif
#ifdef REU
    if (app_resources.reu)
      return (read_reuc(address & 0xf));	/* else drop through */
#endif
    
#ifdef IEEE488
    if(app_resources.ieee488) 
      return (read_tpi(address & 0x07));
#endif

    return (BYTE)rand();
}

#endif  /* C64/128 */


/* ------------------------------------------------------------------------- */


#if 0  /* defined(VIC20) || defined(PET) || defined(CSA) ) */

/* Set up VIC=20 memory configuration */

void    init_memmaps(void)
{
    int     i;

    for (i = 0; i < 16; i++) {
	memwr[i] = ramwr;
	memrd[i] = ramrd;
    }


    /* VIC20 map */

#ifdef VIC20
    /*
     * The VIC20 memory map is quite straightforward, as there
     * isn't bank swithing involved there. Also, this function
     * needs to be called once at RESET only.
     */

    memrd[0xe] = memrd[0xf] = kernalrd;
    memrd[0xc] = memrd[0xd] = basicrd;
    memrd[0x8] = charrd;

    memrd[0x9] = iord;
    memwr[0x9] = iowr;

    switch (module) {
      case 1:
	memrd[0x2] = memrd[0x3] = exromrd;
	break;

      case 2:
	memrd[0x4] = memrd[0x5] = exromrd;
	break;

      case 3:
	memrd[0x6] = memrd[0x7] = exromrd;
	break;

      case 5:  /* A000 */
	memrd[0xa] = memrd[0xb] = exromrd;
    }


#endif /* VIC20 */


    /* PET8032 map */

#ifdef PET
    /*
     * The PET8032 memory map is quite straightforward, just like
     * VIC20's, as there isn't bank swithing involved there. Also,
     * this function needs to be called once at RESET only.
     */

    /*memrd[0xf] = kernalrd;
    memrd[0xb] = memrd[0xc] = memrd[0xd] = basicrd;*/

    for(i = 9; i < 16; i++) memrd[i] = romrd;

    memrd[0xe] = iord;	/* Editor ROM shares E000 with I/O */
    memwr[0xe] = iowr;

#endif /* PET */


/* for convenience ... */

    memrd[0x10] = memrd[0];
    memwr[0x10] = memwr[0];
}

#endif  /* VIC + PET */


/* ------------------------------------------------------------------------- */

/*
 * I/O access functions
 * these are defined differently for each mode
 */

#ifdef VIC20
void iowr(ADDRESS address, BYTE byte)
{

    /* VIC-20 I/O */

    switch ((address & 0xf00) >> 8) {
      case 0:	/* VIC */
	store_vic(address & 0xf, byte);
	return;

      case 1:	/* VIA 1 & 2 */
      case 2:
      case 3:
	if (address & 0x10)	/* 911x -- VIA 1 */
	    store_via2(address & 0xf, byte);

	if (address & 0x20)	/* 912x --  VIA 2 */
	    store_via1(address & 0xf, byte);
	return;

      case 4:
      case 5:
      case 6:
      case 7:	/* COLOR RAM */
	store_colorram(address & 0x3ff, byte);
	return;

	/* 9800-9bff I/O1 */
	/* 9c00-9fff I/O1 */

      default:
	return;
    }
}


BYTE iord(ADDRESS address)
{

    /* VIC-20 I/O */

    switch ((address & 0xf00) >> 8) {
      case 0:	/* VIC */
	return (read_vic(address & 0xf));

      case 1:	/* VIA 1 & 2 */
      case 2:
      case 3:
	if ((address & 0x30) == 0x30)
	    return (read_via1(address & 0xf) &
		    read_via2(address & 0xf));	/* VIA 1 & 2 */

	if (address & 0x10)
	    return (read_via2(address & 0xf));	/* VIA 1 */

	if (address & 0x20)
	    return (read_via1(address & 0xf));	/* VIA 2 */

      case 4:
      case 5:
      case 6:
      case 7:/* COLOR RAM */
	return (read_colorram(address & 0x3ff));
	break;

	/* 9800-9bff I/O1 */
	/* 9c00-9fff I/O1 */

      default:
	return ((BYTE)(address >>8));
    }
}
#endif  /* VIC-20 */


/* ------------------------------------------------------------------------- */

    /* PET 3032/4032/8032 */

#ifdef PET
static BYTE   vdc_ptr = 0;		/* CRTC register pointer for PET */

void iowr(ADDRESS address, BYTE byte)
{
#if 0 /* this is not needed any longer... */
    if (!(address & 0x800))
	return;					/* E000 - E7FF  Editor ROM */

    if ((address & 0xf00) == 0x800)
#else
    if (1)
#endif

	switch (address & 0xf0) {

	  case 0x10:	/* PIA 1 */
	    store_pia1(address & 0x3, byte);		/* PIA 1 */
	    return;

	  case 0x20:	/* PIA 2 */
	    store_pia2(address & 0x3, byte);		/* PIA 2 */
	    return;

	  case 0x40: case 0x50:	/* VIA  */
	  case 0x60: case 0x70:
	  case 0xC0: case 0xD0:
	  case 0xE0: case 0xF0:
	    store_via(address & 0xf, byte);		/* VIA */
	    return;

	  case 0x80:	/* CRTC */
	    if (address & 1)
		store_crtc(vdc_ptr, byte);
	    else
		vdc_ptr = byte;
	    return;
	}
}


BYTE iord(ADDRESS address)
{
#if 0 /* this is not needed any longer... */
    if (!(address & 0x800))
#if 0
	return (kernal_rom[address & 0x7FF]);	/* E000 - E7FF  Editor ROM */
#endif
	return (rom[address & 0x7FFF]);		/* E000 - E7FF  Editor ROM */

    if ((address & 0xf00) == 0x800)
#else
    if (1) 
#endif
	switch (address & 0xf0) {

	  case 0x10:	/* PIA 1 */
	    return (read_pia1(address & 0x3));	/* PIA 1 */

	  case 0x20:	/* PIA 2 */
	    return (read_pia2(address & 0x3));	/* PIA 2 */

	  case 0x40: case 0x50:	/* VIA  */
	  case 0x60: case 0x70:
	  case 0xC0: case 0xD0:
	  case 0xE0: case 0xF0:
	    return (read_via(address & 0xf));	/* VIA */

	  case 0x80:	/* CRTC */
	    if (address & 1) {
		return (read_crtc(vdc_ptr));
	    }
	    else
		return 0x9f; /* status */

	  default:
	    return ((BYTE)(address >> 8));
	}
    else
	return ((BYTE)(address >> 8));
}
#endif  /* PET 8032 */

/* ------------------------------------------------------------------------- */

    /* CS/A65 */

#ifdef CSA
static BYTE   vdc_ptr = 0;		/* CRTC register pointer for PET */

void iowr(ADDRESS address, BYTE byte)
{
	switch (address & 0xff0) {

	  case 0x810:	/* PIA 1 */
	    if(!(address & 0x08)) {
	      store_piaC1(address & 0x3, byte);		/* PIA 1 */
	    } else {
	      store_acia2(address, byte);
	    }
	    return;

	  case 0x820:	/* PIA 2 */
	    store_piaC2(address & 0x3, byte);		/* PIA 2 */
	    return;

	  case 0x840: 	/* VIA  */
	    store_viaC(address & 0xf, byte);		/* VIA */
	    return;

	  case 0x880:	/* CRTC */
	    if (!(address & 8)) {
	        if (address & 1)
		    store_crtc(vdc_ptr, byte);
	        else
		    vdc_ptr = byte;
	        return;
	    } else {
		/* write-only video control port (upper address bits,
		 * charrom switching etc */
	        store_crtcport(byte);
	    }
	    break;

	  case 0xfe0:	/* BIOS card - lower 8 byte = BIOSport */
	    if(!(address & 0x08)) {
	      store_csabios(address, byte);
	    } else {	/* BIOS card - upper 8 byte = ACIA1 */
	      store_acia1(address, byte);
	    }
	    return;

	  case 0xff0:	/* MMU */
	    store_csammu(address, byte);
	    return;
	}
}


BYTE iord(ADDRESS address)
{
	switch (address & 0xff0) {

	  case 0x810:	/* PIA 1 */
	    if(!(address & 0x08)) {
	      return (read_piaC1(address & 0x3));	/* PIA 1 */
	    } else {
	      return read_acia2(address);
	    }

	  case 0x820:	/* PIA 2 */
	    return (read_piaC2(address & 0x3));	/* PIA 2 */

	  case 0x840:	/* VIA  */
	    return (read_viaC(address & 0xf));	/* VIA */

	  case 0x880:	/* CRTC */
	    if (!(address & 8)) {
	        if (address & 1) {
		    return (read_crtc(vdc_ptr));
	        }
	        else
		    return 0x9f; /* status */
	    }
	    return ((BYTE)(address >> 8));

	  case 0xfe0:	/* BIOS card - lower 8 byte = BIOSport */
	    if(!(address & 0x08)) {
	      return read_csabios(address);
	    } else {	/* BIOS card - upper 8 byte = ACIA1 */
	      return read_acia1(address);
	    }
	    
	  case 0xff0:	/* MMU */
	    return read_csammu(address);

	  default:
	    return 0; /* ((BYTE)(address >> 8)) */ ;
	}
}
#endif  /* CS/A65 */


/* ------------------------------------------------------------------------- */

    /* C-16, 116, Plus/4 */

#ifdef PLUS_SERIES
void iowr(ADDRESS address, BYTE byte)
{
    switch (address & 0xff0) {

		/* FD00 - FDFF  I/O Portss */

      case 0xd00:
	store_acia(address & 0xf);	/* ACIA 6551 */
	return;

      case 0xd10:
	store_pio1(address & 0xf);	/*  PIO 6529 */
	return;

      case 0xd30:
	store_pio2(address & 0xf);	/*  PIO 6529 */
	return;

      case 0xdd0:				/* ADDR CLK  */
	return;

		/* FE00 - FEFF  Disk Drives */

      case 0xec0:		/* Drive #9, if present */
      case 0xee0:		/* Drive #8, if present */
	return;

      case 0xf00: case 0xf10:		/* FF00 - FF3F  Video Chip */
      case 0xf20: case 0xf30:
	    store_ted(address & 0xf);	/* TED */
	}
}

    /* C-16, 116, Plus/4 */

BYTE iord(ADDRESS address)
{
    switch (address & 0xf00) {

      case 0xd00:		/* FD00 - FDFF  I/O Portss */
	switch (address & 0xf0) {
	  case 0x00:
	    return (read_acia(address & 0xf));	/* ACIA 6551 */

	  case 0x10:
	    return (read_pio1(address & 0xf));	/*  PIO 6529 */

	  case 0x30:
	    return (read_pio2(address & 0xf));	/*  PIO 6529 */

	  case 0xd0:				/* ADDR CLK  */
	  default:
	    return (0xfd);
	}

      case 0xe00:		/* FE00 - FEFF  Disk Drives */
	switch (address & 0xf0) {
	  case 0xec0:		/* Drive #9, if present */
	  case 0xee0:		/* Drive #8, if present */

	  default:
	    return (0xfe);
	}

      case 0xf00:		/* FF00 - FF3F  Video Chip */
	if ((address & 0xf0) < 0x40) {
	    return (read_ted(address & 0xf));	/* TED */
	}

	return (kernal_rom[address & 0x1FFF]);	/* D000 - FCFF, FF40 - FFFF  System ROM */
}
#endif  /* PLUS_SERIES */


/* ------------------------------------------------------------------------- */

/*
 * Memory access functions
 * these are common for each mode except for PET
 */

#if defined(PET) || defined(CSA)
/*
static BYTE romrd(ADDRESS address) 
{
    return (rom[ address & 0x7fff ]);
}
*/
#else

static BYTE basicrd(ADDRESS address)
{
    return (basic_rom[BASIC_ADDRESS(address)]);
}


static BYTE kernalrd(ADDRESS address)
{
    return (kernal_rom[address & 0x1fff]);
}


static BYTE exromrd(ADDRESS address)
{
    /*printf("Exromrd %04X\n", address);*/
    return (external_rom[address & 0x3fff]);
}


static BYTE charrd(ADDRESS address)
{
    return (char_rom[address & 0xfff]);
}


static BYTE ramrd(ADDRESS address)
{
    return (ram[RAMSHAR(address)]);
}

#endif  /* PET or CSA */

/*
 * Handle C64 and C128 low memory access.
 * PET and VIC-20 don't have Peripheral port on the CPU.
 */

#if defined (CBM64) || defined (C128)

static void zerowr(ADDRESS address, BYTE byte)
{
    static BYTE tmp_memconfig = 0;

    if (!address || address == 1) {
#ifdef CBMTAPE
        /* cassette motor is OFF only if both R0 and R1 have the bit 4 set */
	if (address && (*ram & ram[1] & 0x20) && !(byte & 0x20)) {
	    check_tape();
	}
#endif
	ram[address] = byte;
	if (((tmp_memconfig = (0x07 & ~ram[0]) |
	      (ram[1] & ram[0])) & 0x7) != memconfig) {
	    memconfig = tmp_memconfig;
#if defined (C128) || defined (DEBUG_MEMMAPS)
	    init_memmaps();
#else
	    memtab_r = memory_tabs_r [memconfig & 0x7];
	    memtab_w = memory_tabs_w [memconfig & 0x7];
#endif
	}
    } else

#ifdef C128
    if (address < 0x100)
	pagezero[address] = byte;
    else if (address < 0x200)
	pageone[address & 0xff] = byte;
    else
	ram[RAMSHAR(address)] = byte;

    /*if(address > 0x1ff)
	printf("RAMWR %X:%04X at PC = %04X  data %02x [ %02x %02x ]\n",
	       ((mmu[0] & 0xC0) >> 6), address, PC, byte,
	       ram[address], ram[address + 0x10000] );*/

#else
	ram[address] = byte;
#endif  /* C128 */

/*    ram[address] = byte; */
}


static BYTE zerord (ADDRESS address)
{

  if (address == 1)		/* zeroes in ram[0] set bits in ram[1] high */
#ifdef CBMTAPE
    return ram[1] | (0xef & ~ram[0]);		/* do tape sense */
#else
    return ram[1] | (0xff & ~ram[0]);		/* this version not necessary */
#endif

#ifdef C128
  if (address < 0x100)
      return pagezero[address];
  else if (address < 0x200)
      return pageone[address & 0xff];
  else
      return ram[RAMSHAR(address)];
#else
  return ram[address];
#endif
}

#endif  /* C64, C128 */

#ifndef CSA

static void ramwr(ADDRESS address, BYTE byte)
{
    ram[RAMSHAR(address)] = byte;
}


#if (defined(REU) || defined(C128))
static void ramwr_hi(ADDRESS address, BYTE byte)
{
#ifdef C128
    /*printf("BANK %x\n", RAMBANK());*/
    ram[RAMBANK() + address] = byte;

    if (address > 0xff00 && address <= 0xff04) { /* memory config */
	store_mmu(0, mmu[address & 15]);
    }
    else if (address == 0xff00) {
	store_mmu(0, byte);
#ifdef REU
	if (app_resources.reu)	/* only when enabled */
	    reu_dma(-1);
#endif
    }

#else /* C128 */
#ifdef REU
    ram[address] = byte;
    if (address == 0xff00 && app_resources.reu)
	reu_dma(-1);
#endif
#endif
}
#endif


#ifdef C128
static void store_mmu(ADDRESS address, BYTE byte)
{
    static BYTE conf = 0;		/* bank15 -- default */

#if defined (DEBUG_MMU)
    printf("MMU: %04X WR %04X: MMU[%x] = %02X\n", PC, address, address & 15, byte);
#endif
    
    if ((address &= 0xff) < 0x0b) {
	mmu[address] = byte;

	switch (address) {
	  case 0:   /* mem config */
	    if (byte == conf)
		break;
	    conf = byte;

	/* MMU overrides everything, so CR must be always
	 * readable in the selected bank
	 */
	    kernal_rom[0x1f00] = byte;
	    ram[0xff00] = ram[0x1ff00] = byte;
#if (RAMSIZE == 0x40000)
	    ram[0x2ff00] = ram[0x3ff00] = byte;
#endif

	  case 6:   /* ram config */
	    init_memmaps(); /* C128 */
	    break;

	  case 5:   /* operating mode */
	    byte = (byte & 0x7f) | 0x30;	/* read-only bits */


	    if ((byte & 0x41) != 1) {
#ifdef HAS_ZILOG_Z80
		WORD  z_pc;

		if (!bios_rom) {
		    if (!InitZ80())
			exit (-1);

		    printf("Loading BIOS ROM\n");

#if 0
		    bios_rom = allocate_mem (BIOSROM_SIZE);
#endif

		    if (Load_Sys_File (NULL, app_resources.biosName, bios_rom, 
				       0, BIOSROM_SIZE) < 0) {
			fprintf(stderr,"Fatal Error: BIOS image not loaded");
			exit (-1);
		    }

		    fprintf(stderr, "Z80: <stretching> Yaawwnnn...\n");
		}

		printf ("Z80 OK.\nRUNNING ROM CODE...\n");

		z_pc = Z80();

		printf ("Z80 EXITED at PC = %Xh.\n", z_pc);

#else
		fprintf(stderr,
		       "$D505 %02X - Attempted accessing unimplemented mode.\n",
			byte);
#endif
	    } /* if Z80 */
	    break;
	    
	  case 7:
	  case 8:
	  case 9:
	  case 10:
 	    pagezero = (ram + (mmu[0x8] & 0x1 ? 0x10000 : 0x00000)
			+ (mmu[0x7] << 8));
 	    pageone = (ram + (mmu[0xa] & 0x1 ? 0x10000 : 0x00000)
		       + (mmu[0x9] << 8));
#if defined (DEBUG_MMU)
 	    printf ("MMU: PAGE ZERO at $%05X, PAGE ONE at $%05X\n",
		    pagezero - ram, pageone - ram);
#endif
	  }
    }
    return;
}
#endif

#endif	/* ifndef CSA */


/* ------------------------------------------------------------------------- */

/*
 * Z80 Memory Interface for C128.
 *
 * If this seems complex, don't worry -- it really is. The C128 MMU swaps
 * addresses 0xxx and Dxxx to get the BIOS to the correct location.
 * The beginning of RAM0 is always covered by the BIOS but Shared RAM still
 * permits limited access to it.
 * The I/O chips show up both at 0000-0FFF and D000-DFFF, but Colour RAM
 * is also located at 1300-13FF (I/O) and 5000-53FF (always).
 * Since the MMU itself has a hard-coded address, it only shows at D500/FF00.
 */


#if (defined(HAS_ZILOG_Z80) && defined(C128))

#if (RAMSIZE == 0x40000)
#define BNK()  (mmu[0] & 0xC0)  /* 256K MMU support */
#else
#define BNK()  (mmu[0] & 0x40)  /* 128K only */
#endif

#define IF_IO  (mmu[0] & 1)


BYTE M_RDMEM (register ADDRESS address)
{
/*printf ("READ %04X\n", address);*/

    switch(address & 0xF000) {
      case 0x0000:
	if (BNK() || !bios_rom)
	    return (ram[RAMBANK() + address]);	/*shared RAM1 should be RAM0*/
	return (bios_rom[address]);		/* bank 0 always ROM */

      case 0x1000:
	if (IF_IO && address < 0x1400)
	    return (read_colorram(address & 0x3ff));
	return (ram[RAMBANK() + address]);

      case 0x5000:
	if (address < 0x5400)
	    return (read_colorram(address & 0x3ff));
	return (ram[RAMBANK() + address]);

      case 0xD000:
	if (IF_IO)
	    return (iord(address));
	return (ram[RAMBANK() + address]);

      case 0xE000:
	if (address < 0xEE00)
	    return (ram[RAMBANK() + address]);
      case 0xF000:
	return (ram[address]);		/* Common RAM */
    }

    return (ram[RAMBANK() + address]);
}


void M_WRMEM (register ADDRESS address, register BYTE V)
{

/*printf ("Write %04X\n", address);*/

    switch(address & 0xF000) {

      case 0xD000:
	if (IF_IO)  iowr(address, V);
	else  ram[RAMBANK() + address] = V;
	break;

      case 0xE000:
	if (address < 0xEE00) {
	    ram[RAMBANK() + address] = V;
	    break;
	}
      case 0xF000:
	ram[RAMBANK() + address] = V;

	/* Trap REU and MMU writes */

    if (address > 0xff00 && address <= 0xff04) { /* memory config */
	store_mmu(0, mmu[address & 15]);
    }
    else if (address == 0xff00) {
	store_mmu(0, V);
#ifdef REU
	if (app_resources.reu)	/* only when enabled */
	    reu_dma(-1);
#endif
    }
	break;

      default:
	ram[RAMBANK() + address] = V;
    }
}

#endif  /* HAS_ZILOG_Z80 */

