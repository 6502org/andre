/*
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * 16/24bpp support added by
 *   Steven Tieu (stieu@physics.ubc.ca)
 *   Teemu Rantanen (tvr@cs.hut.fi)
 *
 */

/* This is the VIC-II chip emulation.  The screen update is done on a
   line-by-line basis, but we also try to support some features cycle-wise
   (e.g. delayed DMA). */

/* TODO: - speed optimizations;
         - faster sprites and registers;
         - hacks to make timing-dependent things work better. */
 
#define _VICII_C

#include "extern.h"
#include "vice.h"
#include "vicii.h"
#include "vmachine.h"
#include "interrupt.h"
#include "maincpu.h"
#include "extern.h"		/* rmw_flag */
#include "raster.h"
#include "sprites.h"

#if defined (C128)
#include "vdc.h"
#endif

#include <stdlib.h>
#include <stdio.h>

/* ------------------------------------------------------------------------- */

/* Debugging options. */
/* #undef VIC_II_VMODE_DEBUG */
/* #undef VIC_II_RASTER_DEBUG */
/* #undef VIC_II_REGISTERS_DEBUG */

#ifdef VIC_II_VMODE_DEBUG
#define DEBUG_VMODE(x)		if (traceflg) printf x
#else
#define DEBUG_VMODE(x)
#endif

#ifdef VIC_II_RASTER_DEBUG
#define DEBUG_RASTER(x)		if (traceflg) printf x
#else
#define DEBUG_RASTER(x)
#endif

#ifdef VIC_II_REGISTERS_DEBUG
#define DEBUG_REGISTER(x)	if (traceflg) printf x
#else
#define DEBUG_REGISTER(x)
#endif

/* This is used for performance evaluation. */
#undef NO_REDRAW

extern int traceflg;

/* ------------------------------------------------------------------------- */

/* These timings are taken from the ``VIC Article'' by Christian Bauer
   (bauec002@goofy.zdv.uni-mainz.de).  Thanks Christian! */

/* Cycle # at which the VIC takes the bus in a bad line (BA goes low). */
#define	FETCH_CYCLE		14

/* Cycle # at which the raster line is re-drawn.  Some programs don't like this
   to be set at the very end of the line. */
/*#define DRAW_CYCLE		(CYCLES_PER_LINE - 1)*/
#define DRAW_CYCLE		43

/* Number of cycles required to load the raster line register. */
#define LINE_REG_DELAY		0

/* Delay for the raster line interrupt.  This is not due to the VIC-II, since
   it triggers the IRQ line at the beginning of the line, but to the 6510 that
   needs at least 2 cycles to detect it. */
#define RASTER_INT_DELAY	2

/* Starting cycle of the current raster line. */
#define LINE_START_CLK	(oldclk + CYCLES_PER_LINE - DRAW_CYCLE > clk          \
			 ? oldclk - DRAW_CYCLE				      \
			 : (oldclk + 2 * CYCLES_PER_LINE - DRAW_CYCLE > clk   \
			    ? oldclk + CYCLES_PER_LINE - DRAW_CYCLE	      \
			    : oldclk + 2 * CYCLES_PER_LINE - DRAW_CYCLE))

/* Current cycle # within the current raster line. */
#define CURRENT_LINE_CYCLE    ((unsigned int)(clk - LINE_START_CLK))

/* # of the previous and next raster line. */
#define PREVIOUS_LINE(line)   (((line) > 0) \
			       ? (line) - 1 : VIC_II_SCREEN_HEIGHT - 1)
#define NEXT_LINE(line)	      (((line) + 1) % VIC_II_SCREEN_HEIGHT)

/* Current raster line. */
#define CURRENT_LINE	      ((oldclk + CYCLES_PER_LINE - DRAW_CYCLE > clk) \
			       ? PREVIOUS_LINE(rasterline)		     \
			       : ((oldclk + 2 * CYCLES_PER_LINE - DRAW_CYCLE \
			           > clk) ? rasterline			     \
				          : NEXT_LINE(rasterline)))

/* ------------------------------------------------------------------------- */

/* VIC-II registers. */
static BYTE vic[64];

/* Interrupt register. */
static int videoint = 0;

/* Line for raster compare IRQ. */
static int int_raster_line = 0;
/* Clock value for raster compare IRQ. */
static CLOCK int_raster_clk;

/* Internal color memory. */
static BYTE colorRam[0x400];

/* Video memory pointers. */
static BYTE *screen_ptr;
static BYTE *chargen_ptr;
static BYTE *bitmap_ptr;
static BYTE * const color_ptr = colorRam;

/* Screen memory buffers (chars and color). */
static BYTE vbuf[SCREEN_TEXTCOLS];
static BYTE cbuf[SCREEN_TEXTCOLS];

/* If this flag is set, bad lines (DMA's) can happen.  */
static int allow_bad_lines;

/* Sprite-sprite and sprite-background collision registers. */
static BYTE ss_collmask = 0;
static BYTE sb_collmask = 0;

/* Extended background colors. (1, 2 and 3) */
static BYTE ext_background_color[3];

/* Sprite-sprite and sprite-background collisions detected on the current
   line. */
static BYTE cl_ss_collmask;
static BYTE cl_sb_collmask;

/* Time when int_rasterfetch() is called. */
CLOCK vic_ii_fetch_clk;

/* Start of the memory bank seen by the VIC-II. */
int vbank = 0;

/* C128 MMU... unluckily, this is not used yet.  This can result in on-screen
   garbage when the VIC-II is being used. */
#if defined (C128)
extern BYTE mmu[];
#endif

#include "raster.c"

static void init_drawing_tables(void);

/* ------------------------------------------------------------------------- */

/* Set the video mode according to the values in registers $11 and $16 of the
   VIC-II chip. */
inline static void set_video_mode(void)
{
    video_mode = ((vic[0x11] & 0x60) | (vic[0x16] & 0x10)) >> 4;
    
#ifdef VIC_II_VMODE_DEBUG
    switch (video_mode) {
      case VIC_II_NORMAL_TEXT_MODE:
	DEBUG_VMODE(("Standard Text"));
	break;
      case VIC_II_MULTICOLOR_TEXT_MODE:
	DEBUG_VMODE(("Multicolor Text"));
	break;
      case VIC_II_HIRES_BITMAP_MODE:
	DEBUG_VMODE(("Hires Bitmap"));
	break;
      case VIC_II_MULTICOLOR_BITMAP_MODE:
	DEBUG_VMODE(("Multicolor Bitmap"));
	break;
      case VIC_II_EXTENDED_TEXT_MODE:
	DEBUG_VMODE(("Extended Text"));
	break;
      case VIC_II_ILLEGAL_TEXT_MODE:
	DEBUG_VMODE(("Illegal Text"));
	break;
      case VIC_II_ILLEGAL_BITMAP_MODE_1:
	DEBUG_VMODE(("Invalid Bitmap"));
	break;
      case VIC_II_ILLEGAL_BITMAP_MODE_2:
	DEBUG_VMODE(("Invalid Bitmap"));
	break;
      default:			/* cannot happen */
	DEBUG_VMODE(("???"));
    }

    DEBUG_VMODE((" Mode enabled at line $%04X.\n", CURRENT_LINE));
#endif
}

/* Set the memory pointers according to the values in the registers. */
inline static void set_memory_ptrs(void)
{
    ADDRESS scraddr;		/* Screen start address. */
    BYTE *screenbase;		/* Pointer to screen memory. */
    BYTE *charbase;		/* Pointer to character memory. */
    BYTE *bitmapbase;		/* Pointer to bitmap memory. */
    ADDRESS tmp;

    scraddr = vbank + ((vic[0x18] & 0xf0) << 6);

    if ((scraddr & 0x7000) != 0x1000) {
	screenbase = ram + scraddr;
	DEBUG_REGISTER(("\tVideo memory at $%04X\n", scraddr));
    } else {
	screenbase = char_rom + (scraddr & 0x800);
	DEBUG_REGISTER(("\tVideo memory at Character ROM + $%04X\n",
			scraddr & 0x800));
    }

    tmp = (vic[0x18] & 0xe) << 10;
    bitmapbase = ram + (tmp & 0xe000);
    tmp += vbank;

    DEBUG_REGISTER(("\tBitmap memory at $%04X\n", bitmapbase - ram + vbank));

    if ((tmp & 0x7000) != 0x1000) {
	charbase = ram + tmp;
	DEBUG_REGISTER(("\tUser-defined character set at $%04X\n", tmp));
    } else {
	charbase = char_rom + (tmp & 0x0800);
	DEBUG_REGISTER(("\tStandard %s character set enabled\n",
			tmp & 0x800 ? "Lower Case" : "Upper Case"));
    }

    screen_ptr = screenbase;
    bitmap_ptr = bitmapbase + vbank;
    chargen_ptr = charbase;
    vbank_ptr = ram + vbank;
    sprite_ptr_base = screen_ptr + 0x3f8;
}

/* Calculate the value of clk when int_raster() should be called next time. */
inline static void update_int_raster(void)
{
    if (int_raster_line < VIC_II_SCREEN_HEIGHT) {
	int current_line = CURRENT_LINE;

	int_raster_clk = (LINE_START_CLK + RASTER_INT_DELAY - INTERRUPT_DELAY
			  + CYCLES_PER_LINE * (int_raster_line
					       - current_line));
	if (int_raster_line <= current_line)
	    int_raster_clk += VIC_II_SCREEN_HEIGHT * CYCLES_PER_LINE;
	maincpu_set_alarm_clk(A_RASTER, int_raster_clk);
    } else {
	DEBUG_RASTER(("VIC: update_int_raster(): "
		      "raster compare out of range ($%04X)!\n",
		      int_raster_line));
	maincpu_unset_alarm(A_RASTER);
    }
    DEBUG_RASTER(("VIC: update_int_raster(): "
		  "int_raster_clk = %ul, line = $%04X, vic[0x1a]&1 = %d\n",
		  int_raster_clk, int_raster_line, vic[0x1a] & 1));
}

/* Initialize the VIC-II emulation. */
canvas_t vic_ii_init(void)
{
    init_raster(1, 2, 2);
    video_resize();
    if (open_output_window(VIC_II_WINDOW_TITLE,
			   SCREEN_XPIX + SCREEN_BORDERWIDTH * 2,
			   SCREEN_YPIX + ((SCREEN_HEIGHT - SCREEN_YPIX) / 4),
			   color_defs,
			   ((canvas_redraw_t)vic_ii_exposure_handler))) {
	fprintf(stderr,
		"fatal error: can't open window for the VIC-II emulation.\n");
	return NULL;
    }
    display_ystart = VIC_II_25ROW_START_LINE;
    display_ystop = VIC_II_25ROW_STOP_LINE;
    store_vic(0x18, 0x15);
    set_video_mode();
    set_memory_ptrs();
    init_drawing_tables();
    refresh_all();
    return canvas;
}

/* Reset the VIC-II chip. */
void reset_vic_ii(void)
{
    reset_raster();
    maincpu_set_alarm_clk(A_RASTERDRAW, DRAW_CYCLE);
}

/* This hook is called by the CIA#2 whenever vbank is changed. */
void screen_init(void)
{
    set_memory_ptrs();
}

/* Handle the exposure event. */
void vic_ii_exposure_handler(unsigned int width, unsigned int height)
{
    resize(width, height);
    force_repaint();
}

/* Free the allocated frame buffer. */
void video_free(void)
{
    frame_buffer_free(&frame_buffer);
#ifdef C128
    vdc_video_free();
#endif
}

/* ------------------------------------------------------------------------- */

/* This is a helper function for $D011 DMA tricks.  Fetch `chars' characters
   assuming that the matrix line counter is `vmli'. */
inline static void do_dma(int chars, int vmli)
{
    if (chars > 0) {
	/* If in idle state, the counters have not been incremented. */
	if (idle_state)
	    vmli = 0;
	/* As explained in Christian's article, the VIC-II needs at least 3
           cycles to become the bus master and when it is not yet, it fetches
           0xff. */
	if (chars <= 3) {
	    memset(vbuf + vmli, 0xff, chars);
	    /* Color memory is made of nibbles, so we put 0xf in it. */
	    memset(cbuf + vmli, 0x0f, chars);
	} else {
	    memset(vbuf + vmli, 0xff, 3);
	    memcpy(vbuf + vmli + 3,
		   screen_ptr + mem_counter + vmli + 3,
		   chars - 3);
	    memset(cbuf + vmli, 0x0f, 3);
	    memcpy(cbuf + vmli + 3,
		   color_ptr + mem_counter + vmli + 3,
		   chars - 3);
	}
    }
}

/* Here we try to emulate $D011... */
inline static void store_d011(BYTE value)
{
    int r = int_raster_line;
    int cycle = CURRENT_LINE_CYCLE;
    int line = CURRENT_LINE;
	      
    DEBUG_REGISTER(("\tControl register: $%02X\n", value));
    DEBUG_REGISTER(("$D011 trickery at cycle %d, line $%04X, value $%02X\n",
		    cycle, line, value));

    vic[0x11] = value;

    int_raster_line = ((int_raster_line & 0xff) | ((value & 0x80) << 1));

    DEBUG_REGISTER(("\tRaster interrupt line set to $%04X\n",
		    int_raster_line));

    if (int_raster_line != r)
	update_int_raster();

    blank = !(value & 0x10);	/* DEN bit */
    if (line == 0x30)
	allow_bad_lines = !blank;

    if (ysmooth != (value & 0x7) && line >= 0x30 && line <= 0xf7) {
	if ((line & 0x7) == ysmooth && cycle < FETCH_CYCLE) {
	    DEBUG_REGISTER(("$D011 removes bad line $%04X "
			    "at cycle %d\n", line, cycle));
	    DEBUG_REGISTER(("\tmemptr = %d mem_counter = %d\n",
			    memptr, mem_counter));
	    memptr = (memptr + VIC_II_SCREEN_TEXTCOLS) & 0x3ff;
	} else if ((line & 0x7) == (value & 0x7) && allow_bad_lines
		   && line >= 0x30 && !dma_msk) {
	    if (cycle > 54 && cycle <= 57) {
#if DRAW_CYCLE < 57
		/* This means that this line has become `bad' *after* the fetch
		   period.  At cycle 57, if this is a bad line, ycounter is
		   incremented and the chip goes to display state.  Since
		   DRAW_CYCLE is < 57, this has not been done in
		   int_rasterdraw(), so we emulate it here.
		   Not doing this can cause some vertical scrolls to be
		   `jumpy'. */
		ycounter = (ycounter + 1) & 0x7;
		idle_state = 0;
#endif
	    } else if (cycle >= FETCH_CYCLE) {
		/* Delayed DMA.  This can be broken if sprites mess up the
		   video timing! (sprite timings are approximated) */
		int vmli = cycle - FETCH_CYCLE;
		int chars = 40 - vmli;

		DEBUG_REGISTER(("Line $%04X: Delayed DMA chars = %d, "
				"cycle = %d clk-oldclk = %d, ycounter = %d\n",
				line, chars, cycle, clk - oldclk, ycounter));
		/* This is a hack to make emulate_line() do the right
		   thing even if it does not know about it... */
		if (cycle <= DRAW_CYCLE || clk - oldclk >= CYCLES_PER_LINE) {
		    /* The rasterdraw() event is pending for this line.  Just
		       change mem_counter so that when it is incremented by
		       SCREEN_TEXTCOLS in emulate_line() it will contain the
		       right value. */
		    do_dma(chars, vmli);
		    mem_counter -= SCREEN_TEXTCOLS - chars;
		    idle_state = 0;
		    bad_line = 1;
		    memory_fetch_done = 2;
		} else {
		    /* The rasterdraw() event has already been served
		       on this line.  We have to do our best to fix
		       what it has done wrong... */	
		    do_dma(chars, vmli);
		    mem_counter += chars;
		    bad_line = memory_fetch_done = 0;
		    if (!old_idle_state) {
			/* If we were not in idle state and ycounter was equal
			   to 7, the emulate_line() function (wrongly) set
			   memptr to mem_counter in advance and did not change
			   ycounter, so that it is still equal to 7.  So, in
			   order to emulate the right behavior, we have to set
			   memptr to the new value if ycounter is now equal to
			   7. */
			if (ycounter == 7) 
			    memptr = mem_counter;
			/* If ycounter was not 7, it has already been
			   incremented, so we don't have to do
			   anything special. */
		    } else {
			/* We were in idle state when emulate_line() was
			   called, so ycounter was not incremented and
			   memptr_counter was not copied to memptr even if
			   ycounter was equal to 7.  Do this now. */
			if (ycounter == 7)
			    memptr = mem_counter;
			ycounter = (ycounter + 1) & 0x7;
		    }
		}
		idle_state = 0;
		clk = LINE_START_CLK + 54;
	    } else if (cycle == FETCH_CYCLE - 1) {
		ycounter = idle_state = 0;
		memptr = mem_counter;
	    }
	}
    }

    ysmooth = value & 0x7;

    if (value & 0x8) {	 /* 25 column mode */
	display_ystart = VIC_II_25ROW_START_LINE;
	display_ystop = VIC_II_25ROW_STOP_LINE;
	DEBUG_REGISTER(("25 line mode enabled\n"));
    } else {			/* 24 column mode */
	display_ystart = VIC_II_24ROW_START_LINE;
	display_ystop = VIC_II_24ROW_STOP_LINE;
	DEBUG_REGISTER(("24 line mode enabled\n"));
    }

    /* We normally turn borders on/off and enable bad lines only when we
       repaint the raster line, at cycle DRAW_CYCLE.  Try to emulate the real
       behavior here. */
    if (cycle > DRAW_CYCLE) {
	if (line == display_ystart && !blank)
	    blank_enabled = 0;
	else if (line == display_ystop)
	    blank_enabled = 1;
    }
    set_video_mode();
}

/* ------------------------------------------------------------------------- */

/* Store a value in a VIC-II register. */
void store_vic(ADDRESS addr, BYTE value)
{
    addr &= 0x3f;

    if (clk > vic_ii_fetch_clk)
	int_rasterfetch(clk - vic_ii_fetch_clk);
    
    DEBUG_REGISTER(("VIC: WRITE $D0%02X at cycle %d of rasterline $%04X\n",
		    addr, CURRENT_LINE_CYCLE, CURRENT_LINE));

    switch (addr) {
      case 0x0:		/* $D000: Sprite #0 X position LSB */
      case 0x2:		/* $D002: Sprite #1 X position LSB */
      case 0x4:		/* $D004: Sprite #2 X position LSB */
      case 0x6:		/* $D006: Sprite #3 X position LSB */
      case 0x8:		/* $D008: Sprite #4 X position LSB */
      case 0xa:		/* $D00a: Sprite #5 X position LSB */
      case 0xc:		/* $D00c: Sprite #6 X position LSB */
      case 0xe:		/* $D00e: Sprite #7 X position LSB */
	vic[addr] = value;
	sprites[addr >> 1].x &= 0x100;
	sprites[addr >> 1].x |= value;
	DEBUG_REGISTER(("\tSprite #%d X position LSB: $%02X\n",
			addr >> 1, value));
	break;

      case 0x1:		/* $D001: Sprite #0 Y position */
      case 0x3:		/* $D003: Sprite #1 Y position */
      case 0x5:		/* $D005: Sprite #2 Y position */
      case 0x7:		/* $D007: Sprite #3 Y position */
      case 0x9:		/* $D009: Sprite #4 Y position */
      case 0xb:		/* $D00B: Sprite #5 Y position */
      case 0xd:		/* $D00D: Sprite #6 Y position */
      case 0xf:		/* $D00F: Sprite #7 Y position */
	vic[addr] = value;
	sprites[addr >> 1].y = value + 1;
	DEBUG_REGISTER(("\tSprite #%d Y position: $%02X\n",
			addr >> 1, value));
	break;

      case 0x10:		/* $D010: Sprite X position MSB */
	if (value != vic[0x10]) {
	    int i;
	    BYTE b;

	    vic[0x10] = value;
	    for (i = 0, b = 0x01; i < 8; b <<= 1, i++)
		sprites[i].x = ((sprites[i].x & 0xff)
				| (value & b ? 0x100 : 0));
	}
	DEBUG_REGISTER(("\tSprite X position MSBs: $%02X\n", value));
	return;

      case 0x11:		/* $D011: video mode, Y scroll, 24/25 line mode
				   and raster MSB */
	store_d011(value);
	return;

      case 0x12:		/* $D012: Raster line compare */
	{
	    int r = int_raster_line;
	    int line = CURRENT_LINE;

	    vic[0x12] = value;
	    DEBUG_REGISTER(("\tRaster compare register: $%02X\n", value));
	    int_raster_line = (int_raster_line & 0x100) | value;
	    DEBUG_REGISTER(("\tRaster interrupt line set to $%04X\n",
			    int_raster_line));
	    if (r != int_raster_line)
		update_int_raster();
	    if (int_raster_line >= SCR_LINES)
		DEBUG_REGISTER(("\tMmmh... strange raster interrupt at line "
				"$%04X\n", int_raster_line));
	    if (int_raster_line == line)
		if (vic[0x1a] & 0x1) {
		    videoint |= 0x81;
		    maincpu_set_irq(I_RASTER, 1);
		}
	}
      return;

      case 0x13:		/* $D013: Light Pen X */
      case 0x14:		/* $D014: Light Pen Y */
	return;

      case 0x15:		/* $D015: Sprite Enable */
	vic[0x15] = visible_sprite_msk = value;
	DEBUG_REGISTER(("\tSprite Enable register: $%02X\n", value));
	return;

      case 0x16:		/* $D016 */
	{
	    int cycle = CURRENT_LINE_CYCLE;
	      
	    DEBUG_REGISTER(("\tControl register: $%02X\n", value));
	      
	    xsmooth = value & 0x7;

	    /* Bit 4 (CSEL) selects 38/40 column mode, */
	    if (value & 0x8) {
		/* 40 column mode. */
		display_xstart = 0x18;
		display_xstop = 0x158;
		DEBUG_REGISTER(("\t40 column mode enabled\n"));
	    } else {
		/* If CSEL changes from 1 to 0 at cycle 56, the lateral border
		   is open.  The timing of sprites is not 100% correct yet,
		   and the real code to do this is still missing, so we are
		   just joking... */
		if ((vic[0x16] & 0x8) && cycle == 56)
		    /* Open the border... */ ;
		  
		/* 38 column mode. */
		display_xstart = 0x1f;
		display_xstop = 0x14f;
		DEBUG_REGISTER(("\t38 column mode enabled\n"));
	    }

	    vic[0x16] = value;
	    set_video_mode();
	    return;
	}

      case 0x17:		/* $D017: Sprite Y-expand */
	if (value != vic[0x17]) {
	    int i;
	    BYTE b;

	    vic[0x17] = value;
	    for (i = 0, b = 0x01; i < 8; b <<= 1, i++)
		sprites[i].y_expanded = value & b ? 1 : 0;
	}
	DEBUG_REGISTER(("\tSprite Y Expand register: $%02X\n", value));
	return;

      case 0x18:		/* $D018: Video and char matrix base address */
	DEBUG_REGISTER(("\tMemory register: $%02X\n", value));
	vic[0x18] = value;
	set_memory_ptrs();
	return;

      case 0x19:		/* $D019: IRQ flag register */
	if (rmw_flag)		/* (emulates the Read-Modify-Write bug) */
	    vic[0x19] = 0;
	else {
	    vic[0x19] &= ~(value | 0x80);
	    if (vic[0x19] & vic[0x1a])
		vic[0x19] |= 0x80;
	}
	videoint = vic[0x19];
	  
	/* Update the IRQ line accordingly...
	   The external VIC IRQ line is an AND of the internal collision and
	   raster IRQ lines. */
	if (videoint & 0x80) {
	    maincpu_set_irq(I_RASTER, 1);
	} else {
	    maincpu_set_irq(I_RASTER, 0);
	}
	  
	DEBUG_REGISTER(("\tIRQ flag register: $%02X\n", vic[0x19]));
	return;
	  
      case 0x1a:		/* $D01A: IRQ mask register */
#if defined (NEW_TIMER_CODE)
	update_intr_alarm();
#endif

	vic[0x1a] = value & 0xf;

	if (vic[0x1a] & videoint) {
	    videoint |= 0x80;
	    maincpu_set_irq(I_RASTER, 1);
	} else {
	    videoint &= 0x7f;
	    maincpu_set_irq(I_RASTER, 0);
	}

	DEBUG_REGISTER(("\tIRQ mask register: $%02X\n", vic[0x1a]));
	return;

      case 0x1b:		/* $D01B: Sprite priority */
	if (value != vic[0x1b]) {
	    int i;
	    BYTE b;
	    vic[0x1b] = value;
	    for (i = 0, b = 0x01; i < 8; b <<= 1, i++)
		sprites[i].in_background = value & b ? 1 : 0;
	}
	DEBUG_REGISTER(("\tSprite priority register: $%02X\n", value));
	return;

      case 0x1c:		/* $D01C: Sprite Multicolor select */
	if (value != vic[0x1c]) {
	    int i;
	    BYTE b;

	    vic[0x1c] = value;
	    for (i = 0, b = 0x01; i < 8; b <<= 1, i++)
		sprites[i].multicolor = value & b ? 1 : 0;
	}
	DEBUG_REGISTER(("\tSprite Multicolor Enable register: $%02X\n",
			value));
	return;

      case 0x1d:		/* $D01D: Sprite X-expand */
	if (value != vic[0x1d]) {
	    int i;
	    BYTE b;

	    vic[0x1d] = value;
	    for (i = 0, b = 0x01; i < 8; b <<= 1, i++)
		sprites[i].x_expanded = value & b ? 1 : 0;
	}
	DEBUG_REGISTER(("\tSprite X Expand register: $%02X\n", value));
	return;

      case 0x1e:		/* $D01E: Sprite-sprite collision */
      case 0x1f:		/* $D01F: Sprite-background collision */
	DEBUG_REGISTER(("\t(collision register, Read Only)\n"));
	return;

      case 0x20:		/* $D020: Border color */
	border_color = vic[0x20] = value & 0xf;
	DEBUG_REGISTER(("\tBorder color register: $%02X\n", value));
	return;

      case 0x21:		/* $D021: Background #0 color */
	background_color = vic[0x21] = value & 0xf;
	DEBUG_REGISTER(("\tBackground #0 color register: $%02X\n", value));
	return;

      case 0x22:		/* $D022: Background #1 color */
      case 0x23:		/* $D023: Background #2 color */
      case 0x24:		/* $D024: Background #3 color */
	ext_background_color[addr - 0x22] = vic[addr] = value & 0xf;
	DEBUG_REGISTER(("\tBackground color #%d register: $%02X\n",
			addr - 0x21, value));
	return;

      case 0x25:		/* $D025: Sprite multicolor register #0 */
	DEBUG_REGISTER(("\tSprite multicolor register #0: $%02X\n", value));
	mc_sprite_color_1 = vic[0x25] = value & 0xf;
	return;

      case 0x26:		/* $D026: Sprite multicolor register #1 */
	DEBUG_REGISTER(("\tSprite multicolor register #1: $%02X\n", value));
	mc_sprite_color_2 = vic[0x26] = value & 0xf;
	return;

      case 0x27:		/* $D027: Sprite #0 color */
      case 0x28:		/* $D028: Sprite #1 color */
      case 0x29:		/* $D029: Sprite #2 color */
      case 0x2a:		/* $D02A: Sprite #3 color */
      case 0x2b:		/* $D02B: Sprite #4 color */
      case 0x2c:		/* $D02C: Sprite #5 color */
      case 0x2d:		/* $D02D: Sprite #6 color */
      case 0x2e:		/* $D02E: Sprite #7 color */
	sprites[addr - 0x27].color = vic[addr] = value & 0xf;
	DEBUG_REGISTER(("\tSprite #%d color register: $%02X\n", addr - 0x27,
			value));
	return;

      case 0x2f:		/* $D02F: Unused */
      case 0x30:		/* $D030: Unused */
      case 0x31:		/* $D031: Unused */
      case 0x32:		/* $D032: Unused */
      case 0x33:		/* $D033: Unused */
      case 0x34:		/* $D034: Unused */
      case 0x35:		/* $D035: Unused */
      case 0x36:		/* $D036: Unused */
      case 0x37:		/* $D037: Unused */
      case 0x38:		/* $D038: Unused */
      case 0x39:		/* $D039: Unused */
      case 0x3a:		/* $D03A: Unused */
      case 0x3b:		/* $D03B: Unused */
      case 0x3c:		/* $D03C: Unused */
      case 0x3d:		/* $D03D: Unused */
      case 0x3e:		/* $D03E: Unused */
      case 0x3f:		/* $D03F: Unused */
	DEBUG_REGISTER(("\t(unused)\n"));
	return;
    }
}

/* Read a value from a VIC-II register. */
BYTE read_vic(ADDRESS addr)
{
    addr &= 0x3f;

    DEBUG_REGISTER(("VIC: READ $D0%02X at cycle %d of rasterline $%04X:\n",
		    addr, CURRENT_LINE_CYCLE, CURRENT_LINE));

    switch (addr) {
      case 0x0:		/* $D000: Sprite #0 X position LSB */
      case 0x2:		/* $D002: Sprite #1 X position LSB */
      case 0x4:		/* $D004: Sprite #2 X position LSB */
      case 0x6:		/* $D006: Sprite #3 X position LSB */
      case 0x8:		/* $D008: Sprite #4 X position LSB */
      case 0xa:		/* $D00a: Sprite #5 X position LSB */
      case 0xc:		/* $D00c: Sprite #6 X position LSB */
      case 0xe:		/* $D00e: Sprite #7 X position LSB */
	DEBUG_REGISTER(("\tSprite #%d X position LSB: $%02X\n", addr >> 1,
			vic[addr]));
	return vic[addr];

      case 0x1:		/* $D001: Sprite #0 Y position */
      case 0x3:		/* $D003: Sprite #1 Y position */
      case 0x5:		/* $D005: Sprite #2 Y position */
      case 0x7:		/* $D007: Sprite #3 Y position */
      case 0x9:		/* $D009: Sprite #4 Y position */
      case 0xb:		/* $D00B: Sprite #5 Y position */
      case 0xd:		/* $D00D: Sprite #6 Y position */
      case 0xf:		/* $D00F: Sprite #7 Y position */
	DEBUG_REGISTER(("\tSprite #%d Y position: $%02X\n", addr >> 1,
			vic[addr]));
	return vic[addr];

      case 0x10:		/* $D010: Sprite X position MSB */
	DEBUG_REGISTER(("\tSprite X position MSB: $%02X\n", vic[addr]));
	return vic[addr];

      case 0x11:		/* $D011: video mode, Y scroll, 24/25 line mode
				   and raster MSB */
      case 0x12:		/* $D012: Raster line compare */
	{
	    int tmp = CURRENT_LINE;

#if LINE_REG_DELAY > 0
	    /* Emulate the (supposed) delay of the Raster line register. */
	    if (CURRENT_LINE_CYCLE < LINE_REG_DELAY)
		tmp = PREVIOUS_LINE(tmp);
#endif

	    DEBUG_REGISTER(("\tRaster Line register %s value = $%04X\n",
			    (addr == 0x11 ? "(highest bit) " : ""), tmp));

	    if (addr == 0x11)
		return (vic[addr] & 0x7f) | ((tmp & 0x100) >> 1);
	    else
		return tmp & 0xff;
	}

      case 0x13:		/* $D013: Light Pen X */
      case 0x14:		/* $D014: Light Pen Y */
	DEBUG_REGISTER(("\t(Light pen not implemented)\n"));
	return 0xff;

      case 0x15:		/* $D015: Sprite Enable */
	DEBUG_REGISTER(("\tSprite Enable register: $%02X\n", vic[addr]));
	return vic[addr];

      case 0x16:		/* $D016 */
	DEBUG_REGISTER(("\t$D016 Control register read: $%02X\n", vic[addr]));
	return vic[addr];

      case 0x17:		/* $D017: Sprite Y-expand */
	DEBUG_REGISTER(("\tSprite Y Expand register: $%02X\n", vic[addr]));
	return vic[addr];

      case 0x18:		/* $D018: Video and char matrix base address */
	DEBUG_REGISTER(("\tVideo memory address register: $%02X\n",
			vic[addr]));
	return vic[addr];

      case 0x19:		/* $D019: IRQ flag register */
	DEBUG_RASTER(("VIC: read interrupt register: $%02X\n",
		      videoint | 0x70));
	DEBUG_REGISTER(("\tInterrupt register: $%02X\n", videoint | 0x70));
	if (CURRENT_LINE == int_raster_line && (vic[0x1a] & 0x1))
	    /* As int_raster() is called 2 cycles later than it should be to
	       emulate the 6510 internal IRQ delay, videoint might not have
	       bit 0 set as it should. */
	    return videoint | 0x71;
	else
	    return videoint | 0x70;

      case 0x1a:		/* $D01A: IRQ mask register  */
	DEBUG_REGISTER(("\tMask register: $%02X\n", vic[addr] | 0xf0));
	return vic[addr] | 0xf0;

      case 0x1b:		/* $D01B: Sprite priority */
	DEBUG_REGISTER(("\tSprite Priority register: $%02X\n", vic[addr]));
	return vic[addr];

      case 0x1c:		/* $D01C: Sprite Multicolor select */
	DEBUG_REGISTER(("\tSprite Multicolor Enable register: $%02X\n",
			vic[addr]));
	return vic[addr];

      case 0x1d:		/* $D01D: Sprite X-expand */
	DEBUG_REGISTER(("\tSprite X Expand register: $%02X\n", vic[addr]));
	return vic[addr];

      case 0x1e:		/* $D01E: Sprite-sprite collision */
	/* Remove the pending sprite-sprite interrupt, as the collision
	   register is reset upon read accesses. */
	if (!(videoint & 0x3)) {
	    videoint &= ~0x84;
	    maincpu_set_irq(I_RASTER, 0);
	} else {
	    videoint &= ~0x04;
	}
	if (app_resources.checkSsColl) {
	    vic[addr] = ss_collmask;
	    ss_collmask = 0;
	    DEBUG_REGISTER(("\tSprite-sprite collision mask: $%02X\n",
			    vic[addr]));
	    return vic[addr];
	} else {
	    DEBUG_REGISTER(("\tSprite-sprite collision mask: $00 "
			    "(emulation disabled)\n"));
	    ss_collmask = 0;
	    return 0;
	}

      case 0x1f:		/* $D01F: Sprite-background collision */
	/* Remove the pending sprite-background interrupt, as the collision
	   register is reset upon read accesses. */
	if (!(videoint & 0x5)) {
	    videoint &= ~0x82;
	    maincpu_set_irq(I_RASTER, 0);
	} else {
	    videoint &= ~0x2;
	}
	if (app_resources.checkSbColl) {
	    vic[addr] = sb_collmask;
	    /*printf("Reading S-B collision at line $%04X, value = $%04X\n",
		   rasterline, vic[addr]);*/
	    sb_collmask = 0;
	    DEBUG_REGISTER(("\tSprite-background collision mask: $%02X\n",
			    vic[addr]));
#if defined (DEBUG_SB_COLLISIONS)
	    printf("VIC: sb_collmask reset by $D01F read at line 0x%X.\n",
		   rasterline);
#endif
	    return vic[addr];
	} else {
	    DEBUG_REGISTER(("\tSprite-background collision mask: $00 "
			    "(emulation disabled)\n"));
	    sb_collmask = 0;
	    return 0;
	}

      case 0x20:		/* $D020: Border color */
	DEBUG_REGISTER(("\tBorder Color register: $%02X\n", vic[addr]));
	return vic[addr] | 0xf0;

      case 0x21:		/* $D021: Background #0 color */
      case 0x22:		/* $D022: Background #1 color */
      case 0x23:		/* $D023: Background #2 color */
      case 0x24:		/* $D024: Background #3 color */
	DEBUG_REGISTER(("\tBackground Color #%d register: $%02X\n",
			addr - 0x21, vic[addr]));
	return vic[addr] | 0xf0;

      case 0x25:		/* $D025: Sprite multicolor register #0 */
      case 0x26:		/* $D026: Sprite multicolor register #1 */
	DEBUG_REGISTER(("\tMulticolor register #%d: $%02X\n",
			addr - 0x22, vic[addr]));
	return vic[addr] | 0xf0;

      case 0x27:		/* $D027: Sprite #0 color */
      case 0x28:		/* $D028: Sprite #1 color */
      case 0x29:		/* $D029: Sprite #2 color */
      case 0x2a:		/* $D02A: Sprite #3 color */
      case 0x2b:		/* $D02B: Sprite #4 color */
      case 0x2c:		/* $D02C: Sprite #5 color */
      case 0x2d:		/* $D02D: Sprite #6 color */
      case 0x2e:		/* $D02E: Sprite #7 color */
	DEBUG_REGISTER(("\tSprite #%d color: $%02X\n",
			addr - 0x22, vic[addr]));
	return vic[addr] | 0xf0;

#if defined (C128)
      case 0x2f:		/* $D02F: Additional KBD rows */
	return (vic[0x2f] | 0xf8);
#else
      case 0x2f:		/* $D02F: Unused */
#endif

      case 0x30:		/* $D030: Unused */
      case 0x31:		/* $D031: Unused */
      case 0x32:		/* $D032: Unused */
      case 0x33:		/* $D033: Unused */
      case 0x34:		/* $D034: Unused */
      case 0x35:		/* $D035: Unused */
      case 0x36:		/* $D036: Unused */
      case 0x37:		/* $D037: Unused */
      case 0x38:		/* $D038: Unused */
      case 0x39:		/* $D039: Unused */
      case 0x3a:		/* $D03A: Unused */
      case 0x3b:		/* $D03B: Unused */
      case 0x3c:		/* $D03C: Unused */
      case 0x3d:		/* $D03D: Unused */
      case 0x3e:		/* $D03E: Unused */
      case 0x3f:		/* $D03F: Unused */
	return 0xff;

#if 0
      default:
	return ((addr < 0x31) ? vic[addr] : 0xff);	/* VIC IIe size */
#else
      default:
	return 0xff;
#endif
    }
}

/* These are only needed by x128... */

void store_colorram(ADDRESS addr, BYTE value)
{
    colorRam[addr & 0x3ff] = value & 0xf;
}

BYTE read_colorram(ADDRESS addr)
{
    return colorRam[addr & 0x3ff] | (rand() & 0xf0);
}

/* ------------------------------------------------------------------------- */

/* If we are on a bad line, do the DMA. */
inline static void do_memory_fetch(void)
{
    if (!memory_fetch_done) {
	memory_fetch_done = 1;
	mem_counter = memptr;
	if ((rasterline & 7) == ysmooth && rasterline >= 0x30
	    && rasterline <= 0xf7 && allow_bad_lines) {
	    idle_state = ycounter = 0;
	    memory_fetch_done = 2;
	    memcpy(vbuf, screen_ptr + memptr, SCREEN_TEXTCOLS);
	    memcpy(cbuf, color_ptr + memptr, SCREEN_TEXTCOLS);
	    clk += SCREEN_TEXTCOLS + 3;
	    bad_line = 1;
	}
    }
}

/* ------------------------------------------------------------------------- */

/* Redraw the current raster line.  This happens at cycle DRAW_CYCLE of each
   line. */
int int_rasterdraw(long offset)
{
#ifndef NO_REDRAW
    
    BYTE prev_ss_collmask = ss_collmask, prev_sb_collmask = sb_collmask;
    
    emulate_line();

    /* As explained in Christian's article, only the first collision (i.e. the
       first time the collision register becomes non-zero) actually triggers an
       interrupt. */
    if (app_resources.checkSsColl && cl_ss_collmask && !prev_ss_collmask) {
	videoint |= 0x4;
	if (vic[0x1a] & 0x4) {
	    maincpu_set_irq(I_RASTER, 1);
	    videoint |= 0x80;
	}
    }
    if (app_resources.checkSbColl && cl_sb_collmask && !prev_sb_collmask) {
	videoint |= 0x2;
	if (vic[0x1a] & 0x2) {
	    maincpu_set_irq(I_RASTER, 1);
	    videoint |= 0x80;
	}
    }

#else  /* NO_REDRAW */

    rasterline = (rasterline + 1) % SCREEN_HEIGHT;
    oldclk += CYCLES_PER_LINE;

#endif

    /* Set the next RASTERDRAW event. */
    maincpu_set_alarm_clk(A_RASTERDRAW, oldclk + CYCLES_PER_LINE);

    /* If in the bad line range, prepare the DMA access event. */
    if (rasterline >= 0x30 && rasterline <= 0xf7) {
	vic_ii_fetch_clk = (oldclk + FETCH_CYCLE + CYCLES_PER_LINE
			    - DRAW_CYCLE - 2);
	maincpu_set_alarm_clk(A_RASTERFETCH, vic_ii_fetch_clk);
    } else
	vic_ii_fetch_clk = CLOCK_MAX;
    
    return 0;
}

/* If we are on a bad line, do the DMA. */
int int_rasterfetch(long offset)
{
    do_memory_fetch();
    maincpu_unset_alarm(A_RASTERFETCH);
    vic_ii_fetch_clk = CLOCK_MAX;
    return 0;
}

/* If necessary, emulate a raster compare IRQ. This is called when the raster
   line counter matches the value stored in the raster line register. */
int int_raster(long offset)
{
    videoint |= 0x1;
    if (vic[0x1a] & 0x1) {
	maincpu_set_irq_clk(I_RASTER, 1, int_raster_clk);
	videoint |= 0x80;
	DEBUG_RASTER(("VIC: *** IRQ requested at line $%04X, "
		      "int_raster_line=$%04X, offset = %ld, cycle = %d.\n",
		      CURRENT_LINE, int_raster_line, offset,
		      CURRENT_LINE_CYCLE));
    }
    int_raster_clk += VIC_II_SCREEN_HEIGHT * CYCLES_PER_LINE;
    maincpu_set_alarm_clk(A_RASTER, int_raster_clk);
    return 0;
}

/* ------------------------------------------------------------------------- */

/* Here comes the part that actually repaints each raster line and checks for
   sprite collisions.  The following tables are used to speed up the
   drawing. */
/* We do not use multi-dimensional arrays as we can optimize better this
   way... */

/* foreground(4) | background(4) | nibble(4) -> 4 pixels. */
static PIXEL4 hr_table[16 * 16 * 16];
/* foreground(4) | background(4) | idx(2) | nibble(4) -> 4 pixels. */
static PIXEL4 hr_table_2x[16 * 16 * 2 * 16];
/* mc flag(1) | idx(2) | byte(8) -> index into double-pixel table. */
static WORD mc_table[2 * 4 * 256];

/* Sprite tables. */
static DWORD sprite_doubling_table[65536];
static WORD mcmsktable[512];
static BYTE mcsprtable[256];

/* This is a bit mask representing each pixel on the screen (1 = foreground,
   0 = background) and is used both for sprite-background collision checking
   and background sprite drawing.  When cache is turned on, a cached mask for
   each line is used instead. */
static BYTE gfx_msk[SCREEN_GFXMSK_SIZE];

/* Each byte in this array is a bit mask representing the sprites that
   have a pixel turned on in that position.  This is used for sprite-sprite
   collision checking. */
static BYTE sprline[0x230];

/* Initialize the drawing tables. */
static void init_drawing_tables(void)
{
    DWORD i;
    unsigned int f, b;
    WORD wmsk;
    DWORD lmsk;
    char tmptable[4] = { 0, 4, 5, 3 };

    for (i = 0; i <= 0xf; i++) {
	for (f = 0; f <= 0xf; f++) {
	    for (b = 0; b <= 0xf; b++) {
		PIXEL fp = PIXEL(f);
		PIXEL bp = PIXEL(b);
		int offset = (f << 8) | (b << 4);
		PIXEL *p = (PIXEL *)(hr_table + offset + i);

		*p = i & 0x8 ? fp : bp;
		*(p + 1) = i & 0x4 ? fp : bp;
		*(p + 2) = i & 0x2 ? fp : bp;
		*(p + 3) = i & 0x1 ? fp : bp;

		p = (PIXEL *)(hr_table_2x + (offset << 1) + i);
		*p = *(p + 1) = i & 0x8 ? fp : bp;
		*(p + 2) = *(p + 3) = i & 0x4 ? fp : bp;
		*(p + 0x40) = *(p + 0x41) = i & 0x2 ? fp : bp;
		*(p + 0x42) = *(p + 0x43) = i & 0x1 ? fp : bp;
	    }
	}
    }

    for (i = 0; i <= 0xff; i++) {
	mc_table[i + 0x100] = i >> 6;
	mc_table[i + 0x300] = (i >> 4) & 0x3;
	mc_table[i + 0x500] = (i >> 2) & 0x3;
	mc_table[i + 0x700] = i & 0x3;
	mc_table[i] = tmptable[i >> 6];
	mc_table[i + 0x200] = tmptable[(i >> 4) & 0x3];
	mc_table[i + 0x400] = tmptable[(i >> 2) & 0x3];
	mc_table[i + 0x600] = tmptable[i & 0x3];
	mcsprtable[i] = ((i & 0xc0 ? 0xc0 : 0) | (i & 0x30 ? 0x30 : 0)
			 | (i & 0x0c ? 0x0c : 0) | (i & 0x03 ? 0x03 : 0));
	mcmsktable[i + 0x100] = 0;
	mcmsktable[i + 0x100] |= ((i >> 6) & 0x2) ? 0xc0 : 0;
	mcmsktable[i + 0x100] |= ((i >> 4) & 0x2) ? 0x30 : 0;
	mcmsktable[i + 0x100] |= ((i >> 2) & 0x2) ? 0x0c : 0;
	mcmsktable[i + 0x100] |= (i & 0x2) ? 0x03 : 0;
	mcmsktable[i] = i;
    }

    for (i = 0; i <= 0xffff; i++) {
	sprite_doubling_table[i] = 0;
	for (lmsk = 0xc0000000, wmsk = 0x8000; wmsk; lmsk >>= 2, wmsk >>= 1)
	    if (i & wmsk)
		sprite_doubling_table[i] |= lmsk;
    }
}

/* Draw one hires sprite. */
inline static void draw_hires_sprite(BYTE *gfx_msk_ptr, int n,
				     int in_background, int x_expanded,
				     int double_size)
{
    if (sprites[n].x < (VIC_II_SCREEN_XPIX + VIC_II_SCREEN_BORDERWIDTH)) {
	DWORD sprmsk, collmsk;
	BYTE *msk_ptr = gfx_msk_ptr + ((sprites[n].x - xsmooth) >> 3) + 1;
	BYTE *sptr = sprline + sprites[n].x;
	PIXEL *ptr = frame_buffer_ptr + sprites[n].x * ((double_size) ? 2 : 1);
	BYTE *data_ptr = (vbank_ptr + (sprite_ptr_base[n] << 6)
			 + sprites[n].memptr);
	int lshift = (sprites[n].x - xsmooth) & 0x7;

	if (x_expanded) {
	    WORD sbit = 0x101 << n;
	    WORD cmsk = 0;

	    collmsk = ((((msk_ptr[1] << 24) | (msk_ptr[2] << 16)
			 | (msk_ptr[3] << 8) | msk_ptr[4]) << lshift)
		       | (msk_ptr[5] >> (8 - lshift)));
	    if (in_background) {
		sprmsk = sprite_doubling_table[(data_ptr[0] << 8)
					       | data_ptr[1]];
		cmsk = 0;
		if (sprmsk & collmsk)
		    cl_sb_collmask |= sbit;
		sprmsk &= ~collmsk;
		if (double_size)
		    SPRITE_MASK_2x(sprmsk, 32, sbit, ptr, sptr,
				   sprites[n].color, cmsk);
		else
		    SPRITE_MASK(sprmsk, 32, sbit, ptr, sptr, sprites[n].color,
				cmsk);
		sprmsk = sprite_doubling_table[data_ptr[2]];
		collmsk = ((((msk_ptr[5] << 8) | msk_ptr[6]) << lshift)
			   | (msk_ptr[7] >> (8 - lshift)));
		if (sprmsk & collmsk)
		    cl_sb_collmask |= sbit;
		sprmsk &= ~collmsk;
		if (double_size)
		    SPRITE_MASK_2x(sprmsk, 16, sbit, ptr + 64, sptr + 32,
				   sprites[n].color, cmsk);
		else
		    SPRITE_MASK(sprmsk, 16, sbit, ptr + 32, sptr + 32,
				sprites[n].color, cmsk);
	    } else {		/* Foreground */
		/* If in foreground and x-expanded, we can always write pixels
		   in pairs, which is faster. */
		sprmsk = ((data_ptr[0] << 16) | (data_ptr[1] << 8)
			  | data_ptr[2]);
		if (double_size)
		    SPRITE_DOUBLE_MASK_2x(sprmsk, 24, sbit, ptr, sptr,
					  sprites[n].color, cmsk);
		else
		    SPRITE_DOUBLE_MASK(sprmsk, 24, sbit, ptr, sptr,
				       sprites[n].color, cmsk);
		if (sprmsk & collmsk)
		    cl_sb_collmask |= sbit;
		cmsk = (cmsk & 0xff) | (cmsk >> 8);
	    }
	    if (cmsk)
		cl_ss_collmask |= (cmsk >> 8) | ((cmsk | sbit) & 0xff);
	} else {		/* Unexpanded */
	    BYTE sbit = 1 << n;
	    BYTE cmsk = 0;

	    collmsk = ((((msk_ptr[0] << 24) | (msk_ptr[1] << 16)
			 | (msk_ptr[2] << 8) | msk_ptr[3]) << lshift)
		       | (msk_ptr[4] >> (8 - lshift)));
	    sprmsk = (data_ptr[0] << 16) | (data_ptr[1] << 8) | data_ptr[2];
	    if (sprmsk & collmsk) {
		cl_sb_collmask |= sbit;
		if (in_background)
		    sprmsk &= ~collmsk;
	    }
	    if (double_size)
		SPRITE_MASK_2x(sprmsk, 24, sbit, ptr, sptr, sprites[n].color,
			       cmsk);
	    else
		SPRITE_MASK(sprmsk, 24, sbit, ptr, sptr, sprites[n].color,
			    cmsk);
	    if (cmsk)
		cl_ss_collmask |= cmsk | sbit;
	}
    }
}

/* Draw one multicolor sprite. */
inline static void draw_mc_sprite(BYTE *gfx_msk_ptr, int n, int in_background,
				  int x_expanded, int double_size)
{
    if (sprites[n].x < (VIC_II_SCREEN_XPIX + VIC_II_SCREEN_BORDERWIDTH)) {
	DWORD sprmsk, mcsprmsk;
	BYTE *msk_ptr;
	PIXEL *ptr = frame_buffer_ptr + sprites[n].x * (double_size ? 2 : 1);
	BYTE *sptr = sprline + sprites[n].x;
	BYTE *data_ptr = (vbank_ptr + (sprite_ptr_base[n] << 6)
			  + sprites[n].memptr);
	BYTE cmsk = 0, sbit = 1 << n;
	int lshift = (sprites[n].x - xsmooth) & 0x7;
	DWORD c[4];

	c[1] = mc_sprite_color_1;
	c[2] = sprites[n].color;
	c[3] = mc_sprite_color_2;
	msk_ptr = gfx_msk_ptr + ((sprites[n].x - xsmooth) >> 3) + 1;
	mcsprmsk = (data_ptr[0] << 16) | (data_ptr[1] << 8) | data_ptr[2];
	if (x_expanded) {
	    DWORD collmsk = ((((msk_ptr[1] << 24) | (msk_ptr[2] << 16)
			       | (msk_ptr[3] << 8) | msk_ptr[4]) << lshift)
			     | (msk_ptr[5] >> (8 - lshift)));

	    sprmsk = sprite_doubling_table[((mcsprtable[data_ptr[0]] << 8)
					    | mcsprtable[data_ptr[1]])];
	    if (sprmsk & collmsk) {
		cl_sb_collmask |= sbit;
		if (in_background)
		    sprmsk &= ~collmsk;
	    }
	    if (double_size)
		MCSPRITE_DOUBLE_MASK_2x(sprmsk, mcsprmsk, 32, sbit, ptr, sptr,
					c, cmsk);
	    else
		MCSPRITE_DOUBLE_MASK(sprmsk, mcsprmsk, 32, sbit, ptr, sptr,
				     c, cmsk);
	    sprmsk = sprite_doubling_table[mcsprtable[data_ptr[2]]];
	    collmsk = ((((msk_ptr[5] << 8) | msk_ptr[6]) << lshift)
		       | (msk_ptr[7] >> (8 - lshift)));
	    if (sprmsk & collmsk) {
		cl_sb_collmask |= sbit;
		if (in_background)
		    sprmsk &= ~collmsk;
	    }
	    if (double_size)
		MCSPRITE_DOUBLE_MASK_2x(sprmsk, mcsprmsk, 16, sbit, ptr + 64,
					sptr + 32, c, cmsk);
	    else
		MCSPRITE_DOUBLE_MASK(sprmsk, mcsprmsk, 16, sbit, ptr + 32,
				     sptr + 32, c, cmsk);
	} else {		/* Unexpanded */
	    DWORD collmsk = ((((msk_ptr[0] << 24) | (msk_ptr[1] << 16)
			       | (msk_ptr[2] << 8) | msk_ptr[3]) << lshift)
			     | (msk_ptr[4] >> (8 - lshift)));
	    sprmsk = ((mcsprtable[data_ptr[0]] << 16)
		      | (mcsprtable[data_ptr[1]] << 8)
		      | mcsprtable[data_ptr[2]]);
	    if (sprmsk & collmsk) {
		cl_sb_collmask |= sbit;
		if (in_background)
		    sprmsk &= ~collmsk;
	    }
	    if (double_size)
		MCSPRITE_MASK_2x(sprmsk, mcsprmsk, 24, sbit, ptr, sptr, c,
				 cmsk);
	    else
		MCSPRITE_MASK(sprmsk, mcsprmsk, 24, sbit, ptr, sptr, c, cmsk);
	}
	if (cmsk)
	    cl_ss_collmask |= cmsk | (sbit);
    }
}

inline static void draw_all_sprites(BYTE *gfx_msk_ptr)
{
    cl_ss_collmask = cl_sb_collmask = 0;
    
    if (dma_msk) {
	int n;

	memset(sprline, 0, VIC_II_SCREEN_WIDTH);

	for (n = 7; n >= 0; n--) {
	    if (dma_msk & (1 << n)) {
		if (sprites[n].multicolor)
		    draw_mc_sprite(gfx_msk_ptr, n, sprites[n].in_background,
				   sprites[n].x_expanded, 0);
		else
		    draw_hires_sprite(gfx_msk_ptr, n, sprites[n].in_background,
				      sprites[n].x_expanded, 0);
	    }
	}

	ss_collmask |= cl_ss_collmask;
	sb_collmask |= cl_sb_collmask;
    }
}

inline static void draw_all_sprites_2x(BYTE *gfx_msk_ptr)
{ 
    cl_ss_collmask = cl_sb_collmask = 0;
    
    if (dma_msk) {
	int n;
	
	memset(sprline, 0, VIC_II_SCREEN_WIDTH);
	
	for (n = 7; n >= 0; n--) {
	    if (dma_msk & (1 << n)) {
		if (sprites[n].multicolor)
		    draw_mc_sprite(gfx_msk_ptr, n, sprites[n].in_background,
				   sprites[n].x_expanded, 1);
		else
		    draw_hires_sprite(gfx_msk_ptr, n, sprites[n].in_background,
				      sprites[n].x_expanded, 1);
	    }
	}

	ss_collmask |= cl_ss_collmask;
	sb_collmask |= cl_sb_collmask;
    }
}

/* ------------------------------------------------------------------------- */

/* If unaligned 32-bit access is not allowed, the graphics is stored in a
   temporary aligned buffer, and later copied to the real frame buffer.  This
   is ugly, but should be hopefully faster than accessing 8 bits at a time
   anyway. */

#ifndef ALLOW_UNALIGNED_ACCESS
static PIXEL4 _aligned_line_buffer[VIC_II_SCREEN_XPIX / 2 + 1];
static PIXEL * const aligned_line_buffer = (PIXEL *)_aligned_line_buffer;
#endif

/* FIXME: in the cache, we store the foreground bitmap values for the
   characters, but we do not use them when drawing and this is slow!  */

/* Standard text mode. */

static int get_std_text(struct line_cache *l, int *xs, int *xe, int rr)
{
    int r = 0;

    if (background_color != l->bgdata[0] || l->chargen_ptr != chargen_ptr) {
	l->bgdata[0] = background_color;
	l->chargen_ptr = chargen_ptr;
	*xs = 0;
	*xe = SCREEN_TEXTCOLS;
	rr = 1;
    }
    
    r = _fill_cache_text(l->fgdata, vbuf, chargen_ptr, SCREEN_TEXTCOLS,
			 ycounter, xs, xe, rr);
    r |= _fill_cache(l->colordata1, cbuf, SCREEN_TEXTCOLS, 1, xs, xe, rr);

    if (!r) {
	ss_collmask |= l->ss_collmask;
	sb_collmask |= l->sb_collmask;
    }
    
    return r;
}

inline static void _draw_std_text(PIXEL *p, int xs, int xe, BYTE *gfx_msk_ptr)
{
    PIXEL4 *table_ptr = hr_table + (background_color << 4);
    BYTE *char_ptr = chargen_ptr + ycounter;
    int i;

    for (i = xs; i <= xe; i++) {
	PIXEL4 *ptr = table_ptr + (cbuf[i] << 8);
	int d = *(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i)
	    = *(char_ptr + vbuf[i] * 8);
	
	*((PIXEL4 *)p + i * 2) = *(ptr + (d >> 4));
	*((PIXEL4 *)p + i * 2 + 1) = *(ptr + (d & 0xf));
    }
}

static void draw_std_text_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_std_text(p, xs, xe, l->gfx_msk);
#else
    _draw_std_text(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 8, aligned_line_buffer + xs * 8, (xe - xs + 1) * 8);
#endif

    draw_all_sprites(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

static void draw_std_text(void)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_std_text(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_std_text(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		   gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX);
#endif

    draw_all_sprites(gfx_msk);
}


inline static void _draw_std_text_2x(PIXEL *p, int xs, int xe,
				     BYTE *gfx_msk_ptr)
{
    PIXEL4 *table_ptr = hr_table_2x + (background_color << 5);
    BYTE *char_ptr = chargen_ptr + ycounter;
    int i;

    for (i = xs; i <= xe; i++) {
	PIXEL4 *ptr = table_ptr + (cbuf[i] << 9);
	int d = *(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i)
	    = *(char_ptr + vbuf[i] * 8);
	
	*((PIXEL4 *)p + i * 4) = *(ptr + (d >> 4));
	*((PIXEL4 *)p + i * 4 + 1) = *(ptr + 0x10 + (d >> 4));
	*((PIXEL4 *)p + i * 4 + 2) = *(ptr + (d & 0xf));
	*((PIXEL4 *)p + i * 4 + 3) = *(ptr + 0x10 + (d & 0xf));
    }
}

static void draw_std_text_cached_2x(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_std_text_2x(p, xs, xe, l->gfx_msk);
#else
    _draw_std_text_2x(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 16, aligned_line_buffer + xs * 16, (xe - xs + 1) * 16);
#endif

    draw_all_sprites_2x(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

static void draw_std_text_2x(void)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_std_text_2x(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_std_text_2x(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		      gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX * 2);
#endif

    draw_all_sprites_2x(gfx_msk);
}


/* Hires Bitmap mode. */

static int get_hires_bitmap(struct line_cache *l, int *xs, int *xe, int rr)
{
    int r = 0;

    r |= _fill_cache_nibbles(l->colordata1, l->bgdata, vbuf, SCREEN_TEXTCOLS,
			     1, xs, xe, rr);
    r |= _fill_cache(l->fgdata, bitmap_ptr + memptr * 8 + ycounter,
		     SCREEN_TEXTCOLS, 8, xs, xe, rr);

    if (!r) {
	ss_collmask |= l->ss_collmask;
	sb_collmask |= l->sb_collmask;
    }

    return r;
}


inline static void _draw_hires_bitmap(PIXEL *p, int xs, int xe,
				      BYTE *gfx_msk_ptr)
{
    BYTE *bmptr = bitmap_ptr + (memptr << 3) + ycounter;
    int i;

    for (i = xs; i <= xe; i++) {
	PIXEL4 *ptr = hr_table + (vbuf[i] << 4);
	int d;

	d = *(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i) = bmptr[i * 8];
	*((PIXEL4 *)p + i * 2) = *(ptr + (d >> 4));
	*((PIXEL4 *)p + i * 2 + 1) = *(ptr + (d & 0xf));
    }
} 

static void draw_hires_bitmap(void)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_hires_bitmap(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_hires_bitmap(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		      gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX);
#endif

    draw_all_sprites(gfx_msk);
}

static void draw_hires_bitmap_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_hires_bitmap(p, xs, xe, l->gfx_msk);
#else
    _draw_hires_bitmap(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 8, aligned_line_buffer + xs * 8, (xe - xs + 1) * 8);
#endif

    draw_all_sprites(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}


inline static void _draw_hires_bitmap_2x(PIXEL *p, int xs, int xe,
					BYTE *gfx_msk_ptr)
{
    BYTE *bmptr = bitmap_ptr + (memptr << 3) + ycounter;
    int i;

    for (i = xs; i <= xe; i++) {
	PIXEL4 *ptr = hr_table_2x + (vbuf[i] << 5);
	int d;

	d = *(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i) = bmptr[i * 8];
	*((PIXEL4 *)p + i * 4) = *(ptr + (d >> 4));
	*((PIXEL4 *)p + i * 4 + 1) = *(ptr + 0x10 + (d >> 4));
	*((PIXEL4 *)p + i * 4 + 2) = *(ptr + (d & 0xf));
	*((PIXEL4 *)p + i * 4 + 3) = *(ptr + 0x10 + (d & 0xf));
    }
} 

static void draw_hires_bitmap_2x(void)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_hires_bitmap_2x(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_hires_bitmap_2x(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
			 gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX * 2);
#endif

    draw_all_sprites_2x(gfx_msk);
}

static void draw_hires_bitmap_cached_2x(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_hires_bitmap_2x(p, xs, xe, l->gfx_msk);
#else
    _draw_hires_bitmap_2x(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 16, aligned_line_buffer + xs * 16, (xe - xs + 1) * 16);
#endif

    draw_all_sprites_2x(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}


/* Multicolor text mode. */

static int get_mc_text(struct line_cache *l, int *xs, int *xe, int rr)
{
    int r = 0;

    if (background_color != l->bgdata[0] || l->colordata1[0] != vic[0x22]
	|| l->colordata1[1] != vic[0x23] || l->chargen_ptr != chargen_ptr) {
	l->bgdata[0] = background_color;
	l->colordata1[0] = vic[0x22];
	l->colordata1[1] = vic[0x23];
	l->chargen_ptr = chargen_ptr;
	*xs = 0;
	*xe = VIC_II_SCREEN_TEXTCOLS - 1;
	rr = 1;
    }

    r = _fill_cache_text(l->fgdata, vbuf, chargen_ptr, SCREEN_TEXTCOLS,
			 ycounter, xs, xe, rr);
    r |= _fill_cache(l->colordata3, cbuf, SCREEN_TEXTCOLS, 1, xs, xe, rr);

    if (!r) {
	ss_collmask |= l->ss_collmask;
	sb_collmask |= l->sb_collmask;
    }

    return r;
}

inline static void _draw_mc_text(PIXEL *p, int xs, int xe, BYTE *gfx_msk_ptr)
{
    PIXEL2 c[7];
    BYTE *char_ptr = chargen_ptr + ycounter;
    int i;

    c[0] = PIXEL2(background_color);
    c[1] = PIXEL2(ext_background_color[0]);
    c[2] = PIXEL2(ext_background_color[1]);
    *((PIXEL *)c + 8) = *((PIXEL *)c + 11) = PIXEL(background_color);
    for (i = xs; i <= xe; i++) {
	unsigned int d = *(char_ptr + vbuf[i] * 8);
	unsigned int k = (cbuf[i] & 0x8) << 5;

	*(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i) = mcmsktable[k | d];
#ifdef ALLOW_UNALIGNED_ACCESS
	c[3] = *((PIXEL2 *)((PIXEL *)c + 9)) = PIXEL2(cbuf[i] & 0x7);
#else
	c[3] = PIXEL2(cbuf[i] & 0x7);
	*((PIXEL *)c + 9) = *((PIXEL *)c + 10) = PIXEL2(cbuf[i] & 0x7);
#endif
	*((PIXEL2 *)p + 4 * i) = c[mc_table[k | d]];
	*((PIXEL2 *)p + 4 * i + 1) = c[mc_table[0x200 + (k | d)]];
	*((PIXEL2 *)p + 4 * i + 2) = c[mc_table[0x400 + (k | d)]];
	*((PIXEL2 *)p + 4 * i + 3) = c[mc_table[0x600 + (k | d)]];
    }
} 

static void draw_mc_text(void)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_text(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_mc_text(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		  gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX);
#endif

    draw_all_sprites(gfx_msk);
}

static void draw_mc_text_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_text(p, xs, xe, l->gfx_msk);
#else
    _draw_mc_text(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 8, aligned_line_buffer + xs * 8, (xe - xs + 1) * 8);
#endif

    draw_all_sprites(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

inline static void _draw_mc_text_2x(PIXEL *p, int xs, int xe,
				    BYTE *gfx_msk_ptr)
{
    PIXEL4 c[7];
    int i;
    BYTE *char_ptr = chargen_ptr + ycounter;

    c[0] = PIXEL4(background_color);
    c[1] = PIXEL4(ext_background_color[0]);
    c[2] = PIXEL4(ext_background_color[1]);
    *((PIXEL2 *)c + 8) = *((PIXEL2 *)c + 11) = PIXEL2(background_color);
    for (i = xs; i <= xe; i++) {
	unsigned int d = *(char_ptr + vbuf[i] * 8);
	unsigned int k = (cbuf[i] & 0x8) << 5;
	
	*(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i) = mcmsktable[k | d];
#ifdef ALLOW_UNALIGNED_ACCESS
	c[3] = *((PIXEL4 *)((PIXEL2 *)c + 9)) = PIXEL4(cbuf[i] & 0x7);
#else
	c[3] = PIXEL4(cbuf[i] & 0x7);
	*((PIXEL2 *)c + 9) = *((PIXEL2 *)c + 10) = PIXEL2(cbuf[i] & 0x7);
#endif
	*((PIXEL4 *)p + 4 * i) = c[mc_table[k | d]];
	*((PIXEL4 *)p + 4 * i + 1) = c[mc_table[0x200 + (k | d)]];
	*((PIXEL4 *)p + 4 * i + 2) = c[mc_table[0x400 + (k | d)]];
	*((PIXEL4 *)p + 4 * i + 3) = c[mc_table[0x600 + (k | d)]];
    }
} 

static void draw_mc_text_2x(void)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_text_2x(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_mc_text_2x(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		     gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX * 2);
#endif

    draw_all_sprites_2x(gfx_msk);
}

static void draw_mc_text_cached_2x(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_text_2x(p, xs, xe, l->gfx_msk);
#else
    _draw_mc_text_2x(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 16, aligned_line_buffer + xs * 16, (xe - xs + 1) * 16);
#endif

    draw_all_sprites_2x(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}


/* Multicolor Bitmap Mode. */

static int get_mc_bitmap(struct line_cache *l, int *xs, int *xe, int r)
{
    if (background_color != l->bgdata[0]) {
	l->bgdata[0] = background_color;
	r = 1;
	*xs = 0;
	*xe = SCREEN_TEXTCOLS;
    }
    r = _fill_cache_nibbles(l->colordata1, l->colordata2, vbuf,
			    SCREEN_TEXTCOLS, 1, xs, xe, r);
    r = _fill_cache(l->colordata3, cbuf, SCREEN_TEXTCOLS, 1, xs, xe, r);
    r = _fill_cache(l->fgdata, bitmap_ptr + memptr * 8 + ycounter,
		SCREEN_TEXTCOLS, 8, xs, xe, r);

    if (!r) {
	ss_collmask |= l->ss_collmask;
	sb_collmask |= l->sb_collmask;
    }
    return r;
}

inline static void _draw_mc_bitmap(PIXEL *p, int xs, int xe, BYTE *gfx_msk_ptr)
{
    BYTE *colptr = cbuf;
    BYTE *bmptr = bitmap_ptr + (memptr << 3) + ycounter;
    PIXEL2 c[4];
    int i;

    c[0] = PIXEL2(background_color);
    for (i = xs; i <= xe; i++) {
	unsigned int d = *(bmptr + i * 8);
	
	*(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i) = mcmsktable[d | 0x100];
	c[1] = PIXEL2(vbuf[i] >> 4);
	c[2] = PIXEL2(vbuf[i] & 0xf);
	c[3] = PIXEL2(colptr[i]);
	*((PIXEL2 *)p + 4 * i) = c[mc_table[0x100 + d]];
	*((PIXEL2 *)p + 4 * i + 1) = c[mc_table[0x300 + d]];
	*((PIXEL2 *)p + 4 * i + 2) = c[mc_table[0x500 + d]];
	*((PIXEL2 *)p + 4 * i + 3) = c[mc_table[0x700 + d]];
    }
}

static void draw_mc_bitmap(void)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_bitmap(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_mc_bitmap(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		    gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX);
#endif

    draw_all_sprites(gfx_msk);
}

static void draw_mc_bitmap_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_bitmap(p, xs, xe, l->gfx_msk);
#else
    _draw_mc_bitmap(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 8, aligned_line_buffer + xs * 8, (xe - xs + 1) * 8);
#endif

    draw_all_sprites(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

inline static void _draw_mc_bitmap_2x(PIXEL *p, int xs, int xe,
				      BYTE *gfx_msk_ptr)
{
    BYTE *colptr = cbuf;
    BYTE *bmptr = bitmap_ptr + (memptr << 3) + ycounter;
    PIXEL4 c[4];
    int i;

    c[0] = PIXEL4(background_color);
    for (i = xs; i <= xe; i++) {
	unsigned int d = *(bmptr + i * 8);
	
	*(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i) = mcmsktable[d | 0x100];
	c[1] = PIXEL4(vbuf[i] >> 4);
	c[2] = PIXEL4(vbuf[i] & 0xf);
	c[3] = PIXEL4(colptr[i]);
	*((PIXEL4 *)p + 4 * i) = c[mc_table[0x100 + d]];
	*((PIXEL4 *)p + 4 * i + 1) = c[mc_table[0x300 + d]];
	*((PIXEL4 *)p + 4 * i + 2) = c[mc_table[0x500 + d]];
	*((PIXEL4 *)p + 4 * i + 3) = c[mc_table[0x700 + d]];
    }
} 

static void draw_mc_bitmap_2x(void)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_bitmap_2x(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_mc_bitmap_2x(aligned_line_buffer, 0,
		       VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX * 2);
#endif

    draw_all_sprites_2x(gfx_msk);
}

static void draw_mc_bitmap_cached_2x(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_mc_bitmap_2x(p, xs, xe, l->gfx_msk);
#else
    _draw_mc_bitmap_2x(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 16, aligned_line_buffer + xs * 16, (xe - xs + 1) * 16);
#endif

    draw_all_sprites_2x(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}


/* Extended Text Mode. */

static int get_ext_text(struct line_cache *l, int *xs, int *xe, int r)
{
    if (r || vic[0x21] != l->colordata2[0] || vic[0x22] != l->colordata2[1]
	|| vic[0x23] != l->colordata2[2] || vic[0x24] != l->colordata2[3]) {
	l->colordata2[0] = vic[0x21];
	l->colordata2[1] = vic[0x22];
	l->colordata2[2] = vic[0x23];
	l->colordata2[3] = vic[0x24];
	r = 1;
    }

    r = _fill_cache(l->colordata1, cbuf, SCREEN_TEXTCOLS, 1, xs, xe, r);
    r = _fill_cache(l->colordata2, vbuf, SCREEN_TEXTCOLS, 1, xs, xe, r);
    r = _fill_cache(l->fgdata, vbuf, SCREEN_TEXTCOLS, 1, xs, xe, r);

    if (!r) {
	ss_collmask |= l->ss_collmask;
	sb_collmask |= l->sb_collmask;
    }

    return r;
}

inline static void _draw_ext_text(PIXEL *p, int xs, int xe,
				  BYTE *gfx_msk_ptr)
{
    BYTE *char_ptr = chargen_ptr + ycounter;
    int i;

    for (i = 0; i < SCREEN_TEXTCOLS; i++) {
	PIXEL4 *ptr = (hr_table + (cbuf[i] << 8)
		       + (vic[0x21 + (vbuf[i] >> 6)] << 4));
	int d = *(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i)
	    = *(char_ptr + (vbuf[i] & 0x3f) * 8);
	 
	*((PIXEL4 *)p + 2 * i) = *(ptr + (d >> 4));
	*((PIXEL4 *)p + 2 * i + 1) = *(ptr + (d & 0xf));
    }
} 

static void draw_ext_text(void)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_ext_text(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_ext_text(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		   gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX);
#endif

    draw_all_sprites(gfx_msk);
}

static void draw_ext_text_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + SCREEN_BORDERWIDTH + xsmooth;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_ext_text(p, xs, xe, l->gfx_msk);
#else
    _draw_ext_text(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 8, aligned_line_buffer + xs * 8, (xe - xs + 1) * 8);
#endif

    draw_all_sprites(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

inline static void _draw_ext_text_2x(PIXEL *p, int xs, int xe,
					 BYTE *gfx_msk_ptr)
{
    BYTE *char_ptr = chargen_ptr + ycounter;
    int i;

    for (i = 0; i < SCREEN_TEXTCOLS; i++) {
	PIXEL4 *ptr = (hr_table_2x + (cbuf[i] << 9)
		       + (vic[0x21 + (vbuf[i] >> 6)] << 5));
	int d = *(gfx_msk_ptr + GFXMSK_LEFTBORDER_SIZE + i)
	    = *(char_ptr + (vbuf[i] & 0x3f) * 8);
	 
	*((PIXEL4 *)p + 4 * i) = *(ptr + (d >> 4));
	*((PIXEL4 *)p + 4 * i + 1) = *(ptr + 0x10 + (d >> 4));
	*((PIXEL4 *)p + 4 * i + 2) = *(ptr + (d & 0xf));
	*((PIXEL4 *)p + 4 * i + 3) = *(ptr + 0x10 + (d & 0xf));
    }
} 

static void draw_ext_text_cached_2x(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_ext_text_2x(p, xs, xe, l->gfx_msk);
#else
    _draw_ext_text_2x(aligned_line_buffer, xs, xe, l->gfx_msk);
    vid_memcpy(p + xs * 16, aligned_line_buffer + xs * 16, (xe - xs + 1) * 16);
#endif

    draw_all_sprites_2x(l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

static void draw_ext_text_2x(void)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * 2;

#ifdef ALLOW_UNALIGNED_ACCESS
    _draw_ext_text_2x(p, 0, VIC_II_SCREEN_TEXTCOLS - 1, gfx_msk);
#else
    _draw_ext_text_2x(aligned_line_buffer, 0, VIC_II_SCREEN_TEXTCOLS - 1,
		      gfx_msk);
    vid_memcpy(p, aligned_line_buffer, VIC_II_SCREEN_XPIX * 2);
#endif

    draw_all_sprites_2x(gfx_msk);
}


/* Illegal mode.  Everything is black. */

static int get_black(struct line_cache *l, int *xs, int *xe, int r)
{
    /* Let's simplify here: if also the previous time we had the Black Mode,
       nothing has changed.  If we had not, the whole line has changed. */

    if (r) {
	*xs = 0;
	*xe = SCREEN_TEXTCOLS - 1;
    } else {
	ss_collmask |= l->ss_collmask;
	sb_collmask |= l->sb_collmask;
    }

    return r;
}

static void draw_black(void)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * pixel_width;

    vid_memset(p, PIXEL(0), VIC_II_SCREEN_TEXTCOLS * 8 * pixel_width);

    memset(gfx_msk, 0, sizeof(gfx_msk));

    if (pixel_width == 1)
	draw_all_sprites(gfx_msk);
    else
	draw_all_sprites_2x(gfx_msk);
}

static void draw_black_cached(struct line_cache *l, int xs, int xe)
{
    PIXEL *p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * pixel_width;

    vid_memset(p, PIXEL(0), SCREEN_TEXTCOLS * 8 * pixel_width);
    memset(gfx_msk, 0, sizeof(l->gfx_msk));

    if (pixel_width == 1)
	draw_all_sprites(l->gfx_msk);
    else
	draw_all_sprites_2x(l->gfx_msk);

    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}


/* Idle state. */

static int get_idle(struct line_cache *l, int *xs, int *xe, int rr)
{
    BYTE *p = vbank_ptr + (vic[0x11] & 0x40 ? 0x39ff : 0x3fff);

    if (rr || background_color != l->colordata1[0] || *p != l->fgdata[0]) {
	l->colordata1[0] = background_color;
	l->fgdata[0] = *p;
	*xs = 0;
	*xe = VIC_II_SCREEN_TEXTCOLS - 1;
	return 1;
    } else
	return 0;
}

inline static void _draw_idle(int xs, int xe, int pixel_width,
			      BYTE *gfx_msk_ptr)
{
    PIXEL *p;
    BYTE d = vbank_ptr[vic[0x11] & 0x40 ? 0x39ff : 0x3fff];
    int i;

#ifdef ALLOW_UNALIGNED_ACCESS
    p = frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * pixel_width;
#else
    p = aligned_line_buffer;
#endif

    if (pixel_width == 1) {
	/* The foreground color is always black (0). */
	unsigned int offs = background_color << 4;
	PIXEL4 c1 = *(hr_table + offs + (d >> 4));
	PIXEL4 c2 = *(hr_table + offs + (d & 0xf));

	for (i = xs * 8; i <= xe * 8; i += 8) {
	    *((PIXEL4 *)(p + i)) = c1;
	    *((PIXEL4 *)(p + i + 4)) = c2;
	}
    } else if (pixel_width == 2) {
	/* The foreground color is always black (0). */
	unsigned int offs = background_color << 5;
	PIXEL4 c1 = *(hr_table_2x + offs + (d >> 4));
	PIXEL4 c2 = *(hr_table_2x + 0x10 + offs + (d >> 4));
	PIXEL4 c3 = *(hr_table_2x + offs + (d & 0xf));
	PIXEL4 c4 = *(hr_table_2x + 0x10 + offs + (d & 0xf));
	
	for (i = xs * 16; i <= xe * 16; i += 16) {
	    *((PIXEL4 *)(p + i)) = c1;
	    *((PIXEL4 *)(p + i + 4)) = c2;
	    *((PIXEL4 *)(p + i + 8)) = c3;
	    *((PIXEL4 *)(p + i + 12)) = c4;
	}
    }

#ifndef ALLOW_UNALIGNED_ACCESS
    vid_memcpy(frame_buffer_ptr + (SCREEN_BORDERWIDTH + xsmooth) * pixel_width,
	       aligned_line_buffer + xs * 8 * pixel_width,
	       (xe - xs + 1) * 8 * pixel_width);
#endif

    memset(gfx_msk_ptr, d, SCREEN_GFXMSK_SIZE);

    if (pixel_width == 1)
	draw_all_sprites(gfx_msk);
    else
	draw_all_sprites_2x(gfx_msk);
}

static void draw_idle(void)
{
    _draw_idle(0, VIC_II_SCREEN_TEXTCOLS - 1, 1, gfx_msk);
}

static void draw_idle_cached(struct line_cache *l, int xs, int xe)
{
    _draw_idle(xs, xe, 1, l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

static void draw_idle_2x(void)
{
    _draw_idle(0, VIC_II_SCREEN_TEXTCOLS - 1, 2, gfx_msk);
}

static void draw_idle_cached_2x(struct line_cache *l, int xs, int xe)
{
    _draw_idle(xs, xe, 2, l->gfx_msk);
    l->ss_collmask = cl_ss_collmask;
    l->sb_collmask = cl_sb_collmask;
}

/* ------------------------------------------------------------------------- */

/* Set proper functions and constants for the current video settings. */
void video_resize(void)
{
    static int old_size = 0;

    video_modes[VIC_II_NORMAL_TEXT_MODE].fill_cache = get_std_text;
    video_modes[VIC_II_MULTICOLOR_TEXT_MODE].fill_cache = get_mc_text;
    video_modes[VIC_II_HIRES_BITMAP_MODE].fill_cache = get_hires_bitmap;
    video_modes[VIC_II_MULTICOLOR_BITMAP_MODE].fill_cache = get_mc_bitmap;
    video_modes[VIC_II_EXTENDED_TEXT_MODE].fill_cache = get_ext_text;
    video_modes[VIC_II_ILLEGAL_TEXT_MODE].fill_cache = get_black;
    video_modes[VIC_II_ILLEGAL_BITMAP_MODE_1].fill_cache = get_black;
    video_modes[VIC_II_ILLEGAL_BITMAP_MODE_2].fill_cache = get_black;
    video_modes[VIC_II_ILLEGAL_TEXT_MODE].draw_line_cached = draw_black_cached;
    video_modes[VIC_II_ILLEGAL_BITMAP_MODE_1].draw_line_cached = draw_black_cached;
    video_modes[VIC_II_ILLEGAL_BITMAP_MODE_2].draw_line_cached = draw_black_cached;
    video_modes[VIC_II_ILLEGAL_TEXT_MODE].draw_line = draw_black;
    video_modes[VIC_II_ILLEGAL_BITMAP_MODE_1].draw_line = draw_black;
    video_modes[VIC_II_ILLEGAL_BITMAP_MODE_2].draw_line = draw_black;
    video_modes[VIC_II_IDLE_MODE].fill_cache = get_idle;

    if (app_resources.doubleSize) {
	pixel_width = 2;
	pixel_height = 2;
	video_modes[VIC_II_NORMAL_TEXT_MODE].draw_line_cached = draw_std_text_cached_2x;
	video_modes[VIC_II_NORMAL_TEXT_MODE].draw_line = draw_std_text_2x;
	video_modes[VIC_II_MULTICOLOR_TEXT_MODE].draw_line_cached = draw_mc_text_cached_2x;
	video_modes[VIC_II_MULTICOLOR_TEXT_MODE].draw_line = draw_mc_text_2x;
	video_modes[VIC_II_EXTENDED_TEXT_MODE].draw_line_cached = draw_ext_text_cached_2x;
	video_modes[VIC_II_EXTENDED_TEXT_MODE].draw_line = draw_ext_text_2x;
	video_modes[VIC_II_HIRES_BITMAP_MODE].draw_line_cached = draw_hires_bitmap_cached_2x;
	video_modes[VIC_II_HIRES_BITMAP_MODE].draw_line = draw_hires_bitmap_2x;
	video_modes[VIC_II_MULTICOLOR_BITMAP_MODE].draw_line_cached = draw_mc_bitmap_cached_2x;
	video_modes[VIC_II_MULTICOLOR_BITMAP_MODE].draw_line = draw_mc_bitmap_2x;
	video_modes[VIC_II_IDLE_MODE].draw_line = draw_idle_2x;
	video_modes[VIC_II_IDLE_MODE].draw_line_cached = draw_idle_cached_2x;
	if (old_size == 1) {
	    window_width *= 2;
	    window_height *= 2;
	}
    } else {
	pixel_width = 1;
	pixel_height = 1;
	video_modes[VIC_II_NORMAL_TEXT_MODE].draw_line_cached = draw_std_text_cached;
	video_modes[VIC_II_NORMAL_TEXT_MODE].draw_line = draw_std_text;
	video_modes[VIC_II_MULTICOLOR_TEXT_MODE].draw_line_cached = draw_mc_text_cached;
	video_modes[VIC_II_MULTICOLOR_TEXT_MODE].draw_line = draw_mc_text;
	video_modes[VIC_II_EXTENDED_TEXT_MODE].draw_line_cached = draw_ext_text_cached;
	video_modes[VIC_II_EXTENDED_TEXT_MODE].draw_line = draw_ext_text;
	video_modes[VIC_II_HIRES_BITMAP_MODE].draw_line_cached = draw_hires_bitmap_cached;
	video_modes[VIC_II_HIRES_BITMAP_MODE].draw_line = draw_hires_bitmap;
	video_modes[VIC_II_MULTICOLOR_BITMAP_MODE].draw_line_cached = draw_mc_bitmap_cached;
	video_modes[VIC_II_MULTICOLOR_BITMAP_MODE].draw_line = draw_mc_bitmap;
	video_modes[VIC_II_IDLE_MODE].draw_line = draw_idle;
	video_modes[VIC_II_IDLE_MODE].draw_line_cached = draw_idle_cached;
	if (old_size == 2) {
	    window_width /= 2;
	    window_height /= 2;
	}
    }

    old_size = app_resources.doubleSize ? 2 : 1;

    if (canvas) {
	resize(window_width, window_height);
	force_repaint();
	frame_buffer_clear(&frame_buffer, PIXEL(0));
	refresh_all();
    }
}

void vic_ii_prevent_clk_overflow()
{
    int_raster_clk -= PREVENT_CLK_OVERFLOW_SUB;
    oldclk -= PREVENT_CLK_OVERFLOW_SUB;
    vic_ii_fetch_clk -= PREVENT_CLK_OVERFLOW_SUB;
}
