/*
 * $Id: table.c,v 1.10 1996/07/29 22:57:17 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file contains lookup-table which is used to translate
 * MOS6502 machine instructions. Machine code is used as index
 * to array called lookup. Pointer to function is then fetched
 * from array and function is called.
 * Timing of the undocumented opcodes is based on information
 * in an article in C=Lehti by Kai Lindfors and Topi Maurola.
 *
 *
 * Written by
 *   Vesa-Matti Puro (vmp@lut.fi)
 *   Jarkko Sonninen (sonninen@lut.fi)
 *   Jouko Valta (jopi@stekt.oulu.fi)
 *
 *
 * $Log: table.c,v $
 * Revision 1.10  1996/07/29 22:57:17  ettore
 * lookup[] changed to provide a separate u_anc() function for the
 * ANC illegal opcode.
 *
 * Revision 1.9  1996/04/01  09:01:41  jopi
 * *** empty log message ***
 *
 * Revision 1.8  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * Some inconsistency removed.
 *
 * Revision 1.7  1994/12/12  16:59:44  jopi
 * Added clock fix flag
 *
 * Revision 1.6  1994/08/10  17:52:03  jopi
 * *** empty log message ***
 *
 * Revision 1.5  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:39:31  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 */

#include "cpu.h"
#include "mnemonic.h"
#include "op.h"


/*
 * The "mnemonic.h" file contains #defines for BRK, ORA, NOOP... which
 * are character strings, i.e. #define BRK    "BRK"
 * #define ORA    "ORA" . . . Used mainly to reduce typing...
 *
 * There are #defines for addressing modes i.e. IMPLIED, INDIRECT_X,
 * ZERO_PAGE in "cpu.h"... These can be used to make a diassembler.
 */


int     clength[] = {1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 2, 2, 2, 0};

struct lookup_tag lookup[] = {

    /****  Positive  ****/

    /* 00 */ {brki,	BRK,	IMPLIED, M_NONE, M_PC, 7, 0},		/* Pseudo Absolute */
    /* 01 */ {ora,	ORA,	INDIRECT_X, M_INDX, M_AC, 6, 0},	/* (Indirect,X) */
    /* 02 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE, 0, 0},		/* TILT */
    /* 03 */ {u_slor,	SLO,	INDIRECT_X, M_INDX, M_INDX, 8, 0},

    /* 04 */ {u_nop,	NOOP,	ZERO_PAGE, M_NONE, M_NONE, 3, 0},
    /* 05 */ {ora,	ORA,	ZERO_PAGE, M_ZERO, M_AC, 3, 0},		/* Zeropage */
    /* 06 */ {asl,	ASL,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},	/* Zeropage */
    /* 07 */ {u_slor,	SLO,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},

    /* 08 */ {push,	PHP,	IMPLIED, M_SR, M_NONE, 3, 0},
    /* 09 */ {ora,	ORA,	IMMEDIATE, M_IMM, M_AC, 2, 0},		/* Immediate */
    /* 0a */ {asl,	ASL,	ACCUMULATOR, M_AC, M_AC, 2, 0},		/* Accumulator */
    /* 0b */ {u_anc,	ANC,	IMMEDIATE, M_ACIM, M_ACNC, 2, 0},

    /* 0c */ {u_nop,	NOOP,	ABSOLUTE, M_NONE, M_NONE, 4, 0},
    /* 0d */ {ora,	ORA,	ABSOLUTE, M_ABS, M_AC, 4, 0},		/* Absolute */
    /* 0e */ {asl,	ASL,	ABSOLUTE, M_ABS, M_ABS, 6, 0},		/* Absolute */
    /* 0f */ {u_slor,	SLO,	ABSOLUTE, M_ABS, M_ABS, 6, 0},

    /* 10 */ {bpl,	BPL,	RELATIVE, M_REL, M_NONE, 2, 0},
    /* 11 */ {ora,	ORA,	INDIRECT_Y, M_INDY, M_AC, 5, 1},	/* (Indirect),Y */
    /* 12 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE, 0, 0},		/* TILT */
    /* 13 */ {u_slor,	SLO,	INDIRECT_Y, M_INDY, M_INDY, 8, 0},

    /* 14 */ {u_nop,	NOOP,	ZERO_PAGE_X, M_NONE, M_NONE, 4, 0},
    /* 15 */ {ora,	ORA,	ZERO_PAGE_X, M_ZERX, M_AC, 4, 0},	/* Zeropage,X */
    /* 16 */ {asl,	ASL,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},	/* Zeropage,X */
    /* 17 */ {u_slor,	SLO,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},

    /* 18 */ {clrf,	CLC,	IMPLIED, M_NONE, M_FC, 2, 0},
    /* 19 */ {ora,	ORA,	ABSOLUTE_Y, M_ABSY, M_AC, 4, 1},	/* Absolute,Y */
    /* 1a */ {u_nop,	NOOP,	IMPLIED, M_NONE, M_NONE, 2, 0},
    /* 1b */ {u_slor,	SLO,	ABSOLUTE_Y, M_ABSY, M_ABSY, 7, 0},

    /* 1c */ {u_nop,	NOOP,	ABSOLUTE_X, M_NONE, M_NONE, 4, 1},
    /* 1d */ {ora,	ORA,	ABSOLUTE_X, M_ABSX, M_AC,   4, 1},	/* Absolute,X */
    /* 1e */ {asl,	ASL,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},	/* Absolute,X */
    /* 1f */ {u_slor,	SLO,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},

    /* 20 */ {jsr,	JSR,	ABSOLUTE, M_ADDR, M_PC, 6, 0},
    /* 21 */ {and,	AND,	INDIRECT_X, M_INDX, M_AC, 6, 0},	/* (Indirect ,X) */
    /* 22 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE,    0, 0},	/* TILT */
    /* 23 */ {u_rlan,	RLA,	INDIRECT_X, M_INDX, M_INDX, 8, 0},

    /* 24 */ {bit,	BIT,	ZERO_PAGE, M_ZERO, M_NONE, 3, 0},	/* Zeropage */
    /* 25 */ {and,	AND,	ZERO_PAGE, M_ZERO, M_AC,   3, 0},	/* Zeropage */
    /* 26 */ {rol,	ROL,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},	/* Zeropage */
    /* 27 */ {u_rlan,	RLA,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},

    /* 28 */ {plp,	PLP,	IMPLIED, M_NONE, M_SR, 4, 0},
    /* 29 */ {and,	AND,	IMMEDIATE, M_IMM, M_AC, 2, 0},		/* Immediate */
    /* 2a */ {rol,	ROL,	ACCUMULATOR, M_AC, M_AC, 2, 0},		/* Accumulator */
    /* 2b */ {u_anc,	ANC,	IMMEDIATE, M_ACIM, M_ACNC, 2, 0},

    /* 2c */ {bit,	BIT,	ABSOLUTE, M_ABS, M_NONE, 4, 0},		/* Absolute */
    /* 2d */ {and,	AND,	ABSOLUTE, M_ABS, M_AC,  4, 0},		/* Absolute */
    /* 2e */ {rol,	ROL,	ABSOLUTE, M_ABS, M_ABS, 6, 0},		/* Absolute */
    /* 2f */ {u_rlan,	RLA,	ABSOLUTE, M_ABS, M_ABS, 6, 0},

    /* 30 */ {bmi,	BMI,	RELATIVE, M_REL, M_NONE, 2, 0},
    /* 31 */ {and,	AND,	INDIRECT_Y, M_INDY, M_AC, 5, 1},	/* (Indirect),Y */
    /* 32 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE, 0, 0},		/* TILT */
    /* 33 */ {u_rlan,	RLA,	INDIRECT_Y, M_INDY, M_INDY, 8, 0},

    /* 34 */ {u_nop,	NOOP,	ZERO_PAGE_X, M_NONE, M_NONE, 4, 0},
    /* 35 */ {and,	AND,	ZERO_PAGE_X, M_ZERX, M_AC,   4, 0},	/* Zeropage,X */
    /* 36 */ {rol,	ROL,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},	/* Zeropage,X */
    /* 37 */ {u_rlan,	RLA,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},

    /* 38 */ {setf,	SEC,	IMPLIED, M_NONE, M_FC, 2, 0},
    /* 39 */ {and,	AND,	ABSOLUTE_Y, M_ABSY, M_AC, 4, 1},	/* Absolute,Y */
    /* 3a */ {u_nop,	NOOP,	IMPLIED, M_NONE, M_NONE,  2, 0},
    /* 3b */ {u_rlan,	RLA,	ABSOLUTE_Y, M_ABSY, M_ABSY, 7, 0},

    /* 3c */ {u_nop,	NOOP,	ABSOLUTE_X, M_NONE, M_NONE, 4, 1},
    /* 3d */ {and,	AND,	ABSOLUTE_X, M_ABSX, M_AC,   4, 1},	/* Absolute,X */
    /* 3e */ {rol,	ROL,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},	/* Absolute,X */
    /* 3f */ {u_rlan,	RLA,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},

    /* 40 */ {rti,	RTI,	IMPLIED, M_NONE, M_PC, 6, 0},
    /* 41 */ {eor,	EOR,	INDIRECT_X, M_INDX, M_AC, 6, 0},	/* (Indirect,X) */
    /* 42 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE, 0, 0},		/* TILT */
    /* 43 */ {u_sreo,	SRE,	INDIRECT_X, M_INDX, M_INDX, 8, 0},

    /* 44 */ {u_nop,	NOOP,	ZERO_PAGE, M_NONE, M_NONE, 3, 0},
    /* 45 */ {eor,	EOR,	ZERO_PAGE, M_ZERO, M_AC,   3, 0},	/* Zeropage */
    /* 46 */ {lsr,	LSR,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},	/* Zeropage */
    /* 47 */ {u_sreo,	SRE,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},

    /* 48 */ {push,	PHA,	IMPLIED, M_AC, M_NONE,   3, 0},
    /* 49 */ {eor,	EOR,	IMMEDIATE, M_IMM, M_AC,  2, 0},		/* Immediate */
    /* 4a */ {lsr,	LSR,	ACCUMULATOR, M_AC, M_AC, 2, 0},		/* Accumulator */
    /* 4b */ {u_asr,	ASR,	IMMEDIATE, M_ACIM, M_AC, 2, 0},		/* (AC & IMM) >>1 */

    /* 4c */ {store,	JMP,	ABSOLUTE, M_ADDR, M_PC, 3, 0},		/* Absolute */
    /* 4d */ {eor,	EOR,	ABSOLUTE, M_ABS, M_AC,  4, 0},		/* Absolute */
    /* 4e */ {lsr,	LSR,	ABSOLUTE, M_ABS, M_ABS, 6, 0},		/* Absolute */
    /* 4f */ {u_sreo,	SRE,	ABSOLUTE, M_ABS, M_ABS, 6, 0},

    /* 50 */ {bvc,	BVC,	RELATIVE, M_REL, M_NONE,  2, 0},
    /* 51 */ {eor,	EOR,	INDIRECT_Y, M_INDY, M_AC, 5, 1},	/* (Indirect),Y */
    /* 52 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE,  0, 0},	/* TILT */
    /* 53 */ {u_sreo,	SRE,	INDIRECT_Y, M_INDY, M_INDY, 8, 0},

    /* 54 */ {u_nop,	NOOP,	ZERO_PAGE_X, M_NONE, M_NONE, 4, 0},
    /* 55 */ {eor,	EOR,	ZERO_PAGE_X, M_ZERX, M_AC,   4, 0},	/* Zeropage,X */
    /* 56 */ {lsr,	LSR,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},	/* Zeropage,X */
    /* 57 */ {u_sreo,	SRE,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},

    /* 58 */ {clrf,	CLI,	IMPLIED, M_NONE, M_FI,     2, 0},
    /* 59 */ {eor,	EOR,	ABSOLUTE_Y, M_ABSY, M_AC,  4, 1},	/* Absolute,Y */
    /* 5a */ {u_nop,	NOOP,	IMPLIED, M_NONE, M_NONE,   2, 0},
    /* 5b */ {u_sreo,	SRE,	ABSOLUTE_Y, M_ABSY, M_ABSY, 7, 0},

    /* 5c */ {u_nop,	NOOP,	ABSOLUTE_X, M_NONE, M_NONE, 4, 1},
    /* 5d */ {eor,	EOR,	ABSOLUTE_X, M_ABSX, M_AC,   4, 1},	/* Absolute,X */
    /* 5e */ {lsr,	LSR,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},	/* Absolute,X */
    /* 5f */ {u_sreo,	SRE,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},

    /* 60 */ {rts,	RTS,	IMPLIED, M_NONE, M_PC, 6, 0},
    /* 61 */ {adc,	ADC,	INDIRECT_X, M_INDX, M_AC, 6, 0},	/* (Indirect,X) */
    /* 62 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE, 0, 0},		/* TILT */
    /* 63 */ {u_rrad,	RRA,	INDIRECT_X, M_INDX, M_INDX, 8, 0},

    /* 64 */ {u_nop,	NOOP,	ZERO_PAGE, M_NONE, M_NONE, 3, 0},
    /* 65 */ {adc,	ADC,	ZERO_PAGE, M_ZERO, M_AC,   3, 0},	/* Zeropage */
    /* 66 */ {ror,	ROR,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},	/* Zeropage */
    /* 67 */ {u_rrad,	RRA,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},

    /* 68 */ {pull,	PLA,	IMPLIED, M_NONE, M_AC,   4, 0},
    /* 69 */ {adc,	ADC,	IMMEDIATE, M_IMM, M_AC,  2, 0},		/* Immediate */
    /* 6a */ {ror,	ROR,	ACCUMULATOR, M_AC, M_AC, 2, 0},		/* Accumulator */
    /* 6b */ {u_ror,	ARR,	IMMEDIATE, M_ACIM, M_AC, 2, 0},		/* ARR isn't typo */

    /* 6c */ {store,	JMP,	ABS_INDIRECT, M_AIND, M_PC,  5, 0},	/* Indirect */
    /* 6d */ {adc,	ADC,	ABSOLUTE, M_ABS, M_AC,  4, 0},		/* Absolute */
    /* 6e */ {ror,	ROR,	ABSOLUTE, M_ABS, M_ABS, 6, 0},		/* Absolute */
    /* 6f */ {u_rrad,	RRA,	ABSOLUTE, M_ABS, M_ABS, 6, 0},

    /* 70 */ {bvs,	BVS,	RELATIVE, M_REL, M_NONE,  2, 0},
    /* 71 */ {adc,	ADC,	INDIRECT_Y, M_INDY, M_AC, 5, 1},	/* (Indirect),Y */
    /* 72 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE,  0, 0},	/* TILT relative? */
    /* 73 */ {u_rrad,	RRA,	INDIRECT_Y, M_INDY, M_INDY, 8, 0},

    /* 74 */ {u_nop,	NOOP,	ZERO_PAGE_X, M_NONE, M_NONE, 4, 0},
    /* 75 */ {adc,	ADC,	ZERO_PAGE_X, M_ZERX, M_AC,   4, 0},	/* Zeropage,X */
    /* 76 */ {ror,	ROR,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},	/* Zeropage,X */
    /* 77 */ {u_rrad,	RRA,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},

    /* 78 */ {setf,	SEI,	IMPLIED, M_NONE, M_FI, 2, 0},
    /* 79 */ {adc,	ADC,	ABSOLUTE_Y, M_ABSY, M_AC, 4, 1},	/* Absolute,Y */
    /* 7a */ {u_nop,	NOOP,	IMPLIED, M_NONE, M_NONE,  2, 0},
    /* 7b */ {u_rrad,	RRA,	ABSOLUTE_Y, M_ABSY, M_ABSY, 7, 0},

    /* 7c */ {u_nop,	NOOP,	ABSOLUTE_X, M_NONE, M_NONE, 4, 1},
    /* 7d */ {adc,	ADC,	ABSOLUTE_X, M_ABSX, M_AC,   4, 1},	/* Absolute,X */
    /* 7e */ {ror,	ROR,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},	/* Absolute,X */
    /* 7f */ {u_rrad,	RRA,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},

    /****  Negative  ****/

    /* 80 */ {u_nop,	NOOP,	IMMEDIATE, M_NONE, M_NONE, 2, 0},
    /* 81 */ {store,	STA,	INDIRECT_X, M_AC, M_INDX,  6, 0},	/* (Indirect,X) */
    /* 82 */ {u_nop,	NOOP,	IMMEDIATE, M_NONE, M_NONE,  2, 0},
    /* 83 */ {u_store,	SAX,	INDIRECT_X, M_ANXR, M_INDX, 6, 0},

    /* 84 */ {store,	STY,	ZERO_PAGE, M_YR, M_ZERO,  3, 0},	/* Zeropage */
    /* 85 */ {store,	STA,	ZERO_PAGE, M_AC, M_ZERO,  3, 0},	/* Zeropage */
    /* 86 */ {store,	STX,	ZERO_PAGE, M_XR, M_ZERO,  3, 0},	/* Zeropage */
    /* 87 */ {u_store,	SAX,	ZERO_PAGE, M_ANXR, M_ZERO, 3, 0},

    /* 88 */ {dec,	DEY,	IMPLIED, M_YR, M_YR, 2, 0},
    /* 89 */ {u_nop,	NOOP,	IMMEDIATE, M_NONE, M_NONE, 2, 0},
    /* 8a */ {load_reg,	TXA,	IMPLIED, M_XR, M_AC, 2, 0},
    /****  very abnormal: usually AC = AC | #$EE & XR & #$oper  ****/
    /* 8b */ {u_load,	ANE,	IMMEDIATE, M_AXIM, M_AC, 2, 0},

    /* 8c */ {store,	STY,	ABSOLUTE, M_YR, M_ABS, 4, 0},		/* Absolute */
    /* 8d */ {store,	STA,	ABSOLUTE, M_AC, M_ABS, 4, 0},		/* Absolute */
    /* 8e */ {store,	STX,	ABSOLUTE, M_XR, M_ABS, 4, 0},		/* Absolute */
    /* 8f */ {u_store,	SAX,	ABSOLUTE, M_ANXR, M_ABS, 4, 0},

    /* 90 */ {bcc,	BCC,	RELATIVE, M_REL, M_NONE, 2, 0},
    /* 91 */ {store,	STA,	INDIRECT_Y, M_AC, M_INDY, 6, 0},	/* (Indirect),Y */
    /* 92 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE, 0, 0},		/* TILT relative? */
    /* 93 */ {u_store,	SHA,	INDIRECT_Y, M_ANXR, M_STH0, 6, 0},

    /* 94 */ {store,	STY,	ZERO_PAGE_X, M_YR, M_ZERX, 4, 0},	/* Zeropage,X */
    /* 95 */ {store,	STA,	ZERO_PAGE_X, M_AC, M_ZERX, 4, 0},	/* Zeropage,X */
    /* 96 */ {store,	STX,	ZERO_PAGE_Y, M_XR, M_ZERY, 4, 0},	/* Zeropage,Y */
    /* 97 */ {u_store,	SAX,	ZERO_PAGE_Y, M_ANXR, M_ZERY, 4, 0},

    /* 98 */ {load_reg,	TYA,	IMPLIED, M_YR, M_AC, 2, 0},
    /* 99 */ {store,	STA,	ABSOLUTE_Y, M_AC, M_ABSY, 5, 0},	/* Absolute,Y */
    /* 9a */ {store,	TXS,	IMPLIED, M_XR, M_SP, 2, 0},
    /*** This is very mysterious command ... */
    /* 9b */ {u_store,	SHS,	ABSOLUTE_Y, M_ANXR, M_STH3, 5, 0},

    /* 9c */ {u_store,	SHY,	ABSOLUTE_X, M_YR, M_STH2, 5, 0},
    /* 9d */ {store,	STA,	ABSOLUTE_X, M_AC, M_ABSX, 5, 0},	/* Absolute,X */
    /* 9e */ {u_store,	SHX,	ABSOLUTE_Y, M_XR, M_STH1, 5, 0},
    /* 9f */ {u_store,	SHA,	ABSOLUTE_Y, M_ANXR, M_STH1, 5, 0},

    /* a0 */ {load_reg,	LDY,	IMMEDIATE, M_IMM, M_YR, 2, 0},		/* Immediate */
    /* a1 */ {load_reg,	LDA,	INDIRECT_X, M_INDX, M_AC, 6, 0},	/* (Indirect,X) */
    /* a2 */ {load_reg,	LDX,	IMMEDIATE, M_IMM, M_XR, 2, 0},		/* Immediate */
    /* a3 */ {u_load,	LAX,	INDIRECT_X, M_INDX, M_ACXR, 6, 0},	/* (indirect,X) */

    /* a4 */ {load_reg,	LDY,	ZERO_PAGE, M_ZERO, M_YR, 3, 0},		/* Zeropage */
    /* a5 */ {load_reg,	LDA,	ZERO_PAGE, M_ZERO, M_AC, 3, 0},		/* Zeropage */
    /* a6 */ {load_reg,	LDX,	ZERO_PAGE, M_ZERO, M_XR, 3, 0},		/* Zeropage */
    /* a7 */ {u_load,	LAX,	ZERO_PAGE, M_ZERO, M_ACXR, 3, 0},

    /* a8 */ {load_reg,	TAY,	IMPLIED, M_AC, M_YR,    2, 0},
    /* a9 */ {load_reg,	LDA,	IMMEDIATE, M_IMM, M_AC, 2, 0},		/* Immediate */
    /* aa */ {load_reg,	TAX,	IMPLIED, M_AC, M_XR,    2, 0},
    /* ab */ {u_load,	LXA,	IMMEDIATE, M_ACIM, M_ACXR, 2, 0},	/* LXA isn't a typo */

    /* ac */ {load_reg,	LDY,	ABSOLUTE, M_ABS, M_YR, 4, 0},		/* Absolute */
    /* ad */ {load_reg,	LDA,	ABSOLUTE, M_ABS, M_AC, 4, 0},		/* Absolute */
    /* ae */ {load_reg,	LDX,	ABSOLUTE, M_ABS, M_XR, 4, 0},		/* Absolute */
    /* af */ {u_load,	LAX,	ABSOLUTE, M_ABS, M_ACXR, 4, 0},

    /* b0 */ {bcs, 	BCS,	RELATIVE, M_REL, M_NONE,  2, 0},
    /* b1 */ {load_reg,	LDA,	INDIRECT_Y, M_INDY, M_AC, 5, 1},	/* (indirect),Y */
    /* b2 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE,  0, 0},	/* TILT */
    /* b3 */ {u_load,	LAX,	INDIRECT_Y, M_INDY, M_ACXR, 5, 1},

    /* b4 */ {load_reg,	LDY,	ZERO_PAGE_X, M_ZERX, M_YR, 4, 0},	/* Zeropage,X */
    /* b5 */ {load_reg,	LDA,	ZERO_PAGE_X, M_ZERX, M_AC, 4, 0},	/* Zeropage,X */
    /* b6 */ {load_reg,	LDX,	ZERO_PAGE_Y, M_ZERY, M_XR, 4, 0},	/* Zeropage,Y */
    /* b7 */ {u_load,	LAX,	ZERO_PAGE_Y, M_ZERY, M_ACXR, 4, 0},

    /* b8 */ {clrf,	CLV,	IMPLIED, M_NONE, M_FV,    2, 0},
    /* b9 */ {load_reg,	LDA,	ABSOLUTE_Y, M_ABSY, M_AC, 4, 1},	/* Absolute,Y */
    /* ba */ {load_reg,	TSX,	IMPLIED, M_SP, M_XR,      2, 0},
    /* bb */ {u_load,	LAS,	ABSOLUTE_Y, M_SABY, M_ACXS, 4, 1},

    /* bc */ {load_reg,	LDY,	ABSOLUTE_X, M_ABSX, M_YR, 4, 1},	/* Absolute,X */
    /* bd */ {load_reg,	LDA,	ABSOLUTE_X, M_ABSX, M_AC, 4, 1},	/* Absolute,X */
    /* be */ {load_reg,	LDX,	ABSOLUTE_Y, M_ABSY, M_XR, 4, 1},	/* Absolute,Y */
    /* bf */ {u_load,	LAX,	ABSOLUTE_Y, M_ABSY, M_ACXR, 4, 1},

    /* c0 */ {cpy,	CPY,	IMMEDIATE, M_IMM, M_NONE, 2, 0},	/* Immediate */
    /* c1 */ {cmp,	CMP,	INDIRECT_X, M_INDX, M_NONE, 6, 0},	/* (Indirect,X) */
    /* c2 */ {u_nop,	NOOP,	IMMEDIATE, M_NONE, M_NONE, 2, 0},	/* occasional TILT */
    /* c3 */ {u_decp,	DCP,	INDIRECT_X, M_INDX, M_INDX, 8, 0},

    /* c4 */ {cpy,	CPY,	ZERO_PAGE, M_ZERO, M_NONE, 3, 0},	/* Zeropage */
    /* c5 */ {cmp,	CMP,	ZERO_PAGE, M_ZERO, M_NONE, 3, 0},	/* Zeropage */
    /* c6 */ {dec,	DEC,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},	/* Zeropage */
    /* c7 */ {u_decp,	DCP,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},

    /* c8 */ {inc,	INY,	IMPLIED, M_YR, M_YR, 2, 0},
    /* c9 */ {cmp,	CMP,	IMMEDIATE, M_IMM, M_NONE, 2, 0},	/* Immediate */
    /* ca */ {dec,	DEX,	IMPLIED, M_XR, M_XR, 2, 0},
    /* cb */ {u_sbx,	SBX,	IMMEDIATE, M_IMM, M_XR, 2, 0},

    /* cc */ {cpy,	CPY,	ABSOLUTE, M_ABS, M_NONE, 4, 0},		/* Absolute */
    /* cd */ {cmp,	CMP,	ABSOLUTE, M_ABS, M_NONE, 4, 0},		/* Absolute */
    /* ce */ {dec,	DEC,	ABSOLUTE, M_ABS, M_ABS,  6, 0},		/* Absolute */
    /* cf */ {u_decp,	DCP,	ABSOLUTE, M_ABS, M_ABS,  6, 0},

    /* d0 */ {bne,	BNE,	RELATIVE, M_REL, M_NONE, 2, 0},
    /* d1 */ {cmp,	CMP,	INDIRECT_Y, M_INDY, M_NONE, 5, 1},	/* (Indirect),Y */
    /* d2 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE,    0, 0},	/* TILT */
    /* d3 */ {u_decp,	DCP,	INDIRECT_Y, M_INDY, M_INDY, 8, 0},

    /* d4 */ {u_nop,	NOOP,	ZERO_PAGE_X, M_NONE, M_NONE, 4, 0},
    /* d5 */ {cmp,	CMP,	ZERO_PAGE_X, M_ZERX, M_NONE, 4, 0},	/* Zeropage,X */
    /* d6 */ {dec,	DEC,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},	/* Zeropage,X */
    /* d7 */ {u_decp,	DCP,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},

    /* d8 */ {clrf,	CLD,	IMPLIED, M_NONE, M_FD, 2, 0},
    /* d9 */ {cmp,	CMP,	ABSOLUTE_Y, M_ABSY, M_NONE, 4, 1},	/* Absolute,Y */
    /* da */ {u_nop,	NOOP,	IMPLIED, M_NONE, M_NONE,    2, 0},
    /* db */ {u_decp,	DCP,	ABSOLUTE_Y, M_ABSY, M_ABSY, 7, 0},

    /* dc */ {u_nop,	NOOP,	ABSOLUTE_X, M_NONE, M_NONE, 4, 1},
    /* dd */ {cmp,	CMP,	ABSOLUTE_X, M_ABSX, M_NONE, 4, 1},	/* Absolute,X */
    /* de */ {dec,	DEC,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},	/* Absolute,X */
    /* df */ {u_decp,	DCP,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},

    /* e0 */ {cpx,	CPX,	IMMEDIATE, M_IMM, M_NONE, 2, 0},	/* Immediate */
    /* e1 */ {sbc,	SBC,	INDIRECT_X, M_INDX, M_AC, 6, 0},	/* (Indirect,X) */
    /* e2 */ {u_nop,	NOOP,	IMMEDIATE, M_NONE, M_NONE,  2, 0},
    /* e3 */ {u_isbc,	ISB,	INDIRECT_X, M_INDX, M_INDX, 8, 0},

    /* e4 */ {cpx,	CPX,	ZERO_PAGE, M_ZERO, M_NONE, 3, 0},	/* Zeropage */
    /* e5 */ {sbc,	SBC,	ZERO_PAGE, M_ZERO, M_AC,   3, 0},	/* Zeropage */
    /* e6 */ {inc,	INC,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},	/* Zeropage */
    /* e7 */ {u_isbc,	ISB,	ZERO_PAGE, M_ZERO, M_ZERO, 5, 0},

    /* e8 */ {inc,	INX,	IMPLIED, M_XR, M_XR,     2, 0},
    /* e9 */ {sbc,	SBC,	IMMEDIATE, M_IMM, M_AC,  2, 0},		/* Immediate */
    /* ea */ {nop,	NOP,	IMPLIED, M_NONE, M_NONE, 2, 0},
    /* eb */ {u_sbc,	USBC,	IMMEDIATE, M_IMM, M_AC,  2, 0},		/* same as e9 */

    /* ec */ {cpx,	CPX,	ABSOLUTE, M_ABS, M_NONE, 4, 0},		/* Absolute */
    /* ed */ {sbc,	SBC,	ABSOLUTE, M_ABS, M_AC,  4, 0},		/* Absolute */
    /* ee */ {inc,	INC,	ABSOLUTE, M_ABS, M_ABS, 6, 0},		/* Absolute */
    /* ef */ {u_isbc,	ISB,	ABSOLUTE, M_ABS, M_ABS, 6, 0},

    /* f0 */ {beq,	BEQ,	RELATIVE, M_REL, M_NONE,  2, 0},
    /* f1 */ {sbc,	SBC,	INDIRECT_Y, M_INDY, M_AC, 5, 1},	/* (Indirect),Y */
    /* f2 */ {noop,	JAM,	IMPLIED, M_NONE, M_NONE,  0, 0},	/* TILT */
    /* f3 */ {u_isbc,	ISB,	INDIRECT_Y, M_INDY, M_INDY, 8, 0},

    /* f4 */ {u_nop,	NOOP,	ZERO_PAGE_X, M_NONE, M_NONE, 4, 0},
    /* f5 */ {sbc,	SBC,	ZERO_PAGE_X, M_ZERX, M_AC,   4, 0},	/* Zeropage,X */
    /* f6 */ {inc,	INC,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},	/* Zeropage,X */
    /* f7 */ {u_isbc,	ISB,	ZERO_PAGE_X, M_ZERX, M_ZERX, 6, 0},

    /* f8 */ {setf,	SED,	IMPLIED, M_NONE, M_FD,    2, 0},
    /* f9 */ {sbc,	SBC,	ABSOLUTE_Y, M_ABSY, M_AC, 4, 1},	/* Absolute,Y */
    /* fa */ {u_nop,	NOOP,	IMPLIED, M_NONE, M_NONE,  2, 0},
    /* fb */ {u_isbc,	ISB,	ABSOLUTE_Y, M_ABSY, M_ABSY, 7, 0},

    /* fc */ {u_nop,	NOOP,	ABSOLUTE_X, M_NONE, M_NONE, 4, 1},
    /* fd */ {sbc,	SBC,	ABSOLUTE_X, M_ABSX, M_AC,   4, 1},	/* Absolute,X */
    /* fe */ {inc,	INC,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0},	/* Absolute,X */
    /* ff */ {u_isbc,	ISB,	ABSOLUTE_X, M_ABSX, M_ABSX, 7, 0}
};
