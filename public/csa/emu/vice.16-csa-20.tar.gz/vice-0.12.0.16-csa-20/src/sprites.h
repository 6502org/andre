/*
 * $Id: sprites.h,v 1.1 1997/05/22 21:35:50 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 *
 * Sprite drawing macros.
 *
 * Written by
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: sprites.h,v $
 * Revision 1.1  1997/05/22 21:35:50  ettore
 * Initial revision
 *
 */


#define SPRITE_ONE_PIXEL(sprite_bit, imgptr, collmskptr, pos, color,	\
			 collmsk_return)				\
  (imgptr)[(pos)] = PIXEL((color));					\
  (collmsk_return) |= (collmskptr)[(pos)];				\
  (collmskptr)[(pos)] |= (sprite_bit);

#ifdef ALLOW_UNALIGNED_ACCESS

#  define SPRITE_TWO_PIXELS(sprite_bit, imgptr, collmskptr, pos, color, \
			    collmsk_return)				\
     *((PIXEL2 *)(imgptr) + (pos)) = PIXEL2((color));			\
     (collmsk_return) |= *((WORD *)(collmskptr) + (pos));		\
     *((WORD *)(collmskptr) + (pos)) |= (sprite_bit) | ((sprite_bit) << 8);

#  define SPRITE_ONE_PIXEL_2x(sprite_bit, imgptr, collmskptr, pos, color, \
			      collmsk_return)				  \
     *((PIXEL2 *)(imgptr) + (pos)) = PIXEL2((color));			  \
     (collmsk_return) |= (collmskptr)[(pos)];				  \
     (collmskptr)[(pos)] |= (sprite_bit);

#  define SPRITE_TWO_PIXELS_2x(sprite_bit, imgptr, collmskptr, pos, color, \
			       collmsk_return)				   \
     *((PIXEL4 *)(imgptr) + (pos)) = PIXEL4((color));	        	   \
     (collmsk_return) |= *((WORD *)(collmskptr) + (pos));		   \
     *((WORD *)(collmskptr) + (pos)) |= (sprite_bit) | ((sprite_bit) << 8);

#else

#  define SPRITE_TWO_PIXELS(sprite_bit, imgptr, collmskptr, pos, color, \
			    collmsk_return)                             \
     SPRITE_ONE_PIXEL(sprite_bit, imgptr, collmskptr, pos * 2, color,   \
		      collmsk_return);                                  \
     SPRITE_ONE_PIXEL(sprite_bit, imgptr, collmskptr, pos * 2 + 1,	\
		      color, collmsk_return);

#  define SPRITE_ONE_PIXEL_2x(sprite_bit, imgptr, collmskptr, pos, color,   \
			      collmsk_return)				    \
     (imgptr)[(pos) * 2] = (imgptr)[(pos) * 2 + 1] = PIXEL((color));  \
     (collmsk_return) |= (collmskptr)[pos];				    \
     (collmskptr)[pos] |= (sprite_bit);

#  define SPRITE_TWO_PIXELS_2x(sprite_bit, imgptr, collmskptr, pos, color, \
			       collmsk_return)				   \
     SPRITE_ONE_PIXEL_2x(sprite_bit, imgptr, collmskptr, pos * 2, color,   \
        	         collmsk_return);				   \
     SPRITE_ONE_PIXEL_2x(sprite_bit, imgptr, collmskptr, pos * 2 + 1,	   \
		         color, collmsk_return);
     
#endif


/* Hires sprites */
  
#define _SPRITE_MASK(msk, size, sprite_bit, imgptr, collmskptr, color,	       \
		     collmsk_return, DRAW)				       \
  do {								               \
      DWORD __m;							       \
      int __p;								       \
      for (__m = 1 << ((size) - 1), __p = 0; __p < (size); __p++, __m >>= 1)   \
	  if ((msk) & __m) {						       \
	      DRAW(sprite_bit, imgptr, collmskptr, __p, color,  	       \
		   collmsk_return);                                            \
	  }							               \
  } while (0)

     
#define SPRITE_MASK(msk, size, sprite_bit, imgptr, collmskptr, color, \
		    collmsk_return)				      \
  _SPRITE_MASK(msk, size, sprite_bit, imgptr, collmskptr, color,      \
               collmsk_return, SPRITE_ONE_PIXEL)
     
#define SPRITE_DOUBLE_MASK(msk, size, sprite_bit, imgptr, collmskptr, \
			   color, collmsk_return)		      \
  _SPRITE_MASK(msk, size, sprite_bit, imgptr, collmskptr, color,      \
	       collmsk_return, SPRITE_TWO_PIXELS)
     
#define SPRITE_MASK_2x(msk, size, sprite_bit, imgptr, collmskptr,     \
		       color, collmsk_return)			      \
  _SPRITE_MASK(msk, size, sprite_bit, imgptr, collmskptr, color,      \
	       collmsk_return, SPRITE_ONE_PIXEL_2x)
     
#define SPRITE_DOUBLE_MASK_2x(msk, size, sprite_bit, imgptr, collmskptr, \
			      color, collmsk_return)			 \
  _SPRITE_MASK(msk, size, sprite_bit, imgptr, collmskptr, color,	 \
		  collmsk_return, SPRITE_TWO_PIXELS_2x)
     
     
/* Multicolor sprites */


#define _MCSPRITE_MASK(msk, mcmsk, size, sprite_bit, imgptr, collmskptr, \
		       pixel_table, collmsk_return, DRAW)		 \
  do {							     	         \
      DWORD __m;							 \
      int __p;								 \
      for (__m = 1 << ((size) - 1), __p = 0; __p < (size);		 \
	   __p += 2, __m >>= 2, (mcmsk) <<= 2) {			 \
  	  if ((msk) & __m) {						 \
	      DRAW(sprite_bit, imgptr, collmskptr, __p,			 \
		   pixel_table[((mcmsk) >> 22) & 0x3], collmsk_return);  \
									 \
	  }								 \
	  if ((msk) & (__m >> 1)) {					 \
	      DRAW(sprite_bit, imgptr, collmskptr, __p + 1,		 \
		   pixel_table[((mcmsk) >> 22) & 0x3], collmsk_return);  \
          }								 \
      }									 \
  } while (0)

     
#define MCSPRITE_MASK(msk, mcmsk, size, sprite_bit, imgptr, collmskptr,	\
		      pixel_table, collmsk_return)			\
  _MCSPRITE_MASK(msk, mcmsk, size, sprite_bit, imgptr, collmskptr,	\
		 pixel_table, collmsk_return, SPRITE_ONE_PIXEL)
		     
#define MCSPRITE_MASK_2x(msk, mcmsk, size, sprite_bit, imgptr, collmskptr, \
			 pixel_table, collmsk_return)			   \
  _MCSPRITE_MASK(msk, mcmsk, size, sprite_bit, imgptr, collmskptr,         \
		 pixel_table, collmsk_return, SPRITE_ONE_PIXEL_2x)
     

#define _MCSPRITE_DOUBLE_MASK(msk, mcmsk, size, sprite_bit, imgptr,           \
			      collmskptr, pixel_table, collmsk_return, DRAW)  \
  do {									      \
      DWORD __m;							      \
      int __p, __i;							      \
      for (__m = 1 << ((size) - 1), __p = 0; __p < (size);		      \
	   __p += 4, (mcmsk) <<= 2) {					      \
	  for (__i = 0; __i < 4; __i++, __m >>= 1)			      \
   	      if ((msk) & __m) {					      \
	          DRAW(sprite_bit, imgptr, collmskptr, __p + __i,             \
		       pixel_table[((mcmsk) >> 22) & 0x3],  collmsk_return);  \
	      }								      \
      }								              \
  } while (0)

#define MCSPRITE_DOUBLE_MASK(msk, mcmsk, size, sprite_bit, imgptr,         \
			     collmskptr, pixel_table, collmsk_return)      \
  _MCSPRITE_DOUBLE_MASK (msk, mcmsk, size, sprite_bit, imgptr, collmskptr, \
			 pixel_table, collmsk_return, SPRITE_ONE_PIXEL)
  
#define MCSPRITE_DOUBLE_MASK_2x(msk, mcmsk, size, sprite_bit, imgptr,      \
				collmskptr, pixel_table, collmsk_return)   \
  _MCSPRITE_DOUBLE_MASK (msk, mcmsk, size, sprite_bit, imgptr, collmskptr, \
			 pixel_table, collmsk_return, SPRITE_ONE_PIXEL_2x)
