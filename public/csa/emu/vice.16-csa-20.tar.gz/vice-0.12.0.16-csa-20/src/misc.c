/*
 * $Id: misc.c,v 1.10 1997/05/22 20:12:16 ettore Exp $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file contains misc funtions to help debugging.
 * Included are:
 *	o Show numeric conversions
 *	o Show CPU registers
 *	o Show Stack contents
 *	o Print binary number
 *	o Print instruction hexas from memory
 *	o Print instruction from memory
 *	o Decode instruction
 *	o Find effective address for operand
 *	o Create a copy of string
 *	o Move memory
 *
 * sprint_opcode returns mnemonic code of machine instruction.
 * sprint_binary returns binary form of given code (8bit)
 *
 *
 * Written by
 *   Vesa-Matti Puro (vmp@lut.fi)
 *   Jarkko Sonninen (sonninen@lut.fi)
 *   Jouko Valta     (jopi@stekt.oulu.fi)
 *
 *
 * $Log: misc.c,v $
 * Revision 1.10  1997/05/22 20:12:16  ettore
 * #include "maincpu.h" added to support the new CPU emulation.
 *
 * Revision 1.9  1995/11/07  16:51:00  jopi
 * *** empty log message ***
 *
 * Revision 1.8  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * print_stack aligned. sprint_ophex from xdebugger.
 *
 * Revision 1.7  1994/12/12  16:59:44  jopi
 * Effective Address calculation routines
 *
 * Revision 1.6  1994/06/16  17:19:26  jopi
 * Code reorganized and cleaned up
 *
 * Revision 1.5  1994/06/07  22:38:56  jopi
 * Patchlevel 2
 *
 * Revision 1.4  1993/11/10  01:55:34  jopi
 * reu, asm and disk directory fixed
 * REL_ADDR macro and 1541 made more portable
 *
 * Revision 1.3  93/06/21  13:38:42  jopi
 *  X64 version 0.2 PL 0
 *
 * Revision 1.2  1993/06/13  08:21:50  sonninen
 * *** empty log message ***
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "cpu.h"
#include "maincpu.h"
#include "misc.h"
#include "macro.h"
#include "extern.h"


#define HEX 1


/*
 * Base conversions.
 * (+) -%&#$
 */

void    show_bases(char *line, int mode)
{
    char buf[20];
    int temparg = sconv(line, 0, mode);

    strcpy(buf, sprint_binary(UPPER(temparg)) );
    printf("\n %17x x\n %17d d\n %17o o\n %s %s b\n\n",
	   temparg, temparg, temparg, buf,
	   sprint_binary(LOWER(temparg)));
}


/*
 * show prints PSW and contents of registers.
 */

void    show(void)
{
    if (verflg)
	printf(hexflg ?
	    "PC=%4X AC=%2X XR=%2X YR=%2X PF=%s SP=%2X %3X %3d %s\n" :
	    "PC=%04d AC=%03d XR=%03d YR=%03d PF=%s SP=%03d %3d %2X %s\n",
	    (int) PC, (int) AC, (int) XR, (int) YR,
	    sprint_status(), (int) SP,
	    LOAD(PC), LOAD(PC), sprint_opcode(PC, hexflg));
    else
	printf(hexflg ? "%lx %4X %s\n" : "%ld %4d %s\n",
	    clk, PC, sprint_opcode(PC, hexflg));
}


void    print_stack(BYTE sp)
{
    int     i;

    printf("Stack: ");
    for (i = 0x101 + sp; i < 0x200; i += 2)
	printf("%02X%02X  ", ram[i + 1], ram[i]);
    printf("\n");
}


char   *sprint_binary(BYTE code)
{
    static char bin[9];
    int     i;

    bin[8] = 0;		/* Terminator. */

    for (i = 0; i < 8; i++) {
	bin[i] = (code & 128) ? '1' : '0';
	code <<= 1;
    }

    return bin;
}


/* ------------------------------------------------------------------------- */

char   *sprint_ophex (ADDRESS p)
{
    static char hexbuf [20];
    char *bp;
    int   j, len;

    len = clength[lookup[LOAD(p)].addr_mode];
    *hexbuf = '\0';
    for (j = 0, bp = hexbuf; j < 3 ; j++, bp += 3) {
	if (j < len) {
	    sprintf (bp, "%02X ", LOAD(p+j));
	} else {
	    strcat (bp, "   ");
	}
    }
    return hexbuf;
}


/* sprint_opcode parameters:
 *
 *	string		the name of the machine instruction
 *	addr_mode	# describing used addressing mode, see "vmachine.h"
 *	base		if 1==base => HEX, 0==base => DEC, see code
 *	opcode		address of memory where machine instruction
 *                      and argument are. First byte is unused, because
 *                      it is the machine code and it is already known -
 *                      string!
 */


char   *sprint_opcode(ADDRESS counter, int base)
{
    BYTE    x = LOAD(counter);
    BYTE    p1 = LOAD(counter + 1);
    BYTE    p2 = LOAD(counter + 2);

    return sprint_disassembled(counter, x, p1, p2, base);
}


char   *sprint_disassembled(ADDRESS counter, BYTE x, BYTE p1, BYTE p2, int base)
{
    char   *string;
    int     addr_mode;
    char   *buffp;
    static char buff[20];
    int     ival;

    ival = p1 & 0xFF;

    buffp = buff;
    string = lookup[x].mnemonic;
    addr_mode = lookup[x].addr_mode;

    sprintf(buff, "%s", string);	/* Print opcode. */
    while (*++buffp);

    switch (addr_mode) {
	/*
	 * Bits 0 and 1 are usual marks for X and Y indexed addresses, i.e.
	 * if  bit #0 is set addressing mode is X indexed something and if
	 * bit #1 is set addressing mode is Y indexed something. This is not
	 * from MOS6502, but convention used in this program. See
	 * "vmachine.h" for details.
	 */

	/* Print arguments of the machine instruction. */

      case IMPLIED:
	break;

      case ACCUMULATOR:
	sprintf(buffp, " A");
	break;

      case IMMEDIATE:
	sprintf(buffp, ((base & HEX) ? " #$%02X" : " %3d"), ival);
	break;

      case ZERO_PAGE:
	sprintf(buffp, ((base & HEX) ? " $%02X" : " %3d"), ival);
	break;

      case ZERO_PAGE_X:
	sprintf(buffp, ((base & HEX) ? " $%02X,X" : " %3d,X"), ival);
	break;

      case ZERO_PAGE_Y:
	sprintf(buffp, ((base & HEX) ? " $%02X,Y" : " %3d,Y"), ival);
	break;

      case ABSOLUTE:
	ival |= ((p2 & 0xFF) << 8);
	sprintf(buffp, ((base & HEX) ? " $%04X" : " %5d"), ival);
	break;

      case ABSOLUTE_X:
	ival |= ((p2 & 0xFF) << 8);
	sprintf(buffp, ((base & HEX) ? " $%04X,X" : " %5d,X"), ival);
	break;

      case ABSOLUTE_Y:
	ival |= ((p2 & 0xFF) << 8);
	sprintf(buffp, ((base & HEX) ? " $%04X,Y" : " %5d,Y"), ival);
	break;

      case INDIRECT_X:
	sprintf(buffp, ((base & HEX) ? " ($%02X,X)" : " (%3d,X)"), ival);
	break;

      case INDIRECT_Y:
	sprintf(buffp, ((base & HEX) ? " ($%02X),Y" : " (%3d),Y"), ival);
	break;

      case ABS_INDIRECT:
	ival |= ((p2 & 0xFF) << 8);
	sprintf(buffp, ((base & HEX) ? " ($%04X)" : " (%5d)"), ival);
	break;

      case RELATIVE:
	if (0x80 & ival)
	    ival -= 256;
	ival += counter;
	ival += 2;
	sprintf(buffp, ((base & HEX) ? " $%04X" : " %5d"), ival);
	break;
    }

    return buff;
}


int     eff_address(ADDRESS counter, int step)
{
    int     addr_mode, eff;
    BYTE    x = LOAD(counter);
    BYTE    p1 = 0;
    ADDRESS p2 = 0;


    addr_mode = lookup[x].addr_mode;

    switch (clength[addr_mode]) {
      case 2:
	p1 = LOAD(counter + 1);
	break;
      case 3:
	p2 = LOAD(counter + 1) | (LOAD(counter + 2) << 8);
	break;
    }

    switch (addr_mode) {

      case IMPLIED:
      case ACCUMULATOR:
	eff = -1;
	break;

      case IMMEDIATE:
	eff = -1;
	break;

      case ZERO_PAGE:
	eff = p1;
	break;

      case ZERO_PAGE_X:
	eff = (p1 + XR) & 0xff;
	break;

      case ZERO_PAGE_Y:
	eff = (p1 + YR) & 0xff;
	break;

      case ABSOLUTE:
	eff = p2;
	break;

      case ABSOLUTE_X:
	eff = p2 + XR;
	break;

      case ABSOLUTE_Y:
	eff = p2 + YR;
	break;

      case ABS_INDIRECT:  /* loads 2-byte address */
	eff = p2;
	break;

      case INDIRECT_X:
	eff = LOAD_ZERO_ADDR(p1 + XR);
	break;

      case INDIRECT_Y:
	eff = LOAD_ZERO_ADDR(p1) + YR;
	break;

      case RELATIVE:
	eff = REL_ADDR(counter +2, p1);
	break;

      default:
	eff = -1;
    }

    return eff;
}


/* ------------------------------------------------------------------------- */

char   *xstrdup(char *str)
{
    char   *t = (char *) malloc(strlen(str) + 1);
    strcpy(t, str);
    return (t);
}


char   *strndup(char *str, int n)
{
    char   *t = (char *) malloc(n + 1);
    strncpy(t, str, n);
    t[n] = '\0';
    return (t);
}


void    memmov(char *target, char *source, unsigned int length)
{
    if (target > source) {
	target += length;
	source += length;
	while (length--)
	    *--target = *--source;
    } else if (target < source) {
	while (length--)
	    *target++ = *source++;
    }
}
