/*
 * $Id: viad1.h,v 1.1 1997/05/22 21:43:00 fachat Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Andre' Fachat (fachat@physik.tu-chemnitz.de)
 *   Daniel Sladic (sladic@eecg.toronto.edu)
 *   Ettore Perazzoli (ettore@comm2000.it)
 *
 * $Log: viad1.h,v $
 * Revision 1.1  1997/05/22 21:43:00  fachat
 * Initial revision
 *
 */

/* 1541 VIA 1 header.  viad1.c is built by convvia from this file and
   via-tmpl.c. */

#define	INCLUDES #include "true1541.h"

#define	GLOBALS

#define	via_set_int		true1541_set_irq
#define	VIAD1_INT		IK_IRQ


/* #define VIAD1_TIMER_DEBUG */

PRE_VIA_FUNCS()
{

void set_atn(BYTE state)
{
#ifdef OLDIRQ
   if (state) {
      viaD1ifr |= 2;
   } else {
      viaD1ifr &= 0xfe;
   }
#else
   viaD1_signal(VIA_SIG_CA1, state ? VIA_SIG_RISE : 0);
#endif
}
}

#define STORE_PRA 	viaD1[addr] = byte;

STORE_PRB()
{
    if (byte != viaD1[addr]) {
        viaD1[addr] = byte;
 	serial_bus_drive_write(~viaD1[VIA_DDRB] | viaD1[VIA_PRB]);
    }
}

#define	STORE_PCR
#define	STORE_ACR
#define	STORE_SR
#define	STORE_T2L

#define	RESET_VIA

READ_PRA() 
{
        return ((viaD1[VIA_PRA] & viaD1[VIA_DDRA]) | (0xff & ~viaD1[VIA_DDRA]));

}

READ_PRB() 
{
        return ((viaD1[VIA_PRB] & viaD1[VIA_DDRB]) | ((serial_bus_drive_read()) & ~viaD1[VIA_DDRB]));
}

#define POST_VIA_FUNCS

