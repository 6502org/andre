/*
 * $Id: types.h,v 1.9 1997/05/22 21:39:42 ettore Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice
 *
 * This file declares types used all over.
 *
 *
 * Written by
 *   Jarkko Sonninen  (sonninen@lut.fi)
 *   Jouko Valta      (jopi@stekt.oulu.fi)
 *   Ettore Perazzoli (ettore@comm2000.it)
 *   Andre Fachat     (a.fachat@physik.tu-chemnitz.de)
 *   Teemu Rantanen   (tvr@cs.hut.fi)
 *
 * $Log: types.h,v $
 * Revision 1.9  1997/05/22 21:39:42  ettore
 * Code cleaned up.
 * `app_resources' removed.
 * `BYTE', `WORD', `DWORD', `PIXEL', `PIXEL2' and `PIXEL4' added.
 *
 * Revision 1.8  1996/07/30 08:19:53  ettore
 * hjoyPort.
 *
 * Revision 1.7  1996/07/29 23:06:33  ettore
 * PIXEL turned into unsigned char.
 * start_addr turned into startAddr.
 * directory, gamepath, tapeName and floppy9Name added.
 *
 * Revision 1.6  1996/04/01  09:01:41  jopi
 * New variables
 *
 * Revision 1.5  1995/11/07  16:51:00  jopi
 * *** empty log message ***
 *
 * Revision 1.4  1995/04/01  07:54:09  jopi
 * X64 0.3 PL 0
 * Typedef for signed char.
 * Room for new options for Printer charsets, Basic patch, REU size.
 *
 * Revision 1.3  1994/12/12  16:59:44  jopi
 * 16-bit portability
 *
 * Revision 1.2  1994/08/10  18:34:13  jopi
 * More changeability
 *
 * Revision 1.1  1994/06/16  17:19:26  jopi
 * Initial revision
 *
 */


#ifndef X64_TYPES_H
#define X64_TYPES_H

#include <limits.h>

#include "autoconf.h"


typedef signed char	SIGNED_CHAR;

typedef unsigned short 	ADDRESS;

typedef unsigned char 	BYTE;

#if SIZEOF_UNSIGNED_SHORT == 2
typedef unsigned short 	WORD;
#elif SIZEOF_UNSIGNED_INT == 2
typedef unsigned int  WORD;
#else
#error Cannot find a proper 16-bit type!
#endif

#if SIZEOF_UNSIGNED_INT == 4
typedef unsigned int    DWORD;
#elif SIZEOF_UNSIGNED_LONG == 4
typedef unsigned long   DWORD;
#else
#error Cannot find a proper 32-bit type!
#endif

typedef DWORD CLOCK;

#if X_DISPLAY_DEPTH == 16
typedef WORD		  		PIXEL;
#elif X_DISPLAY_DEPTH == 24
typedef DWORD				PIXEL;
#elif X_DISPLAY_DEPTH == 8 || X_DISPLAY_DEPTH == 0
typedef BYTE		PIXEL;
#else
#error Unsupported display depth!
#endif

#if X_DISPLAY_DEPTH == 8 || X_DISPLAY_DEPTH == 0
typedef WORD		PIXEL2;
typedef DWORD		PIXEL4;
#else
typedef struct { PIXEL a, b; }		PIXEL2;
typedef struct { PIXEL a, b, c, d; }	PIXEL4;
#endif

typedef int		ADDR_T;

typedef struct trap_s
{
    char        *name;
    ADDRESS      address;
    BYTE         check[3];
#ifdef __STDC__
    void       (*func)(void);
#else
    void       (*func)();
#endif
} trap_t;
 

#endif  /* X64_TYPES_H */
