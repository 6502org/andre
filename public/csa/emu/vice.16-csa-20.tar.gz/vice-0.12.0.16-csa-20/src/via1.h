/*
 * $Id: via1.h,v 1.1 1997/05/22 21:42:29 fachat Exp ettore $
 *
 * This file is part of VICE, the Versatile Commodore Emulator.
 * See README for copyright notice.
 *
 * Written by
 *   Andre' Fachat (fachat@physik.tu-chemnitz.de)
 *
 * $Log: via1.h,v $
 * Revision 1.1  1997/05/22 21:42:29  fachat
 * Initial revision
 *
 */

/* Header for building via1.c (VIC20 VIA 2 emulation) */


INCLUDES()
{
#include "true1541.h"
}

#define	via_set_int		maincpu_set_irq
#define	VIA1_INT		IK_IRQ

#define	GLOBALS BYTE keyarr[KBD_ROWS];

/* #define VIA1_TIMER_DEBUG */

#define	PRE_VIA_FUNCS

#define STORE_PRA 	via1[addr] = byte;
#define STORE_PRB 	via1[addr] = byte;

#define STORE_ACR 	
#define STORE_SR 	
#define STORE_T2L 	

RESET_VIA()
{
	serial_bus_pcr_write(0x22);
}


STORE_PCR()
{
	if(byte != via1[VIA_PCR]) {
	  register BYTE tmp = byte;
	  /* first set bit 1 and 5 to the real output values */
	  if((tmp & 0x0c) != 0x0c) tmp |= 0x02;
	  if((tmp & 0xc0) != 0xc0) tmp |= 0x20;
	  serial_bus_pcr_write(tmp);
	}
}

READ_PRA() 
{
       {
           int     t, i;
           BYTE    j, v = 1;
           t = ~(via1[VIA_PRB] & via1[VIA_DDRB]);
           for (j = i = 0; i < KBD_ROWS; v <<= 1, i++)
               if (t & keyarr[i])
                   j |= v;
           j = ~j;

           if (debugflg) {
               printf("read port A %d\n", j);
               printf("a: %x b:%x  ca: %x cb: %x joy: %x\n",
                      (int) j, (int) via1[VIA_PRB],
                      (int) via1[VIA_DDRA], (int) via1[VIA_DDRB], joy[2]);
           }
           return (((j & ~via1[VIA_DDRA]) | (via1[VIA_PRA] & via1[VIA_DDRA])) & ~joy[2]);
       }
}

READ_PRB() 
{
       {
           int     t, i;
           BYTE    j;
           t = via1[VIA_PRA] & via1[VIA_DDRA];  /* intr() updates keyboard */

           for (j = i = 0; i < KBD_ROWS; t >>= 1, i++)
               if (!(t & 1))
                   j |= keyarr[i];
           j = ~j;

           if (debugflg) {
               printf("read port B %d\n", j);
               printf("a: %x b:%x  ca: %x cb: %x joy: %x\n",
                      (int) via1[VIA_PRA], (int) j,
                      (int) via1[VIA_DDRA], (int) via1[VIA_DDRB], joy[1]);
           }
           return (((j & ~via1[VIA_DDRB]) | (via1[VIA_PRB] & via1[VIA_DDRB])) & ~joy[1]);
       }
}

POST_VIA_FUNCS() 
{

int show_keyarr(void)
{
    int     i, j;
    for (j = 0; j < KBD_ROWS; j++) {
        printf("%d:", j);
        for (i = 0x80; i; i >>= 1)
            printf(" %d", keyarr[j] & i);
        printf("\n");
    }
    return (0);
}

}
